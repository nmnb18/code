const rewire = require('rewire');
const defaults = rewire('react-scripts/scripts/build.js');
const version = require('../package.json').version;

let config = defaults.__get__('config');
const isEnvProduction = config.mode === 'production';

if (isEnvProduction) {
  config.output.filename = `static/js/${version}-[name].[contenthash:8].js`;
  config.output.chunkFilename = `static/js/${version}-[name].[contenthash:8].chunk.js`;

  config.optimization.runtimeChunk.name = entrypoint => `runtime-${version}-${entrypoint.name}`;

  // prevent mangling of source code for easier debugging 
  const terserObj = config.optimization.minimizer.find(obj=> obj.options && obj.options.terserOptions);
  if (terserObj) {
    const terserOptions = terserObj.options.terserOptions;
    terserOptions.mangle = false;
  } else {
    console.error('CUSTOM-BUILD ERROR: terserObj not found. Mangling was not disabled.');
  }

  // "url" loader works like "file" loader except that it embeds assets
  // smaller than specified limit in bytes as data URLs to avoid requests.
  // A missing `test` is equivalent to a match.
  config.module.rules[2].oneOf[0].options.name = `static/media/${version}-[name].[hash:8].[ext]`;

  // "file" loader makes sure those assets get served by WebpackDevServer.
  // When you `import` an asset, you get its (virtual) filename.
  // In production, they would get copied to the `build` folder.
  // This loader doesn't use a "test" so it will catch all modules
  // that fall through the other loaders.
  config.module.rules[2].oneOf[7].options.name = `static/media/${version}-[name].[hash:8].[ext]`;

  // MiniCssExtractPlugin
  config.plugins[5].options.filename = `static/css/${version}-[name].[contenthash:8].css`;
  config.plugins[5].options.chunkFilename = `static/css/${version}-[name].[contenthash:8].chunk.css`;

  // ManifestPlugin
  config.plugins[6].opts.fileName = `${version}-asset-manifest.json`;
}
