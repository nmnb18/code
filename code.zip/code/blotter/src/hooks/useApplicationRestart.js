import { useEffect } from 'react';
import { RESTART } from '~services/mmiService';
import { getQueryParam } from '~helpers/uri';
import { scheduleRestart, scheduleSendLogs } from '~services/launcherService';
import { applicationRestartHourUTC, applicationRestartTimezone } from '~services/openfinConfig';

function getRestartValue(str) {
  if (!str) return false;

  const lowerCaseStr = str.toLowerCase();
  const state = {
    true: true,
    false: false
  };

  return state[lowerCaseStr] ?? str;
}

function scheduleRestartAndSendLogs({ restartTime, restartTimezone, sendlogTime }) {
  scheduleRestart(restartTime, restartTimezone);
  scheduleSendLogs(sendlogTime, restartTimezone);
}

const useApplicationRestart = () => {
  useEffect(() => {
    const restartParam = getQueryParam(RESTART) ?? true;

    if (typeof restartParam === 'boolean' && restartParam) {
      // FN restarting flow
      scheduleRestartAndSendLogs({
        restartTime: applicationRestartHourUTC,
        restartTimezone: applicationRestartTimezone,
        sendlogTime: applicationRestartHourUTC
      });
    } else {
      // MMI restarting flow
      const restartValue = getRestartValue(restartParam);
      if (typeof restartValue === 'string') {
        // custom restart time, as instance 22:45
        scheduleRestartAndSendLogs({
          restartTime: restartValue,
          restartTimezone: applicationRestartTimezone,
          sendlogTime: restartValue
        });
      } else {
        if (!restartValue) {
          // TODO: Add a env variable for tracking MMI restart time instead of applicationRestartHourUTC
          scheduleSendLogs(applicationRestartHourUTC, applicationRestartTimezone);
        } else {
          scheduleRestartAndSendLogs({
            restartTime: applicationRestartHourUTC,
            restartTimezone: applicationRestartTimezone,
            sendlogTime: applicationRestartHourUTC
          });
        }
      }
    }
  }, []);
};

export default useApplicationRestart;
