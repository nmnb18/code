import { useEffect } from 'react';

const useDynamicSubscription = (subscriptionFn, subscribeCb) => {
  useEffect(() => {
    const subscription = subscriptionFn(subscribeCb);

    return () => {
      subscription.unsubscribe();
    };
  }, [subscriptionFn, subscribeCb]);
};

export default useDynamicSubscription;
