import { useEffect } from 'react';
import { CLOSE_CONTROL, MINIMIZE_CONTROL, MAXIMIZE_CONTROL, RFQ_POPUP_CONTROL } from '~services/mmiService';

const useMMIConfiguration = setWindowOptions => {
  useEffect(() => {
    const mmiParams = new URLSearchParams(window.location.search);

    const mmiOptions = {
      [CLOSE_CONTROL]: mmiParams.get(CLOSE_CONTROL),
      [MINIMIZE_CONTROL]: mmiParams.get(MINIMIZE_CONTROL),
      [MAXIMIZE_CONTROL]: mmiParams.get(MAXIMIZE_CONTROL),
      [RFQ_POPUP_CONTROL]: mmiParams.get(RFQ_POPUP_CONTROL)
    };

    const hasMMIOptions = !!Object.keys(mmiOptions).filter(key => mmiOptions[key]).length;

    if (hasMMIOptions) setWindowOptions(mmiOptions);
  }, [setWindowOptions]);
};

export default useMMIConfiguration;
