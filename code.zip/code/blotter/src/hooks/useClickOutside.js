import { useState, useEffect } from 'react';

const useClickOutside = ref => {
  const [isOpen, setIsOpen] = useState(null);

  useEffect(() => {
    const handleClickOutside = event => {
      if (
        isOpen &&
        ((event.type === 'mousedown' && ref.current && !ref.current.contains(event.target)) || event.type === 'blur')
      ) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      window.addEventListener('blur', handleClickOutside);
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      window.removeEventListener('blur', handleClickOutside);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [ref, isOpen, setIsOpen]);

  return [isOpen, setIsOpen];
};

export default useClickOutside;
