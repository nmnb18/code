import { useEffect } from 'react';

const useSubscription = (subscriptionFn, subscribeCb) => {
  useEffect(() => {
    const subscription = subscriptionFn(subscribeCb);
    return () => {
      subscription.unsubscribe();
    };
  }, [subscriptionFn, subscribeCb]);
};

export default useSubscription;
