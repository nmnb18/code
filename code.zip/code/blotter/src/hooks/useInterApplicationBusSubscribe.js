import { useEffect, useState } from 'react';
import { iabSubscribe, iabUnsubscribe } from '~services/openfinService';

const fin = window.fin;

const FlowNavigatorIAB = 'Flow Navigator IAB';

const useInterApplicationBusSubscribe = (source, topic, onReceiveMessage, onFail = () => {}) => {
  const [isSubscribed, setIsSubscribed] = useState(false);

  useEffect(() => {
    if (isSubscribed || !fin || !fin.InterApplicationBus) {
      return () => null;
    }

    iabSubscribe({
      source,
      topic,
      handler: onReceiveMessage,
      logLabel: `${FlowNavigatorIAB} for Topic ${topic}`,
      onSuccess: () => setIsSubscribed(true),
      onFail
    });

    return () => {
      setIsSubscribed(false);
      iabUnsubscribe({
        source,
        topic,
        handler: onReceiveMessage,
        logLabel: `${FlowNavigatorIAB} for Topic ${topic}`,
        onFail
      });
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return isSubscribed;
};

export default useInterApplicationBusSubscribe;
