import { useEffect } from 'react';
import * as openfinService from '~services/openfinService';

const useApplicationRegisterUser = user => {
  useEffect(() => {
    user && openfinService.applicationRegisterUser(user);
  }, [user]);
};

export default useApplicationRegisterUser;
