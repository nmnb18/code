import { useEffect } from 'react';

const useSetTheme = theme => {
  useEffect(() => {
    const body = document.querySelector('body');
    const themeClass = `theme--${theme}`;
    theme && document.body.classList.add(themeClass);
    return () => {
      theme && body.classList.remove(themeClass);
    };
  }, [theme]);
};

export default useSetTheme;
