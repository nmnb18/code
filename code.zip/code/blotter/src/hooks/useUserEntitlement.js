import { useMemo, useContext } from 'react';
import { UserEntitlementContext } from '~contexts/UserEntitlementContext';
import { UserContext } from '~contexts/UserContext';

const useUserEntitlement = () => {
  const { userEntitlement, impersonatedUserEntitlement } = useContext(UserEntitlementContext);
  const { impersonatedUser } = useContext(UserContext);
  const entitlement = useMemo(() => (impersonatedUser ? impersonatedUserEntitlement : userEntitlement), [
    impersonatedUserEntitlement,
    userEntitlement,
    impersonatedUser
  ]);
  return entitlement;
};

export default useUserEntitlement;
