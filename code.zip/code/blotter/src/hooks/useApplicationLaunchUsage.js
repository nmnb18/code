import { useEffect, useState, useContext } from 'react';
import * as usageService from '~services/usageService';
import { UserContext } from '~contexts/UserContext';
import { BlotterContext } from '~contexts/BlotterContext';

const useApplicationLaunchUsage = () => {
  const [shouldRecordApplicationLaunch, setShouldRecordApplicationLaunch] = useState(true);
  const { blotter } = useContext(BlotterContext);
  const { currentUser } = useContext(UserContext);

  useEffect(() => {
    if (currentUser && blotter && shouldRecordApplicationLaunch) {
      usageService.sendUsage({ userAction: usageService.actions.LAUNCH });
      setShouldRecordApplicationLaunch(false);
    }
  }, [currentUser, blotter, shouldRecordApplicationLaunch, setShouldRecordApplicationLaunch]);
};

export default useApplicationLaunchUsage;
