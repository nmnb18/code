import { useState, useEffect } from 'react';
import { postMessageActions } from '~helpers/globals';
import { newToken } from '~helpers/token';

const useChildContent = () => {
  const [reloadChildContentToken, setReloadChildContentToken] = useState(undefined);

  const childMessageHandler = event => {
    if (~event.origin.indexOf(window.location.hostname) && event.data.type === postMessageActions.childContentReady) {
      setReloadChildContentToken(newToken());
    }
  };

  useEffect(() => {
    window.addEventListener('message', childMessageHandler);

    return () => {
      window.removeEventListener('message', childMessageHandler);
    };
  }, []);

  return {
    reloadChildContentToken
  };
};

export default useChildContent;
