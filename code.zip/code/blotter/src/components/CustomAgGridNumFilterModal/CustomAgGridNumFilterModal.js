import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { getColumnFilterValue } from '~helpers/filters';
import { FILTER_TYPES, FILTER_TYPES_ARRAY } from '~constants/filters';
import { KEYS } from '~helpers/keyCodes';
import { formatNumber, isNotEmpty } from '~helpers/number';
import styles from './CustomAgGridNumFilterModal.module.scss';

const CustomAgGridNumFilterModal = ({
  onFilterChange,
  sortingMenu,
  column,
  api,
  toggleFilter,
  showToggle,
  toggle,
  toggleOptions
}) => {
  const [numText, setNumText] = useState('');
  const [maskNumText, setMaskNumText] = useState('');
  const [numType, setNumType] = useState(FILTER_TYPES.EQUALS);
  const [model, setModel] = useState();

  const getAgModel = () => {
    const filterInstance = api.getFilterInstance(column.colId);
    return filterInstance?.getModel();
  };

  useEffect(() => {
    const agModel = getAgModel();
    setModel(agModel);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const onFilterChanged = () => {
      const filters = api.getFilterModel();
      const newValue = getColumnFilterValue(column, filters);

      const agModel = getAgModel();
      setModel(agModel);

      if (showToggle && toggle) {
        setNumText(newValue);
        const newMaskValue = isNotEmpty(newValue) ? newValue / toggleOptions.denominator : newValue;
        setMaskNumText(newMaskValue);
      } else {
        setNumText(newValue);
      }
    };

    column.addEventListener('filterChanged', onFilterChanged);

    return () => {
      column.removeEventListener('filterChanged', onFilterChanged);
    };
  }, [column, api, toggle, showToggle, toggleOptions]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const newValue = formatNumber(numText);

    const agModel = getAgModel();
    setModel(agModel);

    if (!agModel) return;

    if (showToggle && isNotEmpty(newValue)) {
      let maskValue;
      let value;
      const currentValueIsActiveFilter = agModel.filter === newValue;

      if (toggle) {
        maskValue = currentValueIsActiveFilter ? newValue / toggleOptions.denominator : newValue;
        value = currentValueIsActiveFilter ? newValue : newValue * toggleOptions.denominator;
      } else {
        maskValue = currentValueIsActiveFilter ? newValue : newValue / toggleOptions.denominator;
        value = currentValueIsActiveFilter ? newValue : newValue / toggleOptions.denominator;
      }

      setNumText(value);
      setMaskNumText(maskValue);
    }
  }, [showToggle, toggle]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleClear = () => {
    setNumType(FILTER_TYPES.EQUALS);
    setNumText('');
    if (showToggle) setMaskNumText('');
    onFilterChange(null, null, null);
  };

  const handleApply = () => {
    let newFilter = numText;

    if (!model && showToggle && toggle) {
      newFilter = numText * toggleOptions.denominator;
    }

    onFilterChange(formatNumber(newFilter), null, numType);
  };

  const handleKeyDown = event => {
    if (event.keyCode === KEYS.ENTER) {
      event.preventDefault();
      handleApply();
    }
  };

  const value = useMemo(() => {
    if (!model) return numText;

    return showToggle && toggle ? maskNumText : numText;
  }, [showToggle, toggle, maskNumText, numText, model]); // eslint-disable-line react-hooks/exhaustive-deps

  const onChange = useCallback(
    e => {
      const newValue = e.target.value;

      if (!model) {
        setNumText(newValue);
      } else {
        if (showToggle && toggle) {
          setNumText(newValue * toggleOptions.denominator);
          setMaskNumText(newValue);
        } else {
          setNumText(newValue);
        }
      }
    },
    [showToggle, toggle, setNumText, setMaskNumText, toggleOptions, model]
  );

  return (
    <div className={styles['number-filter-modal']}>
      {sortingMenu}
      {toggleFilter}
      <div className={styles['number-filter-modal__wrapper-textbox']}>
        <select className={styles['dropdown']} onChange={e => setNumType(e.target.value)} value={numType}>
          {FILTER_TYPES_ARRAY &&
            FILTER_TYPES_ARRAY.map((filterType, index) => {
              return (
                <option
                  key={`key_filterType_${filterType.value}_${index}`}
                  className={styles['option']}
                  value={filterType.value}
                >
                  {filterType.stringValue}
                </option>
              );
            })}
        </select>
      </div>
      <div className={styles['number-filter-modal__wrapper-textbox']}>
        <input
          className={styles['number-filter-modal__textbox']}
          type="text"
          placeholder="Search..."
          value={value}
          onChange={onChange}
          onKeyDown={handleKeyDown}
        />
      </div>
      <footer className={styles['number-filter-modal__footer']}>
        <button onClick={handleClear}>Clear Filter</button>
        <button onClick={handleApply}>Apply Filter</button>
      </footer>
      <div className={styles['number-filter-modal__footer__fix']}></div>
    </div>
  );
};

export default CustomAgGridNumFilterModal;
