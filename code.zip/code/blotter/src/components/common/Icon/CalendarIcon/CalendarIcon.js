import React from 'react';
import styles from './CalendarIcon.module.scss';
import { ReactComponent as Calendar } from '~assets/icon/util/calendar.svg';

const CalendarIcon = () => <Calendar className={styles['calendar-icon']} />;

export default CalendarIcon;
