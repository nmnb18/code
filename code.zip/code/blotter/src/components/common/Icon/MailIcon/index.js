import React from 'react';
import './styles.scss';
import { ReactComponent as Mail } from '~assets/icon/mail.svg';

const MailIcon = () => <Mail className="mail-icon" />;

export default MailIcon;
