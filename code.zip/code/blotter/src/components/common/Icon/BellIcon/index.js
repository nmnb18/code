import React from 'react';
import './styles.scss';
import { ReactComponent as Bell } from '~assets/icon/bell.svg';

const BellIcon = () => <Bell className="bell-icon" />;

export default BellIcon;
