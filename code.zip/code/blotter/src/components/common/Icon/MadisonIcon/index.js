import React from 'react';
import styles from './MadisonIcon.module.scss';
import { ReactComponent as MadisonAssist } from '~assets/img/madisonassist.svg';

const MadisonAssistIcon = () => <MadisonAssist title="M Assist" className={styles.madison} />;

export default MadisonAssistIcon;
