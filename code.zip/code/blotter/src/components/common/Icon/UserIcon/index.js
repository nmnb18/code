import React from 'react';
import styles from './styles.module.scss';
import { ReactComponent as User } from '~assets/icon/user.svg';

const UserIcon = () => <User data-testid="UserIcon" className={styles.icon} />;

export default UserIcon;
