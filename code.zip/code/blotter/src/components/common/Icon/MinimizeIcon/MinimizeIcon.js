import React from 'react';
import styles from './MinimizeIcon.module.scss';
import { ReactComponent as MinimizeIc } from '~assets/icon/minimize.svg';

const MinimizeIcon = ({ active = false }) => (
  <MinimizeIc className={active ? styles.close['--active'] : styles.minimize} />
);

export default MinimizeIcon;
