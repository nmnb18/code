import React from 'react';
import './style.scss';
import { ReactComponent as SortAsc } from '~assets/icon/util/sort-asc.svg';

const SortAscIcon = () => <SortAsc className={'icon-sort-asc'} />;

export default SortAscIcon;
