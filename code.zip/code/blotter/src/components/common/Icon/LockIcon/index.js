import React from 'react';
import './style.scss';
import { ReactComponent as LockIc } from '~assets/icon/util/lock.svg';

const LockIcon = ({ active }) => <LockIc className={active ? 'icon-lock active' : 'icon-lock-dismiss'} />;

export default LockIcon;
