import React from 'react';
import './styles.scss';
import { ReactComponent as Add } from '~assets/icon/add.svg';

const AddIcon = () => <Add className="add-icon" />;

export default AddIcon;
