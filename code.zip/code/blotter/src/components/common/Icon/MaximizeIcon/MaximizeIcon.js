import React from 'react';
import styles from './MaximizeIcon.module.scss';
import { ReactComponent as MaximizeIc } from '~assets/icon/maximize.svg';

const MaximizeIcon = ({ active = false }) => (
  <MaximizeIc className={active ? styles.close['--active'] : styles.maximize} />
);

export default MaximizeIcon;
