import React from 'react';
import './style.scss';
import { ReactComponent as FilterDismissIc } from '~assets/icon/util/filter-dismiss.svg';

const FilterDismissIcon = ({ active }) => (
  <FilterDismissIc className={active ? 'icon-filter-dismiss active' : 'icon-filter-dismiss'} />
);

export default FilterDismissIcon;
