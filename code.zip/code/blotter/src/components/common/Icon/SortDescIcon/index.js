import React from 'react';
import './style.scss';
import { ReactComponent as SortDesc } from '~assets/icon/util/sort-desc.svg';

const SortDescIcon = () => <SortDesc className={'icon-sort-desc'} />;

export default SortDescIcon;
