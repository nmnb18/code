import React from 'react';
import './style.scss';
import { ReactComponent as ClearFilter } from '~assets/icon/util/clear-filter.svg';

const ClearFilterIcon = () => <ClearFilter className={'icon-clear-filter'} />;

export default ClearFilterIcon;
