import React from 'react';
import styles from './ColumnsIcon.module.scss';
import { ReactComponent as ColumnsIc } from '~assets/icon/util/columns.svg';

const ColumnsIcon = () => <ColumnsIc className={styles['column']} />;
export default ColumnsIcon;
