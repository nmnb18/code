import React from 'react';
import { render, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import UserSettings from './UserSettings';

import { UserContext } from '~contexts/UserContext';
import { UserEntitlementContext } from '~contexts/UserEntitlementContext';
import { ImpersonatedUsersProvider } from '~contexts/ImpersonatedUsersContext';
import { BlotterUserSettingsContext } from '~contexts/BlotterUserSettingsContext';

// Unmount everything from the dom after each test
afterEach(cleanup);

describe('<UserSettings />', () => {
  test('renders component', () => {
    const { getByTestId } = render(
      <UserContext.Provider value={{ currentUser: 'jvento', impersonatedUser: null }}>
        <BlotterUserSettingsContext.Provider value={{ blotterUserSettings: null }}>
          <UserEntitlementContext.Provider value={{ userEntitlement: null }}>
            <ImpersonatedUsersProvider>
              <UserSettings />
            </ImpersonatedUsersProvider>
          </UserEntitlementContext.Provider>
        </BlotterUserSettingsContext.Provider>
      </UserContext.Provider>
    );
    const component = getByTestId('UserSettings');
    const userIcon = getByTestId('UserIcon');

    expect(component).toBeInTheDocument();
    expect(userIcon).toBeInTheDocument();
  });
});
