// @External Dependencies
import React, { useRef, useContext } from 'react';
import { Tooltip } from '~ui-library';
import PropTypes from 'prop-types';
import styles from './UserSettings.module.scss';

// @Dependencies
import { UserIcon } from '~common';
import { useClickOutside } from '~hooks';
import { UserSettingOptions } from '~components';
import { UserEntitlementContext } from '~contexts/UserEntitlementContext';
import { ImpersonatedUsersContext } from '~contexts/ImpersonatedUsersContext';
import { UserContext } from '~contexts/UserContext';

// @Component
const UserSettings = () => {
  const myRef = useRef();
  const [isOpen, setIsOpen] = useClickOutside(myRef);
  const { userEntitlement } = useContext(UserEntitlementContext);
  const { impersonatedUser } = useContext(UserContext);
  const { setReloadImpersonatedUserToken } = useContext(ImpersonatedUsersContext);

  if (!userEntitlement) {
    return (
      <div data-testid="UserSettings" ref={myRef} className={styles.container}>
        <button className={`${styles['user-icon']} ${styles['user-icon--inactive']}`}>
          <UserIcon />
        </button>
      </div>
    );
  }

  const handleIsOpen = () => setIsOpen(!isOpen);
  const handleSelectSettingOption = newToken => {
    setIsOpen(false);
    newToken && setReloadImpersonatedUserToken(newToken);
  };

  return (
    <div
      data-testid="UserSettings"
      ref={myRef}
      className={`${styles['container']} ${impersonatedUser ? styles['container--impersonated'] : ''}`}
    >
      <div className={styles['user-information']}>
        {impersonatedUser && (
          <ul className={styles['impersonated-user-information__list']}>
            <li>IMPERSONATING</li>
            <Tooltip label={impersonatedUser.role}>
              <li className={styles['impersonated-user-information__name']}>{impersonatedUser.name}</li>
            </Tooltip>
          </ul>
        )}
        <button
          onClick={handleIsOpen}
          className={`${styles['user-icon']} ${impersonatedUser ? styles['user-icon--impersonated'] : ''} `}
        >
          <UserIcon />
        </button>
      </div>

      {isOpen && <UserSettingOptions onSelectSettingOption={handleSelectSettingOption} />}
    </div>
  );
};

// @Proptypes
UserSettings.propTypes = {
  user: PropTypes.shape({
    name: PropTypes.string.isRequired,
    level3: PropTypes.string,
    role: PropTypes.string
  })
};

// @Export Component
export default UserSettings;
