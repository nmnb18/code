import React, { memo, useState, useEffect, useContext } from 'react';
import styles from './WindowOptions.module.scss';
import { MinimizeIcon, MaximizeIcon, CloseIcon } from '~common';
import { MAXIMIZED, FLOW } from '~helpers/globals';
import { BlotterContext } from '~contexts/BlotterContext';
import * as usageService from '~services/usageService';
import { blotterContainerService } from '~services/blotterContainerService';
import { flowBlotterService } from '~services/flowBlotterService';
import { flowBlotterActions } from '~services/openfinConfig';

const fin = window.fin;

const currentFinWindow = fin && fin.desktop.Window.getCurrent();

const WindowOptions = ({ showCloseControl, showMaximizeControl, showMinimizeControl }) => {
  const [maximized, setMaximized] = useState(false);
  const { blotter } = useContext(BlotterContext);

  useEffect(() => {
    currentFinWindow &&
      currentFinWindow.getState(state => {
        state === MAXIMIZED && setMaximized(true);
      });
  });

  const handleMinimize = () => currentFinWindow && currentFinWindow.minimize();

  const handleMaximize = () => {
    if (fin) {
      !maximized ? currentFinWindow.maximize() : currentFinWindow.restore();

      setMaximized(!maximized);
    }
  };

  const handleClose = () => {
    usageService.sendUsage({ userAction: usageService.actions.CLOSE_APP });

    if (blotter === FLOW) {
      currentFinWindow && flowBlotterService.sendEvent({ type: flowBlotterActions.closingBlotterApp });
    } else {
      blotterContainerService.closeApp();
    }
  };

  return (
    <div className={styles['nav']}>
      <div className={styles['nav__buttons']}>
        {showMinimizeControl && (
          <button onClick={handleMinimize}>
            <MinimizeIcon />
          </button>
        )}
        {showMaximizeControl && (
          <button onClick={handleMaximize}>
            <MaximizeIcon />
          </button>
        )}
        {showCloseControl && (
          <button onClick={handleClose}>
            <CloseIcon />
          </button>
        )}
      </div>
    </div>
  );
};

export default memo(WindowOptions);
