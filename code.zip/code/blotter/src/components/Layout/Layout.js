import React from 'react';
import { useSetTheme } from '~hooks';
import './Layout.scss';

const Layout = ({ header, sidePanel = false, content, theme }) => {
  useSetTheme(theme);
  return (
    <div className="layout-container">
      {header && <div className="header">{header}</div>}
      {sidePanel && <div className="side-panel">{sidePanel}</div>}
      {content && <div className="content">{content}</div>}
    </div>
  );
};

export default Layout;
