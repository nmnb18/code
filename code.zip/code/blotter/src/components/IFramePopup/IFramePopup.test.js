import React from 'react';
import { render, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import IFramePopup from './IFramePopup';

// Unmount everything from the dom after each test
afterEach(cleanup);

describe('<IFramePopup />', () => {
  test('renders default IFramePopup', () => {
    const { getByTestId } = render(<IFramePopup />);
    const iFramePopup = getByTestId('IFramePopup');
    const iFrame = getByTestId('IFrame');

    expect(iFramePopup).toBeInTheDocument();
    expect(iFrame).toBeInTheDocument();
  });
});
