import React, { useEffect, useState, useCallback } from 'react';
import styles from './IFramePopup.module.scss';

import { IFrame } from '~components';
import { topicForUpdatingXiosWindows, xiosWindowsEvents } from '~helpers/popups';
import { iabSubscribe, iabUnsubscribe } from '~services/openfinService';

const fin = window.fin;

const finWindow = fin && fin.desktop.Window.getCurrent();

const IFramePopup = () => {
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');

  useEffect(() => {
    fin &&
      finWindow.getOptions(options => {
        const { customData } = options;
        setName(customData.name);
        setUrl(customData.url);
        //TODO: Check the Document.Title, for better readability (can be confused with the global one)
        document.title = customData.name;
      });
  }, []);

  const handleMessage = useCallback(
    ({ type, payload }) => {
      if (type === xiosWindowsEvents.updateTheme && url) {
        const currentUrl = new URL(url);
        currentUrl.searchParams.delete('theme');
        currentUrl.searchParams.set('theme', payload);
        setUrl(currentUrl.href);
      }
    },
    [url]
  );

  useEffect(() => {
    const logLabel = 'Xios Window';
    iabSubscribe({
      topic: topicForUpdatingXiosWindows,
      handler: handleMessage,
      logLabel
    });

    return () =>
      iabUnsubscribe({
        topic: topicForUpdatingXiosWindows,
        handler: handleMessage,
        logLabel
      });
  }, [handleMessage]);

  return (
    <div data-testid="IFramePopup" className={styles['iframe-popup']}>
      <IFrame url={url} name={name} />
    </div>
  );
};

export default IFramePopup;
