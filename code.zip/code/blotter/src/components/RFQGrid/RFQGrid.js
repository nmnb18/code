import React, { Component } from 'react';
import { AgGridReact } from 'ag-grid-react';
import { interval, Subject, merge } from 'rxjs';
import { switchMap, filter, tap, startWith, takeUntil, throttleTime, debounceTime } from 'rxjs/operators';
import 'ag-grid-enterprise';
import './RFQGrid.scss';
import { createProxyService } from '~services/proxyService';
import { createViewportDatasource, REMOVE_OTHER_SELECTIONS } from '~services/viewportDataSource';
import { LEGNO, WS_COMMANDS } from '~helpers/jasperMessage';
import { getRFQRowDetail } from '~helpers/rfq';
import {
  MaturityFilter,
  CustomTooltip,
  CustomAgGridHeaderTextFilter,
  CalendarFilter,
  CustomAgGridSetFilter,
  CustomAgGridDynamicSetFilter,
  CustomAgGridTextFilter,
  CustomAgGridNumFilter,
  CustomAgGridHeaderLabelFilter
} from '~components';
import { requestXiosWindowFromGrid } from '~helpers/popups';
import {
  columnsHavingBloombergIBChat,
  columnsHavingBloombergDataCommands,
  columnsHavingClientDetailsOption,
  columnsHavingBondDetailsOption,
  AG_GRID_AUTOSAVE_INTERVAL,
  AG_GRID_FILTER_CHANGED_INTERVAL,
  FLOW_APP_NAME
} from '~helpers/globals';
import * as bloombergService from '~services/bloombergService';
import * as usageService from '~services/usageService';
import { getFilterList, getAgGridFilter } from '~helpers/agGridFilterRecreation';
import { DATETIME, REACT_COMPONENT_FILTER_STRING, DYNAMIC_SET_FILTER } from '~constants/filters';
import { isEmpty } from 'flow-navigator-shared/dist/array';
import { isPartiallyEqual, isPropertyEqual } from '~helpers/object';
import { showEntitlementOption, uiEntitlementOptions } from '~helpers/entitlement';
import { formatDateOrTime } from '~helpers/rfqFormatters';
import { multiFilterService } from '~services/multiFilterService';
import { viewsActions } from '~helpers/userSettingsActionCreator';
import { ROW_CLASS_RULES } from '~helpers/agGrid';
import { ErrorModal, TextButton } from '~ui-library';

const keyIdRFQGroup = 'key_id_rfq_group';
const legNumber = 'legno';
const rfqNotifyTimer = 500;
const skipAutoSelectionTimer = 500;

const rfqNotifyEvents = {
  RESET_CARDS: 'RESET_CARDS',
  SET_CARDS: 'SET_CARDS'
};
const AUTOSAVE_EVENTS = {
  DRAG_STOP: 'handleDragStopped'
};
const wsConnStateTransitions = {
  SWITCHED_OFF: 'SWITCHED_OFF',
  SWITCHED_ON: 'SWITCHED_ON',
  NO_CHANGE: 'NO_CHANGE'
};

const COPY = 'Copy';
const SEPARATOR = 'separator';
const CLIENT_DETAILS = 'Client Details';
const BOND_DETAILS = 'Bond Details';

class RFQGrid extends Component {
  requireRFQNotificationPopupConfiguration = true;
  proxyService;
  filterEvent$ = new Subject();
  subscriptionId$ = new Subject();
  rfqNotifyFlag$ = new Subject();
  autoSelection$ = new Subject();
  userSelection$ = new Subject();
  lastRFQNotifyEvent;
  rfqLegArr = [];
  lastKeyIdRFQGroup;
  veryFirstNewRFQMessage = null;
  hasVeryFirstNewRFQMessageBeenSelected = false;
  fixedSelectedNodeFlag = false;
  filterChange$ = new Subject();

  rfqEventHandlers = {
    [WS_COMMANDS.NEW_MESSAGE]: rfqMessage => {
      if (this.fixedSelectedNodeFlag || !rfqMessage) return;

      const node = this.gridApi.getDisplayedRowAtIndex(rfqMessage.rowIndex);
      if (node?.data) this.autoSelection$.next(node);
    },
    [WS_COMMANDS.DELETE_MESSAGE]: rfqMessage => {
      // const rfqNotifyEvent = {
      //   type: rfqNotifyEvents.RESET_CARDS
      // };
      // this.rfqNotifyFlagSubject.next(rfqNotifyEvent);
    },
    [WS_COMMANDS.GROUP_END]: () => {
      if (!this.veryFirstNewRFQMessage) return;

      const rfqMessage = { ...this.veryFirstNewRFQMessage };
      this.veryFirstNewRFQMessage = null;
      const isVeryFirstSelection = true;
      this.forceSelectRFQ(rfqMessage, isVeryFirstSelection);
    }
  };
  autoSaveSubject = new Subject();
  autoSaveSubject$ = this.autoSaveSubject.asObservable();

  state = {
    getRowNodeId: data => data.sowkey,
    headerComponentFramework: {
      CustomAgGridHeaderTextFilter: CustomAgGridHeaderTextFilter,
      CustomAgGridHeaderLabelFilter: CustomAgGridHeaderLabelFilter
    },
    components: {
      rowIdRenderer: params => '' + params.rowIndex
    },
    frameworkComponents: {
      CalendarFilter: CalendarFilter,
      MaturityFilter: MaturityFilter,
      CustomAgGridSetFilter: CustomAgGridSetFilter,
      CustomAgGridDynamicSetFilter: CustomAgGridDynamicSetFilter,
      CustomAgGridTextFilter: CustomAgGridTextFilter,
      CustomAgGridNumFilter: CustomAgGridNumFilter,
      customTooltip: CustomTooltip
    },
    flowApp: {},
    rowClassRules: ROW_CLASS_RULES,
    showFilterTooBigMessage: false
  };

  componentDidMount() {
    const { forceSelectRFQs$, connectionStatus$, userSettings } = this.props;
    const flowApp = userSettings.Applications.find(app => app.AppName === FLOW_APP_NAME);
    this.setState({ flowApp });

    this.wsConnected$ = connectionStatus$.pipe(filter(({ status }) => typeof status === 'boolean' && !status));
    this.wsDisconnected$ = connectionStatus$.pipe(
      filter(({ status }) => typeof status === 'boolean' && status),
      tap(() => {
        this.veryFirstNewRFQMessage = true;
      })
    );

    // new RFQ mesage came in
    this.rfqNotifyFlagSubscription = this.wsConnected$
      .pipe(
        switchMap(() =>
          this.rfqNotifyFlag$.pipe(
            filter(() => this.hasVeryFirstNewRFQMessageBeenSelected),
            tap(rfqNotifyEvent => (this.lastRFQNotifyEvent = rfqNotifyEvent)),
            switchMap(rfqNotifyEvent =>
              interval(rfqNotifyTimer).pipe(startWith(rfqNotifyEvent), takeUntil(this.wsDisconnected$))
            )
          )
        )
      )
      .subscribe(() => {
        const lastRFQNotifyEventCopy = { ...this.lastRFQNotifyEvent };
        const { type, payload } = lastRFQNotifyEventCopy;
        const isSelectedRFQAvailable = this.areSelectedRowsAvailable(payload);

        if (type === rfqNotifyEvents.SET_CARDS && isSelectedRFQAvailable) {
          const updatedRows = this.getUpdatedDataFromGrid(payload);
          this.pushSelectedRFQsTotheStream(updatedRows);
        } else if (type === rfqNotifyEvents.RESET_CARDS || !isSelectedRFQAvailable) {
          const displayedRows = this.gridApi.getDisplayedRowCount();
          this.fixedSelectedNodeFlag = false;

          if (displayedRows > 0) {
            this.autoSelectFirstRow();
          } else {
            this.pushSelectedRFQsTotheStream(null);
          }
        }
      });

    this.forceSelectRFQSubscription = forceSelectRFQs$.subscribe(rfqMessage => {
      this.veryFirstNewRFQMessage = rfqMessage;
    });

    this.selectRFQSubscription = merge(
      this.userSelection$,
      this.autoSelection$.pipe(throttleTime(skipAutoSelectionTimer))
    ).subscribe(node => {
      this.selectNode(node);
    });

    this.autoSaveSubscription = this.autoSaveSubject$
      .pipe(debounceTime(Number(AG_GRID_AUTOSAVE_INTERVAL)))
      .subscribe(() => this.handleColumnSizeAndOrderAndSortAutoSave());

    this.filterChangeSubscription = this.filterChange$
      .pipe(debounceTime(Number(AG_GRID_FILTER_CHANGED_INTERVAL)))
      .subscribe(event => this.handleFilterChange(event));
  }

  shouldRequestForTotals = (prevProps, wsConnStateTransition) => {
    const propertiesToCompare = [
      'subscriptionInstanceId',
      'toggles',
      'filterToggles',
      'filterList',
      'columnDefs',
      'currentViewName'
    ];

    return (
      wsConnStateTransition === wsConnStateTransitions.SWITCHED_ON ||
      !isPartiallyEqual(this.props, prevProps, propertiesToCompare, false)
    );
  };

  getWsConnStateTransition = prevProps => {
    const { SWITCHED_OFF, SWITCHED_ON, NO_CHANGE } = wsConnStateTransitions;
    const wsConnectionChanged = !isPropertyEqual(this.props, prevProps, 'webSocketDisconnected');

    if (wsConnectionChanged) {
      if (this.props.webSocketDisconnected) {
        return SWITCHED_OFF;
      } else {
        return SWITCHED_ON;
      }
    } else {
      return NO_CHANGE;
    }
  };

  shouldComponentUpdate(nextProps, nextState) {
    const propertiesToCompare = [
      'gridId',
      'subscriptionInstanceId',
      'toggles',
      'filterToggles',
      'filterList',
      'columnDefs',
      'columnOrderFromView',
      'columnState',
      'currentViewName',
      'userSettings',
      'webSocketDisconnected'
    ];

    const stateToCompare = ['showFilterTooBigMessage'];

    return (
      !isPartiallyEqual(this.props, nextProps, propertiesToCompare, false) ||
      !isPartiallyEqual(this.state, nextState, stateToCompare, false)
    );
  }

  componentDidUpdate(prevProps) {
    const wsConnStateTransition = this.getWsConnStateTransition(prevProps);

    if (wsConnStateTransition === wsConnStateTransitions.SWITCHED_OFF) {
      this.pushSelectedRFQsTotheStream(null);
    }

    if (!isPropertyEqual(this.props, prevProps, 'subscriptionInstanceId')) {
      this.setSubscriptionInstance(this.props.subscriptionInstanceId);
    }

    if (!isPropertyEqual(this.props, prevProps, 'columnDefs')) {
      this.gridApi.setColumnDefs([]);
      this.gridApi.setColumnDefs(this.props.columnDefs);
    }

    if (this.shouldRequestForTotals(prevProps, wsConnStateTransition)) {
      this.filterEvent$.next({ newCriteria: true });
    }
  }

  componentWillUnmount() {
    this.proxyService.disconnect();
    this.rfqNotifyFlagSubscription.unsubscribe && this.rfqNotifyFlagSubscription.unsubscribe();
    this.selectRFQSubscription.unsubscribe && this.selectRFQSubscription.unsubscribe();
    this.filterChangeSubscription.unsubscribe();
  }

  emitAutoSaveEvent = event => this.autoSaveSubject.next(event);

  handleColumnSizeAndOrderAndSortAutoSave = () => {
    const { currentViewName, columnState } = this.props;
    const sortModel = this.gridApi.getSortModel();

    viewsActions.editColumnStateAndSort({
      currentViewName,
      sortModel,
      columnState
    });
  };

  pushSelectedRFQsTotheStream = RFQs => {
    const { selectedRFQs$ } = this.props;
    selectedRFQs$ && selectedRFQs$.next(RFQs);
  };

  getUpdatedDataFromGrid = rows =>
    rows.map(row => {
      const node = this.gridApi.getRowNode(row.sowkey);
      return node ? node.data : row;
    });

  areSelectedRowsAvailable = selectedRows => {
    if (!selectedRows) return false;

    const mainRFQRow = getRFQRowDetail(selectedRows, LEGNO.MAIN);
    if (!mainRFQRow) return false;

    const { sowkey } = mainRFQRow;
    const node = this.gridApi.getRowNode(sowkey);

    return !!node;
  };

  autoSelectFirstRow = () => {
    const node = this.gridApi.getDisplayedRowAtIndex(0);

    if (node && node.data) {
      this.autoSelection$.next(node);
    }
  };

  handleRowCountChanged = totalRows => {
    const { onTotalRowChanged } = this.props;
    onTotalRowChanged && onTotalRowChanged(totalRows);
  };

  toggleShowFilterTooBigMessage = value => {
    this.setState({ showFilterTooBigMessage: value });
  };

  handleOnGridReady = params => {
    const {
      datasource$,
      subscriptionInstanceId,
      filterList,
      columnState,
      setColumnOrderFromView,
      columnsDictionary
    } = this.props;
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

    const proxyServiceOptions = {
      notifyOnViewportReady: true,
      notifyOnGroupEnd: true
    };

    this.proxyService = createProxyService(
      this.subscriptionId$,
      datasource$,
      this.filterEvent$,
      this.handleRequestData,
      this.handleRowCountChanged,
      proxyServiceOptions,
      null,
      null,
      this.handleRFQEvent,
      this.handleOnViewportReady,
      this.handleUnsubscribeRange
    );

    this.proxyService.setReferenceKeys(columnsDictionary.sourceColumnNames);

    this.setSubscriptionInstance(subscriptionInstanceId);

    const viewportOptions = {
      notifyOnNewMessage: true
    };
    const viewportDatasource = createViewportDatasource(this.proxyService, null, viewportOptions, this.handleRFQEvent);
    this.gridApi.setViewportDatasource(viewportDatasource);

    const colIds = this.gridColumnApi.getAllDisplayedColumns();
    setColumnOrderFromView && setColumnOrderFromView(colIds);

    this.gridColumnApi.setColumnState(columnState && columnState.length > 0 ? columnState : null);

    const agGridFilterModel = getAgGridFilter(filterList);
    this.gridApi.setFilterModel(agGridFilterModel);
  };

  /**@param {{firstRow?:number,lastRow?:number,newCriteria?:boolean}} obj*/
  handleRequestData = ({ firstRow, lastRow, newCriteria = false } = {}) => {
    const { subscriptionInstanceId, columnDefs, requestData, gridId, appName } = this.props;
    requestData &&
      requestData({
        subscriptionInstanceId,
        columnDefs,
        firstRow,
        lastRow,
        newCriteria,
        gridId,
        appName,
        requireRFQNotificationPopupConfiguration: this.requireRFQNotificationPopupConfiguration
      });
  };

  handleUnsubscribeRange = () => {
    const { subscriptionInstanceId, onUnsubscribeRange } = this.props;
    onUnsubscribeRange && onUnsubscribeRange({ subscriptionInstanceId });
  };

  handleRFQEvent = rfqEvent => {
    const { type, data } = rfqEvent;

    const rfqEventHandler = this.rfqEventHandlers[type];
    rfqEventHandler && rfqEventHandler(data);
  };

  handleOnViewportReady = () => {
    const { onRFQGridReady } = this.props;

    onRFQGridReady && onRFQGridReady();
  };

  onRowClicked = event => {
    this.fixedSelectedNodeFlag = true;
    this.userSelection$.next(event.node);
  };

  selectNode = node => {
    const { data, rowIndex } = node;

    // legno property indicates the row's type:
    //    legno 0 = main row
    //    legno 1 = L1
    //    legno 2 = L2
    // if the row is a LEG, it'll target to the main record

    // select main RFQ row
    const selectedNode = data[legNumber] > 0 ? this.gridApi.getDisplayedRowAtIndex(rowIndex - data[legNumber]) : node;
    selectedNode.setSelected(true, REMOVE_OTHER_SELECTIONS);

    // select LEG Rows
    for (
      let i = selectedNode.rowIndex, next = this.gridApi.getDisplayedRowAtIndex(i + 1);
      next && next.data && data[keyIdRFQGroup] === next.data[keyIdRFQGroup];
      i++, next = this.gridApi.getDisplayedRowAtIndex(i + 1)
    ) {
      next.setSelected(true, !REMOVE_OTHER_SELECTIONS);
    }

    const selectedRows = this.gridApi.getSelectedRows();
    const rfqNotifyEvent = {
      type: rfqNotifyEvents.SET_CARDS,
      payload: selectedRows
    };

    this.rfqNotifyFlag$.next(rfqNotifyEvent);
  };

  forceSelectRFQ = (rfqMessage, isVeryFirstSelection = false) => {
    if (isVeryFirstSelection) {
      this.hasVeryFirstNewRFQMessageBeenSelected = true;
      const rfqNotifyEvent = { type: rfqNotifyEvents.RESET_CARDS };
      this.rfqNotifyFlag$.next(rfqNotifyEvent);
    } else {
      const node = this.gridApi.getRowNode(rfqMessage.sowkey);
      if (node) node.setSelected(true, REMOVE_OTHER_SELECTIONS);
    }
  };

  setSubscriptionInstance = subscriptionInstanceId => this.subscriptionId$.next(subscriptionInstanceId);

  getViewDetailsOption = (
    { showClientDetails, showBondDetails },
    { colId, currentFinUser, idmonikerclient, code, value, signedInUser }
  ) => {
    const menuItems = [];

    const launchPopup = () => {
      requestXiosWindowFromGrid(
        {
          target: {
            paramField: colId,
            paramMonikerClient: idmonikerclient,
            paramIsin: code
          }
        },
        currentFinUser,
        signedInUser
      );

      usageService.sendUsageForRFQ({
        userAction: usageService.actions.RFQ_CLICK,
        notes: {
          Selection: usageService.BLOTTER_CLICK_ACTION_LABELS[colId],
          Name: value
        }
      });
    };

    if (showClientDetails) {
      menuItems.push({
        name: CLIENT_DETAILS,
        action: launchPopup
      });
    }

    if (showBondDetails) {
      menuItems.push({
        name: BOND_DETAILS,
        action: launchPopup
      });
    }

    return menuItems;
  };

  handleContextMenuUsage = action => {
    usageService.sendUsage({
      userAction: usageService.actions.RIGHT_CLICK,
      notes: { Selection: action, RecordCount: 1 }
    });
  };

  getDefaultOptions = (value, colId) => {
    const { columnsDictionary } = this.props;
    const colDef = columnsDictionary.sourceColumnNames.find(({ sourcecolumnname }) => sourcecolumnname === colId);
    // implmented custom copy as ag-grid copy function copies whole row on selection
    const copyOption = {
      name: COPY,
      action: () => {
        const { columntype, formatinstruction } = colDef;
        let dynamicTextarea = document.createElement('textarea');
        dynamicTextarea.innerText =
          columntype === DATETIME ? formatDateOrTime(value, formatinstruction.dateFormat) : value;
        document.body.appendChild(dynamicTextarea);
        dynamicTextarea.select();
        document.execCommand('Copy');
        dynamicTextarea.remove();
        this.handleContextMenuUsage(COPY);
      }
    };

    return [copyOption];
  };

  createBloombergOption = (rfqData, commandLabel, command = commandLabel) => ({
    name: commandLabel,
    action: () => {
      this.props.handleBloombergCommand(rfqData, commandLabel, command);
      this.handleContextMenuUsage(commandLabel);
    }
  });

  getBloombergOptions = (rfqData, commands) => {
    return [...commands].map(command => this.createBloombergOption(rfqData, command));
  };

  getContextMenuItems = params => {
    if (!params.column || !params.node.data) return;

    const {
      value,
      column: { colId }
    } = params;

    const data = { ...params.node.data };

    const showXiosPopup = showEntitlementOption(this.props.entitlement, uiEntitlementOptions.XIOS_POPUP_VISIBLE);
    const showClientDetails = showXiosPopup && columnsHavingClientDetailsOption.includes(colId);
    const showBondDetails = showXiosPopup && columnsHavingBondDetailsOption.includes(colId);
    const showBloombergIBChat = columnsHavingBloombergIBChat.includes(colId);
    const showBloombergDataCommands = columnsHavingBloombergDataCommands.includes(colId);

    /**@type {Array.<{name: String, action: ()=>void}|String>} */
    const contextMenuItems = [...this.getDefaultOptions(value, colId)];

    if (showClientDetails || showBondDetails) {
      const { idmonikerclient, code } = data;
      const { currentFinUser, signedInUser } = this.props;
      const menuItems = this.getViewDetailsOption(
        { showClientDetails, showBondDetails },
        { colId, currentFinUser, idmonikerclient, code, value, signedInUser }
      );
      menuItems.length && contextMenuItems.push(SEPARATOR, ...menuItems);
    }

    if (showBloombergIBChat) {
      const { label, command } = bloombergService.IBCHAT_COMMAND;
      const ibChatItem = this.createBloombergOption(data, label, command);
      contextMenuItems.push(SEPARATOR, ibChatItem);
    }

    if (showBloombergDataCommands) {
      const { rfqnlegs } = data;
      const commands = Object.values(bloombergService.DATA_COMMANDS)
        .filter(command => command.legs === rfqnlegs)
        .map(command => command.command);
      const bloombergOptions = this.getBloombergOptions(data, commands);
      bloombergOptions.length && contextMenuItems.push(SEPARATOR, ...bloombergOptions);
    }

    return contextMenuItems;
  };

  onFilterChanged = event => {
    if (event) this.filterChange$.next(event);
  };

  handleFilterChange = params => {
    const { columnDefs, setColumnsFilters } = this.props;
    const agGridFilterModel = this.gridApi.getFilterModel();
    const filterList = getFilterList(columnDefs, agGridFilterModel);

    let skipDoQueryForMultiSelectFilterList = null;
    const { columnMetadata } = params;

    if (columnMetadata) {
      const { filterType, field, isEmpty, skipFetch } = columnMetadata;

      if (filterType === DYNAMIC_SET_FILTER) {
        skipDoQueryForMultiSelectFilterList = isEmpty ? [] : [field];
      } else if (filterType !== DYNAMIC_SET_FILTER) {
        skipDoQueryForMultiSelectFilterList = [];
      }

      if (typeof skipFetch === 'boolean' && !skipFetch) multiFilterService.setMultiFilterField(field);
    }

    setColumnsFilters && setColumnsFilters(filterList, skipDoQueryForMultiSelectFilterList);

    //The next line removes the div generated by the filter PopUp upon filtering:
    [...document.getElementsByClassName('ag-tab-body')].map(n => n && n.remove());
  };

  setFilterModel = () => {
    if (this.gridApi) {
      const { filterList } = this.props;
      const agGridFilterModel = getAgGridFilter(filterList);
      this.gridApi.setFilterModel(agGridFilterModel);
    }
  };

  isCustomFilter = filterInstance => {
    if (Object.keys(filterInstance).find(value => value === REACT_COMPONENT_FILTER_STRING)) {
      return true;
    }
    return false;
  };

  handleOnDragStopped = params => {
    const { setColumnOrder, setColumnState, impersonatingUser } = this.props;
    const colIds = params.columnApi.getAllDisplayedColumns();
    setColumnOrder && setColumnOrder(colIds);
    setColumnState && setColumnState(params.columnApi.getColumnState());

    !impersonatingUser && this.emitAutoSaveEvent(AUTOSAVE_EVENTS.DRAG_STOP);
  };

  handleResetFilter = fieldId => {
    if (!this.gridApi || !this.gridColumnApi) return;

    const { filterList, columnState, removeFilter } = this.props;
    this.gridColumnApi.setColumnState(columnState && columnState.length > 0 ? columnState : null);

    if (isEmpty(filterList) || !fieldId) {
      multiFilterService.clearMultiFilter();
      this.gridApi.setFilterModel(null);
      const agGridFilterModel = this.gridApi.getFilterModel();

      if (!agGridFilterModel || !Object.keys(agGridFilterModel).length) {
        this.props.setColumnsFilters([]);
        [...document.getElementsByClassName('ag-tab-body')].map(n => n && n.remove());
      }
      return;
    }

    const column = columnState.find(({ colId }) => colId === fieldId);

    if (!column) {
      multiFilterService.clearMultiFilter();
      removeFilter(fieldId);
    } else {
      const filterInstance = this.gridApi.getFilterInstance(fieldId);
      if (!filterInstance) return;

      multiFilterService.clearMultiFilter();
      filterInstance.setModel(null);

      if (!this.isCustomFilter(filterInstance)) {
        filterInstance.applyModel();
      }

      this.gridApi.onFilterChanged();
    }
  };

  handleFilterModelAndSortingRecovery = (
    options = {
      skipSetFilterModel: false,
      skipSetColumnState: false
    }
  ) => {
    if (this.gridColumnApi) {
      if (!options.skipSetColumnState) {
        const { columnState } = this.props;
        this.gridColumnApi.setColumnState(columnState && columnState.length > 0 ? columnState : null);
      }
    }
    if (this.gridApi) {
      if (!options.skipSetFilterModel) {
        const { filterList } = this.props;
        const agGridFilterModel = getAgGridFilter(filterList);
        this.gridApi.setFilterModel(agGridFilterModel);
      }
    }
  };

  render() {
    const { gridId, columnDefs, rowSelection, rowModelType, gridOptions } = this.props;
    const { getRowNodeId, components, frameworkComponents, headerComponentFramework, rowClassRules } = this.state;

    return (
      <div className={'rfq-grid-container ag-theme-balham'}>
        <AgGridReact
          id={gridId}
          rowSelection={rowSelection}
          rowModelType={rowModelType}
          getRowNodeId={getRowNodeId}
          headerComponentFramework={headerComponentFramework}
          components={components}
          frameworkComponents={frameworkComponents}
          onGridReady={this.handleOnGridReady}
          columnDefs={columnDefs}
          gridOptions={gridOptions}
          onRowClicked={this.onRowClicked}
          onFilterChanged={this.onFilterChanged}
          viewportRowModelBufferSize={0}
          suppressRowClickSelection={true}
          suppressMenuHide={true}
          rowClassRules={rowClassRules}
          getContextMenuItems={this.getContextMenuItems}
          onDragStopped={this.handleOnDragStopped}
          toggleShowFilterTooBigMessage={this.toggleShowFilterTooBigMessage}
        />
        <ErrorModal
          isOpen={this.state.showFilterTooBigMessage}
          onDismiss={() => {
            this.toggleShowFilterTooBigMessage(false);
          }}
          content="This filter cannot be applied as it exceeds maximum connection size. Please choose fewer options or remove other filters."
          controls={<TextButton handleClick={() => this.toggleShowFilterTooBigMessage(false)}>OK</TextButton>}
        />
      </div>
    );
  }
}

RFQGrid.defaultProps = {
  rowSelection: 'multiple',
  rowModelType: 'viewport',
  gridOptions: {
    rowHeight: 24,
    suppressDragLeaveHidesColumns: true,
    suppressPropertyNamesCheck: true
  }
};

export default RFQGrid;
