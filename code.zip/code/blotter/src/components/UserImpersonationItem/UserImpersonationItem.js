import React, { useEffect, useRef } from 'react';
import styles from './UserImpersonationItem.module.scss';
import { UserInformation } from '~components';

const UserImpersonationItem = ({ active, impersonatedUser, handleSelectUser }) => {
  const myRef = useRef();

  useEffect(() => {
    active && myRef.current.focus();
  }, [active]);

  const activeClass = active ? styles['user-impersonation-item--active'] : '';

  return (
    <button
      ref={myRef}
      className={`${styles['user-impersonation-item']} ${activeClass}`}
      onClick={() => handleSelectUser(impersonatedUser)}
    >
      <UserInformation showVersion={false} user={impersonatedUser} />
    </button>
  );
};

export default UserImpersonationItem;
