import React, { useEffect, useCallback, useReducer } from 'react';
import styles from './RFQPopupHeader.module.scss';
import { RFQCardDetail, HeaderToggle, ConnectionIndicator } from '~components';
import * as bloombergService from '~services/bloombergService';
import { LEGNO } from '~helpers/jasperMessage';
import { formatDateOrTime, FORMATS } from '~helpers/rfqFormatters';
import { getRFQRowDetail, sortRFQRows } from '~helpers/rfq';
import { getEnvironmentName } from '~services/apiConfig';
import { ReactComponent as CloseIcon } from '~assets/icon/close.svg';
import { ReactComponent as MaximizeIcon } from '~assets/icon/maximize.svg';
import { ReactComponent as MinimizeIcon } from '~assets/icon/minimize.svg';
import { TAG_STATUS } from '~helpers/columnStyles';

const statusObject = {};
Object.values(TAG_STATUS).forEach(item => {
  statusObject[item.value] = item.class;
});

/**
 * Apply class to mini-ticket status.
 * @param {string} statusstr The statusstr value
 * @returns {string} Returns a string to use as className.
 */
const getStatusClassname = statusstr => {
  const cleanedClass = statusstr.toLowerCase();
  let classname = 'rfq-popup-header__status';
  if (statusObject[cleanedClass]) {
    classname = classname + `--${statusObject[cleanedClass]}`;
  }
  return classname;
};

const formatMainRFQRow = mainRFQRow => {
  if (!mainRFQRow) return null;

  const { clientname, countdown, rfqnlegs, code, bbgcustchatid, statusstr } = mainRFQRow;
  const formattedCountdown = formatDateOrTime(countdown, FORMATS.countdown);
  return {
    clientname,
    countdown: formattedCountdown,
    rfqnlegs,
    code,
    bbgcustchatid,
    statusstr
  };
};

const initialState = {
  maximized: false,
  mainRow: null,
  selectedRows: []
};

const SET_MAXIMIZED = 'SET_MAXIMIZED';
const SET_MINITICKET_DETAILS = 'SET_MINITICKET_DETAILS';
const SET_SELECTED_ROWS = 'SET_SELECTED_ROWS';

function reducer(state, action) {
  switch (action.type) {
    case SET_MAXIMIZED:
      return {
        ...state,
        maximized: action.payload.maximized
      };
    case SET_SELECTED_ROWS:
      return {
        ...state,
        selectedRows: action.payload.selectedRows
      };
    case SET_MINITICKET_DETAILS:
      return {
        ...state,
        mainRow: action.payload.mainRow,
        selectedRows: action.payload.selectedRows
      };
    default:
      return state;
  }
}

const RFQPopupHeader = ({
  columnsDictionary,
  selectedRFQs$,
  popUp,
  onRFQPopupClose,
  onRFQToggle,
  connectionStatus,
  handleBloombergCommand,
  TogglesSection,
  FilterBarSection
}) => {
  const [{ maximized, mainRow, selectedRows }, dispatch] = useReducer(reducer, initialState);
  const currentEnv = getEnvironmentName();

  const setMiniTicketDetails = useCallback(
    (_mainRow, _selectedRows) =>
      dispatch({
        type: SET_MINITICKET_DETAILS,
        payload: {
          mainRow: _mainRow,
          selectedRows: _selectedRows
        }
      }),
    [dispatch]
  );

  const setSelectedRows = useCallback(
    _selectedRows =>
      dispatch({
        type: SET_SELECTED_ROWS,
        payload: {
          selectedRows: _selectedRows
        }
      }),
    [dispatch]
  );

  const setMaximized = useCallback(
    _maximized =>
      dispatch({
        type: SET_MAXIMIZED,
        payload: {
          maximized: _maximized
        }
      }),
    [dispatch]
  );

  useEffect(() => {
    const rfqSubscription = selectedRFQs$.subscribe(RFQs => {
      if (!RFQs) {
        setMiniTicketDetails(null, []);
      } else {
        const mainRFQRow = getRFQRowDetail(RFQs, LEGNO.MAIN);
        if (mainRFQRow) {
          const formattedMainRow = formatMainRFQRow(mainRFQRow);
          const sortedSelectedRows = sortRFQRows(RFQs);
          setMiniTicketDetails(formattedMainRow, sortedSelectedRows);
        } else {
          const sortedSelectedRows = sortRFQRows(RFQs);
          setSelectedRows(sortedSelectedRows);
        }
      }
    });

    return () => {
      rfqSubscription.unsubscribe();
    };
  }, [selectedRFQs$, setMiniTicketDetails, setSelectedRows]);

  const handleMinimize = useCallback(() => {
    console.log('rfqPopup action: user clicked minimize (_) from within RFQ popup');
    popUp.minimize();
  }, [popUp]);

  const handleMaximize = useCallback(() => {
    console.log('rfqPopup action: user clicked maximize ([]) from within RFQ popup');
    if (!maximized) popUp.maximize();
    else popUp.restore();

    setMaximized(!maximized);
  }, [maximized, popUp, setMaximized]);

  const handleClose = useCallback(() => {
    console.log('rfqPopup action: user clicked close (x) from within RFQ popup');
    onRFQPopupClose();
  }, [onRFQPopupClose]);

  const handleToggle = useCallback(() => {
    console.log('rfqPopup action: user toggled RFQ popup OFF from within RFQ popup');
    onRFQToggle();
  }, [onRFQToggle]);

  const getRFQData = () => {
    const { rfqnlegs, bbgcustchatid, code } = mainRow;
    const leg1 = getRFQRowDetail(selectedRows, LEGNO.L1);
    const leg2 = getRFQRowDetail(selectedRows, LEGNO.L2);

    return {
      l1_code: leg1?.code,
      l2_code: leg2?.code,
      rfqnlegs,
      bbgcustchatid: bbgcustchatid,
      code_main_value: code,
      code: code
    };
  };

  const ibChatOnClickHandler = event => {
    event.preventDefault();
    handleBloombergCommand(
      getRFQData(),
      bloombergService.IBCHAT_COMMAND.label,
      bloombergService.IBCHAT_COMMAND.command
    );
  };

  const bloombergOnClickHandler = (command, event) => {
    event.preventDefault();
    handleBloombergCommand(getRFQData(), command);
  };

  const renderBloombergButtons = () => (
    <div className={styles['rfq-popup-header__bloomberg']}>
      <div className={styles['rfq-card-details__header__options']}>
        {mainRow && <button onClick={ibChatOnClickHandler}>{bloombergService.IBCHAT_COMMAND.label}</button>}
        {mainRow &&
          Object.values(bloombergService.DATA_COMMANDS)
            .filter(({ legs }) => legs === mainRow.rfqnlegs.toString())
            .map(({ command }) => (
              <button key={command} onClick={bloombergOnClickHandler.bind(null, command)}>
                {command}
              </button>
            ))}
      </div>
    </div>
  );

  const renderClientName = () => (
    <div className={styles['rfq-popup-header__client__exp-name']}>
      <span className={`${styles['rfq-popup-header__client__exp']} ibmmono`}>{mainRow?.countdown || '--:--'}</span>
      <span className={styles['rfq-popup-header__client__name']}>{mainRow?.clientname || '----'}</span>
      {mainRow?.statusstr && <span className={styles[getStatusClassname(mainRow.statusstr)]}>{mainRow.statusstr}</span>}
    </div>
  );

  return (
    <div className={styles['rfq-popup-header']}>
      <header className={styles['rfq-popup-header__topbar']}>
        <div className={styles['topbar-drag']}>
          <h3 className={styles['topbar-title']}>RFQ Notification</h3>
          <ConnectionIndicator status={connectionStatus} text={currentEnv} />
        </div>
        <div className={styles['rfq-popup-header__actions']}>
          <HeaderToggle onToggleChange={handleToggle} isToggleOn={true} text="RFQ Popup" className={'inline_toggle'} />
          <button className={styles['window-button']} onClick={handleMinimize}>
            <MinimizeIcon />
          </button>
          <button className={styles['window-button']} onClick={handleMaximize}>
            <MaximizeIcon />
          </button>
          <button className={styles['window-button']} onClick={handleClose}>
            <CloseIcon />
          </button>
        </div>
      </header>
      <section className={styles['rfq-popup-header__client']}>
        <header>
          <div className={styles['rfq-popup-header__client-button']}>
            {renderClientName()}
            {renderBloombergButtons()}
          </div>
          <div className={styles['rfq-popup-header__client-toggle']}>{TogglesSection}</div>
        </header>
        <div className={styles['rfq-popup-header__cards']}>
          {selectedRows.map((row, index) => (
            <RFQCardDetail key={index} columnsDictionary={columnsDictionary} {...row} />
          ))}
        </div>
      </section>
      {FilterBarSection}
    </div>
  );
};

export default RFQPopupHeader;
