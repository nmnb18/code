import React, { Component } from 'react';
import { SortingMenu, CustomAgGridTextFilterModal } from '~components';
import { moveFilterComponentToTheLeft, focusTextBox } from '~helpers/customFilterArrangement';
import { TEXT_FILTER } from '~constants/filters';
import { isEmpty } from '~helpers/string';
import { FILTER_MODEL_TEXT } from '~constants/filterModelTypes';

class CustomAgGridTextFilter extends Component {
  constructor(props) {
    super(props);

    this.state = {
      filter: '',
      direction: this.props.column.getSort()
    };

    this.myRef = React.createRef();
  }

  handleFilterChange = textFilter => {
    const {
      filterChangedCallback,
      colDef: { field }
    } = this.props;
    const { filter } = this.state;

    if (isEmpty(filter) && isEmpty(textFilter)) {
      filterChangedCallback();
      return;
    }

    this.setState(
      {
        filter: textFilter
      },
      () => {
        filterChangedCallback({
          columnMetadata: {
            filterType: TEXT_FILTER,
            field
          }
        });
      }
    );
  };

  getModel = () => {
    if (this.state.filter.length > 0) {
      return {
        field: this.props.colDef.field,
        headerName: this.props.colDef.headerName,
        filter: this.state.filter,
        filterType: FILTER_MODEL_TEXT,
        type: '='
      };
    } else {
      return undefined;
    }
  };

  setModel = model => {
    const {
      filterChangedCallback,
      colDef: { field }
    } = this.props;

    this.setState(
      {
        filter: model ? model.filter : ''
      },
      () => {
        filterChangedCallback({
          columnMetadata: {
            filterType: TEXT_FILTER,
            field
          }
        });
      }
    );
  };

  isFilterActive = () => {
    return this.state.filter.length > 0;
  };

  afterGuiAttached = () => {
    const customFilterContainer = this.myRef.current;

    if (customFilterContainer) {
      focusTextBox(customFilterContainer);
      moveFilterComponentToTheLeft(customFilterContainer);
    }
  };

  setDirection = direction => {
    const { column, api } = this.props;
    const multisort = false;
    api.sortController.setSortForColumn(column, direction, multisort);
    this.setState({ direction });
  };

  render() {
    const { direction } = this.state;
    const { sortable } = this.props;

    return (
      <div ref={this.myRef}>
        <CustomAgGridTextFilterModal
          column={this.props.column}
          api={this.props.api}
          onFilterChange={this.handleFilterChange}
          sortingMenu={sortable ? <SortingMenu direction={direction} setDirection={this.setDirection} /> : null}
        />
      </div>
    );
  }
}

export default CustomAgGridTextFilter;
