import React, { useContext, useMemo } from 'react';
import {
  Dropdown,
  WindowOptions,
  ClientsSearchBar,
  UserSettings,
  QuickLauncher,
  ConnectionIndicator,
  RFQToggle
} from '~components';
import { useUserEntitlement } from '~hooks';
import { UserContext } from '~contexts/UserContext';
import { ImpersonatedUsersProvider } from '~contexts/ImpersonatedUsersContext';
import { FLOW, JASPER } from '~helpers/globals';
import { getEnvironmentName } from '~services/apiConfig';
import JASPER_LOGO from '~assets/img/jasper-logo-dark.png';
import MASISON_LOGO from '~assets/img/madison.svg';
import styles from './Header.module.scss';
import { uiEntitlementOptions, showEntitlementOption } from '~helpers/entitlement';
import {
  showControl,
  mmiControlsDefaultState,
  CLOSE_CONTROL,
  MINIMIZE_CONTROL,
  MAXIMIZE_CONTROL
} from '~services/mmiService';

const headerConfigurationDefaultState = {
  logoSrc: JASPER_LOGO,
  logoClassName: '',
  appLabel: JASPER
};

const isFlowBlotter = blotter => blotter.name === FLOW;

const Header = ({ currentBlotter, connectionStatus }) => {
  const { impersonatedUser, windowOptions } = useContext(UserContext);
  const entitlement = useUserEntitlement();
  const currentEnv = getEnvironmentName();

  const searchBarVisible = useMemo(() => showEntitlementOption(entitlement, uiEntitlementOptions.SEARCH_BAR_VISIBLE), [
    entitlement
  ]);

  const winOptions = useMemo(() => {
    if (!windowOptions) {
      const { showCloseControl, showMaximizeControl, showMinimizeControl } = mmiControlsDefaultState;
      return { showCloseControl, showMaximizeControl, showMinimizeControl };
    }

    return {
      showCloseControl: showControl(windowOptions, CLOSE_CONTROL),
      showMaximizeControl: showControl(windowOptions, MAXIMIZE_CONTROL),
      showMinimizeControl: showControl(windowOptions, MINIMIZE_CONTROL)
    };
  }, [windowOptions]);

  const { showWindowOptions, disableDragStyle } = useMemo(() => {
    return {
      showWindowOptions: Object.keys(winOptions)
        .map(key => winOptions[key])
        .some(Boolean),
      disableDragStyle: !winOptions.showCloseControl ? styles['disable-drag'] : ''
    };
  }, [winOptions]);

  const { logoSrc, logoClassName, appLabel } = useMemo(() => {
    if (!currentBlotter) return headerConfigurationDefaultState;
    return {
      logoSrc: isFlowBlotter(currentBlotter) ? JASPER_LOGO : MASISON_LOGO,
      logoClassName: isFlowBlotter(currentBlotter) ? '' : styles['logo-madison'],
      appLabel: isFlowBlotter(currentBlotter) ? JASPER : ''
    };
  }, [currentBlotter]);

  return (
    <div className={`${styles.container} ${disableDragStyle}`}>
      <div className="jp-entry">
        <div className={`left ${styles.left}`}>
          <figure className={`${styles.heading} ${disableDragStyle}`}>
            <img src={logoSrc} alt={JASPER} className={`${logoClassName} ${styles.logo}`} />
            {appLabel}
          </figure>
          <div className={styles.navtab}>
            <QuickLauncher />
          </div>
        </div>
        {searchBarVisible && <ClientsSearchBar />}

        <div className="right">
          <RFQToggle className="toggle-wrap" />
          <Dropdown />
          <div className={`${styles['user-options']} ${impersonatedUser ? styles['user-options--impersonated'] : ''}`}>
            <ImpersonatedUsersProvider>
              <UserSettings />
            </ImpersonatedUsersProvider>
            <div className={styles['app-options']}>
              {showWindowOptions ? <WindowOptions {...winOptions} /> : <div className={styles['empty-nav']} />}
              <ConnectionIndicator status={connectionStatus} text={currentEnv} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
