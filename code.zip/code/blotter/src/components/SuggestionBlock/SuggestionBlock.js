import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import { SuggestionBlockItem } from '~components';
import { UserContext } from '~contexts/UserContext';
import styles from './SuggestionBlock.module.scss';
import { clientType, searchType } from '~services/axeService';
import * as usageService from '~services/usageService';
import { requestXiosWindow } from '~helpers/popups';

const SuggestionBlock = ({ current, columns, suggestions, searching, suggestionType }) => {
  const { currentUser, impersonatedUser } = useContext(UserContext);

  const handleSelection = item => {
    let popupType;
    let identifier = null;
    let notes = {};

    if (item && item.Name) {
      popupType = clientType.CUSTOMER;
      identifier = item.Id;
      notes = {
        Name: item.Name,
        Selection: searchType.CLIENT
      };
    }

    if (item && item.Ticker && !item.Cusip) {
      popupType = clientType.TICKER;
      identifier = item.Ticker;
      notes = {
        Name: item.Ticker,
        Selection: searchType.TICKER
      };
    }

    if (item && item.Cusip) {
      popupType = clientType.CUSIP;
      identifier = item.Cusip;
      notes = {
        Name: `${item.Cusip}  ${item.Ticker} ${item.Coupon}`,
        Selection: searchType.CUSIP
      };
    }

    usageService.sendUsage({ userAction: usageService.actions.SEARCH, notes: notes });

    const userData = {
      realUser: impersonatedUser ? impersonatedUser.id : currentUser,
      signedInUser: currentUser
    };

    requestXiosWindow({ userData, popupType, sendUsage: false, identifier });
  };

  const getCurrent = suggestion => suggestion === current;

  const renderResults = () => {
    if (searching) {
      return (
        <li>
          <em>Searching... </em>
        </li>
      );
    }

    if (suggestions && suggestions.length) {
      return suggestions.map((suggestion, index) => (
        <SuggestionBlockItem
          key={index}
          active={getCurrent(suggestion)}
          suggestion={suggestion}
          onSelectItem={handleSelection}
          suggestionType={suggestionType}
        />
      ));
    }

    return (
      <li>
        <em>No results</em>
      </li>
    );
  };

  return (
    <div className={styles['suggestion-block-container']}>
      <header>
        {columns.map((row, index) => (
          <span key={index}>{row}</span>
        ))}
      </header>
      <ul>{renderResults()}</ul>
    </div>
  );
};

SuggestionBlock.propTypes = {
  columns: PropTypes.array.isRequired,
  suggestions: PropTypes.array.isRequired
};

export default SuggestionBlock;
