import React from 'react';
import PropTypes from 'prop-types';
import './LauncherButton.scss';

const LauncherButton = ({ className, onClick, name }) => (
  <button data-testid="LauncherButton" className={`${className} launcher-button-container`} onClick={onClick}>
    <div className="button">{name}</div>
  </button>
);

// @Proptypes
LauncherButton.propTypes = {
  className: PropTypes.string,
  onClick: PropTypes.func,
  name: PropTypes.string
};

export default LauncherButton;
