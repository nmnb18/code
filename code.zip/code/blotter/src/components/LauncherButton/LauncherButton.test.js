import React from 'react';
import { render, cleanup, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import LauncherButton from './LauncherButton';

// Unmount everything from the dom after each test
afterEach(cleanup);

const props = {
  name: 'Flow',
  onClick: jest.fn()
};

describe('<LauncherButton />', () => {
  test('renders OK', () => {
    const { getByTestId } = render(<LauncherButton {...props} />);
    const button = getByTestId('LauncherButton');

    expect(button).toBeInTheDocument();
    expect(button.tagName).toBe('BUTTON');
  });

  test('click on button', () => {
    const { getByTestId } = render(<LauncherButton {...props} />);
    const button = getByTestId('LauncherButton');

    fireEvent.click(button);

    expect(props.onClick).toHaveBeenCalledTimes(1);
  });
});
