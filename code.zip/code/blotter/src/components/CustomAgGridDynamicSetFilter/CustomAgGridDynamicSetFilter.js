import React, { Component } from 'react';
import { Subject, of } from 'rxjs';
import { concatMap } from 'rxjs/operators';
import { SortingMenu, CustomAgGridDynamicSetFilterModal } from '~components';
import { moveFilterComponentToTheLeft, focusTextBox } from '~helpers/customFilterArrangement';
import { isEmpty, hasItems } from 'flow-navigator-shared/dist/array';
import { WS_COMMANDS } from '~helpers/jasperMessage';
import { ascCompare } from '~helpers/sort';
import { multiFilterStore, safeOptionValue, safeOptionLabel } from '~patterns/singleton/multiFilterStore';
import { DYNAMIC_SET_FILTER, MAX_FILTER_SIZE } from '~constants/filters';
import { FILTER_MODEL_DYNAMIC_SET } from '~constants/filterModelTypes';
import { multiFilterService, fbEvents } from '~services/multiFilterService';
import { isNotEmpty } from '~helpers/string';

const parseNameToToken = str => (str || '').replace(/[^0-9a-zA-Z]/g, '');

const getOptionsByText = (options, searchText) =>
  searchText ? options.filter(option => option.toLowerCase().includes(searchText.toLowerCase())) : options;

const mapToOptionsBySearchText = (options, searchText = '', textFilter = '', arrayFilter = []) => {
  const availableOptions = getOptionsByText(options, searchText);

  if (searchText)
    return availableOptions.map((option, index) => ({
      pos: index,
      value: option,
      label: safeOptionLabel(option),
      checked: true
    }));

  const checkArray = Boolean(arrayFilter.length);

  return availableOptions.map((option, index) => {
    const optionConfig = { pos: index, value: option, label: safeOptionLabel(option) };
    if (checkArray && arrayFilter.includes(option)) return { ...optionConfig, checked: true };

    const optionMatch = textFilter && option.toLowerCase().includes(textFilter.toLowerCase());
    return { ...optionConfig, checked: optionMatch };
  });
};

const mapToDefaultOptions = options =>
  options.map((option, index) => ({
    pos: index,
    value: option,
    label: safeOptionLabel(option),
    checked: true
  }));

const mapToOptionsByFilters = (options, arrayFilter = []) => {
  const selectAll = isEmpty(arrayFilter);

  return options.map((option, index) => {
    const optionConfig = { pos: index, value: option, label: safeOptionLabel(option) };
    if (selectAll) return { ...optionConfig, checked: true };

    const isOptionsChecked = arrayFilter.includes(option);
    return { ...optionConfig, checked: isOptionsChecked };
  });
};

const mapToFilterOptions = (options, optionsState, textFilter = '', arrayFilter = [], searchText = '') => {
  const newAvailableOptions = getOptionsByText(options, searchText);
  const checkArray = Boolean(arrayFilter.length);

  return newAvailableOptions.map((option, index) => {
    const optionConfig = { pos: index, value: option, label: safeOptionLabel(option) };
    const optionEntity = optionsState[parseNameToToken(option)];

    if (optionEntity) return { ...optionConfig, checked: Boolean(optionEntity.checked) };

    if (checkArray) {
      return { ...optionConfig, checked: arrayFilter.includes(option) };
    }

    const isAllCheck = Object.keys(optionsState)
      .map(key => optionsState[key])
      .every(o => o.checked);

    const optionMatch = textFilter ? option.toLowerCase().includes(textFilter.toLowerCase()) : isAllCheck;
    return { ...optionConfig, checked: optionMatch };
  });
};

const checkAvailableOptionsByTextFilter = (availableOptions, textFilter = '') =>
  availableOptions.map((option, index) => {
    const optionMatch = !!textFilter && option.value.toLowerCase().includes(textFilter.toLowerCase());

    return {
      pos: index,
      value: option.value,
      label: option.label,
      checked: optionMatch
    };
  });

const checkAvailableOptionsByArrayFilter = (availableOptions, arrayFilter = []) => {
  const arrayIsEmpty = isEmpty(arrayFilter);
  const arrayHasItems = hasItems(arrayFilter);

  return availableOptions.map((option, index) => {
    const isChecked = arrayIsEmpty || (arrayHasItems && arrayFilter.includes(option.value));

    return {
      pos: index,
      value: option.value,
      label: option.label,
      checked: isChecked
    };
  });
};

class CustomAgGridDynamicSetFilter extends Component {
  tempOptionList = [];

  constructor(props) {
    super(props);

    this.state = {
      arrayFilter: [],
      textFilter: '',
      textFilterOptions: [],
      options: [],
      availableOptions: [],
      selectAll: true,
      searchText: '',
      direction: props.column.getSort(),
      multiFilterId: `${props.agGridReact.props.id}-${props.colDef.field}`,
      loading: true
    };

    this.myRef = React.createRef();
    this.hidePopup = null;
    this.filters$ = new Subject();
  }

  componentDidMount() {
    this.filterSubscription = this.filters$
      .pipe(concatMap(filterEvent => of(filterEvent)))
      .subscribe(this.updateFilterOptions);
  }

  componentWillUnmount() {
    this.filterSubscription && this.filterSubscription.unsubscribe();
  }

  getDefaultState = () => ({
    arrayFilter: [],
    textFilter: '',
    textFilterOptions: [],
    options: [],
    availableOptions: [],
    selectAll: true,
    searchText: ''
  });

  handleApply = addCurrentSelection => {
    const {
      filterChangedCallback,
      colDef: { field }
    } = this.props;
    const {
      multiFilterId,
      arrayFilter,
      textFilterOptions,
      availableOptions,
      options,
      selectAll,
      searchText
    } = this.state;

    let updatedArrayFilter;
    const optionsCopy = [...options];
    const availableOptionsCopy = [...availableOptions];
    const textFilterOptionsCopy = [...textFilterOptions];

    const checkedOptions = availableOptionsCopy.filter(o => o.checked).map(o => o.value);
    const uncheckedOptions = availableOptionsCopy.filter(o => !o.checked).map(o => o.value);

    if (addCurrentSelection) {
      const remainingArrayFilter = arrayFilter.filter(o => !uncheckedOptions.includes(o));
      updatedArrayFilter = Array.from(new Set([...remainingArrayFilter, ...textFilterOptionsCopy, ...checkedOptions]));
    } else {
      if (selectAll) {
        updatedArrayFilter = searchText ? getOptionsByText(optionsCopy, searchText) : [];
      } else {
        updatedArrayFilter = searchText ? getOptionsByText(checkedOptions, searchText) : [...checkedOptions];
      }
    }

    // rough filter length estimation.
    // We could refine this to more accurately get length, but not really essential.
    // Concept is we are not allowing filters to be over ~50kb as ws max message is 64kb so if calculation is off by ~1kb it's not a problem.
    const existingFilters = this.props.api.getFilterModel();
    existingFilters[field] && delete existingFilters[field];
    const roughFilterLength = JSON.stringify(existingFilters).length + `'${updatedArrayFilter.join("','")}'`.length;

    if (roughFilterLength > MAX_FILTER_SIZE) {
      this.props.agGridReact.props.toggleShowFilterTooBigMessage(true);
      return;
    }

    const isSelectAll = !searchText ? selectAll : false;
    const updatedAvailableOptions = mapToOptionsByFilters(optionsCopy, updatedArrayFilter);

    const updatedState = this.getDefaultState();
    updatedState.options = optionsCopy;
    updatedState.arrayFilter = updatedArrayFilter;
    updatedState.availableOptions = updatedAvailableOptions;
    updatedState.selectAll = isSelectAll;

    multiFilterStore.initMap(multiFilterId);

    this.setState(updatedState, () => {
      filterChangedCallback({
        columnMetadata: {
          filterType: DYNAMIC_SET_FILTER,
          field,
          isEmpty: isEmpty(updatedArrayFilter)
        }
      });
    });
  };

  handleReset = () => {
    const {
      filterChangedCallback,
      colDef: { field }
    } = this.props;
    const { multiFilterId, arrayFilter, textFilter, options } = this.state;

    const updatedState = this.getDefaultState();
    updatedState.options = options;
    updatedState.availableOptions = mapToDefaultOptions(options);

    multiFilterStore.initMap(multiFilterId);
    multiFilterService.clearMultiFilter();

    if (isEmpty(arrayFilter) && !textFilter) {
      this.hidePopup && this.hidePopup();
      this.setState(updatedState);
      return;
    }

    this.setState(updatedState, () => {
      filterChangedCallback({
        columnMetadata: {
          filterType: DYNAMIC_SET_FILTER,
          field,
          isEmpty: true
        }
      });
    });
  };

  handleCancel = () => {
    const { multiFilterId, arrayFilter, textFilter, textFilterOptions, options } = this.state;
    const updatedState = this.getDefaultState();
    updatedState.options = options;

    if (isEmpty(arrayFilter) && !textFilter) {
      updatedState.availableOptions = mapToDefaultOptions(options);
    } else if (textFilter) {
      updatedState.textFilter = textFilter;
      updatedState.textFilterOptions = textFilterOptions;
      updatedState.availableOptions = mapToOptionsByFilters(options, textFilterOptions);
    } else if (hasItems(arrayFilter)) {
      updatedState.arrayFilter = arrayFilter;
      updatedState.availableOptions = mapToOptionsByFilters(options, arrayFilter);
    }

    updatedState.selectAll = updatedState.availableOptions?.every(o => o.checked);

    multiFilterStore.initMap(multiFilterId);

    this.setState(updatedState);
    this.hidePopup && this.hidePopup();
  };

  getModel = () => {
    if (isEmpty(this.state.arrayFilter) && !this.state.textFilter) return undefined;

    return {
      field: this.props.colDef.field,
      headerName: this.props.colDef.headerName,
      arrayFilter: this.state.arrayFilter,
      textFilter: this.state.textFilter,
      filterType: FILTER_MODEL_DYNAMIC_SET,
      type: ''
    };
  };

  setModel = model => {
    const {
      filterChangedCallback,
      colDef: { field }
    } = this.props;

    const { multiFilterId } = this.state;
    multiFilterStore.initMap(multiFilterId);

    const updatedState = {
      selectAll: true,
      arrayFilter: [],
      textFilter: '',
      textFilterOptions: []
    };

    const fetchFilterOptions = Boolean(model?.fetchFilterOptions);
    let skipFetch = false;

    if (model) {
      const availableOptionsCopy = [...this.state.availableOptions];
      const optionsCopy = [...this.state.options];

      if (model.textFilter) {
        updatedState.textFilter = model.textFilter;
        updatedState.textFilterOptions = model.textFilter
          ? optionsCopy.filter(o => o.toLowerCase().includes(model.textFilter.toLowerCase()))
          : [];
        updatedState.availableOptions = checkAvailableOptionsByTextFilter(availableOptionsCopy, model.textFilter);
      } else {
        updatedState.arrayFilter = [...model.arrayFilter];
        updatedState.availableOptions = checkAvailableOptionsByArrayFilter(availableOptionsCopy, model.arrayFilter);
      }

      skipFetch = model.skipFetch ?? false;
      updatedState.selectAll = hasItems(updatedState.availableOptions)
        ? updatedState.availableOptions.every(o => o.checked)
        : false;
    } else {
      const { options } = this.state;
      const updatedAvailableOptions = mapToFilterOptions(options, {}, '', [], '');
      updatedState.availableOptions = updatedAvailableOptions;
    }

    this.setState(updatedState, () => {
      filterChangedCallback({
        columnMetadata: {
          filterType: DYNAMIC_SET_FILTER,
          field,
          isEmpty: fetchFilterOptions || !model,
          skipFetch
        }
      });
    });
  };

  isFilterActive = () => hasItems(this.state.arrayFilter) || isNotEmpty(this.state.textFilter);

  afterGuiAttached = async ({ hidePopup }) => {
    const { multiFilterId } = this.state;
    const {
      colDef: { field }
    } = this.props;
    const switchedView = multiFilterService.hasSwitchedView();

    if (switchedView) multiFilterService.setMultiFilterEvent(fbEvents.READY_TO_FETCH);

    if (multiFilterService.shouldSendMultiFilterRequest(field) || switchedView) {
      multiFilterService.sendMultiFilterRequest({ field, multiFilterId, event: fbEvents.FETCH });
      this.setState({ loading: true, options: [], availableOptions: [] });
    }

    this.hidePopup = hidePopup;
    const customFilterContainer = this.myRef.current;

    if (customFilterContainer) {
      focusTextBox(customFilterContainer);
      moveFilterComponentToTheLeft(customFilterContainer);
    }
  };

  updateFilterOptions = ({ option, command }) => {
    const { multiFilterId, options, textFilter, arrayFilter, searchText } = this.state;
    const optionsCopy = [...options];

    let updatedOptions;
    let optional = {};

    const commandHandler = {
      [WS_COMMANDS.GROUP_BEGIN]: () => {
        updatedOptions = [];
        multiFilterStore.initSet(multiFilterId);
        multiFilterStore.initMap(multiFilterId);
      },
      [WS_COMMANDS.NEW_MESSAGE_SOW]: () => {
        multiFilterStore.addSetOption(multiFilterId, option);
      },
      [WS_COMMANDS.GROUP_END]: () => {
        const cachedOptionList = multiFilterStore.getSetOptions(multiFilterId);
        updatedOptions = Array.from(cachedOptionList).sort(ascCompare);
        optional.loading = false;
      },
      [WS_COMMANDS.NEW_MESSAGE]: () => {
        const optionList = new Set([...optionsCopy, safeOptionValue(option)]);
        updatedOptions = Array.from(optionList).sort(ascCompare);
      },
      [WS_COMMANDS.DELETE_MESSAGE]: () => {
        updatedOptions = optionsCopy.filter(opt => opt !== safeOptionValue(option));
      }
    };

    const handler = commandHandler[command];
    handler && handler();

    if (!updatedOptions) return;

    const optionsState = multiFilterStore.getMap(multiFilterId);
    const optionsStateCopy = { ...optionsState };

    const optionValue = safeOptionValue(option);
    const optionToken = parseNameToToken(optionValue);

    if (command === WS_COMMANDS.DELETE_MESSAGE && optionsStateCopy[optionToken]) {
      delete optionsStateCopy[optionToken];
      multiFilterStore.setMap(multiFilterId, optionsStateCopy);
    }

    const textFilterOptions = textFilter
      ? updatedOptions.filter(o => o.toLowerCase().includes(textFilter.toLowerCase()))
      : [];
    const updatedAvailableOptions = mapToFilterOptions(
      updatedOptions,
      optionsStateCopy,
      textFilter,
      arrayFilter,
      searchText
    );

    const selectAll = hasItems(updatedAvailableOptions) ? updatedAvailableOptions.every(o => o.checked) : true;

    this.setState({
      options: updatedOptions,
      availableOptions: updatedAvailableOptions,
      textFilterOptions,
      selectAll,
      ...optional
    });
  };

  handleSearchTextChange = searchText => {
    const { multiFilterId, options, arrayFilter, textFilter } = this.state;
    const optionsCopy = [...options];

    const optionsState = multiFilterStore.getMap(multiFilterId);
    const optionsStateCopy = { ...optionsState };
    const availableOptions = mapToOptionsBySearchText(optionsCopy, searchText, textFilter, arrayFilter);

    availableOptions.forEach(option => {
      optionsStateCopy[parseNameToToken(option.value)] = option;
    });

    multiFilterStore.setMap(multiFilterId, optionsStateCopy);

    const selectAll = availableOptions.every(o => o.checked);
    const isSelectAll = searchText ? true : selectAll;

    this.setState({
      availableOptions,
      searchText,
      selectAll: isSelectAll
    });
  };

  handleToggle = option => {
    const { multiFilterId } = this.state;
    const availableOptionsCopy = [...this.state.availableOptions];
    const optionIndex = availableOptionsCopy.findIndex(ao => ao.value === option.value);

    if (optionIndex !== -1) {
      availableOptionsCopy[optionIndex] = { ...availableOptionsCopy[optionIndex], checked: !option.checked };

      const optionsState = multiFilterStore.getMap(multiFilterId);
      const optionsStateCopy = { ...optionsState };

      optionsStateCopy[parseNameToToken(option.value)] = availableOptionsCopy[optionIndex];
      multiFilterStore.setMap(multiFilterId, optionsStateCopy);

      const selectAll = availableOptionsCopy.every(o => o.checked);

      this.setState({
        availableOptions: availableOptionsCopy,
        selectAll
      });
    }
  };

  handleToggleAll = ({ target: { checked } }) => {
    const { multiFilterId } = this.state;
    const availableOptionsCopy = [...this.state.availableOptions];

    const optionsState = multiFilterStore.getMap(multiFilterId);
    const optionsStateCopy = { ...optionsState };

    availableOptionsCopy.forEach(option => {
      option.checked = checked;
      optionsStateCopy[parseNameToToken(option.value)] = option;
    });

    multiFilterStore.setMap(multiFilterId, optionsStateCopy);

    this.setState({
      availableOptions: availableOptionsCopy,
      selectAll: checked
    });
  };

  setDirection = direction => {
    const { column, api } = this.props;
    const multisort = false;
    api.sortController.setSortForColumn(column, direction, multisort);
    this.setState({ direction });
  };

  render() {
    const { sortable } = this.props;
    const { availableOptions, direction, selectAll, searchText, arrayFilter, textFilterOptions, loading } = this.state;

    return (
      <div ref={this.myRef}>
        <CustomAgGridDynamicSetFilterModal
          selectAll={selectAll}
          searchText={searchText}
          availableOptions={availableOptions}
          arrayFilter={arrayFilter}
          textFilterOptions={textFilterOptions}
          onSearchTextChange={this.handleSearchTextChange}
          onToggle={this.handleToggle}
          onToggleAll={this.handleToggleAll}
          onApply={this.handleApply}
          onCancel={this.handleCancel}
          onReset={this.handleReset}
          sortingMenu={sortable ? <SortingMenu direction={direction} setDirection={this.setDirection} /> : null}
          loading={loading}
        />
      </div>
    );
  }
}

export default CustomAgGridDynamicSetFilter;
