import React from 'react';
import styles from './ConnectionIndicator.module.scss';

const getStatusStyle = status => {
  if (!status) return 'gray';
  return status === 'on' ? 'online' : 'offline';
};

const ConnectionIndicator = ({ status, text }) => (
  <div className={styles.connectionLabel}>
    <label>{text}</label>
    <div className={styles[`circle--${getStatusStyle(status)}`]}></div>
  </div>
);

export default ConnectionIndicator;
