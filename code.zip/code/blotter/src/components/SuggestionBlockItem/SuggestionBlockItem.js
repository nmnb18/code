import React, { useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import styles from './SuggestionBlockItem.module.scss';
import { clientType } from '~services/axeService';

// Axeom API response structure   {Client: [], Security: [], Ticker: []}
// Client (CLIENT section)        {Id, IsMine, Name}
// Ticker (TICKER section)        {IssuerName, Ticker}
// Security (CUSIP section)       {Coupon, Cusip, Is144a, IsAxed, MaturityDateMMddyyyy, SeriesDesc, Ticker}

function CustomerItem({ Name, IsMine, iBackupAccount }) {
  const iBackupAccountClass = (!IsMine && iBackupAccount) ? styles['suggestion-block-item__coverage-backup'] : '';
  return (
    <>
      {Name && <span className={styles['suggestion-block-item__client-name']}>{Name}</span>}
      {(IsMine || iBackupAccount) && <span className={`${styles['suggestion-block-item__coverage']} ${iBackupAccountClass}`}>C</span>}
    </>
  );
}

function CusipItem({ SecurityInfo, Cusip, IsAxed }) {
  return (
    <>
      {Cusip && <span className={`${styles['suggestion-block-item__name']}`}>{Cusip}</span>}
      <span className={styles['suggestion-block-item__detail']}>{`${SecurityInfo}`}</span>
      {IsAxed && <span className={`${styles['rfq-axed-content']}`}>AXE</span>}
    </>
  );
}

function TickerItem({ Ticker, IssuerName }) {
  return (
    <>
      {Ticker && <span className={styles['suggestion-block-item__name']}> {Ticker}</span>}
      {IssuerName && <span className={styles['suggestion-block-item__detail']}>{IssuerName}</span>}
    </>
  );
}

const renderSuggestion = (suggestion, type) => {
  if (type === clientType.CUSTOMER) {
    return <CustomerItem {...suggestion} />;
  } else if (type === clientType.CUSIP) {
    return <CusipItem {...suggestion} />;
  } else if (type === clientType.TICKER) {
    return <TickerItem {...suggestion} />;
  } else return null;
};

function SuggestionBlockItem({ suggestion, onSelectItem, active, suggestionType }) {
  const myRef = useRef(null);
  const { IsAxed, IsMine, iBackupAccount } = suggestion;

  useEffect(() => {
    active ? myRef.current.focus() : myRef.current.blur();
  }, [active]);

  const iconFlagClass = IsAxed || IsMine || iBackupAccount ? styles['suggestion-block-item--hasIconFlag'] : '';
  const activeClass = active ? styles['suggestion-block-item--active'] : '';

  return (
    <button
      ref={myRef}
      onClick={() => onSelectItem(suggestion)}
      className={`${styles['suggestion-block-item']} ${iconFlagClass} ${activeClass}`}
    >
      {renderSuggestion(suggestion, suggestionType)}
    </button>
  );
}

SuggestionBlockItem.propTypes = {
  suggestion: PropTypes.shape({
    Name: PropTypes.string,
    IssuerName: PropTypes.string,
    Cusip: PropTypes.string,
    MaturityDateMMddyyyy: PropTypes.string,
    Ticker: PropTypes.string,
    IsAxed: PropTypes.bool
  }),
  onSelectItem: PropTypes.func
};

export default SuggestionBlockItem;
