import React, { useState, useContext, memo, useEffect, useRef } from 'react';
import { of, Subject } from 'rxjs';
import { debounceTime, tap, switchMap, catchError } from 'rxjs/operators';
import { SearchBar, SuggestionBlock } from '~components';
import { UserContext } from '~contexts/UserContext';
import * as axeService from '~services/axeService';
import { useClickOutside } from '~hooks';
import { KEYS } from '~helpers/keyCodes';
import styles from './ClientsSearchBar.module.scss';

const { clientType } = axeService;

const USER_TYPING_INTERVAL = 250;
const initialSearchResults = {
  customers: [],
  tickers: [],
  cusips: []
};

const ClientsSearchBar = () => {
  const [searchResults, setSearchResults] = useState(initialSearchResults);
  const [input, setInput] = useState('');
  const [resetInput, setResetInput] = useState(false);
  const { currentUser, impersonatedUser } = useContext(UserContext);
  const [allResults, setAllResults] = useState([]);
  const [current, setCurrent] = useState(null);
  const [cursor, setCursor] = useState(-1);
  const [inputActive, setInputActive] = useState(false);
  const myRef = useRef();
  const [isOpen, setIsOpen] = useClickOutside(myRef);
  const searchSubject = useRef(new Subject());

  const searchResultSubject$ = new Subject();
  const [customerSearching, setCustomerSearching] = useState(false);
  const [tickerSearching, setTickerSearching] = useState(false);
  const [cusipSearching, setCusipSearching] = useState(false);

  const blotterUser = impersonatedUser ? impersonatedUser.id : currentUser;
  const impersonater = impersonatedUser ? currentUser : null;

  const setResults = ({ customers = [], tickers = [], cusips = [] }) => {
    const results = [...customers, ...tickers, ...cusips];
    setAllResults(results);
    setCurrent(results[cursor]);
    setSearchResults({ customers, tickers, cusips });
  };

  // Keep listening to input, handle debounc and set all initial flags
  useEffect(() => {
    const searchSubscription = searchSubject.current
      .pipe(
        debounceTime(USER_TYPING_INTERVAL),
        tap(({ userInput }) => {
          setInput(userInput);
          setCustomerSearching(true);
          setTickerSearching(true);
          setCusipSearching(true);
          setIsOpen(true);
          if (userInput) {
            searchResultSubject$.next({ blotterUser, userInput, impersonater });
          }
        })
      )
      .subscribe();
    return () => {
      searchSubscription.unsubscribe();
    };
  }, [blotterUser]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    let customers = [];
    let tickers = [];
    let cusips = [];
    const searchSubscriptionCustomer = searchResultSubject$
      .pipe(
        switchMap(({ blotterUser, userInput, impersonater }) =>
          axeService
            .getClientsByType(blotterUser, userInput, axeService.searchApiType.CUSTOMER, impersonater)
            .pipe(catchError(() => of({})))
        )
      )
      .subscribe(res => {
        if (res?.data?.results) {
          setCustomerSearching(false);
          customers = res.data.results;
          setResults({ customers, tickers, cusips });
        }
      });
    const searchSubscriptionTicker = searchResultSubject$
      .pipe(
        switchMap(({ blotterUser, userInput }) =>
          axeService
            .getClientsByType(blotterUser, userInput, axeService.searchApiType.TICKER, impersonater)
            .pipe(catchError(() => of({})))
        )
      )
      .subscribe(res => {
        if (res?.data?.results) {
          setTickerSearching(false);
          tickers = res.data.results;
          setResults({ customers, tickers, cusips });
        }
      });
    const searchSubscriptiomCusip = searchResultSubject$
      .pipe(
        switchMap(({ blotterUser, userInput }) =>
          axeService
            .getClientsByType(blotterUser, userInput, axeService.searchApiType.BOND, impersonater)
            .pipe(catchError(() => of({})))
        )
      )
      .subscribe(res => {
        if (res?.data?.results) {
          setCusipSearching(false);
          cusips = res.data.results;
          setResults({ customers, tickers, cusips });
        }
      });
    return () => {
      searchSubscriptionCustomer.unsubscribe();
      searchSubscriptionTicker.unsubscribe();
      searchSubscriptiomCusip.unsubscribe();
    };
  }, [blotterUser]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleInputChange = userInput => searchSubject.current.next({ userInput, blotterUser, impersonater });

  useEffect(() => {
    setCurrent(allResults[cursor]);
  }, [cursor, allResults]);

  useEffect(() => {
    // if user impersonate somebody else I need to reset all the search results
    setResetInput(true);
    setResults({});
    // eslint-disable-next-line
  }, [blotterUser]);

  const handleFocus = () => input.length > 0 && setIsOpen(true);

  const handleOnResetInput = () => setResetInput(false);

  const handleKeyDown = e => {
    if (e.keyCode === KEYS.ESC) {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    input.length > 0 ? setIsOpen(true) : setIsOpen(false);
  }, [input, setIsOpen]);

  useEffect(() => {
    const handleKeyDownListener = event => {
      const { keyCode } = event;
      const active = document.activeElement;
      if (keyCode === KEYS.ENTER) {
        if (active instanceof HTMLElement) active.click();
      } else if (keyCode === KEYS.UP) {
        event.preventDefault();
        cursor > 0 ? setCursor(cursor - 1) : setCursor(allResults.length - 1);
        setInputActive(false);
      } else if (keyCode === KEYS.DOWN) {
        event.preventDefault();
        cursor < allResults.length - 1 ? setCursor(cursor + 1) : setCursor(0);
        setInputActive(false);
      } else {
        setInputActive(true);
        setCursor(-1);
      }
    };

    if (isOpen) {
      window.addEventListener('keydown', handleKeyDownListener, true);
    }

    return () => window.removeEventListener('keydown', handleKeyDownListener, true);
  }, [isOpen, cursor, allResults]);
  const { customers, tickers, cusips } = searchResults;
  return (
    <div className={`${styles.container} center`} ref={myRef}>
      <SearchBar
        active={inputActive}
        placeholder="Launch details page for..."
        onInputChange={handleInputChange}
        onKeyDown={handleKeyDown}
        onFocus={handleFocus}
        resetInput={resetInput}
        onResetInput={handleOnResetInput}
      />
      {isOpen && input.length > 0 && (
        <section className={styles['search-bar-results']}>
          <SuggestionBlock
            current={current}
            columns={['client']}
            suggestions={customers}
            searching={customerSearching}
            suggestionType={clientType.CUSTOMER}
          />
          <SuggestionBlock
            current={current}
            columns={['ticker', 'issuer name']}
            suggestions={tickers}
            searching={tickerSearching}
            suggestionType={clientType.TICKER}
          />
          <SuggestionBlock
            current={current}
            columns={['CUSIP/ISIN', 'description']}
            suggestions={cusips}
            searching={cusipSearching}
            suggestionType={clientType.CUSIP}
          />
        </section>
      )}
    </div>
  );
};

// @Export Component
export default memo(ClientsSearchBar);
