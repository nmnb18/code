import React, { useEffect, useContext, useMemo, useCallback, useState } from 'react';
import { merge } from 'rxjs';
import { Header, IFrame, Layout, RFQContainer, ProgressBar, XiosWindowLauncher, ErrorModal } from '~components';
import { UserContext } from '~contexts/UserContext';
import { BlotterContext } from '~contexts/BlotterContext';
import { WebSocketContext } from '~contexts/WebSocketContext';
import { ColumnDictionariesContext } from '~contexts/ColumnDictionariesContext';
import { BlotterUserSettingsContext } from '~contexts/BlotterUserSettingsContext';
import { ThemeContext } from '~contexts/ThemeContext';
import { iabPublish } from '~services/openfinService';

import {
  defaultRfqGridId,
  getRequestCommand,
  getMultiFilterRequestCommand,
  getExportRequestCommand,
  getUnsubscribeRequestCommand,
  getConnectionStatus,
  UNSUBSCRIBE_MULTI,
  UNSUBSCRIBE_RANGE,
  isWSRequestSizeOk,
  defaultMainGridId
} from '~helpers/jasperWebSocket';
import { getRFQNotificationPopup } from '~helpers/userSettings';
import { blotterConfiguration } from '~helpers/blotter';
import { APP_NAME, RFQ_APP_NAME } from '~helpers/globals';
import { getFlowNavigatorUser, getBlotterUrl } from '~helpers/blotter';
import { getSubscriptionsInstances } from '~helpers/subscriptions';
import { setExtraLogsUser } from '~helpers/logger';
import { rfqNotificationService } from '~services/rfqNotificationService';
import * as usageService from '~services/usageService';
import * as userSettingsService from '~services/userSettingsService';
import { blotterContainerService } from '~services/blotterContainerService';
import { flowBlotterService } from '~services/flowBlotterService';
import { exportDataSourceService } from '~services/exportDataSourceService';
import * as openfinService from '~services/openfinService';
import {
  useApplicationRegisterUser,
  useSubscription,
  useInterApplicationBusSubscribe,
  useApplicationLaunchUsage,
  useUserEntitlement,
  useMMIConfiguration,
  useApplicationRestart,
  useDebounce,
  usePrevious
} from '~hooks';
import wsActions from '~webworkers/wsActions';
import wsWorker from 'workerize-loader!~webworkers/wsWorker'; // eslint-disable-line import/no-webpack-loader-syntax
import './App.scss';
import {
  appUsageRecordingTopic,
  appUserSettingsTopic,
  rfqNotificationTopicForChild,
  rfqNotificationActions
} from '~services/openfinConfig';
import { sharedSettingsActions } from '~helpers/userSettingsActionCreator';
import { TextButton } from '~ui-library';
import { UserEntitlementContext } from '~contexts/UserEntitlementContext';

const fin = window.fin;
let worker;

const {
  INIT_WS,
  INIT_WS_SUCCESS,
  CONNECT_WS,
  CONNECT_WS_SUCCESS,
  DISCONNECT_WS,
  DISCONNECT_WS_SUCCESS,
  SUBSCRIBE_TO_WS_CONNECTION_STATUS_CHANGE,
  WS_REQUEST,
  WS_MS_REQUEST,
  WS_REQUEST_FILTER,
  WS_RFQ_FLOW_BLOTTER_RESPONSE,
  WS_RFQ_NOTIFICATION_RESPONSE,
  WS_RFQ_EXPORT_DATASOURCE_RESPONSE,
  WS_MULTI_FILTER_FLOW_BLOTTER_RESPONSE,
  WS_MULTI_FILTER_RFQ_NOTIFICATION_RESPONSE
} = wsActions;

const rfqPopupToggleDebounceTime = 300;

export const App = () => {
  const { rfqNotificationsColumnsDictionary, mainBlotterColumnsDictionary } = useContext(ColumnDictionariesContext);
  const {
    currentUser,
    currentComputer,
    impersonatedUser,
    toggles,
    filterToggles,
    rfqToggles,
    rfqFilterToggles,
    setWindowOptions
  } = useContext(UserContext);
  const {
    webSocketInitialized,
    webSocketUser,
    webSocketDisconnected,
    ampsConnected,
    setWebSocketInitialized,
    setWebSocketUser,
    setAmpsAndWebSocketStatus
  } = useContext(WebSocketContext);

  const { blotter, setFlowBlotterMounted } = useContext(BlotterContext);
  const { blotterUserSettings, setBlotterUserSettings } = useContext(BlotterUserSettingsContext);
  const { userEntitlement, impersonatedUserEntitlement } = useContext(UserEntitlementContext);

  const isRFQNotificationToggleOn = useMemo(() => getRFQNotificationPopup(blotterUserSettings, APP_NAME), [
    blotterUserSettings
  ]);
  const entitlement = useUserEntitlement();

  const { theme } = useContext(ThemeContext);

  useEffect(() => {
    openfinService.deleteCacheOnExit();
    openfinService.showVersion();
  }, []);

  useApplicationRestart();
  useMMIConfiguration(setWindowOptions);
  useApplicationRegisterUser(currentUser);

  useEffect(() => {
    worker = new wsWorker();

    const handleWsWorkerResponse = message => {
      if (!message) return;

      const { type } = message.data;
      const action = wsActions[type];
      if (!action) return;

      const { payload } = message.data;

      switch (type) {
        case INIT_WS_SUCCESS: {
          setWebSocketInitialized(true);
          return;
        }
        case CONNECT_WS_SUCCESS: {
          return;
        }
        case DISCONNECT_WS_SUCCESS: {
          setWebSocketUser(null);
          return;
        }
        case SUBSCRIBE_TO_WS_CONNECTION_STATUS_CHANGE: {
          const { ampsConnected, webSocketDisconnected } = payload;
          setAmpsAndWebSocketStatus(ampsConnected, webSocketDisconnected);
          return;
        }
        case WS_RFQ_FLOW_BLOTTER_RESPONSE: {
          const { message } = payload;
          flowBlotterService.dataSource$.next(message);
          return;
        }
        case WS_RFQ_NOTIFICATION_RESPONSE: {
          const { message } = payload;
          rfqNotificationService.dataSource$.next(message);
          return;
        }
        case WS_RFQ_EXPORT_DATASOURCE_RESPONSE: {
          const { message } = payload;
          exportDataSourceService.dataSource$.next(message);
          return;
        }
        case WS_MULTI_FILTER_FLOW_BLOTTER_RESPONSE: {
          const { message } = payload;
          flowBlotterService.multiFilterSource$.next(message);
          return;
        }
        case WS_MULTI_FILTER_RFQ_NOTIFICATION_RESPONSE: {
          const { message } = payload;
          rfqNotificationService.multiFilterSource$.next(message);
          return;
        }
        default:
          return;
      }
    };

    worker.addEventListener('message', handleWsWorkerResponse);
    worker.handleWsWorkerRequest({ type: INIT_WS });

    return () => {
      worker.removeEventListener('message', handleWsWorkerResponse);
      worker.terminate();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    blotterContainerService.initFlow();
  }, []);

  // set the log user for determining whether to log extra data
  useEffect(() => {
    if (currentUser) {
      setExtraLogsUser(impersonatedUser ? impersonatedUser.id : currentUser);
    }
  }, [currentUser, impersonatedUser]);

  useEffect(() => {
    if (webSocketUser) {
      flowBlotterService.sendMessage({ ampsConnected, webSocketDisconnected });
      rfqNotificationService.setConnectionStatus({ ampsConnected, webSocketDisconnected });
    }
  }, [webSocketUser, ampsConnected, webSocketDisconnected]);

  useEffect(() => {
    if (webSocketUser && isRFQNotificationToggleOn) {
      rfqNotificationService.sendStateChangesToRFQNotification({ ampsConnected, webSocketDisconnected });
    }
  }, [webSocketUser, isRFQNotificationToggleOn, ampsConnected, webSocketDisconnected]);

  useSubscription(usageService.initUpdateUsageSubscription);
  useApplicationLaunchUsage();
  useInterApplicationBusSubscribe(openfinService.applicationIdentity, appUsageRecordingTopic, usageService.sendUsage);

  useSubscription(userSettingsService.initUpdateUserSettingsSubscription, setBlotterUserSettings);
  useInterApplicationBusSubscribe(
    openfinService.applicationIdentity,
    appUserSettingsTopic,
    userSettingsService.saveAndRehydrateUserSettings
  );

  useEffect(() => {
    if (webSocketInitialized && currentUser) {
      const flowNavigatorUser = getFlowNavigatorUser(currentUser, impersonatedUser);

      if (webSocketUser && flowNavigatorUser !== webSocketUser) {
        worker.handleWsWorkerRequest({ type: DISCONNECT_WS });
      } else if (!webSocketUser) {
        setWebSocketUser(flowNavigatorUser);
      }
    }
  }, [webSocketInitialized, currentUser, impersonatedUser, webSocketUser, setWebSocketUser]);

  const webSocketUserPrevious = usePrevious(webSocketUser);
  const impersonatedUserPrevious = usePrevious(impersonatedUser);
  useEffect(() => {
    if (webSocketUser && webSocketUser !== webSocketUserPrevious) {
      const columnsDictionaries = {
        [APP_NAME]: mainBlotterColumnsDictionary,
        [RFQ_APP_NAME]: rfqNotificationsColumnsDictionary
      };
      worker.handleWsWorkerRequest({
        type: CONNECT_WS,
        payload: { user: webSocketUser, columnsDictionaries }
      });

      const {
        rfqSubscriptionInstanceId,
        rfqMultiFilterSourceInstanceId,
        flowSubscriptionInstanceId,
        flowMultiFilterSourceInstanceId,
        exportDataSourceInstanceId
      } = getSubscriptionsInstances({
        signedInUser: currentUser,
        flowNavigatorUser: webSocketUser,
        computerId: currentComputer
      });

      rfqNotificationService.setInitialConfiguration(
        webSocketUser,
        currentComputer,
        rfqSubscriptionInstanceId,
        rfqMultiFilterSourceInstanceId,
        currentUser,
        impersonatedUser,
        entitlement,
        Boolean(impersonatedUser)
      );
      flowBlotterService.setInitialConfiguration(
        webSocketUser,
        currentComputer,
        flowSubscriptionInstanceId,
        flowMultiFilterSourceInstanceId,
        currentUser
      );
      exportDataSourceService.setInitialConfiguration(
        webSocketUser,
        currentComputer,
        exportDataSourceInstanceId,
        currentUser
      );
    }

    return () => {
      if (
        (impersonatedUser && impersonatedUser !== impersonatedUserPrevious) ||
        (!impersonatedUser && impersonatedUserPrevious)
      ) {
        rfqNotificationService.removeRFQPopupSubscriptionsOnChangeUser();
      }
    };
  }, [
    currentComputer,
    currentUser,
    entitlement,
    impersonatedUser,
    impersonatedUserPrevious,
    mainBlotterColumnsDictionary,
    rfqNotificationsColumnsDictionary,
    webSocketUser,
    webSocketUserPrevious
  ]);

  useEffect(() => {
    rfqNotificationService.setEntitlement(entitlement);
  }, [entitlement]);

  useEffect(() => {
    if (webSocketUser) {
      rfqNotificationService.setToggles(rfqToggles);
      rfqNotificationService.setFilterToggles(rfqFilterToggles);
    }
  }, [webSocketUser, rfqToggles, rfqFilterToggles]);

  const [isInitiated, setIsInitiated] = useState(false);
  const [isFetchingData, setIsFetchingData] = useState(false);
  const [processedRecord, setProcessedRecord] = useState(0);
  const [totalRecords, setTotalRecords] = useState(0);

  const isInitiatedPrevious = usePrevious(isInitiated);
  useEffect(() => {
    if (isInitiated && !isInitiatedPrevious) {
      console.log(`rfqPopup action: App started with RFQ Popup turned ${isRFQNotificationToggleOn ? 'on' : 'off'}.`);
    } else if (impersonatedUser && impersonatedUser !== impersonatedUserPrevious) {
      console.log(
        `rfqPopup action: Impersonated '${impersonatedUser.name}' with RFQ Popup turned ${
          isRFQNotificationToggleOn ? 'on' : 'off'
        } on load.`
      );
    } else if (!impersonatedUser && impersonatedUserPrevious) {
      console.log(
        `rfqPopup action: Returned to self with RFQ Popup turned ${isRFQNotificationToggleOn ? 'on' : 'off'} on load.`
      );
    }
  }, [
    ampsConnected,
    blotterUserSettings,
    isInitiated,
    isRFQNotificationToggleOn,
    isInitiatedPrevious,
    impersonatedUser,
    impersonatedUserPrevious
  ]);

  useEffect(() => {
    let filterSubscription, fechingStatusSubscriber, processedRecordSubscriber;
    if (webSocketUser) {
      filterSubscription = rfqNotificationService.jasperWebSocketFilterSubject.subscribe(filter =>
        worker.handleWsWorkerRequest({ type: WS_REQUEST_FILTER, payload: { filter } })
      );

      fechingStatusSubscriber = exportDataSourceService.fetchingStatusSubject$.subscribe(isFetching => {
        setIsFetchingData(isFetching);
        setProcessedRecord(0);
      });

      processedRecordSubscriber = exportDataSourceService.processedRecordSubject$.subscribe(
        ({ processedRecord, totalRecords }) => {
          setProcessedRecord(processedRecord);
          setTotalRecords(totalRecords);
        }
      );
    }
    return () => {
      filterSubscription && filterSubscription.unsubscribe();
      fechingStatusSubscriber && fechingStatusSubscriber.unsubscribe();
      processedRecordSubscriber && processedRecordSubscriber.unsubscribe();
    };
  }, [webSocketUser]);

  useEffect(() => {
    if (webSocketUser && blotter) {
      if (blotter === blotterConfiguration.flow) {
        flowBlotterService.initPublishFlow();

        exportDataSourceService.initPublishFlow();
      } else {
        flowBlotterService.removePublishFlow();
        flowBlotterService.handleUnsubscribe();

        exportDataSourceService.removePublishFlow();
      }
    }

    return () => {
      if (webSocketUser && blotter === blotterConfiguration.flow) {
        flowBlotterService.removePublishFlow();
        flowBlotterService.handleUnsubscribe();

        exportDataSourceService.removePublishFlow();
      }
    };
  }, [webSocketUser, blotter]);

  useEffect(() => {
    const finWindow = fin.desktop.Window.getCurrent();

    const handleFocusedEvent = () => {
      if (currentUser) {
        usageService.sendUsage({
          userAction: usageService.actions.FOCUSED
        });
      }
    };

    finWindow.addEventListener('focused', handleFocusedEvent);

    return () => {
      finWindow.removeEventListener('focused', handleFocusedEvent);
    };
  }, [currentUser]);

  const [wsRequestTooBig, setWsRequestTooBig] = useState(false);

  const handleRequestData = useCallback(
    ({
      isMultiFilter,
      subscriptionInstanceId,
      firstRow,
      lastRow,
      columnDefs,
      filterList,
      sortList,
      toggles,
      newCriteria,
      gridId,
      appName,
      requireRFQNotificationPopupConfiguration,
      isCoverageSelected,
      isMyDeskSelected,
      multiFilterFields
    }) => {
      const RFQNotificationSendStateChangesLog = 'rfq Notification Send State Changes Topic for Child';
      if (!ampsConnected) return;

      if (isMultiFilter) {
        const requestCommand = getMultiFilterRequestCommand({
          subscriptionInstanceId,
          gridId,
          appName,
          multiFilterFields,
          filterList,
          toggles,
          isCoverageSelected,
          isMyDeskSelected,
          impersonatingUser: impersonatedUser ? impersonatedUser.id : null,
          entitlement
        });

        if (isWSRequestSizeOk(requestCommand)) {
          worker.handleWsWorkerRequest({ type: WS_MS_REQUEST, payload: { requestCommand } });
        } else {
          console.log(`WEBSOCKET-SIZE-EXCEEDED (${gridId}: multi-select). Size: ${requestCommand.length}`);
          // handle ux for this?
        }
        return;
      }

      const customGridConfiguration = requireRFQNotificationPopupConfiguration
        ? { axeOnly: toggles.AxeOnly }
        : { sortList };

      const requestCommand = getRequestCommand({
        subscriptionInstanceId,
        firstRow,
        lastRow,
        columnDefs,
        newCriteria,
        impersonatingUser: impersonatedUser ? impersonatedUser.id : null,
        gridId,
        appName,
        entitlement,
        filterList,
        toggles,
        isCoverageSelected,
        isMyDeskSelected,
        ...customGridConfiguration
      });

      if (isWSRequestSizeOk(requestCommand)) {
        worker.handleWsWorkerRequest({ type: WS_REQUEST, payload: { requestCommand } });
        setIsInitiated(true);
        if (gridId === defaultMainGridId) {
          setWsRequestTooBig(false);
        } else {
          iabPublish({
            topic: rfqNotificationTopicForChild,
            message: {
              type: rfqNotificationActions.rfqNotificationSendStateChanges,
              payload: { wsRequestTooBig: false }
            },
            logLabel: RFQNotificationSendStateChangesLog
          });
        }
      } else {
        console.log(`WEBSOCKET-SIZE-EXCEEDED (${gridId}: data). Size: ${requestCommand.length}`);
        if (gridId === defaultMainGridId) {
          setWsRequestTooBig(true);
        } else {
          // pass state to rfq popup so it can show the problem
          iabPublish({
            topic: rfqNotificationTopicForChild,
            message: {
              type: rfqNotificationActions.rfqNotificationSendStateChanges,
              payload: { wsRequestTooBig: true }
            },
            logLabel: RFQNotificationSendStateChangesLog
          });
        }
      }
    },
    [impersonatedUser, ampsConnected, entitlement]
  );

  const handleExportRequestData = useCallback(
    ({
      subscriptionInstanceId,
      firstRow,
      lastRow,
      columnDefs,
      filterList,
      sortList,
      toggles,
      newCriteria,
      impersonatingUser,
      gridId,
      selectAllCheckboxStatus,
      selectedRowsValue,
      isCoverageSelected,
      isMyDeskSelected
    }) => {
      if (!ampsConnected) return;

      const requestCommand = getExportRequestCommand({
        subscriptionInstanceId,
        firstRow,
        lastRow,
        columnDefs,
        filterList,
        sortList,
        toggles,
        newCriteria,
        impersonatingUser,
        gridId,
        selectAllCheckboxStatus,
        selectedRowsValue,
        isCoverageSelected,
        isMyDeskSelected,
        entitlement
      });

      worker.handleWsWorkerRequest({ type: WS_REQUEST, payload: { requestCommand } });
    },
    [ampsConnected, entitlement]
  );

  const handleUnsubscribeRequest = useCallback(
    (subscriptionInstanceId, isMultiFilterRequest) => {
      if (!ampsConnected) return;

      const unsubscribeTarget = isMultiFilterRequest ? UNSUBSCRIBE_MULTI : undefined;
      const requestCommand = getUnsubscribeRequestCommand(subscriptionInstanceId, unsubscribeTarget);
      if (!requestCommand) return;

      const wsRequestType = !isMultiFilterRequest ? WS_REQUEST : WS_MS_REQUEST;

      worker.handleWsWorkerRequest({ type: wsRequestType, payload: { requestCommand } });
    },
    [ampsConnected]
  );

  const handleUnsubscribeRangeRequest = useCallback(
    subscriptionInstanceId => {
      if (!ampsConnected) return;

      const requestCommand = getUnsubscribeRequestCommand(subscriptionInstanceId, UNSUBSCRIBE_RANGE);
      if (!requestCommand) return;

      worker.handleWsWorkerRequest({ type: WS_REQUEST, payload: { requestCommand } });
    },
    [ampsConnected]
  );

  useEffect(() => {
    rfqNotificationService.initPopupSubscription();
    flowBlotterService.initBlotterSubscription();
    exportDataSourceService.initBlotterSubscription();

    return () => {
      rfqNotificationService.removePopupSubscription();
      flowBlotterService.removeBlotterSubscription();
      exportDataSourceService.removeBlotterSubscription();
    };
  }, []);

  useEffect(() => {
    if (webSocketUser && blotterUserSettings) {
      rfqNotificationService.setUserSettings(blotterUserSettings);
      flowBlotterService.setUserSettings(blotterUserSettings);
    }
  }, [webSocketUser, blotterUserSettings]);

  useEffect(() => {
    if (webSocketUser && rfqNotificationsColumnsDictionary) {
      rfqNotificationService.setColumnDictionary(rfqNotificationsColumnsDictionary);
    }
  }, [webSocketUser, rfqNotificationsColumnsDictionary]);

  const handleRFQNotificationToggleChange = useCallback(
    () => sharedSettingsActions.toggleRFQPopup({ toggledFrom: 'RFQ popup' }),
    []
  );

  const isBlotterUserConnectedToWs = useMemo(() => {
    return currentUser && webSocketUser && blotterUserSettings && blotterUserSettings.User === webSocketUser;
  }, [blotterUserSettings, currentUser, webSocketUser]);

  const isCurrentUserConnectedToWs = useMemo(() => {
    return isBlotterUserConnectedToWs && currentUser === webSocketUser && !impersonatedUser;
  }, [isBlotterUserConnectedToWs, currentUser, webSocketUser, impersonatedUser]);

  const isImpersonatedUserConnectedToWs = useMemo(() => {
    return (
      isBlotterUserConnectedToWs &&
      impersonatedUser &&
      impersonatedUser.id !== currentUser &&
      impersonatedUser.id === webSocketUser
    );
  }, [isBlotterUserConnectedToWs, currentUser, webSocketUser, impersonatedUser]);

  useEffect(() => {
    if (isCurrentUserConnectedToWs || isImpersonatedUserConnectedToWs) {
      flowBlotterService.setHandlers(handleRequestData, handleUnsubscribeRequest, handleUnsubscribeRangeRequest);

      exportDataSourceService.setHandlers(handleExportRequestData);

      rfqNotificationService.setHandlers(
        handleRequestData,
        handleRFQNotificationToggleChange,
        handleUnsubscribeRequest,
        handleUnsubscribeRangeRequest
      );
    }
  }, [
    isCurrentUserConnectedToWs,
    isImpersonatedUserConnectedToWs,
    handleRequestData,
    handleUnsubscribeRequest,
    handleUnsubscribeRangeRequest,
    handleExportRequestData,
    handleRFQNotificationToggleChange
  ]);

  const connectionStatus = useMemo(() => getConnectionStatus(ampsConnected), [ampsConnected]);

  const currentBlotter = useMemo(() => {
    const flowNavigatorUser = getFlowNavigatorUser(currentUser, impersonatedUser);
    const url = getBlotterUrl(blotter, flowNavigatorUser, currentUser, theme.value);
    return { name: blotter, url };
  }, [blotter, currentUser, impersonatedUser, theme]);

  useEffect(() => {
    let requestCloseApplicationSubscription = merge(
      flowBlotterService.flowBlotterRequestClose$,
      blotterContainerService.blotterContainerRequestClose$
    ).subscribe(() => openfinService.closeApplication());

    return () => requestCloseApplicationSubscription.unsubscribe();
  }, []);

  const showRFQPopup = useMemo(
    () => isBlotterUserConnectedToWs && rfqNotificationsColumnsDictionary && isRFQNotificationToggleOn,
    [isBlotterUserConnectedToWs, rfqNotificationsColumnsDictionary, isRFQNotificationToggleOn]
  );

  const debouncedShowRFQPopup = useDebounce(showRFQPopup, rfqPopupToggleDebounceTime);
  const debouncedIsRFQNotificationToggleOn = useDebounce(isRFQNotificationToggleOn, rfqPopupToggleDebounceTime);

  useEffect(() => {
    if (
      (isCurrentUserConnectedToWs || isImpersonatedUserConnectedToWs) &&
      debouncedIsRFQNotificationToggleOn === isRFQNotificationToggleOn
    )
      rfqNotificationService.toggleRFQNotification(debouncedIsRFQNotificationToggleOn);
  }, [
    debouncedIsRFQNotificationToggleOn,
    isRFQNotificationToggleOn,
    isCurrentUserConnectedToWs,
    isImpersonatedUserConnectedToWs
  ]);

  const handleGetAssignedBlotterUser = useCallback(() => {
    const flowBlotterState = {
      signedInUser: currentUser,
      computer: currentComputer,
      ampsConnected,
      webSocketDisconnected,
      toggles,
      filterToggles
    };

    const payload = impersonatedUser
      ? {
          user: impersonatedUser.id,
          impersonating: true,
          impersonatedUser
        }
      : {
          user: currentUser,
          impersonating: false,
          impersonatedUser: null
        };

    return { ...payload, ...flowBlotterState };
  }, [currentUser, currentComputer, ampsConnected, webSocketDisconnected, toggles, filterToggles, impersonatedUser]);

  const handleGetUserEntitlement = useCallback(() => {
    if (!impersonatedUser) return { userEntitlement };
    else if (impersonatedUserEntitlement) return { userEntitlement: impersonatedUserEntitlement };
    else return { userEntitlement: null };
  }, [impersonatedUser, userEntitlement, impersonatedUserEntitlement]);

  const handleGetBlotterUserSettings = useCallback(() => ({ blotterUserSettings }), [blotterUserSettings]);

  useEffect(() => {
    flowBlotterService.setGetters({
      getAssignedBlotterUser: handleGetAssignedBlotterUser,
      getBlotterUserSettings: handleGetBlotterUserSettings,
      getUserEntitlement: handleGetUserEntitlement
    });
  }, [handleGetAssignedBlotterUser, handleGetBlotterUserSettings, handleGetUserEntitlement]);

  useEffect(() => {
    flowBlotterService.setSetters({
      setFlowBlotterMounted
    });
  }, [setFlowBlotterMounted]);

  const renderProgressBar = () => {
    return (
      (isFetchingData && processedRecord > 0 && totalRecords > 0 && (
        <ProgressBar
          processedRecord={processedRecord}
          totalRecords={totalRecords}
          isFetchingData={isFetchingData}
        ></ProgressBar>
      )) ||
      null
    );
  };

  return (
    <>
      <XiosWindowLauncher theme={theme.value} />
      <ErrorModal
        isOpen={wsRequestTooBig}
        content={<div>Query is too big to send. Try removing a filter or use fewer columns.</div>}
        controls={
          <TextButton
            handleClick={() => {
              setWsRequestTooBig(false);
            }}
          >
            Okay
          </TextButton>
        }
      ></ErrorModal>
      <Layout
        header={currentUser && <Header currentBlotter={currentBlotter} connectionStatus={connectionStatus} />}
        content={isBlotterUserConnectedToWs && <IFrame {...currentBlotter} />}
        theme={theme.value}
      />
      {renderProgressBar()}
      {debouncedShowRFQPopup &&
        debouncedShowRFQPopup === showRFQPopup &&
        debouncedIsRFQNotificationToggleOn &&
        debouncedIsRFQNotificationToggleOn === isRFQNotificationToggleOn && (
          <RFQContainer
            gridId={defaultRfqGridId}
            requestData={handleRequestData}
            columnsDictionary={rfqNotificationsColumnsDictionary}
            userSettings={blotterUserSettings}
            signedInUser={currentUser}
            currentFinUser={webSocketUser}
            currentComputer={currentComputer}
            appName={RFQ_APP_NAME}
            rfqToggles={rfqToggles}
          />
        )}
    </>
  );
};

export default App;
