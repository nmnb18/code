import React, { useState, useEffect, useContext } from 'react';
import { interval } from 'rxjs';
import { pingApi, renewCookieInterval } from '~services/apiConfig';
import { NO_CORS_CONFIGURATION_OPTIONS, CORS_CONFIGURATION_OPTIONS } from '~services/jasperApiService';
import { CustomLoading, ErrorScreen } from '~components';
import { UserContext } from '~contexts/UserContext';
import * as usageService from '~services/usageService';

const AUTH_LOADING = 'Initializing the session.';
const AUTH_ERROR = 'Error while trying to initialize the session.';

const reNewCookie$ = interval(renewCookieInterval);
const pingApiUrl = pingApi();
const pingApiWithUserInfoAndHaltRedirectUrl = pingApi(true, true);

const Auth = ({ children }) => {
  const { setCurrentUser } = useContext(UserContext);
  const [authenticated, setAuthenticated] = useState(false);
  const [authError, setAuthError] = useState(null);

  useEffect(() => {
    fetch(pingApiUrl, NO_CORS_CONFIGURATION_OPTIONS)
      .then(() => fetch(pingApiWithUserInfoAndHaltRedirectUrl, CORS_CONFIGURATION_OPTIONS))
      .then(res => res.json())
      .then(res => {
        const {
          data: {
            response: { user: currentUser }
          }
        } = res;
        usageService.setUser(currentUser);
        setCurrentUser(currentUser);
        setAuthenticated(true);
      })
      .catch(error => setAuthError(error));

    const reNewCookieSubscription = reNewCookie$.subscribe(() => {
      fetch(pingApiUrl, NO_CORS_CONFIGURATION_OPTIONS);
    });

    return () => reNewCookieSubscription.unsubscribe();
  }, [setCurrentUser]);

  if (!authenticated) {
    if (authError) return <ErrorScreen errorTitle={AUTH_ERROR} />;

    return <CustomLoading loadingMsg={AUTH_LOADING} />;
  }

  return children;
};

export default Auth;
