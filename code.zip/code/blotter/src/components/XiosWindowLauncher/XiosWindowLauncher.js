import React, { useEffect, useCallback } from 'react';
import {
  topicForCreatingXiosWindows,
  xiosWindowsEvents,
  popupDefaultOptions,
  popupIframeOptions,
  popupSecurityOptions
} from '~helpers/popups';
import { iabSubscribe, iabUnsubscribe } from '~services/openfinService';
import { createNewFinWindow } from '~helpers/openfin';
import * as usageService from '~services/usageService';

import {
  BLOTTER_CONTAINER_URL,
  CONTAINER_ADD_INQUIRY,
  CONTAINER_ADD_INQUIRY_URL,
  CONTAINER_ADD_INQUIRY_TITLE,
  CONTAINER_MANAGE_INQUIRY,
  CONTAINER_MANAGE_INQUIRY_URL,
  CONTAINER_MANAGE_INQUIRY_TITLE,
  CONTAINER_EDIT_INQUIRY,
  CONTAINER_EDIT_INQUIRY_URL,
  CONTAINER_EDIT_INQUIRY_TITLE,
  CONTAINER_ADD_PORTFOLIO,
  CONTAINER_ADD_PORTFOLIO_URL,
  CONTAINER_ADD_PORTFOLIO_TITLE,
  CONTAINER_MANAGE_PORTFOLIO,
  CONTAINER_MANAGE_PORTFOLIO_URL,
  CONTAINER_MANAGE_PORTFOLIO_TITLE,
  CONTAINER_BOND_DASHBOARD,
  CONTAINER_BOND_DASHBOARD_TITLE,
  CONTAINER_BOND_DASHBOARD_URL,
  CONTAINER_CUSTOMER_DASHBOARD,
  CONTAINER_CUSTOMER_DASHBOARD_TITLE,
  CONTAINER_TICKER,
  CONTAINER_TICKER_TITLE
} from '~helpers/globals';

const fin = window.fin;

const getFormattedUrl = (url, user, searchtype, identifier, signedInUser, theme) => {
  let constructedUrl = `${url}?impersonator=${signedInUser}&uid=${user}`;
  constructedUrl += identifier ? `&identifier=${identifier}` : '';
  constructedUrl += searchtype ? `&searchType=${searchtype}` : '';
  constructedUrl += theme ? `&theme=${theme}` : '';
  return constructedUrl;
};

const defaultPopupTypesProperties = {
  CONTAINER_ADD_INQUIRY: {
    popUpType: CONTAINER_ADD_INQUIRY,
    popUpTitle: CONTAINER_ADD_INQUIRY_TITLE,
    popUpUrl: CONTAINER_ADD_INQUIRY_URL,
    popUpWidth: 655,
    popUpHeight: 430,
    resizable: false
  },
  CONTAINER_MANAGE_INQUIRY: {
    popUpType: CONTAINER_MANAGE_INQUIRY,
    popUpTitle: CONTAINER_MANAGE_INQUIRY_TITLE,
    popUpUrl: CONTAINER_MANAGE_INQUIRY_URL,
    popUpWidth: 1100,
    popUpHeight: 500
  },
  CONTAINER_EDIT_INQUIRY: {
    popUpType: CONTAINER_EDIT_INQUIRY,
    popUpTitle: CONTAINER_EDIT_INQUIRY_TITLE,
    popUpUrl: CONTAINER_EDIT_INQUIRY_URL,
    popUpWidth: 650,
    popUpHeight: 458,
    resizable: false
  },
  CONTAINER_ADD_PORTFOLIO: {
    popUpType: CONTAINER_ADD_PORTFOLIO,
    popUpTitle: CONTAINER_ADD_PORTFOLIO_TITLE,
    popUpUrl: CONTAINER_ADD_PORTFOLIO_URL,
    popUpWidth: 507,
    popUpHeight: 635,
    resizable: false
  },
  CONTAINER_MANAGE_PORTFOLIO: {
    popUpType: CONTAINER_MANAGE_PORTFOLIO,
    popUpTitle: CONTAINER_MANAGE_PORTFOLIO_TITLE,
    popUpUrl: CONTAINER_MANAGE_PORTFOLIO_URL,
    popUpWidth: 823,
    popUpHeight: 495,
    resizable: false
  },
  CONTAINER_BOND_DASHBOARD: {
    popUpType: CONTAINER_BOND_DASHBOARD,
    popUpTitle: CONTAINER_BOND_DASHBOARD_TITLE,
    popUpUrl: CONTAINER_BOND_DASHBOARD_URL,
    popUpWidth: 1100,
    popUpHeight: 500,
    popUpSearchType: 'cusip'
  },
  CONTAINER_CUSTOMER_DASHBOARD: {
    popUpType: CONTAINER_CUSTOMER_DASHBOARD,
    popUpTitle: CONTAINER_CUSTOMER_DASHBOARD_TITLE,
    popUpUrl: CONTAINER_BOND_DASHBOARD_URL,
    popUpWidth: 1100,
    popUpHeight: 500,
    popUpSearchType: 'customer'
  },
  CONTAINER_TICKER: {
    popUpType: CONTAINER_TICKER,
    popUpTitle: CONTAINER_TICKER_TITLE,
    popUpUrl: CONTAINER_BOND_DASHBOARD_URL,
    popUpWidth: 1100,
    popUpHeight: 500,
    popUpSearchType: 'ticker'
  }
};

const openIFramePopup = async ({ userData, popupType, sendUsage = false, identifier = null, theme }) => {
  if (fin && defaultPopupTypesProperties[popupType]) {
    const { realUser, signedInUser } = userData;
    const {
      popUpType,
      popUpTitle,
      popUpUrl,
      popUpWidth,
      popUpHeight,
      popUpSearchType,
      resizable
    } = defaultPopupTypesProperties[popupType];
    const popUpName =
      popUpType === CONTAINER_BOND_DASHBOARD || popUpType === CONTAINER_TICKER ? 'bondPopUp' : popUpTitle;

    const application = await fin.Application.getCurrent();
    const children = await application.getChildWindows();
    const popup = children.find(child => child.identity.name === popUpName);

    const urlConstructor = getFormattedUrl(popUpUrl, realUser, popUpSearchType, identifier, signedInUser, theme);

    if (!popup) {
      const createWindow = async () => {
        const winOption = {
          ...popupDefaultOptions,
          ...popupIframeOptions,
          ...popupSecurityOptions,
          name: popUpName,
          url: `${BLOTTER_CONTAINER_URL}iframepopup`,
          customData: {
            name: `${popUpTitle}`,
            url: urlConstructor
          },
          defaultHeight: popUpHeight,
          minHeight: popUpHeight,
          defaultWidth: popUpWidth,
          minWidth: popUpWidth,
          ...(resizable === undefined ? null : { resizable })
        };
        return await createNewFinWindow(winOption);
      };

      createWindow();
    } else {
      popup.updateOptions({
        customData: {
          name: `${popUpTitle}`,
          url: urlConstructor
        }
      });

      popup.reload();
      popup.focus();
    }
    if (sendUsage) {
      usageService.sendUsage({
        userAction: popUpTitle
      });
    }
  } else {
    console.error('Openfin is not available...');
  }
};

const XiosWindowLauncher = ({ theme }) => {
  const handleNewWindowRequest = useCallback(
    ({ type, payload }) => {
      if (type === xiosWindowsEvents.createWindow) {
        openIFramePopup({ ...payload, theme });
      }
    },
    [theme]
  );

  useEffect(() => {
    const logLabel = 'Xios window launcher';
    iabSubscribe({
      topic: topicForCreatingXiosWindows,
      handler: handleNewWindowRequest,
      logLabel
    });

    return () =>
      iabUnsubscribe({
        topic: topicForCreatingXiosWindows,
        handler: handleNewWindowRequest,
        logLabel
      });
  }, [handleNewWindowRequest]);

  return <></>;
};

export default XiosWindowLauncher;
