import React, { Component } from 'react';
import styles from './CustomLoading.module.scss';

export default class CustomLoading extends Component {
  render() {
    const { loadingMsg } = this.props;
    return (
      <div className={styles['loader-block']}>
        <div className={styles['loader']}></div>
        <div className={styles['loadingText']}>{loadingMsg}</div>
      </div>
    );
  }
}
