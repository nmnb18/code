import React, { Component } from 'react';
import {
  RFQPopupHeader,
  RFQGrid,
  RFQPopupFooter,
  ModalSaveView,
  HeaderToggle,
  FilterBar,
  ModalColumnPicker,
  ViewsList
} from '~components';
import { RFQ_APP_NAME, FLOW_APP_NAME, BLOOMBERG_TERMINAL_WINDOW } from '~helpers/globals';
import { defaultMultiFilterRfqGridId, defaultRfqGridId } from '~helpers/jasperWebSocket';
import { ReplaySubject, Subject, BehaviorSubject, of } from 'rxjs';
import { filter, switchMap, delay } from 'rxjs/operators';
import {
  rfqNotificationTopicForChild,
  rfqNotificationTopicForParent,
  rfqNotificationActions
} from '~services/openfinConfig';
import './RFQPopup.scss';
import * as userSettingsService from '~services/userSettingsService';
import * as integrationService from '~services/integrationService';
import { isEmpty, hasItems } from 'flow-navigator-shared/dist/array';
import * as usageService from '~services/usageService';
import { getConnectionStatus } from '~helpers/jasperWebSocket';
import * as settingsService from '~services/settingsService';
import { sharedSettingsActions, viewsActions } from '~helpers/userSettingsActionCreator';
import { RFQNLEGS } from '~helpers/jasperMessage';
import * as bloombergService from '~services/bloombergService';
import { executeCommandWithUsage } from '~helpers/bloomberg';
import { updateRatingFilters } from '~helpers/filterListHelper';
import { defaultRFQPopupSharedSettings, defaultRFQPopupFilterSharedSettings } from '~helpers/userSettings';
import { AXED_FILTER, AXED_FILTER_DISABLE_OPTIONS, DYNAMIC_SET_FILTER } from '~constants/filters';
import { COLUMNS } from '~helpers/columnStyles';
import { AXESIDE_NONE } from '~helpers/columnRenderer';
import { CustomFilterFactory } from '~patterns/factory-method/customFilter';
import { defaultFilterRange } from '~helpers/proxyService';
import { rfqNotificationSteps } from '~services/rfqNotificationService';
import { iabSubscribe, iabUnsubscribe, iabPublish } from '~services/openfinService';
import {
  getSelectedViewName,
  getColumnFilters,
  getDynamicSetFilterColumns,
  getEnhancedColumnDefs,
  shouldLoadRatings,
  getColumnState
} from '~helpers/viewSettings';
import {
  FILTER_MODEL_SET,
  FILTER_MODEL_DYNAMIC_SET,
  FILTER_MODEL_TEXT,
  FILTER_MODEL_NUMBER,
  FILTER_MODEL_DATE
} from '~constants/filterModelTypes';
import {
  TOGGLE_AXE_ONLY,
  TOGGLE_ME_ONLY,
  getTogglesToReset,
  getToggleLabel,
  filterTogglesConfiguration,
  filterToggleConfigurationMapping
} from '~helpers/toggles';
import { showEntitlementOption, uiEntitlementOptions, isTechOrAdminUser, userIsTrader } from '~helpers/entitlement';
import { setExtraLogsUser } from '~helpers/logger';
import ModalOverlay from '~ui-library/Modal/ModalOverlay';
import { kvpStore } from '~patterns/singleton/kvpStore';
import { filterToggleStore } from '~patterns/singleton/filterToggleStore';
import { fbEvents, multiFilterService } from '~services/multiFilterService';
import { WS_COMMANDS } from '~helpers/jasperMessage';
import ErrorModal from '../ErrorModal/ErrorModal';
import { TextButton } from '~ui-library';
import { useSetTheme } from '~hooks';

const fin = window.fin;

// TODO: migrate to API V2 promise-based architecture
const popUp = fin && fin.desktop.Window.getCurrent();

const RFQPopupLog = 'RFQ notification popup';
const CLOSE_REQUESTED_EVENT = 'close-requested';
const CHECK_FILTER_INSTANCE_INTERVAL = 250;
const requestInterval = 50;
const delayCloseInterval = 500;

const mapToUsageFilterList = filterList =>
  filterList.map(({ filterType, filter, headerName, type, arrayFilter, textFilter }) => {
    const getValue = {
      [FILTER_MODEL_SET]: () => filter,
      [FILTER_MODEL_DYNAMIC_SET]: () => {
        const dynamicFilterValue = [];
        if (hasItems(arrayFilter)) dynamicFilterValue.push(...arrayFilter.filter(Boolean));
        if (textFilter) dynamicFilterValue.push(textFilter);
        return dynamicFilterValue;
      },
      [FILTER_MODEL_TEXT]: () => filter.filter(Boolean).toString(),
      [FILTER_MODEL_NUMBER]: () => type + filter.filter(Boolean).toString(),
      [FILTER_MODEL_DATE]: () => filter.filter(Boolean).join(' - ')
    }[filterType];

    return { [`${headerName}`]: getValue && getValue() };
  });

const ThemeSetter = ({ theme }) => {
  useSetTheme(theme);
  return <></>;
};

class RFQPopup extends Component {
  constructor(props) {
    super(props);
    this.RFQGridRef = React.createRef();
  }

  jasperDataSource$ = new ReplaySubject();
  selectedRFQs$ = new Subject();
  forceSelectRFQs$ = new Subject();
  connectionStatus$ = new BehaviorSubject();
  requestHandler$ = new Subject();

  flowBlotterMessageHandlers = {
    [rfqNotificationActions.rfqNotificationReloadCommand]: () => {
      this.handleReloadRFQ();
    },
    [rfqNotificationActions.rfqNotificationSendStateChanges]: payload => {
      this.updateRFQPopupState(payload);
    },
    [rfqNotificationActions.rfqNotificationSendRFQMessage]: payload => {
      this.handleRFQMessage(payload);
    },
    [rfqNotificationActions.rfqNotificationForceSelectNewRFQ]: payload => {
      this.forceSelectNewRFQ(payload);
    },
    [rfqNotificationActions.rfqNotificationSendStepMessage]: payload => {
      this.handleStepMessage(payload);
    },
    [rfqNotificationActions.rfqNotificationSendMultiFilterMessage]: payload => {
      this.handleMultiFilterMessage(payload);
    },
    [rfqNotificationActions.rfqNotificationUpdateTheme]: payload => {
      this.updateTheme(payload);
    }
  };

  rfqPopupStepHandlers = {
    [rfqNotificationSteps.STEP_1]: () => {
      const { subscriptionInstanceId, columnDefs } = this.state;
      const params = {
        subscriptionInstanceId,
        columnDefs,
        gridId: defaultRfqGridId,
        appName: RFQ_APP_NAME,
        newCriteria: true,
        requireRFQNotificationPopupConfiguration: true,
        ...defaultFilterRange
      };
      this.handleRequestData(params);
    }
  };

  state = {
    signedInUser: null,
    impersonatedUser: null,
    impersonatingUser: false,
    userSettings: {},
    columnsDictionary: null,
    columnDefs: [],
    currentFinUser: null,
    currentFinComputer: null,
    subscriptionInstanceId: null,
    multiFilterSourceInstanceId: null,
    totalRows: 0,
    ampsConnected: null,
    webSocketDisconnected: null,
    ratingFilters: {},
    filterList: [],
    rfqToggles: defaultRFQPopupSharedSettings,
    rfqFilterToggles: defaultRFQPopupFilterSharedSettings,
    resetAllFiltersButtonClicked: false,
    columnState: null,
    currentViewName: '',
    selectedViewIsReadOnly: false,
    isEditing: false,
    editingView: '',
    showModalSaveView: false,
    showModalSaveViewOverModal: false,
    columnOrderFromGrid: [],
    columnOrderFromView: [],
    isSaveButtonVisible: false,
    forceClosing: false,
    isAxedToggledManually: false,
    showModalColumnPicker: false,
    disableColumnChooserButtons: false,
    entitlement: null,
    multiFilterList: [],
    isTech: null,
    isUserTrader: false,
    wsRequestTooBig: false
  };

  async componentDidMount() {
    if (!fin) return;

    // "RFQ notification popup" subscribes to the messages that "Blotter container" send for the "rfq notification" topic

    iabSubscribe({
      topic: rfqNotificationTopicForChild,
      handler: this.handleFlowBlotterMessage,
      logLabel: RFQPopupLog
    });

    this.publishMessageToFlowBlotter(rfqNotificationTopicForParent, {
      type: rfqNotificationActions.rfqNotificationPopupMounted
    });

    popUp.addEventListener(
      CLOSE_REQUESTED_EVENT,
      this.handleOnRFQPopupClose,
      () => console.log(`${RFQPopupLog} - Add close-requested event listener sucess`),
      err => console.error(`${RFQPopupLog} - Add close-requested event listener fail`, err)
    );

    popUp.getOptions(options => {
      const {
        customData: { popUpTitle, currentFinUser, currentFinComputer }
      } = options;
      document.title = popUpTitle;
      this.setState({ currentFinUser, currentFinComputer });
    });

    this.filterToggleChangeSubscription = filterToggleStore.stateChanges$.subscribe(this.handleOnFilterToggleChange);

    this.requestHandlerSubscription = this.requestHandler$
      .pipe(switchMap(requestCommand => of(requestCommand).pipe(delay(requestInterval))))
      .subscribe(requestCommand => {
        this.publishMessageToFlowBlotter(rfqNotificationTopicForParent, {
          type: rfqNotificationActions.rfqNotificationRequestData,
          payload: { requestCommand }
        });
      });

    this.multiFilterRequestHandlerSubscription = multiFilterService.multiFilterRequest$.subscribe(
      ({ field, event }) => {
        multiFilterService.setMultiFilterField(field);
        multiFilterService.setMultiFilterEvent(event);

        const requestCommand = this.getRequestMultiFilterCommand(field);

        this.publishMessageToFlowBlotter(rfqNotificationTopicForParent, {
          type: rfqNotificationActions.rfqNotificationRequestMultiFilter,
          payload: { requestCommand }
        });
      }
    );

    const multiFilterCommands = [
      WS_COMMANDS.GROUP_BEGIN,
      WS_COMMANDS.NEW_MESSAGE,
      WS_COMMANDS.GROUP_END,
      WS_COMMANDS.NEW_MESSAGE_SOW,
      WS_COMMANDS.DELETE_MESSAGE
    ];
    this.multiFilterSubscription = multiFilterService.multiFiltersSource$
      .pipe(filter(filterMessage => multiFilterCommands.includes(filterMessage.command)))
      .subscribe(this.handleMultiFilterChanges);
  }

  componentDidUpdate(_, prevState) {
    const {
      userSettings: userSettingsPrev,
      columnsDictionary: columnsDictionaryPrev,
      webSocketDisconnected: webSocketDisconnectedPrev,
      currentFinUser: currentFinUserPrev
    } = prevState;
    const {
      userSettings,
      columnsDictionary,
      webSocketDisconnected,
      filterList,
      filterFromView,
      currentFinUser
    } = this.state;

    if (
      userSettings &&
      userSettingsPrev !== userSettings &&
      columnsDictionary &&
      columnsDictionaryPrev !== columnsDictionary
    ) {
      this.setRFQColumnDefinitionAndToggles(null, false, false);
    }
    if (this.isSaveButtonVisible(prevState.columnOrderFromGrid)) {
      this.setState({ isSaveButtonVisible: true });
    }

    if (webSocketDisconnected !== webSocketDisconnectedPrev) {
      this.connectionStatus$.next({ status: webSocketDisconnected });
    }
    if (
      filterList.length > 0 &&
      filterFromView.length > 0 &&
      JSON.stringify(filterFromView) !== JSON.stringify(filterList) &&
      JSON.stringify(prevState.filterList) !== JSON.stringify(filterList)
    ) {
      this.setState({ isSaveButtonVisible: true });
    }
    // set the log user for determining whether to log extra data
    if (currentFinUser && currentFinUser !== currentFinUserPrev) {
      setExtraLogsUser(currentFinUser);
    }
  }

  componentCleanUp() {
    this.publishMessageToFlowBlotter(rfqNotificationTopicForParent, {
      type: rfqNotificationActions.rfqNotificationPopupReload
    });

    iabUnsubscribe({
      topic: rfqNotificationTopicForChild,
      handler: this.handleFlowBlotterMessage,
      logLabel: RFQPopupLog
    });

    popUp.removeEventListener(
      CLOSE_REQUESTED_EVENT,
      this.handleOnRFQPopupClose,
      () => console.log(`${RFQPopupLog} - Remove close-requested event listener sucess`),
      err => console.error(`${RFQPopupLog} - Remove close-requested event listener fail`, err)
    );

    this.requestHandlerSubscription && this.requestHandlerSubscription.unsubscribe();
    this.multiFilterSubscription && this.multiFilterSubscription.unsubscribe();
    this.multiFilterRequestHandlerSubscription && this.multiFilterRequestHandlerSubscription.unsubscribe();
    this.filterToggleChangeSubscription && this.filterToggleChangeSubscription.unsubscribe();
  }

  componentWillUnmount() {
    this.componentCleanUp();
  }

  handleMultiFilterChanges = filterMessage => {
    const { elements } = filterMessage;
    if (!elements) return;

    const keys = Object.keys(elements);
    if (!keys.length) return;

    const filterFieldId = keys[0];
    const filterInstance = this.RFQGridRef.current.gridApi.getFilterInstance(filterFieldId);
    if (!filterInstance) return;

    const { command } = filterMessage;
    const filterValue = elements[filterFieldId];

    const componentInstance = filterInstance.getFrameworkComponentInstance();
    if (!componentInstance) return;

    componentInstance.filters$.next({
      option: filterValue,
      command
    });
  };

  isSaveButtonVisible = prevStateColumnOrderFromGrid => {
    const { impersonatedUser, selectedViewIsReadOnly, columnOrderFromGrid } = this.state;
    return (
      (Boolean(impersonatedUser) !== false || selectedViewIsReadOnly) &&
      prevStateColumnOrderFromGrid !== columnOrderFromGrid
    );
  };

  closeApplicationRequest = () => {
    if (this.state.isSaveButtonVisible) {
      this.setState({ forceClosing: true });

      this.handleClickOpenModalSaveView();
    } else {
      this.handleOnToggleRequested();
    }
  };

  handleOnCloseRequested = () => {
    this.publishMessageToFlowBlotter(rfqNotificationTopicForParent, {
      type: rfqNotificationActions.rfqNotificationPopupClose
    });

    popUp.close(true);
  };

  handleOnRFQPopupClose = () => {
    const { totalRows } = this.state;

    if (totalRows) {
      this.handleOnCloseRequested();
      return;
    }

    this.handleRangeSubscriptionBeforeClosingPopup();
    setTimeout(() => this.handleOnCloseRequested(), delayCloseInterval);
  };

  handleOnToggleRequested = () => {
    usageService.sendUsageForRFQ({
      userAction: usageService.actions.RFQ,
      notes: { Action: 'OFF' }
    });

    const rfqTogglesCopy = { ...this.state.rfqToggles };

    this.publishMessageToFlowBlotter(rfqNotificationTopicForParent, {
      type: rfqNotificationActions.rfqNotificationPopupToggle,
      payload: { rfqToggles: rfqTogglesCopy, source: RFQ_APP_NAME }
    });
  };

  handleFlowBlotterMessage = message => {
    const { type, payload } = message;

    const flowBlotterMessageHandler = this.flowBlotterMessageHandlers[type];
    flowBlotterMessageHandler && flowBlotterMessageHandler(payload);
  };

  publishMessageToFlowBlotter = (topic, message) =>
    iabPublish({
      topic,
      message,
      logLabel: RFQPopupLog
    });

  updateRFQPopupState = payload => {
    if (!payload) return;

    this.setState(payload);
  };

  handleRFQMessage = rfqMessage => this.jasperDataSource$.next(rfqMessage);

  handleMultiFilterMessage = message => {
    multiFilterService.multiFilterSource$.next(message);
  };

  setColumnOrder = columnOrder => this.setState({ columnOrderFromGrid: columnOrder });

  setColumnState = columns => this.setState({ columnState: columns });

  handleOnRFQGridReady = () =>
    this.publishMessageToFlowBlotter(rfqNotificationTopicForParent, {
      type: rfqNotificationActions.rfqNotificationGridReadyForReceiveData
    });

  getRequestMultiFilterCommand = column => {
    const { multiFilterSourceInstanceId } = this.state;
    const multiFilterFields = [{ column, doQuery: true }];

    const command = this.handleMultiFilterRequest({
      subscriptionInstanceId: multiFilterSourceInstanceId,
      gridId: defaultMultiFilterRfqGridId,
      appName: RFQ_APP_NAME,
      multiFilterFields,
      excludeFilter: column
    });

    return command;
  };

  setRFQColumnDefinitionAndToggles = (selectedView, editing, switchingView) => {
    const {
      userSettings,
      columnsDictionary,
      currentFinUser,
      signedInUser,
      entitlement,
      impersonatedUser,
      impersonatingUser,
      currentViewName,
      rfqFilterToggles
    } = this.state;

    if (!userSettings || !columnsDictionary) return;
    if (!editing && selectedView?.ViewName === currentViewName) return;

    kvpStore.clear();
    filterToggleStore.clear();

    if (editing) {
      this.setState({
        isEditing: true,
        editingView: selectedView.ViewName,
        showModalSaveView: true
      });
      return;
    }

    multiFilterService.clearMultiFilter();
    if (switchingView) multiFilterService.setMultiFilterEvent(fbEvents.SWITCH_VIEW);

    const selectedViewName = getSelectedViewName(userSettings, selectedView);
    const viewSettings = userSettingsService.getPopupViewSettings(userSettings, FLOW_APP_NAME, selectedViewName);
    if (!viewSettings) return;

    const { level3 } = impersonatingUser ? impersonatedUser : entitlement;
    const { isAdmin } = entitlement;
    const isTechOrAdmin = isTechOrAdminUser(isAdmin, level3);
    const isUserTrader = userIsTrader(entitlement);

    const columnDefs = integrationService.getColumnsDefinition({
      view: viewSettings,
      columnsDictionary,
      currentUser: currentFinUser,
      isTechOrAdmin,
      signedInUser
    });

    if (!columnDefs) return;
    const enhancedColumnDefs = getEnhancedColumnDefs(columnDefs, columnsDictionary);
    if (shouldLoadRatings(enhancedColumnDefs)) this.loadRatings();

    const columnStateFromViewSettings = getColumnState(viewSettings, columnDefs, null);

    const columnFilterList = getColumnFilters(viewSettings);

    const dynamicSetFilters = integrationService.getFiltersByType(columnsDictionary, DYNAMIC_SET_FILTER);
    const updatedState = {};

    if (dynamicSetFilters) {
      const dynamicSetFilterColumnsFromViewSettings = getDynamicSetFilterColumns(viewSettings, dynamicSetFilters);
      if (dynamicSetFilterColumnsFromViewSettings) {
        updatedState.multiFilterList = dynamicSetFilterColumnsFromViewSettings.map(({ ColName }) => ColName);
      } else if (hasItems(this.state.multiFilterList)) {
        updatedState.multiFilterList = [];
      }
    }

    this.setFilterTogglesInStore({
      viewColumnDefs: enhancedColumnDefs,
      columnsDictionary: columnsDictionary.sourceColumnNames,
      rfqFilterToggles
    });

    const {
      rfqToggles: { AxeOnly }
    } = this.state;
    const liveAxeColumnDef = enhancedColumnDefs.find(colDef => colDef.colId === COLUMNS.AXESIDE);

    let liveAxeFilterOption = [];
    if (liveAxeColumnDef && AxeOnly) {
      const liveAxeFilter = new CustomFilterFactory().createCustomFilter(liveAxeColumnDef, AXED_FILTER);
      liveAxeFilterOption = [liveAxeFilter];
    }

    this.setState(
      {
        columnDefs: enhancedColumnDefs,
        filterList: [...columnFilterList, ...liveAxeFilterOption],
        filterFromView: [...columnFilterList, ...liveAxeFilterOption],
        columnState: columnStateFromViewSettings,
        currentViewName: viewSettings.ViewName,
        selectedViewIsReadOnly: viewSettings.ReadOnly,
        isTech: isTechOrAdmin,
        isSaveButtonVisible: false,
        isSettingCurrentFinUserProfile: false,
        isAxedToggledManually: AxeOnly,
        ...updatedState,
        isUserTrader
      },
      () => {
        if (!this.RFQGridRef.current) return;

        this.RFQGridRef.current.setFilterModel();

        if (impersonatingUser || impersonatedUser || selectedView) {
          const gridOptions = { skipSetFilterModel: true };
          this.RFQGridRef.current.handleFilterModelAndSortingRecovery(gridOptions);
        }
      }
    );
  };

  setFilterTogglesInStore = ({ viewColumnDefs, columnsDictionary, rfqFilterToggles }) => {
    Object.keys(rfqFilterToggles).forEach(key => {
      if (Object.prototype.hasOwnProperty.call(filterTogglesConfiguration, key)) {
        const filterToggleConfiguration = filterTogglesConfiguration[key];
        const { field, label, breadCrumbText, instructionField } = filterToggleConfiguration;

        const viewColumnDef = viewColumnDefs.find(viewColDef => viewColDef.field === field);
        const columnDictionary = columnsDictionary.find(colDictionary => colDictionary.sourcecolumnname === field);

        if (columnDictionary) {
          let columnDefinition;

          if (viewColumnDef)
            columnDefinition =
              viewColumnDef && viewColumnDef.filterParams && viewColumnDef.filterParams.columnDefinition;

          const { codeinstruction, columntype } = columnDictionary;
          const instructions = codeinstruction[instructionField];

          filterToggleStore.set(field, {
            showToggle: true,
            toggle: rfqFilterToggles[key],
            toggleOptions: {
              field,
              label,
              breadCrumbText,
              denominator: instructions.denominator,
              decFormat: instructions.decFormat,
              exportColumnHeader: instructions.exportColumnHeader,
              columntype,
              filterType: integrationService.getFilterType(columnDefinition)
            }
          });
        }
      }
    });
  };

  loadRatings = () => {
    settingsService
      .getRatings()
      .pipe(filter(ratings => ratings))
      .subscribe(ratings => {
        const moodyRatings = ratings.filter(rating => rating.ratingsource === COLUMNS.MOODY);
        const spRatings = ratings.filter(rating => rating.ratingsource === COLUMNS.SP);
        this.setState({ ratingFilters: { moody: moodyRatings, sp: spRatings } });
      });
  };

  resetModalState = () => {
    const { showModalSaveViewOverModal } = this.state;

    showModalSaveViewOverModal
      ? this.handleClickOpenModalSaveViewOverModal(false)
      : this.handleClickOpenModalSaveView(false);

    this.setState({ forceClosing: false });
  };

  handleClickOpenModalSaveViewOverModal = reload => {
    // reload happens when saving, editing or removing a view.
    if (reload) {
      this.handleReloadRFQ();
    } else {
      const { showModalSaveViewOverModal, disableColumnChooserButtons } = this.state;
      this.setState({
        showModalSaveViewOverModal: !showModalSaveViewOverModal,
        disableColumnChooserButtons: !disableColumnChooserButtons,
        isEditing: false
      });
    }
  };

  handleClickOpenModalColumnPicker = reload => {
    // reload happens when saving, editing or removing a view.
    if (reload) {
      this.handleReloadRFQ();
    } else {
      this.setState({
        showModalColumnPicker: !this.state.showModalColumnPicker
      });
    }
  };

  handleRangeSubscriptionBeforeClosingPopup = () => {
    const { subscriptionInstanceId, columnDefs } = this.state;

    this.handleRequestData({
      subscriptionInstanceId,
      columnDefs,
      firstRow: 0,
      lastRow: 0,
      newCriteria: true,
      gridId: defaultRfqGridId,
      appName: RFQ_APP_NAME,
      requireRFQNotificationPopupConfiguration: true
    });
  };

  handleRequestData = ({
    subscriptionInstanceId,
    columnDefs,
    firstRow,
    lastRow,
    newCriteria,
    gridId,
    appName,
    requireRFQNotificationPopupConfiguration
  }) => {
    const fields = columnDefs.map(({ field }) => ({ field }));
    const { filterList, rfqToggles } = this.state;
    const requestCommand = {
      subscriptionInstanceId,
      columnDefs: fields,
      firstRow,
      lastRow,
      newCriteria,
      gridId,
      appName,
      filterList,
      toggles: rfqToggles,
      requireRFQNotificationPopupConfiguration
    };

    this.requestHandler$.next(requestCommand);
  };

  handleMultiFilterRequest = ({ subscriptionInstanceId, gridId, appName, multiFilterFields, excludeFilter }) => {
    const { filterList, rfqToggles } = this.state;
    const multiFilterList = filterList.filter(f => f.field !== excludeFilter);

    const requestCommand = {
      isMultiFilter: true,
      subscriptionInstanceId,
      gridId,
      appName,
      multiFilterFields,
      filterList: multiFilterList,
      toggles: rfqToggles
    };

    return requestCommand;
  };

  handleUnsubscribeRange = ({ subscriptionInstanceId }) => {
    this.publishMessageToFlowBlotter(rfqNotificationTopicForParent, {
      type: rfqNotificationActions.rfqNotificationRequestUnsubscribeRange,
      payload: { subscriptionInstanceId }
    });
  };

  forceSelectNewRFQ = rfqMessage => this.forceSelectRFQs$.next(rfqMessage);

  handleTotalRowChanged = totalRows => this.setState({ totalRows });

  handleBloombergCommand = (rfq, commandLabel, command = commandLabel) => {
    const { code, rfqnlegs, l1_code, l2_code, bbgcustchatid } = rfq;
    const { userSettings, currentFinUser } = this.state;
    const settings = settingsService.getSettings(userSettings, FLOW_APP_NAME);
    const bloombergTerminalWindow = settings.BloombergTerminalWindow || BLOOMBERG_TERMINAL_WINDOW;
    // in case if rfqnlegs > 1, if we click on main row check if code_main_value is defined for that or not else we need to assign code value to that
    let code_main_value = rfq.code_main_value || code;
    let cusipIsinArg;

    if (command === bloombergService.IBCHAT_COMMAND.command) {
      cusipIsinArg = !bbgcustchatid ? ' ' : isNaN(bbgcustchatid) ? bbgcustchatid : `>${bbgcustchatid}`;
    } else if (rfqnlegs === RFQNLEGS.MAIN) {
      cusipIsinArg = code;
    } else if (rfqnlegs === RFQNLEGS.L1) {
      cusipIsinArg = [code_main_value, l1_code];
    } else if (rfqnlegs === RFQNLEGS.L2) {
      cusipIsinArg = [code_main_value, l1_code, l2_code];
    }

    const listener = result => console.log('Bloomber integration listener. The exit code', result.exitCode);
    const onSuccess = processIdentity => console.log(`Bloomberg ${command} command success`, processIdentity);
    const onError = err => console.log(`Bloomberg ${command} command fail`, err);

    const bloombergOptions = { command, args: cusipIsinArg, listener, onSuccess, onError, bloombergTerminalWindow };
    const usageOptions = { commandLabel, currentFinUser };

    executeCommandWithUsage(bloombergOptions, usageOptions);
  };

  isOnlyAxedFilter = filteredList => {
    const { isAxedToggledManually } = this.state;
    const liveAxeFilter = filteredList.filter(data => data.field === COLUMNS.AXESIDE);
    return isAxedToggledManually && hasItems(liveAxeFilter) && filteredList.length === 1;
  };

  removeFilter = fieldId => {
    const newFilterList = this.state.filterList.filter(({ field }) => field !== fieldId);
    this.setFilterList(newFilterList);
  };

  isColumnlessFilter = fieldId => !this.state.columnState.find(({ colId }) => colId === fieldId);

  getColumnlessFilters = () => this.state.filterList.filter(({ field }) => this.isColumnlessFilter(field));

  setColumnsFilters = columnFilters => {
    const { filterList } = this.state;
    const columnlessFilters = this.getColumnlessFilters();
    const deletedFilters = filterList.filter(filter => !columnFilters.find(({ field }) => filter.field === field));
    deletedFilters.forEach(filter => {
      const filterUID = kvpStore.findUID(filter.field);
      if (filterUID) kvpStore.delete(filterUID);
    });
    this.setFilterList([...columnFilters, ...columnlessFilters]);
  };

  setFilterList = newFilterList => {
    // filterListFromGrid
    const { filterList, filterFromView, ratingFilters, resetAllFiltersButtonClicked, rfqToggles } = this.state;
    const updatedState = { rfqToggles };
    const updatedFilterList = resetAllFiltersButtonClicked ? [] : updateRatingFilters(newFilterList, ratingFilters); // filteredList

    const fields = new Set(updatedFilterList.map(({ field }) => field));
    const deletedFilterList = filterList.filter(({ field }) => !fields.has(field));
    deletedFilterList.forEach(filter => {
      const filterUID = kvpStore.findUID(filter.field);
      if (filterUID) kvpStore.delete(filterUID);
    });

    if (JSON.stringify(filterFromView) !== JSON.stringify(updatedFilterList)) {
      if (!this.isOnlyAxedFilter(updatedFilterList)) {
        updatedState.isSaveButtonVisible = true;
      }

      if (filterList.length <= newFilterList.length) {
        this.handleUsageFilterChange(newFilterList, usageService.actions.APPLY_FILTER);
      } else if (!resetAllFiltersButtonClicked) {
        this.handleUsageFilterChange(deletedFilterList, usageService.actions.CLEAR_FILTER);
      }
    } else {
      updatedState.isSaveButtonVisible = false;
    }

    if (resetAllFiltersButtonClicked) {
      const togglesToReset = getTogglesToReset(rfqToggles);
      this.handleAxeFilterToggle(togglesToReset);
      sharedSettingsActions.updateToggles({ updatedToggles: togglesToReset });
      updatedState.isAxedToggledManually = false;
      updatedState.rfqToggles = { ...rfqToggles, ...togglesToReset };
      kvpStore.clear();
    }

    const liveAxeFilter = updatedFilterList.find(element => element.field === COLUMNS.AXESIDE);
    const isToggleOnAxed = !!(liveAxeFilter && !liveAxeFilter.filter.includes(AXESIDE_NONE));
    updatedState.rfqToggles.AxeOnly = isToggleOnAxed;

    this.setState({
      resetAllFiltersButtonClicked: false,
      filterList: updatedFilterList,
      selectedRows: 0,
      ...updatedState
    });
  };

  handleClickResetFilter = fieldId => {
    const { filterList } = this.state;
    const resetAllFiltersButtonClicked = !fieldId;

    if (resetAllFiltersButtonClicked) {
      usageService.sendUsageForRFQ({ userAction: usageService.actions.RESET_FILTER });
    } else {
      const deletedFilterList = filterList.filter(colFilter => colFilter.field === fieldId);
      this.handleUsageFilterChange(deletedFilterList, usageService.actions.CLEAR_FILTER);
    }

    this.setState(
      { resetAllFiltersButtonClicked },
      function() {
        this.RFQGridRef.current.handleResetFilter(fieldId);

        const filterInstance = this.RFQGridRef.current.gridApi.getFilterInstance(COLUMNS.AXESIDE);
        if (filterInstance) {
          filterInstance.getFrameworkComponentInstance().updateFilterOptions([]);
        }
      }.bind(this)
    );
  };

  handleUsageFilterChange = (filterList, action) => {
    const usageFilterList = mapToUsageFilterList(filterList);
    if (isEmpty(usageFilterList)) return;

    const payload = {
      userAction: action,
      notes: {
        ...usageFilterList
      }
    };
    usageService.sendUsageForRFQ(payload);
  };

  handleAxeFilterToggle = updatedToggles => {
    if (Object.prototype.hasOwnProperty.call(updatedToggles, TOGGLE_AXE_ONLY)) {
      const filterInstance = this.RFQGridRef.current.gridApi.getFilterInstance(COLUMNS.AXESIDE);
      const axeOnlyValue = updatedToggles[TOGGLE_AXE_ONLY];
      this.setLiveAxeFilter(filterInstance, axeOnlyValue);
    }
  };

  handleOnToggleChange = toggleKey => {
    const { rfqToggles } = this.state;
    const updatedRFQToggle = { [toggleKey]: !rfqToggles[toggleKey] };
    const updatedRFQToggles = { ...rfqToggles, ...updatedRFQToggle };

    this.handleAxeFilterToggle(updatedRFQToggle);
    sharedSettingsActions.updateToggles({ updatedToggles: updatedRFQToggle });
    this.setState({
      selectedRows: 0,
      resetAllFiltersButtonClicked: false,
      rfqToggles: updatedRFQToggles
    });

    multiFilterService.clearMultiFilter();
  };

  handleOnFilterToggleChange = stateChange => {
    const { field, toggle } = stateChange;

    const filterToggleState = filterToggleStore.get(field);
    if (filterToggleState) {
      filterToggleStore.set(field, { ...filterToggleState, toggle });
    }

    const filterToggleKey = filterToggleConfigurationMapping[field];

    const { rfqFilterToggles } = this.state;
    const updatedRFQFilterToggleState = { [filterToggleKey]: toggle };

    multiFilterService.clearMultiFilter();

    sharedSettingsActions.updateFilterToggles({ updatedFilterToggles: updatedRFQFilterToggleState });

    this.setState({
      selectedRows: 0,
      resetAllFiltersButtonClicked: false,
      rfqFilterToggles: { ...rfqFilterToggles, ...updatedRFQFilterToggleState }
    });
  };

  requestUpdateSharedSettings = (payload, callback) => {
    const { currentFinUser, impersonatedUser } = this.state;
    const metadata = { user: currentFinUser, impersonating: Boolean(impersonatedUser) };
    const options = { source: RFQ_APP_NAME };

    settingsService.requestUpdateUserSharedSettings(metadata, payload, options).then(() => {
      if (callback) callback();
    });
  };

  setLiveAxeFilter = (filterInstance, toggleValue) => {
    if (!filterInstance) {
      setTimeout(() => {
        const _filterInstance = this.RFQGridRef.current.gridApi.getFilterInstance(COLUMNS.AXESIDE);
        this.setLiveAxeFilter(_filterInstance);
      }, CHECK_FILTER_INSTANCE_INTERVAL);
      return;
    }

    const newFilterModel = toggleValue ? AXED_FILTER : [];
    const newFilterOptions = toggleValue ? AXED_FILTER_DISABLE_OPTIONS : [];

    filterInstance.setModel(newFilterModel);
    filterInstance.getFrameworkComponentInstance().updateFilterOptions(newFilterOptions);
  };

  handleStepMessage = payload => {
    const stepHandler = this.rfqPopupStepHandlers[payload.step];
    stepHandler && stepHandler();
  };

  handleSelectedView = (selectedView, editing) => {
    viewsActions.switch({ viewName: selectedView.ViewName });
    this.setRFQColumnDefinitionAndToggles(selectedView, editing, true);
  };

  updateTheme = theme => {
    this.setState({ theme });
  };

  setCurrentViewName = viewName => this.setState({ currentViewName: viewName });

  handleClickOpenModalSaveView = reload => {
    // reload happens when saving, editing or removing a view.
    if (reload) {
      this.handleReloadRFQ();
    } else {
      this.setState({
        showModalSaveView: !this.state.showModalSaveView,
        isEditing: false
      });
    }
  };

  handleReloadRFQ = () => {
    this.componentCleanUp();
    setTimeout(() => window.location.reload(), delayCloseInterval);
  };

  setColumnOrderFromView = colFromView => this.setState({ columnOrderFromView: colFromView });

  handleCloseIconClick = () => {
    this.setState({ disableColumnChooserButtons: !this.state.disableColumnChooserButtons });
  };

  renderToggleSection = () => {
    const { rfqToggles, entitlement } = this.state;
    return Object.entries(rfqToggles)
      .filter(
        ([toggleKey]) =>
          toggleKey !== TOGGLE_ME_ONLY || showEntitlementOption(entitlement, uiEntitlementOptions.ME_ONLY_VISIBLE)
      )
      .map(([toggleKey, value]) => (
        <HeaderToggle
          key={toggleKey}
          onToggleChange={() => this.handleOnToggleChange(toggleKey)}
          isToggleOn={value}
          text={getToggleLabel(toggleKey)}
        />
      ));
  };

  render() {
    const {
      columnDefs,
      subscriptionInstanceId,
      columnsDictionary,
      totalRows,
      userSettings,
      webSocketDisconnected,
      ampsConnected,
      currentFinUser,
      signedInUser,
      impersonatingUser,
      filterList,
      rfqToggles,
      rfqFilterToggles,
      columnState,
      currentViewName,
      columnOrderFromGrid,
      isSaveButtonVisible,
      showModalSaveView,
      isEditing,
      editingView,
      columnOrderFromView,
      forceClosing,
      showModalSaveViewOverModal,
      showModalColumnPicker,
      disableColumnChooserButtons,
      entitlement,
      isUserTrader,
      isTech,
      theme,
      wsRequestTooBig
    } = this.state;
    const connectionStatus = getConnectionStatus(ampsConnected);

    return (
      <div className={`rfq-popup-container ${isUserTrader ? 'theme-userType-trader' : ''}`}>
        <ThemeSetter theme={theme}></ThemeSetter>
        <ErrorModal
          isOpen={wsRequestTooBig}
          content={<div>Query is too big to send. Try removing a filter or use fewer columns.</div>}
          controls={
            <TextButton
              handleClick={() => {
                this.setState({ wsRequestTooBig: false });
              }}
            >
              Okay
            </TextButton>
          }
        ></ErrorModal>
        {showModalSaveView && (
          <>
            <ModalOverlay handleClick={this.resetModalState} />
            <ModalSaveView
              isEditing={isEditing}
              editingView={editingView}
              fromColumnPicker={false}
              currentView={currentViewName}
              handleClickOpenModalSaveView={this.handleClickOpenModalSaveView}
              handleClickOpenModalSaveViewOverModal={this.handleClickOpenModalSaveViewOverModal}
              handleOnCloseApplication={this.handleOnToggleRequested}
              userSettings={userSettings}
              currentFinUser={currentFinUser}
              columnOrderFromGrid={columnOrderFromGrid}
              columnOrderFromView={columnOrderFromView}
              forceClosing={forceClosing}
              setFilterList={this.setFilterList}
              filterList={filterList}
              columnState={columnState}
              currentUser={currentFinUser}
              showModalSaveViewOverModal={showModalSaveViewOverModal}
            />
          </>
        )}
        {showModalColumnPicker && (
          <>
            <ModalOverlay handleClick={() => this.handleClickOpenModalColumnPicker(false)} />
            <ModalColumnPicker
              columnState={columnState}
              isTech={isTech}
              handleCloseIconClick={this.handleCloseIconClick}
              handleClickOpenModalColumnPicker={this.handleClickOpenModalColumnPicker}
              columnsDictionary={columnsDictionary}
              columnOrderFromGrid={columnOrderFromGrid}
              columnOrderFromView={columnOrderFromView}
              currentFinUser={currentFinUser}
              currentView={currentViewName}
              userSettings={userSettings}
              handleClickOpenModalSaveViewOverModal={this.handleClickOpenModalSaveViewOverModal}
              showModalSaveViewOverModal={showModalSaveViewOverModal}
              filterList={filterList}
              disableColumnChooserButtons={disableColumnChooserButtons}
            />
          </>
        )}

        {columnsDictionary && (
          <RFQPopupHeader
            popUp={popUp}
            connectionStatus={connectionStatus}
            columnsDictionary={columnsDictionary}
            selectedRFQs$={this.selectedRFQs$}
            onRFQPopupClose={this.handleOnRFQPopupClose}
            onRFQToggle={this.closeApplicationRequest}
            handleBloombergCommand={this.handleBloombergCommand}
            TogglesSection={this.renderToggleSection()}
            FilterBarSection={
              <FilterBar
                filterList={filterList}
                setFilterList={this.setFilterList}
                handleClickResetFilter={this.handleClickResetFilter}
                onToggleChange={this.handleOnToggleChange}
                toggles={rfqToggles}
                isSaveButtonVisible={isSaveButtonVisible}
                handleClickOpenModalSaveView={() => this.handleClickOpenModalSaveView(false)}
                handleClickOpenModalColumnPicker={() => this.handleClickOpenModalColumnPicker(false)}
                ViewsSection={
                  <ViewsList
                    setCurrentViewName={this.setCurrentViewName}
                    userSettings={userSettings}
                    onSelectView={this.handleSelectedView}
                  />
                }
              />
            }
          />
        )}
        {subscriptionInstanceId && columnDefs && columnDefs.length ? (
          <RFQGrid
            id="tbl-gridLive"
            ref={this.RFQGridRef}
            setColumnOrder={this.setColumnOrder}
            setColumnOrderFromView={this.setColumnOrderFromView}
            columnOrderFromView={columnOrderFromView}
            setColumnState={this.setColumnState}
            gridId={defaultRfqGridId}
            currentViewName={currentViewName}
            subscriptionInstanceId={subscriptionInstanceId}
            datasource$={this.jasperDataSource$}
            onTotalRowChanged={this.handleTotalRowChanged}
            requestData={this.handleRequestData}
            setColumnsFilters={this.setColumnsFilters}
            removeFilter={this.removeFilter}
            filterList={filterList}
            columnDefs={columnDefs}
            columnState={columnState}
            selectedRFQs$={this.selectedRFQs$}
            appName={RFQ_APP_NAME}
            onRFQGridReady={this.handleOnRFQGridReady}
            forceSelectRFQs$={this.forceSelectRFQs$}
            webSocketDisconnected={webSocketDisconnected}
            connectionStatus$={this.connectionStatus$}
            currentFinUser={currentFinUser}
            signedInUser={signedInUser}
            impersonatingUser={impersonatingUser}
            userSettings={userSettings}
            handleBloombergCommand={this.handleBloombergCommand}
            toggles={rfqToggles}
            filterToggles={rfqFilterToggles}
            entitlement={entitlement}
            onUnsubscribeRange={this.handleUnsubscribeRange}
            columnsDictionary={columnsDictionary}
          />
        ) : (
          <p>Loading RFQ Notification columns definition</p>
        )}
        <RFQPopupFooter totalRows={totalRows} />
      </div>
    );
  }
}

export default RFQPopup;
