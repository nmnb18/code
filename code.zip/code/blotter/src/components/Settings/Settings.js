import React from 'react';
import './Settings.scss';

const Settings = ({ img, alt }) => <img src={img} alt={alt} className="jp-setting-icon" />;

export default Settings;
