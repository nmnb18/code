// @External Dependencies
import React, { useState, useContext, useEffect, useRef, useMemo } from 'react';
import { of, Subject } from 'rxjs';
import { debounceTime, tap, switchMap, catchError } from 'rxjs/operators';
import styles from './UserImpersonation.module.scss';

// @Dependencies
import { SearchBar, UserImpersonationItem } from '~components';
import { ImpersonatedUsersContext } from '~contexts/ImpersonatedUsersContext';
import * as entitlementService from '~services/entitlementService';
import { KEYS } from '~helpers/keyCodes';

const USER_TYPING_INTERVAL = 250;

const validUserList = (searchText, searchResults, impersonatedUsers) => {
  const userList = searchText ? searchResults : impersonatedUsers;

  if (!userList) return [];

  return userList.filter(user => !user.blocked);
};

// @Component
const UserImpersonation = ({ onSelectUser }) => {
  const { impersonatedUsers } = useContext(ImpersonatedUsersContext);
  const searchSubject = useRef(new Subject());
  const [searchText, setSearchText] = useState(null);
  const [searchResults, setSearchResults] = useState([]);
  const [current, setCurrent] = useState(null);
  const [cursor, setCursor] = useState(-1);
  const [inputActive, setInputActive] = useState(true);

  const handleSelectUser = selectedUser => {
    const impersonatedUserCopy = { ...selectedUser };
    delete impersonatedUserCopy.blocked;

    onSelectUser && onSelectUser(impersonatedUserCopy);
  };

  const handleInputChange = userInput => searchSubject.current.next(userInput);

  // Keep a single instance of the search subject for execute queries against entitlement/personSearch api
  useEffect(() => {
    const searchUsersSubscription = searchSubject.current
      .pipe(
        debounceTime(USER_TYPING_INTERVAL),
        tap(value => setSearchText(value)),
        switchMap(value => {
          if (value && value.length > 1) {
            return entitlementService.searchPersons(value).pipe(catchError(() => of([])));
          }
          return of([]);
        })
      )
      .subscribe(res => setSearchResults(res));

    return () => {
      searchUsersSubscription.unsubscribe();
    };
  }, []);

  const userList = useMemo(() => validUserList(searchText, searchResults, impersonatedUsers), [
    searchText,
    searchResults,
    impersonatedUsers
  ]);

  useEffect(() => {
    setCurrent(userList[cursor]);
  }, [cursor, userList]);

  useEffect(() => {
    const handleKeyDownListener = event => {
      const { keyCode } = event;
      const active = document.activeElement;
      const length = userList.length;
      const { ENTER, UP, DOWN } = KEYS;

      if (keyCode === ENTER) {
        if (active instanceof HTMLElement) active.click();
      } else if (keyCode === UP) {
        event.preventDefault();
        setCursor((length + cursor - 1) % length);
        setInputActive(false);
      } else if (keyCode === DOWN) {
        event.preventDefault();
        setCursor((cursor + 1) % length);
        setInputActive(false);
      } else {
        setInputActive(true);
        setCursor(-1);
      }
    };

    window.addEventListener('keydown', handleKeyDownListener, true);

    return () => window.removeEventListener('keydown', handleKeyDownListener, true);
  }, [userList, cursor]);

  const isActive = impersonatedUser => {
    return current ? impersonatedUser.id === current.id : false;
  };

  return (
    <div data-testid="UserImpersonation" className={styles.container}>
      <SearchBar active={inputActive} onInputChange={handleInputChange} placeholder="Search User..." />
      {userList.length ? (
        <div className={styles['container__scroll']}>
          {userList.map(impersonatedUser => (
            <UserImpersonationItem
              key={impersonatedUser.id}
              active={isActive(impersonatedUser)}
              impersonatedUser={impersonatedUser}
              handleSelectUser={handleSelectUser}
            />
          ))}
        </div>
      ) : (
        <div className={styles['container__empty']}>No results</div>
      )}
    </div>
  );
};

// @Export Component
export default UserImpersonation;
