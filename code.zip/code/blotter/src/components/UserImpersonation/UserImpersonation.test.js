import React from 'react';
import { render, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import UserImpersonation from './UserImpersonation';
import { ImpersonatedUsersContext } from '~contexts/ImpersonatedUsersContext';

// Unmount everything from the dom after each test
afterEach(cleanup);

const impersonatedUsersMock = [
  {
    id: 'cscarinci',
    name: 'Christine Scarinci',
    level3: 'US FI Management',
    role: 'Business Management',
    primaryRole: 'COO',
    blocked: false
  },
  {
    id: 'bhewitt',
    name: 'Brian Hewitt',
    level3: 'High Yield',
    role: 'Account Executive',
    primaryRole: 'Sales',
    blocked: false
  }
];

describe('<UserImpersonation />', () => {
  test('renders components with empty user list', () => {
    const { container, getByTestId } = render(
      <ImpersonatedUsersContext.Provider value={{ impersonatedUsers: [] }}>
        <UserImpersonation />
      </ImpersonatedUsersContext.Provider>
    );
    const component = getByTestId('UserImpersonation');
    const searchBar = getByTestId('SearchBar');
    const peopleList = container.querySelectorAll('.user-information__list');

    expect(component).toBeInTheDocument();
    expect(searchBar).toBeInTheDocument();
    expect(peopleList.length).toBe(0);
  });

  test('renders components with impersonated user list', () => {
    const { container, getByTestId } = render(
      <ImpersonatedUsersContext.Provider value={{ impersonatedUsers: impersonatedUsersMock }}>
        <UserImpersonation />
      </ImpersonatedUsersContext.Provider>
    );
    const component = getByTestId('UserImpersonation');
    const searchBar = getByTestId('SearchBar');
    const peopleList = container.querySelectorAll('.user-information__list');

    expect(component).toBeInTheDocument();
    expect(searchBar).toBeInTheDocument();
    expect(peopleList.length).toBe(2);
  });
});
