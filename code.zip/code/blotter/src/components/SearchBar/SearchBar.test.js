import React from 'react';
import { render, cleanup, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import SearchBar from './SearchBar';
import { clientsMock, tickersMock, cusipsMock } from '~mocks/searchBar.json';

// Unmount everything from the dom after each test
afterEach(cleanup);

describe('<SearchBar />', () => {
  test('renders default SearchBar', () => {
    const { getByTestId } = render(<SearchBar />);
    const searchBar = getByTestId('SearchBar');

    expect(searchBar).toBeInTheDocument();
    expect(searchBar).toHaveTextContent('');
  });

  test('type something on SearchBar', () => {
    const { getByTestId } = render(<SearchBar />);
    const searchBar = getByTestId('SearchBar');

    const typedValue = 'Madison';
    fireEvent.change(searchBar, { target: { value: typedValue } });
    expect(searchBar).toHaveValue(typedValue);
  });
});
