import React, { memo, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import styles from './SearchBar.module.scss';

const SearchBar = ({
  onInputChange,
  onBlur,
  onFocus,
  onKeyDown = () => {},
  active,
  placeholder,
  resetInput = false,
  onResetInput = () => {},
  rounded = true,
  small = false,
  dataToFilter
}) => {
  const inputEl = useRef(null);
  const handleChange = event => {
    const userInput = event.target.value;
    if (dataToFilter) {
      const regex = new RegExp(userInput, 'i');
      const filteredData = dataToFilter.filter(item =>
        item.name ? item.name.match(regex) : item.ViewName.match(regex)
      );
      onInputChange && onInputChange(filteredData);
    } else {
      onInputChange && onInputChange(event.target.value);
    }
  };

  useEffect(() => {
    if (resetInput) {
      inputEl.current.value = '';
      onResetInput && onResetInput();
    }
  }, [resetInput, onResetInput]);

  useEffect(() => {
    if (active) inputEl.current.focus();
  }, [active]);

  return (
    <div className={`${styles.container} ${small ? styles.small : ''}`}>
      <input
        data-testid="SearchBar"
        ref={inputEl}
        onChange={handleChange}
        onKeyDown={onKeyDown}
        onBlur={onBlur}
        onFocus={onFocus}
        className={`${styles.input} ${rounded ? styles.rounded : ''}`}
        type="text"
        placeholder={placeholder}
      />
    </div>
  );
};

// @Proptypes
SearchBar.propTypes = {
  onInputChange: PropTypes.func,
  onBlur: PropTypes.func,
  onFocus: PropTypes.func,
  placeholder: PropTypes.string
};

SearchBar.defaultProps = {
  placeholder: 'SearchBar'
};

// @Export Component
export default memo(SearchBar);
