export const rfqCardDetailFieldsConfig = legNoPrefix => [
  {
    label: 'Settl Date',
    values: [
      {
        field: 'rfqdatesettl'
      }
    ],
    position: 'top-left'
  },
  {
    label: 'Days Till Settl',
    values: [{ field: `${legNoPrefix}rfqdayssettl` }],
    position: 'top-left'
  },
  {
    label: 'Our Price',
    values: [
      {
        field: 'rfqdealvalue',
        formatinstruction: {
          decFormat: 'base32'
        }
      }
    ],
    position: 'bottom-left'
  },
  {
    label: 'Sent Price',
    values: [
      {
        field: 'adjustedrfqdealvalue',
        formatinstruction: {
          decFormat: 'base32'
        }
      }
    ],
    position: 'bottom-left'
  },
  {
    label: 'Spread',
    values: [
      {
        field: `${legNoPrefix}rfqdealspread`
      }
    ],
    position: 'bottom-left'
  },
  {
    label: 'Size',
    values: [{ field: 'size' }],
    position: 'bottom-left'
  },
  {
    label: 'Comp',
    values: [
      {
        field: 'rfqnumofdealers'
      }
    ],
    position: 'bottom-left'
  },
  {
    label: 'C. Trader',
    values: [
      {
        field: 'custusername'
      }
    ],
    position: 'top-right'
  },
  {
    label: 'TRAX',
    values: [
      {
        field: 'traxaxessall_lastprice'
      }
    ],
    position: 'bottom-right'
  },
  {
    label: 'Editor',
    values: [
      {
        field: 'pxelasteditor'
      }
    ],
    position: 'bottom-right'
  },
  {
    label: 'Our',
    values: [
      {
        field: 'rfqbbgbid'
      },
      {
        field: 'rfqbbgask'
      }
    ],
    position: 'bottom-right'
  },
  {
    label: 'B2B',
    values: [
      {
        field: 'rfqvmobid'
      },
      {
        field: 'rfqvmoask'
      }
    ],
    position: 'bottom-right'
  },
  {
    label: 'Cov P/S',
    values: [
      {
        field: `${legNoPrefix}rfqcoverprice`
      },
      {
        field: `${legNoPrefix}rfqcoverspread`
      }
    ],
    position: 'bottom-right'
  }
];
