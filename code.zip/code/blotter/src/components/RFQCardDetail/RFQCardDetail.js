import React, { memo } from 'react';
import { applyFormatInstruction } from '~helpers/rfqFormatters';
import styles from './RFQCardDetail.module.scss';
import { showLiveAxeFlag, getAxeClass } from '~helpers/columnRenderer';
import { rfqCardDetailFieldsConfig } from './RFQCardDetailFieldsConfig';

const RFQCardDetail = props => {
  const { clientbuysell, description, axeside, axematch, legno } = props;
  const buySellClassName = clientbuysell?.toLowerCase();
  const showAxeIcon = showLiveAxeFlag(axeside);
  const axedClass = getAxeClass(axeside, axematch);

  const legNoPrefix =
    {
      0: '',
      1: 'l1_',
      2: 'l2_'
    }[legno] || '';

  const formatField = (field, formatInstruction, emptyValue = '----') => {
    const value = props[field];
    if (!value) return emptyValue;

    const columnDef = props.columnsDictionary.sourceColumnNames.find(column => column.sourcecolumnname === field);
    if (!columnDef) return value;
    let { formatinstruction, columntype } = columnDef;
    if (formatInstruction) {
      formatinstruction = formatInstruction;
    }
    return applyFormatInstruction(value, { formatinstruction, field }, columntype, false, props);
  };

  const renderField = ({ label, values }, group) => {
    const classNames = ['rfq-card-details__value'];
    if (group === 'bottom-right' && values.length === 1) {
      classNames.push('rfq-card-details__value--col-span-two');
    }
    return (
      <>
        <div className={styles['rfq-card-details__label']}>{label}</div>
        {values.map(({ field, formatinstruction }) => (
          <div className={classNames.map(className => styles[className]).join(' ')} key={field}>
            {formatField(field, formatinstruction)}
          </div>
        ))}
      </>
    );
  };

  const groups = ['top-left', 'top-right', 'bottom-left', 'bottom-right'];

  const renderGroup = group => {
    const classNames = ['rfq-card-details__group', 'rfq-card-details__group--' + group]
      .map(className => styles[className])
      .join(' ');

    return (
      <div className={classNames}>
        {rfqCardDetailFieldsConfig(legNoPrefix)
          .filter(({ position }) => position === group)
          .map(field => renderField(field, group))}
      </div>
    );
  };

  return (
    <article className={styles[`rfq-card-details`]}>
      <header className={styles[`rfq-card-details__header`]}>
        <div className={styles[`verb-${buySellClassName}`]}>
          <span className={styles.verb}>{clientbuysell ? `Client ${clientbuysell}` : ''}</span>
          <span className={styles.description}>{description || ''}</span>
          {showAxeIcon && <div className={`${styles['rfq-axed-content']} ${axedClass}`}>AXE</div>}
        </div>
      </header>
      <section className={styles['rfq-card-details__section']}>{groups.map(group => renderGroup(group))}</section>
    </article>
  );
};

export default memo(RFQCardDetail);
