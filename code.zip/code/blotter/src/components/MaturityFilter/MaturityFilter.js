import React, { Component } from 'react';
import { SortingMenu, Maturity } from '~components';
import { moveFilterComponentToTheLeft } from '~helpers/customFilterArrangement';
import { isEmpty } from 'flow-navigator-shared/dist/array';
import { isUndefined } from '~helpers/dataTypes';
import { MATURITY_FILTER } from '~constants/filters';
import { FILTER_MODEL_DATE } from '~constants/filterModelTypes';

class MaturityFilter extends Component {
  constructor(props) {
    super(props);

    this.state = {
      filter: [],
      direction: this.props.column.getSort()
    };

    this.myRef = React.createRef();
  }

  handleFilterChange = (startDate, endDate) => {
    const {
      filterChangedCallback,
      colDef: { field }
    } = this.props;
    const { filter } = this.state;

    if (isEmpty(filter) && isUndefined(startDate)) {
      filterChangedCallback();
      return;
    }

    this.setState(
      {
        filter: startDate && endDate ? [startDate, endDate] : []
      },
      () =>
        filterChangedCallback({
          columnMetadata: {
            filterType: MATURITY_FILTER,
            field
          }
        })
    );
  };

  getModel = () => {
    if (this.state.filter.length > 0) {
      return {
        field: this.props.colDef.field,
        headerName: this.props.colDef.headerName,
        dateFrom: this.state.filter[0],
        dateTo: this.state.filter[1] || null,
        filterType: FILTER_MODEL_DATE,
        type: ''
      };
    } else {
      return undefined;
    }
  };

  setModel = model => {
    const {
      filterChangedCallback,
      colDef: { field }
    } = this.props;

    this.setState(
      {
        filter: model ? [model.dateFrom, model.dateTo] : []
      },
      () =>
        filterChangedCallback({
          columnMetadata: {
            filterType: MATURITY_FILTER,
            field
          }
        })
    );
  };

  isFilterActive = () => {
    return this.state.filter.length > 0;
  };

  afterGuiAttached = () => {
    const customFilterContainer = this.myRef.current;

    if (customFilterContainer) {
      moveFilterComponentToTheLeft(customFilterContainer);
    }
  };

  setDirection = direction => {
    const { column, api } = this.props;
    const multisort = false;
    api.sortController.setSortForColumn(column, direction, multisort);
    this.setState({ direction });
  };

  render() {
    const { direction } = this.state;
    const { sortable } = this.props;

    return (
      <div ref={this.myRef}>
        <Maturity
          onFilterChange={this.handleFilterChange}
          sortingMenu={sortable ? <SortingMenu direction={direction} setDirection={this.setDirection} /> : null}
        />
      </div>
    );
  }
}

export default MaturityFilter;
