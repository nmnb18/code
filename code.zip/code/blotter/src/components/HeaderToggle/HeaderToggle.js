import React from 'react';
import styles from './HeaderToggle.module.scss';
import { FORCE_DEFAULT_THEME_CLASS } from '~helpers/globals';

const HeaderToggle = ({ onToggleChange, isToggleOn, text, className = null, forceDefaultTheme = false }) => (
  <div
    className={`${className ? styles[className] : styles['toggle']} ${
      forceDefaultTheme ? styles[FORCE_DEFAULT_THEME_CLASS] : ''
    }`}
    onClick={onToggleChange}
    onKeyPress={onToggleChange}
    role="button"
    tabIndex={0}
  >
    <div className={styles['toggle__title']}>{text}</div>
    <div className={styles[`toggle__container--${isToggleOn ? 'active' : 'inactive'}`]}>
      <div className={styles[`toggle__thumb--${isToggleOn ? 'active' : 'inactive'}`]}></div>
    </div>
  </div>
);

export default HeaderToggle;
