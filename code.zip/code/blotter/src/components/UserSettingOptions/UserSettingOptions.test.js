import React from 'react';
import { render, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import UserSettingOptions from './UserSettingOptions';
import { UserProvider } from '~contexts/UserContext';
import { BlotterProvider } from '~contexts/BlotterContext';

// Unmount everything from the dom after each test
afterEach(cleanup);

describe('<UserSettingOptions />', () => {
  test('renders component as an admin user', () => {
    const user = { isAdmin: true, name: 'Juan Vento' };

    const { container, getByTestId, getByText } = render(
      <UserProvider>
        <BlotterProvider>
          <UserSettingOptions user={user} />
        </BlotterProvider>
      </UserProvider>
    );
    const component = getByTestId('UserSettingOptions');
    const userInformation = getByTestId('UserInformation');
    const optionsList = container.querySelectorAll('nav button');

    expect(component).toBeInTheDocument();
    expect(userInformation).toBeInTheDocument();
    expect(optionsList.length).toBe(1);
    expect(getByText(/view as/i)).toBeInTheDocument();
  });

  test('renders component as a non admin user', () => {
    const user = { isAdmin: false, name: 'Juan Vento' };

    const { container, getByTestId } = render(
      <UserProvider>
        <BlotterProvider>
          <UserSettingOptions user={user} />
        </BlotterProvider>
      </UserProvider>
    );
    const component = getByTestId('UserSettingOptions');
    const userInformation = getByTestId('UserInformation');
    const optionsList = container.querySelectorAll('nav button');

    expect(component).toBeInTheDocument();
    expect(userInformation).toBeInTheDocument();
    expect(optionsList.length).toBe(0);
  });
});
