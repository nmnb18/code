// @External Dependencies
import React, { useState, useEffect, useRef, useContext } from 'react';
import PropTypes from 'prop-types';
import styles from './UserSettingOptions.module.scss';
import { sendLogAsync } from '~helpers/sendLogs';

// @Dependencies
import { UserInformation, UserImpersonation, RFQToggle } from '~components';
import { TriangleIcon, MadisonIcon } from '~common';
import { useClickOutside } from '~hooks';
import { UserContext } from '~contexts/UserContext';
import { BlotterContext } from '~contexts/BlotterContext';
import { ThemeContext, showThemeToggle } from '~contexts/ThemeContext';
import * as usageService from '~services/usageService';
import { newToken } from '~helpers/token';
import { BLOTTER_CONTAINER_URL, MADISON_ASSIST_LINK } from '~helpers/globals';
import { createNewFinWindow, openExternalBrowser } from '~helpers/openfin';
import { TextButton } from '~ui-library';
import { UserEntitlementContext } from '~contexts/UserEntitlementContext';
import HeaderToggle from '../HeaderToggle/HeaderToggle';

const defaulAdminSettingOptions = { name: 'View As', hasSubmenu: true };
const defaultImpersonatedUserOptions = { name: 'Return to self' };

// @Component
const UserSettingOptions = ({ onSelectSettingOption }) => {
  const myRef = useRef();
  const [isOpen, setIsOpen] = useClickOutside(myRef);
  const [selected, setSelected] = useState(null);
  const { impersonatedUser, setImpersonatedUser } = useContext(UserContext);
  const { userEntitlement } = useContext(UserEntitlementContext);
  const { blotter, isFlowBlotterMounted, setFlowBlotterMounted } = useContext(BlotterContext);
  const { isAdmin, isDeveloper } = userEntitlement;
  const { theme, toggleTheme } = useContext(ThemeContext);
  const [logStatus, setLogStatus] = useState(null);

  const handleSelectOption = impersonatedUser => {
    if (impersonatedUser) {
      // User clicked on 'Return to self'
      usageService.setImpersonatedUser(null);
      usageService.sendUsage({
        userAction: usageService.actions.RETURN_SELF
      });

      setImpersonatedUser(null);
      setIsOpen(false);
      if (isFlowBlotterMounted) setFlowBlotterMounted(false);

      onSelectSettingOption && onSelectSettingOption(newToken());
    } else {
      setIsOpen(isAdmin ? !isOpen : false);
    }
  };

  const handleSelectUser = selectedUser => {
    usageService.setImpersonatedUser(selectedUser);
    usageService.sendUsage({
      userAction: usageService.actions.IMPERSONATE,
      notes: { LoginAs: selectedUser }
    });

    setImpersonatedUser(selectedUser);
    setIsOpen(false);
    if (isFlowBlotterMounted) setFlowBlotterMounted(false);

    onSelectSettingOption && onSelectSettingOption();
  };

  const openNewWin = async () => {
    const application = await window.fin.Application.getCurrent();
    const childWindows = await application.getChildWindows();
    const popup = childWindows.find(child => child.identity.name === 'Developer Settings');

    if (!popup) {
      const winOption = {
        name: 'Developer Settings',
        url: `${BLOTTER_CONTAINER_URL}settingspage/users`,
        frame: false,
        defaultCentered: true,
        resizable: true,
        cornerRounding: {
          width: 5,
          height: 5
        }
      };

      return createNewFinWindow(winOption);
    } else {
      popup.focus();
    }
  };

  const navigateToMadison = () => {
    const navigateUrl = `${MADISON_ASSIST_LINK}${blotter}`;

    usageService.sendUsage({
      userAction: usageService.actions.MADISON_ASSIST_NAVIGATE
    });

    openExternalBrowser(
      navigateUrl,
      () => console.log('Open external URL success', navigateUrl),
      err => console.log('Open external Url fail', err)
    );
  };

  const handleLogging = async () => {
    setLogStatus('sending');
    sendLogAsync(
      () => {
        setLogStatus('success');
      },
      () => {
        setLogStatus('error');
      }
    );
  };

  useEffect(() => {
    !isOpen && setSelected(null);
  }, [isOpen, selected]);

  return (
    <div data-testid="UserSettingOptions" ref={myRef} className={styles.container}>
      <UserInformation showVersion={true} user={userEntitlement} />
      <nav className={styles['options-list']}>
        {impersonatedUser && (
          <div
            className={`${styles['options-list__item']} ${styles['options-list__label']}`}
            onClick={() => handleSelectOption(impersonatedUser)}
            onKeyPress={() => handleSelectOption(impersonatedUser)}
            role="button"
            tabIndex={0}
          >
            <span>{defaultImpersonatedUserOptions.name}</span>
          </div>
        )}
        {isAdmin && (
          <button
            className={`
              ${styles['options-list__item']} 
              ${defaulAdminSettingOptions.hasSubmenu ? styles['options-list__item--hasSubmenu'] : ''}
            `}
            onClick={() => handleSelectOption()}
          >
            {isAdmin && defaulAdminSettingOptions.hasSubmenu && <TriangleIcon />}
            <span>{defaulAdminSettingOptions.name}</span>
          </button>
        )}
        <>
          {isDeveloper && (
            <button
              onClick={openNewWin}
              className={`
              ${styles['options-list__item']} 
            `}
            >
              <span>Developer Settings</span>
            </button>
          )}
          <div className={styles['options-list__section-title']}>Flow Settings</div>

          <div className={styles['options-list__section-detail']}>
            <RFQToggle />
          </div>
          {showThemeToggle && (
            <>
              <div className={styles['options-list__section-title']}>Global Settings</div>
              <div className={styles['options-list__section-detail']}>
                <HeaderToggle
                  isToggleOn={theme.value === 'light'}
                  onToggleChange={toggleTheme}
                  text="Light theme"
                  forceDefaultTheme
                />
              </div>
            </>
          )}
          <hr className={styles['options-list__hr']}></hr>
        </>
        <div className={styles['options-list__section-title']}>Help:</div>
        <div className={styles['options-list__helpsection']}>
          <button title="M Assist" onClick={navigateToMadison} className={styles['m-assist']}>
            <MadisonIcon />
          </button>
          <TextButton
            handleClick={handleLogging}
            size="flexHeight"
            colorScheme="secondary--dark"
            disabled={logStatus === 'sending'}
          >
            {logStatus !== 'sending' && 'Send logs'}
            {logStatus === 'sending' && 'Sending...'}
          </TextButton>
        </div>
        {logStatus === 'success' && <div className={styles['log-sent']}>Thanks for sending your log files.</div>}
        {logStatus === 'error' && (
          <div className={styles['log-error']}>There was a problem sending the logs. Please try again.</div>
        )}
        {isOpen && <UserImpersonation onSelectUser={handleSelectUser} />}
      </nav>
    </div>
  );
};

// @Proptypes
UserSettingOptions.propTypes = {
  user: PropTypes.shape({
    name: PropTypes.string.isRequired,
    level3: PropTypes.string,
    role: PropTypes.string
  })
};

// @Export Component
export default UserSettingOptions;
