import React, { useEffect, useMemo, useState } from 'react';
import { jasperApi } from '~services/apiConfig';
import { Router, Link, useNavigate } from '@reach/router';
import ReactJson from 'react-json-view';
import styles from './DeveloperSettingsPopup.module.scss';
import { MinimizeIcon, MaximizeIcon, CloseIcon } from '~common';
import { ReactComponent as UserSettingsIcon } from '~assets/icon/devsettings/user-settings.svg';
import { ReactComponent as DictionariesIcon } from '~assets/icon/devsettings/column-dictionary.svg';
import { Modal } from '~ui-library';
import { isJson } from '~helpers/json';

const DeveloperSettingsPopup = () => {
  useEffect(() => {
    var finWindow = window.fin.desktop.Window.getCurrent();
    finWindow.getOptions(function(options) {
      document.title = options.name;
    });
  }, []);

  const currentFinWindow = window.fin.desktop.Window.getCurrent();
  const handleMinimize = () => currentFinWindow && currentFinWindow.minimize();

  const [maximized, setMaximized] = useState(false);

  const handleMaximize = () => {
    if (window.fin) {
      !maximized ? currentFinWindow.maximize() : currentFinWindow.restore();
      setMaximized(!maximized);
    }
  };

  const handleClose = () => currentFinWindow.close();

  const isPartiallyActive = ({ isPartiallyCurrent }) => {
    return isPartiallyCurrent ? { className: styles['links--active'] } : { className: styles['links'] };
  };

  return (
    <div>
      <div className={styles['mainbar']}>
        <div className={styles['navbar']}>
          <div className={styles['navbar__buttons']}>
            <button onClick={handleMinimize}>
              <MinimizeIcon />
            </button>
            <button onClick={handleMaximize}>
              <MaximizeIcon />
            </button>
            <button onClick={handleClose}>
              <CloseIcon />
            </button>
          </div>

          <div className={styles['sidenav']}>
            <div>
              <h3 className={styles['title']}>FLOW</h3>
              <p className={styles['version']}>
                Settings Editor <em>v1.0</em>{' '}
              </p>
            </div>

            <Link getProps={isPartiallyActive} to="users">
              <div className={styles['navlink']}>
                <div className={styles['testicon']}>
                  <UserSettingsIcon />
                </div>
                <p className={styles['linktext']}>User Settings</p>
              </div>
            </Link>
            <Link getProps={isPartiallyActive} to="cd">
              <div className={styles['navlink']}>
                <div className={styles['testicon']}>
                  <DictionariesIcon />
                </div>
                <p className={styles['linktext']}>Column Dictionary</p>
              </div>
            </Link>
          </div>
        </div>

        <div className={styles['container']}>
          <Router>
            <DeveloperSettingsUser path="/users" />
            <DeveloperSettingsViewer path="/:type/*instance" />
            <DeveloperSettingsCD path="/cd" />
          </Router>
        </div>
      </div>
    </div>
  );
};

const DeveloperSettingsUser = () => {
  const [userSearchTerm, setUserSearchTerm] = useState('');

  const handleUserSearchTermChange = event => {
    setUserSearchTerm(event.target.value);
  };

  const navigate = useNavigate();

  const onSubmitSearch = event => {
    event.preventDefault();
    navigate(`/settingspage/users/${userSearchTerm}`);
  };

  return (
    <div>
      <div className={styles['wholepage']}>
        <div>
          <h3>User Settings</h3>

          <form className={styles['searchbar']} onSubmit={onSubmitSearch}>
            <input
              className={styles['searchinput']}
              placeholder="Search for username.."
              onChange={handleUserSearchTermChange}
              value={userSearchTerm}
            />
            <button className={styles['menu-button']}>Search</button>
          </form>
        </div>
      </div>
    </div>
  );
};

const DeveloperSettingsCD = () => {
  return (
    <div className={styles['container']}>
      <div className={styles['wholepage']}>
        <h3>Column Dictionaries</h3>
        <nav className={styles['cdbuttons']}>
          <Link to="/settingspage/cd/Flow">
            <button className={styles['menu-button']}>Main Blotter</button>
          </Link>
          <Link to="/settingspage/cd/FlowRFQNotification">
            <button className={styles['menu-button']}>RFQ Popup</button>
          </Link>
        </nav>
      </div>
    </div>
  );
};

const DeveloperSettingsViewer = props => {
  const [data, setData] = useState(null);
  const [originalData, setOriginalData] = useState(null);
  const [updatedData, setUpdatedData] = useState(null);

  const prefix = props.type === 'cd' ? 'column-dictionaries' : 'user-settings/users';
  const [dataError, setDataError] = useState(false);

  useEffect(() => {
    const abortCtrl = new AbortController();

    fetch(`${jasperApi.url}/${prefix}/${props.instance}`, {
      method: 'GET',
      mode: 'cors',
      credentials: 'include',
      redirect: 'follow',
      signal: abortCtrl.signal
    })
      .then(response => response.json())
      .then(data => {
        const stringData = JSON.stringify(data.data.response, null, 2);
        setData(stringData);
        setOriginalData(stringData);
        if (data.data.response === null) {
          setDataError(true);
        }
      })
      .catch(error => {
        if (error.name === 'AbortError') {
          console.log('Error: request was cancelled');
        } else {
          console.log(error);
        }
      });
    return () => abortCtrl.abort();
  }, [prefix, props.instance]);

  const [changesSavedMsg, setChangesSavedMsg] = useState(false);
  const [dataSuccess, setDataSuccess] = useState(false);

  const updateSettings = async () => {
    if (isJson(updatedData)) {
      fetch(`${jasperApi.url}/${prefix}/${props.instance}`, {
        method: 'PUT',
        mode: 'cors',
        body: JSON.stringify(JSON.parse(updatedData)),
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        redirect: 'follow'
      })
        .then(response => response.json())
        .then(resdata => {
          if (resdata.data.ObjectHealth === 'OK') {
            setDataSuccess(true);
          } else {
            setShowDialog(true);
          }
        })
        .catch(error => {
          setShowDialog(true);
        });
      setData(updatedData);
      await setChangesSavedMsg(true);
    } else {
      setShowJSONDialog(true);
    }
  };

  function discardChanges() {
    setUpdatedData(originalData);
  }

  function handleDataChange(event) {
    event.preventDefault();
    setUpdatedData(event.target.value);
  }

  const CD = 'cd';

  const isDataEditable = value => {
    return value !== CD;
  };

  const Expire = props => {
    useEffect(() => {
      setTimeout(() => {
        setChangesSavedMsg(false);
      }, 5000);
      return () => clearTimeout();
    }, []);

    return dataSuccess ? <div>{props.children}</div> : null;
  };

  const [showDialog, setShowDialog] = useState(false);
  const [showJSONDialog, setShowJSONDialog] = useState(false);
  const [JSONformatted, setJSONformatted] = useState(false);

  const DataComponent = useMemo(() => {
    const handleFormatSwitch = () => {
      setJSONformatted(!JSONformatted);
    };
    return (
      <div>
        <div className={styles['settings-container']}>
          <h3>Settings: {props.instance}</h3>
          {JSON.parse(data) === null ? null : (
            <div className={styles['formatter']}>
              <button className={styles['menu-button']} onClick={handleFormatSwitch}>
                Switch to {JSONformatted === false ? 'Formatted' : 'Parsed'}
              </button>
            </div>
          )}
        </div>
        <div>
          {dataError ? (
            <p className={styles['dataerror']}>Data not found!</p>
          ) : data ? (
            JSONformatted === true ? (
              isDataEditable(props.type) ? (
                <ReactJson
                  name={false}
                  src={updatedData ? JSON.parse(updatedData) : JSON.parse(data)}
                  displayObjectSize={false}
                  displayDataTypes={false}
                  theme={'bright'}
                  enableClipboard={false}
                  onEdit={e => {
                    setUpdatedData(JSON.stringify(e.updated_src));
                  }}
                  onAdd={e => {
                    setUpdatedData(JSON.stringify(e.updated_src));
                  }}
                  onDelete={e => {
                    setUpdatedData(JSON.stringify(e.updated_src));
                  }}
                  style={{
                    backgroundColor: '$blue00',
                    paddingRight: '2%',
                    width: '100%',
                    height: '75vh',
                    overflowY: 'scroll'
                  }}
                />
              ) : (
                <div>
                  <ReactJson
                    name={false}
                    src={data && JSON.parse(data)}
                    displayObjectSize={false}
                    displayDataTypes={false}
                    theme={'bright'}
                    enableClipboard={false}
                    style={{
                      backgroundColor: '$blue00',
                      paddingRight: '2%',
                      width: '100%',
                      height: '75vh',
                      overflowY: 'scroll'
                    }}
                  />
                </div>
              )
            ) : (
              <textarea
                onChange={handleDataChange}
                value={updatedData ? updatedData : data}
                readOnly={!isDataEditable(props.type) ? true : false}
              ></textarea>
            )
          ) : (
            'loading data...'
          )}
        </div>
      </div>
    );
  }, [JSONformatted, data, dataError, props.instance, props.type, updatedData]);

  function DataButtonComponent() {
    return (
      <div>
        {!isDataEditable(props.type) || JSON.parse(data) === null ? null : updatedData && data !== updatedData ? (
          <div className={styles['bottombuttons']}>
            <button className={styles['menu-button']} onClick={updateSettings}>
              Save Changes
            </button>
            <button className={styles['menu-button']} onClick={discardChanges}>
              Clear Changes
            </button>
          </div>
        ) : changesSavedMsg ? (
          <div className={dataSuccess ? styles['saved-changes'] : undefined}>
            <Expire delay="5000">Changes saved!</Expire>
          </div>
        ) : (
          <p className={styles['no-changes']}>No unsaved changes</p>
        )}
      </div>
    );
  }

  function DataSaveError() {
    return (
      <div>
        {!dataSuccess && (
          <Modal isOpen={showDialog}>
            <div className={styles['dialog-text']}>
              <p>Error with saving changes</p>
              <button className={styles['menu-button']} onClick={updateSettings}>
                Retry
              </button>
              <button className={styles['menu-button']} onClick={() => setShowDialog(false)}>
                Close
              </button>
            </div>
          </Modal>
        )}
      </div>
    );
  }

  function DataJsonError() {
    return (
      <Modal isOpen={showJSONDialog}>
        <div className={styles['dialog-text']}>
          <p>JSON is not valid!</p>
          <button className={styles['menu-button']} onClick={() => setShowJSONDialog(false)}>
            Okay
          </button>
        </div>
      </Modal>
    );
  }

  return (
    <div className={styles['container']}>
      {DataComponent}

      <DataButtonComponent />
      <DataSaveError />
      <DataJsonError />
    </div>
  );
};

export default DeveloperSettingsPopup;
