import React from 'react';
import './Branding.scss';

const Branding = () => <p>Branding</p>;

export default Branding;
