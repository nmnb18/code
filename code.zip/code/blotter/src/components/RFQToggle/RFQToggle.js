import React, { useContext, useMemo } from 'react';
import { BlotterUserSettingsContext } from '~contexts/BlotterUserSettingsContext';
import { UserContext } from '~contexts/UserContext';
import { APP_NAME } from '~helpers/globals';
import { getRFQNotificationPopup } from '~helpers/userSettings';
import { mmiControlsDefaultState, RFQ_POPUP_CONTROL, showControl } from '~services/mmiService';
import { HeaderToggle } from '~components';
import styles from './RFQToggle.module.scss';
import { sharedSettingsActions } from '~helpers/userSettingsActionCreator';

const RFQToggle = ({ className = '', toggleVal = false }) => {
  const { windowOptions } = useContext(UserContext);
  const { blotterUserSettings } = useContext(BlotterUserSettingsContext);
  const isRFQNotificationToggleOn = useMemo(() => getRFQNotificationPopup(blotterUserSettings, APP_NAME), [
    blotterUserSettings
  ]);

  const winOptions = useMemo(() => {
    if (!windowOptions) {
      const { showRFQPopupControl } = mmiControlsDefaultState;
      return { showRFQPopupControl };
    }

    return {
      showRFQPopupControl: showControl(windowOptions, RFQ_POPUP_CONTROL)
    };
  }, [windowOptions]);

  return (
    winOptions.showRFQPopupControl && (
      <>
        <div className={styles['rfq-toggle']}>
          <HeaderToggle
            isToggleOn={toggleVal || isRFQNotificationToggleOn}
            onToggleChange={() => sharedSettingsActions.toggleRFQPopup({ toggledFrom: 'main window' })}
            text="RFQ Popup"
            className={className}
            forceDefaultTheme
          />
        </div>
      </>
    )
  );
};

export default RFQToggle;
