import React, { useState, useEffect, useRef } from 'react';
import './styles.scss';
import { notifications as mockNotifications } from '~mocks/notifications';
import { BellIcon, SettingsIcon } from '~common';
import { NotificationItem } from '~components';
import { useClickOutside } from '~hooks';

const Notify = () => {
  const myRef = useRef();
  const [notifications, setNotifications] = useState([]);
  const [isOpen, setIsOpen] = useClickOutside(myRef);

  useEffect(() => {
    setNotifications(mockNotifications);
  }, []);

  const handleIsOpen = () => setIsOpen(!isOpen);

  const handleDismissItem = id => {
    const remainingNotifications = notifications.filter(item => item.id !== id);

    setNotifications(remainingNotifications);
  };

  const handleDismissAll = () => setNotifications([]);

  const handleRead = (event, id) => {
    event.preventDefault();
    const newArray = [...notifications];
    const notificationIndex = newArray.findIndex(item => item.id === id);
    newArray[notificationIndex].read = true;
    setNotifications(newArray);
  };

  return (
    <div ref={myRef} className="notify notify--container">
      <button onClick={handleIsOpen} className="notify__bell">
        <BellIcon />
      </button>
      <span className="notify__bubble">{notifications.length}</span>
      {isOpen && (
        <div className="notify__list">
          <header>
            <span>Alerts</span>
            <div className="notify__actions">
              <button className="notify__actions__dismissAll" onClick={handleDismissAll}>
                Dismiss All
              </button>
              <SettingsIcon />
            </div>
          </header>
          <table>
            <tbody>
              <tr>
                <th>Time</th>
                <th>JEF Side</th>
                <th>Security</th>
                <th>Type</th>
                <th>Size</th>
                <th># of client</th>
                <th></th>
              </tr>
              {notifications.map(item => (
                <NotificationItem key={item.id} {...item} dismissItem={handleDismissItem} markAsRead={handleRead} />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default Notify;
