import React, { memo } from 'react';
import styles from './RFQPopupFooter.module.scss';

const RFQPopupFooter = ({ totalRows }) => <div className={styles['footer-text']}>{totalRows} Items</div>;

export default memo(RFQPopupFooter);
