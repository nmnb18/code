import React from 'react';
import './styles.scss';
import { CloseIcon } from '~common';

const NotificationItem = ({ id, time, side, security, type, size, read, matchers, dismissItem, markAsRead }) => (
  <tr className="notify-item notify-item-container">
    <td className="notify-item__cell notify-item__cell--time">{time}</td>
    <td className={`notify-item__cell notify-item__cell--side notify-item__cell--side--${side}`}>{side}</td>
    <td className={`notify-item__cell notify-item__cell--security ${read ? 'read' : 'unread'}`}>
      <a href={`/notification/${id}`} onClick={event => markAsRead(event, id)}>
        {security}
      </a>
    </td>
    <td className="notify-item__cell notify-item__cell--type">{type}</td>
    <td className="notify-item__cell notify-item__cell--size">{size}</td>
    <td className="notify-item__cell notify-item__cell--matchers">
      <span>{matchers}</span>
    </td>
    <td className="notify-item__cell notify-item__cell--dismiss">
      <button onClick={() => dismissItem(id)}>
        <CloseIcon />
      </button>
    </td>
  </tr>
);

export default NotificationItem;
