import React from 'react';
import SortingItem from './SortingItem';
import styles from './SortingMenu.module.scss';
import { SORT_ASC, SORT_DESC, SORT_NONE } from '~helpers/sort';

const SortingMenu = ({ direction, setDirection }) => {
  const sortOptions = { SORT_ASC, SORT_DESC, SORT_NONE };

  return (
    <div className={styles['sorting-menu']}>
      {Object.entries(sortOptions).map(([key, value]) => (
        <SortingItem
          selected={value && direction === value}
          key={key}
          itemType={key}
          setDirection={setDirection.bind(null, value)}
        />
      ))}
    </div>
  );
};

export default SortingMenu;
