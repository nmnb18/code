import React from 'react';
import { render, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { QuickLauncher } from '~components';
import { applicationSettings } from '~services/apiConfig';
import { UserProvider } from '~contexts/UserContext';
import { BlotterProvider } from '~contexts/BlotterContext';

// Unmount everything from the dom after each test
afterEach(cleanup);

const blotterApps = Object.keys(applicationSettings).slice(0, 3);

describe('<QuickLauncher />', () => {
  test('renders component', () => {
    const { getByTestId, getAllByTestId } = render(
      <UserProvider>
        <BlotterProvider>
          <QuickLauncher />
        </BlotterProvider>
      </UserProvider>
    );
    const component = getByTestId('QuickLauncher');
    expect(component).toBeInTheDocument();

    const buttons = getAllByTestId('LauncherButton');
    expect(buttons.length).toBe(blotterApps.length);

    expect(buttons[0]).toHaveTextContent(/flow/i);
    expect(buttons[1]).toHaveTextContent(/axe/i);
    expect(buttons[2]).toHaveTextContent(/client/i);
  });
});
