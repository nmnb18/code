import React, { useState, useEffect, useContext, useMemo } from 'react';
import PropTypes from 'prop-types';
import styles from './QuickLauncher.module.scss';
import { LauncherButton } from '~components';
import { BlotterContext } from '~contexts/BlotterContext';
import { BlotterUserSettingsContext } from '~contexts/BlotterUserSettingsContext';
import { FLOW } from '~helpers/globals';
import * as usageService from '~services/usageService';
import { getEnabledAppsConfig } from '~helpers/blotter';
import { flowBlotterService } from '~services/flowBlotterService';
import { flowBlotterActions, flowBlotterChangesFoundTopicForParent } from '~services/openfinConfig';
import { iabSubscribe, iabUnsubscribe } from '~services/openfinService';

const FlowNavigatorSwitchingBlotterLog = 'Flow Navigator Switching Blotter Topic for Parent';

const isLeavingFlowBlotter = (currentBlotter, targetBlotter) => currentBlotter === FLOW && targetBlotter !== FLOW;

const QuickLauncher = () => {
  const { blotter, isFlowBlotterMounted, setBlotter, setFlowBlotterMounted } = useContext(BlotterContext);
  const { blotterUserSettings } = useContext(BlotterUserSettingsContext);
  const [selectedBlotterIndex, setSelectedBlotterIndex] = useState(0);
  const enabledAppsConfig = useMemo(() => getEnabledAppsConfig(blotterUserSettings), [blotterUserSettings]);

  const handleSelected = (selectedBlotterApp, index) => {
    if (blotter === selectedBlotterApp) return;

    setSelectedBlotterIndex(index);

    if (isLeavingFlowBlotter(blotter, selectedBlotterApp)) {
      flowBlotterService.sendEvent({ type: flowBlotterActions.switchingBlotterApp });
    } else {
      const targetBlotter = enabledAppsConfig.find(({ DisplayOrder }) => DisplayOrder === index);
      if (!targetBlotter) return;

      setBlotter(targetBlotter.title);
      usageService.setBlotterApp(targetBlotter.title);
    }

    usageService.sendUsage({
      userAction: usageService.actions.NAVIGATE,
      notes: { Destination: selectedBlotterApp }
    });
  };

  useEffect(() => {
    const handleMessage = payload => {
      const { unsavedChanges } = payload;
      if (unsavedChanges) return;

      const targetBlotter = enabledAppsConfig.find(({ DisplayOrder }) => DisplayOrder === selectedBlotterIndex);
      if (!targetBlotter) return;

      flowBlotterService.handleMultiFilterUnsubscription();
      setBlotter(targetBlotter.title);
      if (isFlowBlotterMounted) setFlowBlotterMounted(false);
      usageService.setBlotterApp(targetBlotter.title);
    };

    iabSubscribe({
      topic: flowBlotterChangesFoundTopicForParent,
      handler: handleMessage,
      logLabel: FlowNavigatorSwitchingBlotterLog
    });

    return () =>
      iabUnsubscribe({
        topic: flowBlotterChangesFoundTopicForParent,
        handler: handleMessage,
        logLabel: FlowNavigatorSwitchingBlotterLog
      });
  }, [selectedBlotterIndex, setBlotter, enabledAppsConfig, isFlowBlotterMounted, setFlowBlotterMounted]);

  return (
    <div data-testid="QuickLauncher" className={styles['quick-launcher']}>
      {enabledAppsConfig.map(({ DisplayOrder, title }) => (
        <LauncherButton
          key={`${DisplayOrder}-${title}`}
          className={`${styles['quick-launcher__button']} ${
            blotter === title ? styles['quick-launcher__button--active'] : ''
          }`}
          name={title}
          onClick={() => handleSelected(title, DisplayOrder)}
        />
      ))}
    </div>
  );
};

// @Proptypes
QuickLauncher.propTypes = {
  onSelectBlotter: PropTypes.func
};

export default QuickLauncher;
