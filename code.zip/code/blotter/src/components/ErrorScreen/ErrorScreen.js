// @External Dependencies
import React, { Component } from 'react';
import styles from './ErrorScreen.module.scss';

// @Component
export default class ErrorScreen extends Component {
  render() {
    const { errorTitle } = this.props;
    return (
      <div className={styles['no-access']}>
        <div className={styles['no-access__container']}>
          <span className={styles['no-access__icon']}>!</span>

          <div className={styles['no-access__message']}>
            <h3 className={styles['no-access__message__title']}>{errorTitle}</h3>
          </div>
        </div>
      </div>
    );
  }
}
