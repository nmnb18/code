import React, { useContext } from 'react';
import styles from './ProgressBar.module.scss';
import { getCurrentExcelProgressPercentage } from '~helpers/exportHelper';
import { Timer } from '~components';
import { ThemeContext } from '~contexts/ThemeContext';

const ProgressBar = ({ processedRecord, totalRecords, isFetchingData }) => {
  const { theme } = useContext(ThemeContext);
  return (
    <div className={`${styles['progress-wrapper']}  ${theme?.value ? 'theme--' + theme.value : ''}`}>
      <label className={styles['progress-wrapper__label']} htmlFor="file">
        Export Progress:
      </label>
      <div className={styles['progress-wrapper__bar']}>
        <label className={styles['progress-wrapper__bar-count']}>
          <span>
            {processedRecord}/{totalRecords}
          </span>{' '}
          <Timer isActive={!!isFetchingData}></Timer>
        </label>
        <progress className={styles.progressBar} id="file" value={processedRecord} max={totalRecords}></progress>
      </div>
      <label className={styles['progress-wrapper__label']}>
        <span>{getCurrentExcelProgressPercentage({ processedRecord, totalRecords })}</span>
      </label>
    </div>
  );
};

export default ProgressBar;
