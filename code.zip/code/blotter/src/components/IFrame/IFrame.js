import React from 'react';
import './IFrame.scss';

const IFrame = ({ url, name }) => (
  <iframe
    data-testid="IFrame"
    className="iframe-container"
    title={name}
    src={url}
    frameBorder="0"
    id="frameContainer"
  />
);

export default IFrame;
