import React, { Component } from 'react';

export default class CustomTooltip extends Component {
  getReactContainerClasses() {
    return ['custom-tooltip'];
  }

  render() {
    const valueToDisplay = this.props.value.value ? this.props.value.value : '';
    return (
      <div className="custom-tooltip">
        <p>
          <span>{valueToDisplay}</span>
        </p>
      </div>
    );
  }
}
