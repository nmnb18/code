import { isClientNameColum, isAxeSideColum, isPriorityAxeColum } from '~helpers/columnStyles';
import { getLiveAxeContent, getPriorityAxeContent } from '~helpers/columnRenderer';

export default function customColumnRenderer() {}

customColumnRenderer.prototype.init = function(params) {
  this.eGui = document.createElement('div');
  const { colDef, value, data } = params;
  const { field } = colDef;

  if (value || (isClientNameColum(field) && !value)) {
    if (isAxeSideColum(field)) {
      const { axeside, axematch } = data;
      this.eGui.innerHTML = getLiveAxeContent(axeside, axematch);
      return;
    } else if (isPriorityAxeColum(field)) {
      const { priorityaxe } = data;
      this.eGui.innerHTML = getPriorityAxeContent(priorityaxe);
      return;
    } else {
      this.eGui.innerHTML = `<div class='btn-with-hyperlink'><span>${value || ''}</span></div>`;
      return;
    }
  } else {
    this.eGui.innerHTML = `<span></span>`;
    return;
  }
};

customColumnRenderer.prototype.getGui = function() {
  return this.eGui;
};
