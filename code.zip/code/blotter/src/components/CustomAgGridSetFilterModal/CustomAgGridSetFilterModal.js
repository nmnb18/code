import React, { useState, useEffect, useCallback } from 'react';
import styles from './CustomAgGridSetFilterModal.module.scss';
import { KEYS } from '~helpers/keyCodes';
import { isEmpty } from 'flow-navigator-shared/dist/array';

const mapToFilterOptions = (options, filterList, forceCheck = false) =>
  options.map((option, index) => ({
    pos: index,
    value: option,
    checked: isOptionCheck(option, filterList, forceCheck)
  }));

const mapToSelectAllState = (options, checked) =>
  options.map((option, index) => ({
    pos: index,
    value: option,
    checked
  }));

const isOptionCheck = (option, filterList, forceCheck) => {
  if (forceCheck || isEmpty(filterList)) return true;

  return filterList.includes(option);
};

const getFilterOptionsByValue = (filterOption, value) =>
  filterOption.filter(
    filterOption =>
      filterOption &&
      filterOption['value'] !== undefined &&
      filterOption['value'].toLowerCase().includes(value.toLowerCase())
  );

const countSelectedItems = filteredList =>
  filteredList.reduce((acc, cur) => {
    acc = acc + (cur['checked'] === true ? 1 : 0);
    return acc;
  }, 0);

//options -> The list of all the options associated with the SetFilter
//filterList -> The list of the filters apllied to this particular SetFilter based on the breadcrumb
const CustomAgGridSetFilterModal = ({ options, disabledOptions, filterList, onFilterChange, sortingMenu }) => {
  const [selectAll, setSelectAll] = useState(true);
  const [applyButtonState, setApplyButtonState] = useState(false);
  const [filteredList, setFilteredList] = useState([]);
  const [inputText, setInputText] = useState('');

  useEffect(() => {
    const filterOptions = mapToFilterOptions(options, filterList);
    setFilteredList(filterOptions);
  }, [setFilteredList, options, filterList]);

  //Dinamically check if the "Select All Check" is checked or not based on the numbrer of selected Options
  useEffect(() => {
    const selectedItemsTotal = countSelectedItems(filteredList);
    const areAllItemsSelected = !!(selectedItemsTotal > 0 && selectedItemsTotal === filteredList.length);
    setSelectAll(areAllItemsSelected);
  }, [setSelectAll, filteredList]);

  useEffect(() => {
    // On user typing we filter the options using the text or the breadcrumb
    // if the user has type anything on the input text, we will use the text for filter the options and check them by default
    // if the input text is empty, we show all the options and check them using the breadcrumb
    const forceCheck = inputText.length > 0;
    const filterOptions = mapToFilterOptions(options, filterList, forceCheck);
    const filteredOptions = getFilterOptionsByValue(filterOptions, inputText);
    setFilteredList([...filteredOptions]);
  }, [options, inputText, filterList, setFilteredList]);

  const handleClear = useCallback(() => onFilterChange([]), [onFilterChange]);

  const handleApply = useCallback(() => {
    if (isEmpty(filteredList)) {
      onFilterChange([]);
    } else {
      onFilterChange(filteredList);
      setInputText('');
    }
  }, [filteredList, onFilterChange, setInputText]);

  const toggleAll = useCallback(() => {
    const checked = !selectAll;
    const filterOptions = mapToSelectAllState(options, checked);
    setFilteredList(filterOptions);
  }, [selectAll, options, setFilteredList]);

  const toggleApplyButtonState = useCallback(() => {
    const filteredListCopy = [...filteredList];
    const checkedFilter = filteredListCopy.filter(obj => obj.checked);
    if (checkedFilter.length === 0) {
      setApplyButtonState(true);
    } else {
      setApplyButtonState(false);
    }
  }, [filteredList, setApplyButtonState]);

  const toggle = useCallback(
    selectedValue => {
      const filteredListCopy = [...filteredList];
      const selectedValueIndex = filteredListCopy.findIndex(obj => obj.value === selectedValue);
      if (selectedValueIndex !== -1) {
        filteredListCopy[selectedValueIndex].checked = !filteredListCopy[selectedValueIndex].checked;
        setFilteredList([...filteredListCopy]);
      }
      toggleApplyButtonState();
    },
    [filteredList, setFilteredList, toggleApplyButtonState]
  );

  const handleKeyDown = useCallback(
    event => {
      if (event.keyCode === KEYS.ENTER) {
        event.preventDefault();
        handleApply();
      }
    },
    [handleApply]
  );

  const getFilteredListOptions = useCallback(() => {
    if (isEmpty(filteredList)) return null;

    return filteredList.map((optionValue, index) => (
      <div
        key={`filterchooser_${optionValue.value}_${index}`}
        className={`${styles['set-advanced-options__filter-option']} ${
          disabledOptions.includes(optionValue.value) ? styles['set-advanced-options__filter-option-disable'] : ''
        }`}
      >
        <label className={styles['set-advanced-options-checkbox-container']}>
          {optionValue.value}
          <input type="checkbox" onChange={() => toggle(optionValue.value)} checked={filteredList[index].checked} />
          <span className={styles['set-advanced-options-checkbox-checkmark']}></span>
        </label>
      </div>
    ));
  }, [filteredList, disabledOptions, toggle]);

  const getSearchBox = useCallback(() => {
    return (
      <>
        <div className={styles['set-advanced-options__wrapper-textbox']}>
          <input
            className={styles['set-advanced-options__textbox']}
            type="text"
            placeholder="Search..."
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            onKeyDown={handleKeyDown}
          />
        </div>
        <div
          className={`${styles['set-advanced-options__wrapper-selectall']} ${
            disabledOptions.includes('Select All') ? styles['set-advanced-options__wrapper-selectall-disable'] : ''
          }`}
        >
          <label className={styles['set-advanced-options-checkbox-container']}>
            Select All
            <input type="checkbox" onChange={toggleAll} checked={selectAll} />
            <span className={styles['set-advanced-options-checkbox-checkmark']}></span>
          </label>
        </div>
      </>
    );
  }, [inputText, setInputText, handleKeyDown, disabledOptions, toggleAll, selectAll]);

  return (
    <div className={styles['set-advanced-options']}>
      {sortingMenu}
      {getSearchBox()}
      <div className={styles['set-advanced-options__wrapper-body']}>{getFilteredListOptions()}</div>
      <footer className={styles['set-advanced-options__footer']}>
        <button onClick={handleClear}>Clear Filter</button>
        <button disabled={applyButtonState} onClick={handleApply}>
          Apply Filter
        </button>
      </footer>
      <div className={styles['set-advanced-options__footer__fix']}></div>
    </div>
  );
};

export default CustomAgGridSetFilterModal;
