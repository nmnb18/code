// @Dependencies
import React, { useRef, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import styles from './ViewsList.module.scss';

// @Dependencies
import * as settingsService from '~services/settingsService';
import { ViewsSelector } from '~components';
import { ChevrondownIcon } from '~common';
import { FLOW_APP_NAME } from '~helpers/globals';
import { useClickOutside } from '~hooks';
import { KEYS } from '~helpers/keyCodes';
import { IconButton } from '~ui-library';
import { ReactComponent as SettingsIcon } from '~assets/icon/settings.svg';

// @Component
const ViewsList = ({ onSelectView, setCurrentViewName, userSettings }) => {
  const myRef = useRef();
  const [isOpen, setIsOpen] = useClickOutside(myRef);
  const [view, setView] = useState('');
  const [viewsList, setViewsList] = useState([]);
  const [cursor, setCursor] = useState(-1);
  const [current, setCurrent] = useState(null);
  const [inputActive, setInputActive] = useState(true);

  useEffect(() => {
    if (userSettings) {
      const selectedViewName = settingsService.getSelectedPopUpViewName(userSettings, FLOW_APP_NAME);
      const views = settingsService.getViewsList(userSettings, FLOW_APP_NAME);
      const selectedView = selectedViewName && views && views.find(view => view.ViewName === selectedViewName);
      selectedViewName && setCurrentViewName(selectedViewName);
      views && setViewsList(views);
      selectedView && setView(selectedView);
    }
  }, [userSettings, setCurrentViewName]);

  useEffect(() => {
    const handleKeyDownListener = event => {
      const { keyCode } = event;
      const active = document.activeElement;
      const length = viewsList.length;
      const { ENTER, UP, DOWN } = KEYS;
      if (keyCode === ENTER) {
        if (active instanceof HTMLElement) active.click();
      } else if (keyCode === UP) {
        event.preventDefault();
        setCursor((length + cursor - 1) % length);
        setInputActive(false);
      } else if (keyCode === DOWN) {
        event.preventDefault();
        setCursor((cursor + 1) % length);
        setInputActive(false);
      } else {
        setInputActive(true);
        setCursor(-1);
      }
    };

    if (isOpen) {
      window.addEventListener('keydown', handleKeyDownListener, true);
    }

    return () => window.removeEventListener('keydown', handleKeyDownListener, true);
  }, [isOpen, cursor, viewsList]);

  useEffect(() => {
    setCurrent(viewsList[cursor]);
  }, [cursor, viewsList]);

  const handleSelectedView = (view, editing) => {
    if (!editing) {
      setView(view);
    }
    onSelectView(view, editing);
    setIsOpen(false);
  };

  const handleIsOpen = () => {
    setCurrent(null);
    setCursor(-1);
    setInputActive(!isOpen);
    setIsOpen(!isOpen);
  };

  return (
    <div ref={myRef} data-testid="ViewsList" className={styles['views-list']}>
      <button
        onClick={handleIsOpen}
        className={`${styles['views-list__selected']} ${isOpen ? styles['views-list__selected--opened'] : ''}`}
      >
        <span>{view.ViewName}</span>
        <div className={styles['views-list__selected__actions']}>
          <ChevrondownIcon />
        </div>
      </button>
      {view.ReadOnly ? (
        <div className={styles['views-list__whitespace']}></div>
      ) : (
        <IconButton handleClick={() => handleSelectedView(view, 'edit')} title="Rename / Delete / Set view as default">
          <SettingsIcon />
        </IconButton>
      )}
      {isOpen && (
        <ViewsSelector
          inputActive={inputActive}
          current={current}
          viewsList={viewsList}
          onSelectView={handleSelectedView}
          setCurrentViewName={setCurrentViewName}
        />
      )}
    </div>
  );
};

// @Proptypes
ViewsList.propTypes = {
  onSelectView: PropTypes.func
};

// @Export component
export default ViewsList;
