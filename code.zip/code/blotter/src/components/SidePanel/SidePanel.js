import React, { useEffect, useRef } from 'react';
import { TriangleIcon } from '~common';
import './SidePanel.scss';

const SidePanel = ({ show, toggle }) => {
  const myRef = useRef(null);
  const panelClass = show ? 'side-panel open' : 'side-panel';
  const triggerClass = show ? 'trigger open' : 'trigger';

  useEffect(() => {
    const handleClickOutside = event => {
      if (
        show &&
        ((event.type === 'mousedown' && myRef.current && !myRef.current.contains(event.target)) ||
          event.type === 'blur')
      ) {
        toggle();
      }
    };

    window.addEventListener('blur', handleClickOutside);
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      window.removeEventListener('blur', handleClickOutside);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [show, toggle]);

  return (
    <div className="side-panel-container" ref={myRef}>
      <div className={panelClass}>
        <div className="side-panel-content">
          <main>side panel content goes here</main>
        </div>
      </div>
      <div className={triggerClass}>
        <div className="border"></div>
        <div className="arrow-wrapper">
          <button className="icon-wrapper" onClick={toggle}>
            <TriangleIcon active={show} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default SidePanel;
