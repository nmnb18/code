import React from 'react';
import { render, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import UserInformation from './UserInformation';

// Unmount everything from the dom after each test
afterEach(cleanup);

describe('<UserInformation />', () => {
  test('renders component', () => {
    // Renders component
    const user = {
      name: 'Juan Vento',
      level3: 'FI Technology',
      role: 'Admin'
    };
    const { getByTestId } = render(<UserInformation user={user} />);
    const component = getByTestId('UserInformation');
    const userIcon = getByTestId('UserIcon');
    const userName = component.querySelector('ul li:nth-child(1)');
    const userLevel3 = component.querySelector('ul li:nth-child(2)');
    const userRole = component.querySelector('ul li:nth-child(3)');
    const { name, level3, role } = user;

    expect(component).toBeInTheDocument();
    expect(userIcon).toBeInTheDocument();
    expect(userName).toHaveTextContent(name);
    expect(userLevel3).toHaveTextContent(level3);
    expect(userRole).toHaveTextContent(role);
  });
});
