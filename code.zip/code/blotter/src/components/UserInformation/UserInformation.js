// @External Dependencies
import React from 'react';
import PropTypes from 'prop-types';
import styles from './UserInformation.module.scss';

// @Dependencies
import { UserIcon } from '~common';
import { PROJECT_VERSION } from '~helpers/globals';

// @Component
const UserInformation = ({ user, showVersion }) => (
  <div data-testid="UserInformation" className={styles['container']}>
    <div className={styles['user-info']}>
      <UserIcon />
      <ul className={styles['user-information__list']}>
        <li className={styles['user-information__name']}>{user.name}</li>
        <li>{user.level3}</li>
        <li>{user.role}</li>
      </ul>
    </div>
    {showVersion && <span className={styles['version-number']}>v{PROJECT_VERSION}</span>}
  </div>
);

// @Proptypes
UserInformation.propTypes = {
  user: PropTypes.shape({
    name: PropTypes.string.isRequired,
    level3: PropTypes.string,
    role: PropTypes.string
  })
};

// @Export Component
export default UserInformation;
