import React from 'react';
import { createHistory, LocationProvider, Router } from '@reach/router';
import createHashSource from 'hash-source';
import { App, IFramePopup, RFQPopup } from '~components';
import { BlotterProvider } from '~contexts/BlotterContext';
import { BlotterUserSettingsProvider } from '~contexts/BlotterUserSettingsContext';
import { WebSocketProvider } from '~contexts/WebSocketContext';
import { ColumnDictionariesProvider } from '~contexts/ColumnDictionariesContext';
import { UserEntitlementProvider } from '~contexts/UserEntitlementContext';
import { DeveloperSettingsPopup } from '~components';
import { ThemeProvider } from '~contexts/ThemeContext';

const source = createHashSource();
const history = createHistory(source);

const Routes = () => {
  return (
    <LocationProvider history={history}>
      <ColumnDictionariesProvider>
        <WebSocketProvider>
          <BlotterProvider>
            <BlotterUserSettingsProvider>
              <UserEntitlementProvider>
                <ThemeProvider>
                  <Router>
                    <App path="/" />
                  </Router>
                </ThemeProvider>
                <Router>
                  <RFQPopup path="/rfq" />
                  <IFramePopup path="/iframepopup" />
                </Router>
              </UserEntitlementProvider>
            </BlotterUserSettingsProvider>
          </BlotterProvider>
        </WebSocketProvider>
      </ColumnDictionariesProvider>
      <Router>
        <DeveloperSettingsPopup path="/settingspage/*" />
      </Router>
    </LocationProvider>
  );
};

export default Routes;
