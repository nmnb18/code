import React, { useEffect, useRef } from 'react';
import styles from './ViewsSelectorItem.module.scss';

const ViewsSelectorItem = ({ view, handleSelectedView, active }) => {
  const myRef = useRef();

  useEffect(() => {
    active && myRef.current.focus();
  }, [active]);

  const activeClass = active ? styles['views-selector-view-item--active'] : '';

  return (
    <button
      ref={myRef}
      className={`${styles['views-selector-view-item']} ${activeClass}`}
      onClick={() => handleSelectedView(view)}
    >
      {view.ViewName}
    </button>
  );
};

export default ViewsSelectorItem;
