import React, { useRef, useContext, useMemo } from 'react';
import styles from './Dropdown.module.scss';
import { useClickOutside, useUserEntitlement } from '~hooks';
import { AddIcon } from '~common';
import { postMessageActions } from '~helpers/globals';
import { requestXiosWindow } from '~helpers/popups';
import { UserContext } from '~contexts/UserContext';
import { isInquiryAllowed } from '~services/entitlementService';
import { uiEntitlementOptions, showEntitlementOption } from '~helpers/entitlement';

const Dropdown = () => {
  const myRef = useRef();
  const { currentUser, impersonatedUser } = useContext(UserContext);
  const [isOpen, setIsOpen] = useClickOutside(myRef);
  const entitlement = useUserEntitlement();
  const handleIsOpen = () => setIsOpen(!isOpen);

  const { displayInquiryOptions, displayPortfolioOptions } = useMemo(
    () => ({
      displayInquiryOptions: isInquiryAllowed(entitlement),
      displayPortfolioOptions: showEntitlementOption(entitlement, uiEntitlementOptions.PORTFOLIO_VISIBLE)
    }),
    [entitlement]
  );

  const handleOnClick = popupType => {
    const userData = {
      realUser: impersonatedUser ? impersonatedUser.id : currentUser,
      signedInUser: currentUser
    };

    requestXiosWindow({ userData, popupType, sendUsage: true });
  };

  return displayInquiryOptions || displayPortfolioOptions ? (
    <div ref={myRef} className={styles['dropdown dropdown--container']}>
      <button className={styles['dropdown__icon']} onClick={handleIsOpen}>
        <AddIcon />
      </button>
      {isOpen && (
        <div className={styles['dropdown__options']}>
          {displayInquiryOptions && (
            <span>
              <button onClick={() => handleOnClick(postMessageActions.addInquiry)}>Add Inquiry</button>
              <button onClick={() => handleOnClick(postMessageActions.manageInquiry)}>Manage Inquiry</button>
            </span>
          )}
          {displayPortfolioOptions && (
            <>
              <div className={styles['dropdown__blackline']}></div>
              <button onClick={() => handleOnClick(postMessageActions.addPortfolio)}>Add Portfolio</button>
              <button onClick={() => handleOnClick(postMessageActions.managePortfolio)}>Manage Portfolio</button>
            </>
          )}
        </div>
      )}
    </div>
  ) : null;
};

export default Dropdown;
