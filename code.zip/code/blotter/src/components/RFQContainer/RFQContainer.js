import React, { Component } from 'react';
import { Subject } from 'rxjs';
import { createProxyCacheService } from '~services/proxyCacheService';
import { defaultFilterRange } from '~helpers/proxyService';
import * as userSettingsService from '~services/userSettingsService';
import * as columnDictionaryService from '~services/columnDictionaryService';
import * as integrationService from '~services/integrationService';
import { removeFalsyValues } from 'flow-navigator-shared/dist/array';
import { FLOW_APP_NAME } from '~helpers/globals';
import { getSubscriptionsInstances } from '~helpers/subscriptions';
import { COLUMNS } from '~helpers/columnStyles';
import { CustomFilterFactory } from '~patterns/factory-method/customFilter';
import { AXED_FILTER } from '~constants/filters';
import { rfqNotificationService } from '~services/rfqNotificationService';
import { getColumnFilters } from '~helpers/viewSettings';

class RFQContainer extends Component {
  proxyCacheService;
  subscriptionIdSubject = new Subject();
  subscriptionIdSubject$ = this.subscriptionIdSubject.asObservable();

  state = {
    columnDefs: []
  };

  componentDidMount() {
    const { columnsDictionary, userSettings, signedInUser, currentFinUser, currentComputer } = this.props;
    rfqNotificationService.initRFQNotificationCache$();
    const { rfqSubscriptionInstanceId: subscriptionInstanceId } = getSubscriptionsInstances({
      signedInUser,
      flowNavigatorUser: currentFinUser,
      computerId: currentComputer
    });
    this.setupProxyCacheService(this.subscriptionIdSubject$, this.handleRequestData);
    this.setSubscriptionInstance(subscriptionInstanceId);
    this.setRFQColumnDefinition(userSettings, columnsDictionary, currentFinUser, signedInUser);
  }

  componentDidUpdate(_, prevState) {
    const { columnDefs: columnDefsPrev } = prevState;
    const { columnDefs } = this.state;
    const { isRFQNotificationPopupClosed, rfqNotificationRequestedRangeSubject } = rfqNotificationService;

    if (columnDefs !== columnDefsPrev && isRFQNotificationPopupClosed) {
      // Ask Websocket for RFQ totals only if RFQ popup is closed
      rfqNotificationRequestedRangeSubject.next(defaultFilterRange);

      this.handleRequestData({
        ...defaultFilterRange,
        newCriteria: true,
        requireRFQNotificationPopupConfiguration: true
      });
    }
  }

  componentWillUnmount() {
    this.proxyCacheService && this.proxyCacheService.disconnect();
    this.requestSubscription && this.requestSubscription.unsubscribe();
  }

  setupProxyCacheService = (subsInstance$, handleRequestData) => {
    this.proxyCacheService = createProxyCacheService(subsInstance$, handleRequestData);
  };

  setSubscriptionInstance = subscriptionInstanceId => this.subscriptionIdSubject.next(subscriptionInstanceId);

  setRFQColumnDefinition = (userSettings, columnsDictionary, currentFinUser, signedInUser) => {
    if (!userSettings || !columnsDictionary) return;

    const viewSettings = userSettingsService.getPopupViewSettings(userSettings, FLOW_APP_NAME, null);
    if (!viewSettings) return;

    const columnDefs = integrationService.getColumnsDefinition({
      view: viewSettings,
      columnsDictionary,
      currentUser: currentFinUser,
      isTechOrAdmin: null,
      signedInUser
    });
    if (!columnDefs) return;

    const filteredColumnDefs = removeFalsyValues(columnDefs);
    const alwaysRequiredColumnDefs = columnDictionaryService.getAlwaysRequestColumnDefinitions(columnsDictionary);
    const legsFields = columnDictionaryService.getLegColumnDefinitions(filteredColumnDefs);
    const enhancedColumnDefs = [...filteredColumnDefs, ...legsFields];
    const filteredAlwaysRequestColumnDef = integrationService.filterRepetedColumn(
      alwaysRequiredColumnDefs,
      enhancedColumnDefs
    );
    const nonRepeatedEnchancedColumnDefs = [...enhancedColumnDefs, ...filteredAlwaysRequestColumnDef];

    const { axeOnly } = this.props;
    const liveAxeColumnDef = nonRepeatedEnchancedColumnDefs.find(colDef => colDef.colId === COLUMNS.AXESIDE);

    let liveAxeFilterOption = [];
    if (liveAxeColumnDef && axeOnly) {
      const liveAxeFilter = new CustomFilterFactory().createCustomFilter(liveAxeColumnDef, AXED_FILTER);
      liveAxeFilterOption = [liveAxeFilter];
    }
    const filterFromViewSettings = getColumnFilters(viewSettings);

    this.setState({
      columnDefs: nonRepeatedEnchancedColumnDefs,
      filterList: [...filterFromViewSettings, ...liveAxeFilterOption]
    });
  };

  handleRequestData = ({ firstRow, lastRow, newCriteria = false } = {}) => {
    const { columnDefs, filterList } = this.state;
    const { requestData, gridId, appName, signedInUser, currentFinUser, currentComputer, rfqToggles } = this.props;

    const { rfqSubscriptionInstanceId: subscriptionInstanceId } = getSubscriptionsInstances({
      signedInUser,
      flowNavigatorUser: currentFinUser,
      computerId: currentComputer
    });

    requestData &&
      requestData({
        subscriptionInstanceId,
        columnDefs,
        firstRow,
        lastRow,
        newCriteria,
        gridId,
        appName,
        toggles: rfqToggles,
        filterList,
        requireRFQNotificationPopupConfiguration: true
      });
  };

  render() {
    return <></>;
  }
}

export default RFQContainer;
