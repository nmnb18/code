import React from 'react';
import styles from './ErrorModal.module.scss';
import Modal from '../Modal/Modal';

const ErrorModal = ({ content, controls, isOpen, onDismiss = () => {} }) => {
  return (
    <Modal isOpen={isOpen} onDismiss={onDismiss} customModalClass={styles.modal}>
      <div className={styles.errorIcon}>!</div>
      <div className={styles.content}>{content}</div>
      <div className={styles.controls}>{controls}</div>
    </Modal>
  );
};

export default ErrorModal;
