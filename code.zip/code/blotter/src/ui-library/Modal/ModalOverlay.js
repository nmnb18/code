// legacy component - aim is to use reach-dialog for modals, at which point this can be removed.
import React from 'react';
import PropTypes from 'prop-types';
import styles from './ModalOverlay.module.scss';

const ModalOverlay = ({ handleClick }) => <div className={styles.component} onClick={handleClick} />;

ModalOverlay.propTypes = {
  handleClick: PropTypes.func.isRequired
};

export default ModalOverlay;
