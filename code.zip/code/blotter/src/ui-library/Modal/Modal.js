import React from 'react';
import { DialogContent, DialogOverlay } from '@reach/dialog';
import '@reach/dialog/styles.css';
import styles from './Modal.module.scss';

const Modal = ({
  children,
  isOpen,
  onDismiss = () => {},
  customOverlayClass = null,
  customModalClass = null,
  aria = 'modal'
}) => {
  return (
    <DialogOverlay
      isOpen={isOpen}
      className={`${styles.overlay}  ${customOverlayClass ? customOverlayClass : ''}`}
      onDismiss={onDismiss}
    >
      <DialogContent className={`${styles.modal} ${customModalClass ? customModalClass : ''}`} aria-label={aria}>
        {children}
      </DialogContent>
    </DialogOverlay>
  );
};

export default Modal;
