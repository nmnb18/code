import React from 'react';
import PropTypes from 'prop-types';
import styles from './IconButton.module.scss';
import Tooltip from '../Tooltip/Tooltip';

const IconButton = ({
  children,
  type = 'button',
  disabled = false,
  size = 'default',
  form,
  handleClick,
  title,
  colorScheme = 'default',
  width = '22px',
  padding = '4px',
  disabledExtremeStyle = false,
  disabledAllowEvents = false
}) => {
  const optionalAttributes = {
    form: form,
    onClick: handleClick
  };
  const customStyle =
    size === 'custom'
      ? {
          width,
          padding
        }
      : {};
  const button = (
    <button
      type={type}
      disabled={disabled}
      className={`${styles.component} ${styles['color-' + colorScheme]} ${styles['size-' + size]} ${
        disabledExtremeStyle ? styles.disabledExtremeStyle : ''
      } ${disabledAllowEvents ? styles.disabledAllowEvents : ''}`}
      {...optionalAttributes}
      style={customStyle}
    >
      {children}
    </button>
  );
  if (!title) return button;

  return (
    <Tooltip label={title} disable={disabled}>
      {button}
    </Tooltip>
  );
};

IconButton.propTypes = {
  children: PropTypes.node.isRequired,
  type: PropTypes.oneOf(['submit', 'button']),
  disabled: PropTypes.bool,
  size: PropTypes.oneOf(['tiny', 'small', 'default', 'large', 'custom']),
  colorScheme: PropTypes.oneOf(['default', 'blueHover', 'transparent']),
  form: PropTypes.string,
  handleClick: PropTypes.func,
  title: PropTypes.string,
  width: PropTypes.string,
  padding: PropTypes.string,
  disabledExtremeStyle: PropTypes.bool
};

export default IconButton;
