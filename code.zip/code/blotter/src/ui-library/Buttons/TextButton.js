import React from 'react';
import PropTypes from 'prop-types';
import styles from './TextButton.module.scss';

const TextButton = ({
  children,
  type = 'button',
  disabled = false,
  colorScheme = 'primary',
  fit = 'normalWidth',
  size = 'normalHeight',
  form,
  handleClick,
  fillWidth = false,
  active = false
}) => {
  const optionalAttributes = {
    form: form,
    onClick: handleClick
  };
  return (
    <button
      type={type}
      disabled={disabled}
      className={`${styles.component} ${styles[colorScheme]} ${styles[fit]} ${styles[size]} ${
        fillWidth ? styles.fillWidth : ''
      } ${active ? styles[colorScheme + '--active'] : ''}`}
      {...optionalAttributes}
    >
      {children}
    </button>
  );
};

TextButton.propTypes = {
  children: PropTypes.node.isRequired,
  type: PropTypes.oneOf(['submit', 'button']),
  disabled: PropTypes.bool,
  colorScheme: PropTypes.oneOf(['primary', 'secondary', 'secondary--dark', 'danger']),
  fit: PropTypes.oneOf(['narrowWidth', 'normalWidth']),
  size: PropTypes.oneOf(['small', 'normalHeight', 'flexHeight']),
  form: PropTypes.string,
  handleClick: PropTypes.func,
  fillWidth: PropTypes.bool,
  active: PropTypes.bool
};

export default TextButton;
