import React from 'react';
import { default as ReachTooltip } from '@reach/tooltip';
import '@reach/tooltip/styles.css';
import styles from './Tooltip.module.scss';

const Tooltip = ({ children, label, disable = false, className = null }) => {
  if (disable) return children;
  return (
    <ReachTooltip label={label} className={`${styles.tooltip} ${className}`}>
      {children}
    </ReachTooltip>
  );
};
export default Tooltip;
