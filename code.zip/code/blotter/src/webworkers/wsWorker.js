import { BehaviorSubject } from 'rxjs';
import wsActions from './wsActions';
import { JasperWebSocketService } from '../services/jasperWebSocketService';
import { WS_MESSAGE_TYPE } from '~helpers/jasperMessage';
import {
  defaultMainGridId,
  defaultRfqGridId,
  exportDataSourceId,
  defaultMultiFilterFlowId,
  defaultMultiFilterRfqGridId,
  defaultFlowBlotterMiniTicketPanelId
} from '~helpers/jasperWebSocket';
import { jasperWs } from '~services/apiConfig';

const useSingleWebSocketInstance = jasperWs.url === jasperWs.multiSelectUrl;

const {
  INIT_WS,
  INIT_WS_SUCCESS,
  CONNECT_WS,
  CONNECT_WS_SUCCESS,
  DISCONNECT_WS,
  DISCONNECT_WS_SUCCESS,
  SUBSCRIBE_TO_WS_CONNECTION_STATUS_CHANGE,
  WS_REQUEST,
  WS_REQUEST_FILTER,
  WS_RFQ_FLOW_BLOTTER_RESPONSE,
  WS_RFQ_NOTIFICATION_RESPONSE,
  WS_RFQ_EXPORT_DATASOURCE_RESPONSE,
  WS_MULTI_FILTER_FLOW_BLOTTER_RESPONSE,
  WS_MULTI_FILTER_RFQ_NOTIFICATION_RESPONSE,
  SUBSCRIBE_TO_WS_MS_CONNECTION_STATUS_CHANGE,
  WS_MS_REQUEST
} = wsActions;

const WS_MESSAGE_TYPE_TO_SUBSCRIBE = [
  WS_MESSAGE_TYPE.RFQ_MESSAGE,
  WS_MESSAGE_TYPE.RFQ_TOTALS,
  WS_MESSAGE_TYPE.FIELDS_MESSAGE
];

let jasperWebSocket;
let datasourceSubscription;
let connectionStatusSubscription;
let ampsStatusSubscription;
let jasperWebSocketFilterSubject = new BehaviorSubject(null);

let multiSelectWebSocket;
let multiSelectDatasourceSubscription;
let multiSelectConnectionStatusSubscription;
let multiSelectAmpsStatusSubscription;

const subscriptionTopicTypes = {
  [defaultMainGridId]: WS_RFQ_FLOW_BLOTTER_RESPONSE,
  [defaultFlowBlotterMiniTicketPanelId]: WS_RFQ_FLOW_BLOTTER_RESPONSE,
  [defaultRfqGridId]: WS_RFQ_NOTIFICATION_RESPONSE,
  [exportDataSourceId]: WS_RFQ_EXPORT_DATASOURCE_RESPONSE,
  [defaultMultiFilterFlowId]: WS_MULTI_FILTER_FLOW_BLOTTER_RESPONSE,
  [defaultMultiFilterRfqGridId]: WS_MULTI_FILTER_RFQ_NOTIFICATION_RESPONSE
};

const multiSelectSubscriptionTopicTypes = {
  [defaultMultiFilterFlowId]: WS_MULTI_FILTER_FLOW_BLOTTER_RESPONSE,
  [defaultMultiFilterRfqGridId]: WS_MULTI_FILTER_RFQ_NOTIFICATION_RESPONSE
};

const getSubscriptionTopic = source => {
  const typeIndex = source.lastIndexOf('_');
  const type = source.substring(typeIndex + 1);
  return type;
};

export const handleWsWorkerRequest = message => {
  if (!message) return;

  const { type } = message;
  switch (type) {
    case INIT_WS: {
      // This code run once
      jasperWebSocket = new JasperWebSocketService(
        WS_MESSAGE_TYPE_TO_SUBSCRIBE,
        jasperWebSocketFilterSubject,
        jasperWs.url
      );

      if (!useSingleWebSocketInstance)
        multiSelectWebSocket = new JasperWebSocketService(
          WS_MESSAGE_TYPE_TO_SUBSCRIBE,
          jasperWebSocketFilterSubject,
          jasperWs.multiSelectUrl
        );

      postMessage({ type: INIT_WS_SUCCESS });
      return;
    }
    case CONNECT_WS: {
      const {
        payload: { user, columnsDictionaries }
      } = message;
      const wsParams = user ? { user } : null;

      jasperWebSocket.connect(wsParams, columnsDictionaries);
      if (multiSelectWebSocket) multiSelectWebSocket.connect(wsParams);

      // Grid Subscription
      connectionStatusSubscription = jasperWebSocket.connectionStatus.subscribe(webSocketStatus =>
        postMessage({
          type: SUBSCRIBE_TO_WS_CONNECTION_STATUS_CHANGE,
          payload: { ampsConnected: webSocketStatus, webSocketDisconnected: !webSocketStatus }
        })
      );

      ampsStatusSubscription = jasperWebSocket.ampsStatus.subscribe(ampsStatus =>
        postMessage({
          type: SUBSCRIBE_TO_WS_CONNECTION_STATUS_CHANGE,
          payload: { ampsConnected: ampsStatus, webSocketDisconnected: !ampsStatus }
        })
      );

      datasourceSubscription = jasperWebSocket.datasource.subscribe(message => {
        const topicType = getSubscriptionTopic(message.source);
        const subscriptionTypes = subscriptionTopicTypes[topicType];

        subscriptionTypes && postMessage({ type: subscriptionTypes, payload: { message } });
      });

      if (multiSelectWebSocket) {
        // Multi Select Subscription
        multiSelectConnectionStatusSubscription = multiSelectWebSocket.connectionStatus.subscribe(webSocketStatus =>
          postMessage({
            type: SUBSCRIBE_TO_WS_MS_CONNECTION_STATUS_CHANGE,
            payload: { ampsConnected: webSocketStatus, webSocketDisconnected: !webSocketStatus }
          })
        );

        multiSelectAmpsStatusSubscription = multiSelectWebSocket.ampsStatus.subscribe(ampsStatus =>
          postMessage({
            type: SUBSCRIBE_TO_WS_MS_CONNECTION_STATUS_CHANGE,
            payload: { ampsConnected: ampsStatus, webSocketDisconnected: !ampsStatus }
          })
        );

        multiSelectDatasourceSubscription = multiSelectWebSocket.datasource.subscribe(message => {
          const topicType = getSubscriptionTopic(message.source);
          const subscriptionTypes = multiSelectSubscriptionTopicTypes[topicType];

          subscriptionTypes && postMessage({ type: subscriptionTypes, payload: { message } });
        });
      }

      postMessage({ type: CONNECT_WS_SUCCESS, payload: { user } });
      return;
    }
    case DISCONNECT_WS: {
      datasourceSubscription?.unsubscribe && datasourceSubscription.unsubscribe();
      connectionStatusSubscription?.unsubscribe && connectionStatusSubscription.unsubscribe();
      ampsStatusSubscription?.unsubscribe && ampsStatusSubscription.unsubscribe();
      jasperWebSocket.close();

      multiSelectDatasourceSubscription?.unsubscribe && multiSelectDatasourceSubscription.unsubscribe();
      multiSelectConnectionStatusSubscription?.unsubscribe && multiSelectConnectionStatusSubscription.unsubscribe();
      multiSelectAmpsStatusSubscription?.unsubscribe && multiSelectAmpsStatusSubscription.unsubscribe();
      multiSelectWebSocket.close();

      postMessage({ type: DISCONNECT_WS_SUCCESS });
      return;
    }
    case WS_REQUEST: {
      const {
        payload: { requestCommand }
      } = message;
      jasperWebSocket.send(requestCommand);
      return;
    }
    case WS_MS_REQUEST: {
      const {
        payload: { requestCommand }
      } = message;

      if (multiSelectWebSocket) multiSelectWebSocket.send(requestCommand);
      else jasperWebSocket.send(requestCommand);
      return;
    }
    case WS_REQUEST_FILTER: {
      const {
        payload: { filter }
      } = message;
      jasperWebSocket.dataSourceFilterSubject.next(filter);
      return;
    }
    default:
      return;
  }
};
