class wsWorker {}

module.exports = wsWorker;
