import React from 'react';
import ReactDOM from 'react-dom';
import { LicenseManager } from 'ag-grid-enterprise';
import './index.scss';
import { Auth, Routes } from '~components';
import { UserProvider } from '~contexts/UserContext';

// Configuring ag-grid enterprise license
LicenseManager.setLicenseKey(process.env.REACT_APP_AG_GRID_LICENSE);

ReactDOM.render(
  <UserProvider>
    <Auth>
      <Routes />
    </Auth>
  </UserProvider>,
  document.getElementById('root')
);
