import React, { useReducer, useCallback, useEffect, useContext, createContext } from 'react';
import * as userSettingsService from '~services/userSettingsService';
import { WebSocketContext } from '~contexts/WebSocketContext';
import { UserContext } from '~contexts/UserContext';
import {
  defaultViewSettings,
  getUserSharedSettings,
  getRFQPopupSharedSettings,
  getFilterToggleSharedSettings,
  getRFQPopupFilterToggleSharedSettings,
  replaceSharedSettings,
  copySessionData
} from '~helpers/userSettings';
import { getApplicationByName } from '~services/settingsService';
import { filterValidToggles, filterValidFilterToggles } from '~helpers/toggles';
import { getActionHandler } from '~helpers/userSettingsActionHandlers';
import { FLOW_APP_NAME, RFQ_APP_NAME } from '~helpers/globals';
import { rfqNotificationService } from '~services/rfqNotificationService';
import { flowBlotterService } from '~services/flowBlotterService';
import { userSettingsSyncTopic, flowBlotterActions } from '~services/openfinConfig';
import { blotterContainerService } from '~services/blotterContainerService';
import { iabSubscribe, iabUnsubscribe } from '~services/openfinService';

const fin = window.fin;

const initialState = {
  blotterUserSettings: null
};

const SET_BLOTTER_USER_SETTINGS = 'SET_BLOTTER_USER_SETTINGS';

function reducer(state, action) {
  switch (action.type) {
    case SET_BLOTTER_USER_SETTINGS:
      return {
        ...state,
        blotterUserSettings: action.payload.blotterUserSettings
      };
    default:
      return state;
  }
}

export const BlotterUserSettingsContext = createContext(null);

const notifyUserSettingsChangesToFlowBlotter = blotterUserSettings =>
  flowBlotterService.sendEvent({
    type: flowBlotterActions.updatedUserSettings,
    payload: { userSettings: blotterUserSettings }
  });
const notifyUserSettingsChangesToRFQPopup = blotterUserSettings =>
  rfqNotificationService.sendStateChangesToRFQNotification({ userSettings: blotterUserSettings });

const notifyUserSettingsChanges = ({ blotterUserSettings, target }) => {
  if (target === FLOW_APP_NAME) {
    notifyUserSettingsChangesToFlowBlotter(blotterUserSettings);
  } else if (target === RFQ_APP_NAME) {
    notifyUserSettingsChangesToRFQPopup(blotterUserSettings);
  } else {
    notifyUserSettingsChangesToFlowBlotter(blotterUserSettings);
    notifyUserSettingsChangesToRFQPopup(blotterUserSettings);
  }
};

export const BlotterUserSettingsProvider = props => {
  const [{ blotterUserSettings }, dispatch] = useReducer(reducer, initialState);
  const { webSocketUser } = useContext(WebSocketContext);
  const { currentUser, impersonatedUser, setToggles, setAllToggles, setCustomToggles } = useContext(UserContext);

  const setBlotterUserSettings = useCallback(
    _blotterUserSettings =>
      dispatch({ type: SET_BLOTTER_USER_SETTINGS, payload: { blotterUserSettings: _blotterUserSettings } }),
    [dispatch]
  );

  useEffect(() => {
    if (webSocketUser && currentUser) {
      const userSettingsSubscription = userSettingsService.getUserSettings(webSocketUser).subscribe(userSettings => {
        if (userSettings.User === currentUser) {
          const toggles = filterValidToggles(getUserSharedSettings(userSettings));
          const rfqToggles = filterValidToggles(getRFQPopupSharedSettings(userSettings));
          const filterToggles = filterValidFilterToggles(getFilterToggleSharedSettings(userSettings));
          const rfqFilterToggles = filterValidFilterToggles(getRFQPopupFilterToggleSharedSettings(userSettings));
          setAllToggles({ toggles, rfqToggles, filterToggles, rfqFilterToggles });
        }

        const { defaultView } = defaultViewSettings;

        const flowApplication = getApplicationByName(userSettings, FLOW_APP_NAME);
        const { DefaultPopUpView } = flowApplication;
        const popupView =
          DefaultPopUpView && flowApplication.PopUpViews.find(view => view.ViewName === DefaultPopUpView);
        flowApplication.DefaultPopUpView = popupView?.ViewName || defaultView;

        setBlotterUserSettings(userSettings);
      });

      return () => {
        userSettingsSubscription.unsubscribe();
      };
    }
  }, [currentUser, setBlotterUserSettings, setToggles, setAllToggles, webSocketUser]);

  const handleUsersettingsChange = useCallback(
    async ({ type, payload, origin, reload, syncWithServer, updateImpersonatedUserProfile }) => {
      if (blotterUserSettings === null) return;

      const impersonating = blotterUserSettings.User !== currentUser;
      let targetProfile = blotterUserSettings;
      if (impersonating && !updateImpersonatedUserProfile) {
        targetProfile = await userSettingsService.getUserSettings(currentUser).toPromise();
        replaceSharedSettings(targetProfile, blotterUserSettings);
      }

      const flowAppSettings = userSettingsService.getApplication(targetProfile, FLOW_APP_NAME);
      const handler = getActionHandler(type);
      const updatedFlowAppSettings = handler({
        ...payload,
        currentUser,
        flowAppSettings: { ...flowAppSettings },
        targetApp: origin,
        setCustomToggles
      });

      if (updatedFlowAppSettings === null) return;

      const updatedBlotterUserSettings = userSettingsService.updateApplicationSettings(
        targetProfile,
        FLOW_APP_NAME,
        updatedFlowAppSettings
      );

      const syncState = async _updatedBlotterUserSettings => {
        let blotterUserSettings = _updatedBlotterUserSettings;

        if (impersonating && !updateImpersonatedUserProfile) {
          blotterUserSettings = await userSettingsService.getUserSettings(impersonatedUser.id).toPromise();
          //shared settings from the impersonator user takes precedence
          replaceSharedSettings(blotterUserSettings, _updatedBlotterUserSettings);
          copySessionData(blotterUserSettings, _updatedBlotterUserSettings);
        }

        setBlotterUserSettings(blotterUserSettings);

        // Sync applications with store state (user settings)
        const target = !reload ? undefined : origin === FLOW_APP_NAME ? RFQ_APP_NAME : FLOW_APP_NAME;
        notifyUserSettingsChanges({ blotterUserSettings, target });

        //Post update actions
        //TODO: add validation for checking action originator
        if (payload.switchingBlotterApp) {
          flowBlotterService.sendSwitchBlotterResponse({ unsavedChanges: false });
        } else if (payload.forceClosing) {
          blotterContainerService.closeApp();
        } else if (reload) {
          if (origin === RFQ_APP_NAME) rfqNotificationService.sendReloadCommand();
          else flowBlotterService.sendEvent({ type: flowBlotterActions.reloadBlotterApp });
        }
      };

      if (syncWithServer) {
        const blotterUserSettings = userSettingsService.removeAppSessionData(updatedBlotterUserSettings, FLOW_APP_NAME);

        userSettingsService
          .updateUserSettings(blotterUserSettings.User, blotterUserSettings)
          .subscribe(() => syncState(updatedBlotterUserSettings));
      } else {
        syncState(updatedBlotterUserSettings);
      }
    },
    [currentUser, impersonatedUser, blotterUserSettings, setBlotterUserSettings, setCustomToggles]
  );

  //TODO: adapt useSubscription to this use case
  useEffect(() => {
    if (!fin || !fin.InterApplicationBus) {
      return () => null;
    }

    iabSubscribe({
      topic: userSettingsSyncTopic,
      handler: handleUsersettingsChange,
      logLabel: userSettingsSyncTopic
    });

    return () =>
      iabUnsubscribe({
        topic: userSettingsSyncTopic,
        handler: handleUsersettingsChange,
        logLabel: userSettingsSyncTopic
      });
  }, [handleUsersettingsChange]);

  const value = { blotterUserSettings, setBlotterUserSettings };

  return <BlotterUserSettingsContext.Provider value={value}>{props.children}</BlotterUserSettingsContext.Provider>;
};
