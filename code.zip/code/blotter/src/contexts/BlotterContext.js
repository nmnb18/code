import React, { useReducer, createContext, useCallback } from 'react';
import { blotterConfiguration } from '~helpers/blotter';

const initialState = {
  blotter: blotterConfiguration.flow,
  isFlowBlotterMounted: false
};

const SET_BLOTTER = 'SET_BLOTTER';
const SET_FLOW_BLOTTER_MOUNTED = 'SET_FLOW_BLOTTER_MOUNTED';

function reducer(state, action) {
  switch (action.type) {
    case SET_BLOTTER:
      return {
        ...state,
        blotter: action.payload.blotter
      };
    case SET_FLOW_BLOTTER_MOUNTED:
      return {
        ...state,
        isFlowBlotterMounted: action.payload.isFlowBlotterMounted
      };
    default:
      return state;
  }
}

export const BlotterContext = createContext();

export const BlotterProvider = props => {
  const [{ blotter, isFlowBlotterMounted }, dispatch] = useReducer(reducer, initialState);

  const setBlotter = useCallback(_blotter => dispatch({ type: SET_BLOTTER, payload: { blotter: _blotter } }), [
    dispatch
  ]);

  const setFlowBlotterMounted = useCallback(
    _isFlowBlotterMounted =>
      dispatch({ type: SET_FLOW_BLOTTER_MOUNTED, payload: { isFlowBlotterMounted: _isFlowBlotterMounted } }),
    [dispatch]
  );

  const value = {
    blotter,
    isFlowBlotterMounted,
    setBlotter,
    setFlowBlotterMounted
  };

  return <BlotterContext.Provider value={value}>{props.children}</BlotterContext.Provider>;
};
