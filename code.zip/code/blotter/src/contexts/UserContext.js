import React, { useEffect, createContext, useReducer, useCallback } from 'react';
import { FLOW_APP_NAME } from '~helpers/globals';
import { of, from } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import {
  defaultFlowUserSharedSettings,
  defaultRFQPopupSharedSettings,
  defaultFlowFilterSharedSettings,
  defaultRFQPopupFilterSharedSettings
} from '~helpers/userSettings';
import { setLogName } from '~helpers/sendLogs';

const fin = window.fin;

const initialState = {
  currentUser: null,
  currentComputer: null,
  impersonatedUser: null,
  toggles: defaultFlowUserSharedSettings,
  rfqToggles: defaultRFQPopupSharedSettings,
  filterToggles: defaultFlowFilterSharedSettings,
  rfqFilterToggles: defaultRFQPopupFilterSharedSettings,
  windowOptions: null
};

const SET_USER = 'SET_USER';
const SET_COMPUTER = 'SET_COMPUTER';
const SET_USER_AND_COMPUTER = 'SET_USER_AND_COMPUTER';
const SET_IMPERSONATED_USER = 'SET_IMPERSONATED_USER';
const SET_TOGGLES = 'SET_TOGGLES';
const SET_RFQ_POPUP_TOGGLES = 'SET_RFQ_POPUP_TOGGLES';
const SET_FLOW_APP_TOGGLES = 'SET_FLOW_APP_TOGGLES';
const SET_FILTER_TOGGLES = 'SET_FILTER_TOGGLES';
const SET_RFQ_POPUP_FILTER_TOGGLES = 'SET_RFQ_POPUP_FILTER_TOGGLES';
const SET_FLOW_APP_FILTER_TOGGLES = 'SET_FLOW_APP_FILTER_TOGGLES';
const SET_ALL_TOGGLES = 'SET_ALL_TOGGLES';
const SET_WINDOW_OPTIONS = 'SET_WINDOW_OPTIONS';

function reducer(state, action) {
  switch (action.type) {
    case SET_USER:
      return {
        ...state,
        currentUser: action.payload.currentUser
      };
    case SET_COMPUTER:
      return {
        ...state,
        currentComputer: action.payload.currentComputer
      };
    case SET_USER_AND_COMPUTER:
      return {
        ...state,
        currentUser: action.payload.currentUser,
        currentComputer: action.payload.currentComputer
      };
    case SET_IMPERSONATED_USER:
      return {
        ...state,
        impersonatedUser: action.payload.impersonatedUser
      };

    case SET_TOGGLES:
      return {
        ...state,
        toggles: action.payload.toggles,
        rfqToggles: action.payload.rfqToggles
      };
    case SET_FLOW_APP_TOGGLES:
      return {
        ...state,
        toggles: {
          ...state.toggles,
          ...action.payload.toggles
        }
      };
    case SET_RFQ_POPUP_TOGGLES:
      return {
        ...state,
        rfqToggles: {
          ...state.rfqToggles,
          ...action.payload.toggles
        }
      };
    case SET_FILTER_TOGGLES:
      return {
        ...state,
        filterToggles: action.payload.filterToggles,
        rfqFilterToggles: action.payload.rfqFilterToggles
      };
    case SET_FLOW_APP_FILTER_TOGGLES:
      return {
        ...state,
        filterToggles: {
          ...state.filterToggles,
          ...action.payload.toggles
        }
      };
    case SET_RFQ_POPUP_FILTER_TOGGLES:
      return {
        ...state,
        rfqFilterToggles: {
          ...state.rfqFilterToggles,
          ...action.payload.toggles
        }
      };
    case SET_ALL_TOGGLES:
      return {
        ...state,
        toggles: action.payload.toggles,
        rfqToggles: action.payload.rfqToggles,
        filterToggles: action.payload.filterToggles,
        rfqFilterToggles: action.payload.rfqFilterToggles
      };

    case SET_WINDOW_OPTIONS:
      return {
        ...state,
        windowOptions: action.payload.windowOptions
      };
    default:
      return state;
  }
}

export const UserContext = createContext();

export const UserProvider = props => {
  const [
    {
      currentUser,
      currentComputer,
      impersonatedUser,
      toggles,
      rfqToggles,
      filterToggles,
      rfqFilterToggles,
      windowOptions
    },
    dispatch
  ] = useReducer(reducer, initialState);

  useEffect(() => {
    if (fin) {
      from(fin.System.getEnvironmentVariable('COMPUTERNAME'))
        .pipe(
          map(computerName => computerName || Date.now().toString()),
          catchError(() => of(Date.now().toString()))
        )
        .subscribe(computerName => {
          dispatch({
            type: SET_COMPUTER,
            payload: {
              currentComputer: computerName
            }
          });
        });
    }
  }, []);

  const setCurrentUser = useCallback(
    _userName => {
      setLogName(_userName);
      return dispatch({ type: SET_USER, payload: { currentUser: _userName } });
    },
    [dispatch]
  );

  const setImpersonatedUser = useCallback(
    _impersonatedUser => dispatch({ type: SET_IMPERSONATED_USER, payload: { impersonatedUser: _impersonatedUser } }),
    [dispatch]
  );

  const setCustomToggles = useCallback(
    (toggles, source, isFilterToggle = false) => {
      let action;

      if (source === FLOW_APP_NAME) {
        action = !isFilterToggle ? SET_FLOW_APP_TOGGLES : SET_FLOW_APP_FILTER_TOGGLES;
      } else {
        action = !isFilterToggle ? SET_RFQ_POPUP_TOGGLES : SET_RFQ_POPUP_FILTER_TOGGLES;
      }

      dispatch({
        type: action,
        payload: {
          toggles
        }
      });
    },
    [dispatch]
  );

  const setToggles = useCallback(
    (toggles, rfqToggles) =>
      dispatch({
        type: SET_TOGGLES,
        payload: {
          toggles,
          rfqToggles
        }
      }),
    [dispatch]
  );

  const setAllToggles = useCallback(
    ({ toggles, rfqToggles, filterToggles, rfqFilterToggles }) =>
      dispatch({
        type: SET_ALL_TOGGLES,
        payload: {
          toggles,
          rfqToggles,
          filterToggles,
          rfqFilterToggles
        }
      }),
    [dispatch]
  );

  const setWindowOptions = useCallback(
    windowOptions =>
      dispatch({
        type: SET_WINDOW_OPTIONS,
        payload: {
          windowOptions
        }
      }),
    [dispatch]
  );

  const value = {
    currentUser,
    currentComputer,
    impersonatedUser,
    toggles,
    rfqToggles,
    filterToggles,
    rfqFilterToggles,
    windowOptions,
    setCurrentUser,
    setImpersonatedUser,
    setToggles,
    setAllToggles,
    setCustomToggles,
    setWindowOptions
  };

  return <UserContext.Provider value={value}>{props.children}</UserContext.Provider>;
};
