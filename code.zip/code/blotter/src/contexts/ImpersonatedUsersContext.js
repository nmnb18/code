import React, { useEffect, useContext, createContext, useReducer, useCallback } from 'react';
import { map } from 'rxjs/operators';
import * as entitlementService from '~services/entitlementService';
import { UserContext } from '~contexts/UserContext';
import { UserEntitlementContext } from '~contexts/UserEntitlementContext';
import { APP_PLATFORM } from '~helpers/globals';

const validateImpersonatedUser = impersonatedUser =>
  impersonatedUser && impersonatedUser.Notes && impersonatedUser.Notes.LoginAs && impersonatedUser.Notes.LoginAs.id;

const mapUserInformation = impersonatedUser => {
  const {
    Notes: { LoginAs }
  } = impersonatedUser;

  const { id, name, level3, primaryRole, role } = LoginAs;

  return {
    id,
    name,
    level3,
    role,
    primaryRole,
    blocked: !name
  };
};

const initialState = {
  impersonatedUsers: null,
  reloadImpersonatedUserToken: null
};

const SET_IMPERSONATED_USERS = 'SET_IMPERSONATED_USERS';
const SET_RELOAD_IMPERSONATED_USER_TOKEN = 'SET_RELOAD_IMPERSONATED_USER_TOKEN';

function reducer(state, action) {
  switch (action.type) {
    case SET_IMPERSONATED_USERS:
      return {
        ...state,
        impersonatedUsers: action.payload.impersonatedUsers
      };
    case SET_RELOAD_IMPERSONATED_USER_TOKEN:
      return {
        ...state,
        reloadImpersonatedUserToken: action.payload.reloadImpersonatedUserToken
      };
    default:
      return state;
  }
}

export const ImpersonatedUsersContext = createContext(null);

export const ImpersonatedUsersProvider = props => {
  const [{ impersonatedUsers, reloadImpersonatedUserToken }, dispatch] = useReducer(reducer, initialState);
  const { currentUser } = useContext(UserContext);
  const { userEntitlement } = useContext(UserEntitlementContext);

  useEffect(() => {
    const setimpersonatedUsers = _impersonatedUsers =>
      dispatch({ type: SET_IMPERSONATED_USERS, payload: { impersonatedUsers: _impersonatedUsers } });

    if ((currentUser && userEntitlement?.isAdmin) || reloadImpersonatedUserToken) {
      entitlementService
        .getImpersonatedUsers(APP_PLATFORM, currentUser)
        .pipe(map(impersonatedUsers => impersonatedUsers.filter(validateImpersonatedUser).map(mapUserInformation)))
        .subscribe(users => setimpersonatedUsers(users), () => setimpersonatedUsers([]));
    }
  }, [currentUser, userEntitlement, reloadImpersonatedUserToken]);

  const setReloadImpersonatedUserToken = useCallback(
    _reloadImpersonatedUserToken =>
      dispatch({
        type: SET_RELOAD_IMPERSONATED_USER_TOKEN,
        payload: { reloadImpersonatedUserToken: _reloadImpersonatedUserToken }
      }),
    [dispatch]
  );

  const value = { impersonatedUsers, setReloadImpersonatedUserToken };

  return <ImpersonatedUsersContext.Provider value={value}>{props.children}</ImpersonatedUsersContext.Provider>;
};
