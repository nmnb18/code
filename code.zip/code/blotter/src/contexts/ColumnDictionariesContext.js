import React, { useState, useEffect, createContext } from 'react';
import * as columnDictionaryService from '~services/columnDictionaryService';
import { RFQ_APP_NAME, FLOW_APP_NAME } from '~helpers/globals';
import { CustomLoading } from '~components';

export const ColumnDictionariesContext = createContext(null);

export const ColumnDictionariesProvider = props => {
  const [rfqNotificationsColumnsDictionary, setRfqNotificationsColumnsDictionary] = useState(null);
  const [mainBlotterColumnsDictionary, setMainBlotterColumnsDictionary] = useState(null);

  useEffect(() => {
    let rfqNotificationsColumnsSubscription = columnDictionaryService
      .getApplicationColumns(RFQ_APP_NAME)
      .subscribe(appColumns => {
        setRfqNotificationsColumnsDictionary(appColumns);
      });

    let mainBlotterColumnsSubscription = columnDictionaryService
      .getApplicationColumns(FLOW_APP_NAME)
      .subscribe(appColumns => {
        setMainBlotterColumnsDictionary(appColumns);
      });

    return () => {
      rfqNotificationsColumnsSubscription.unsubscribe();
      mainBlotterColumnsSubscription.unsubscribe();
    };
  }, []);

  const value = { rfqNotificationsColumnsDictionary, mainBlotterColumnsDictionary };

  if (rfqNotificationsColumnsDictionary && mainBlotterColumnsDictionary) {
    return <ColumnDictionariesContext.Provider value={value}>{props.children}</ColumnDictionariesContext.Provider>;
  }
  return <CustomLoading loadingMsg={'Loading...'} />;
};
