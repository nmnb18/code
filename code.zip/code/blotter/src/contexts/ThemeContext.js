import React, { useState, createContext, useEffect, useRef, useContext, useCallback } from 'react';
import { BlotterUserSettingsContext } from '~contexts/BlotterUserSettingsContext';
import { UserContext } from '~contexts/UserContext';
import { BlotterContext } from '~contexts/BlotterContext';
import { themes, DEFAULT_THEME } from '~helpers/globals';
import { usePrevious } from '~hooks';
import {
  rfqNotificationTopicForChild,
  rfqNotificationActions,
  flowBlotterTopicForChild,
  rfqNotificationTopicForParent
} from '~services/openfinConfig';
import { updateUserThemeInSettings, getSavedTheme, getUserSettings } from '~services/userSettingsService';
import * as usageService from '~services/usageService';
import { topicForUpdatingXiosWindows, xiosWindowsEvents } from '~helpers/popups';
import { iabSubscribe, iabUnsubscribe, iabPublish } from '~services/openfinService';

// function to get theme data for a given theme value
const getTheme = themeValue => {
  return themes.find(theme => theme.value === themeValue);
};

export const ThemeContext = createContext(null);

export const showThemeToggle = process.env.REACT_APP_SHOW_THEME_TOGGLE === 'true';

export const ThemeProvider = props => {
  // currently just using defaultTheme.
  // once saving preference in settings need to use that and fallback to this only if not set
  const [theme, setTheme] = useState(getTheme(DEFAULT_THEME));
  const [blotterUserSettingsLoaded, setBlotterUserSettingsLoaded] = useState(false);
  const themeRef = useRef(theme);
  const prevTheme = usePrevious(theme);
  const { blotterUserSettings, setBlotterUserSettings } = useContext(BlotterUserSettingsContext);
  const prevBlotterUserSettings = usePrevious(blotterUserSettings);
  const { currentUser, impersonatedUser } = useContext(UserContext);
  const { isFlowBlotterMounted } = useContext(BlotterContext);

  const chooseTheme = themeValue => {
    const chosenTheme = getTheme(themeValue);
    if (chosenTheme) {
      setTheme(() => {
        themeRef.current = chosenTheme;
        return chosenTheme;
      });
    }
  };

  const toggleTheme = () => {
    // works for 2 themes. If we do more we should switch from toggle to dropdown list. This function and UI component will need updating.
    const newTheme = themes.find(obj => obj.value !== theme.value);
    chooseTheme(newTheme.value);
    // usage report
    usageService.sendUsage({
      userAction: usageService.actions.CHANGE_THEME,
      notes: { Theme: newTheme.value }
    });
  };

  // function to send theme value to rfq popup via IAB
  const notifyRFQPopup = payload =>
    iabPublish({
      topic: rfqNotificationTopicForChild,
      message: {
        type: rfqNotificationActions.rfqNotificationUpdateTheme,
        payload
      },
      logLabel: 'ThemeProvider > RFQ popup'
    });

  // function to send theme value to XIOS windows that we create via IAB
  const notifyXiosPopup = payload =>
    iabPublish({
      topic: topicForUpdatingXiosWindows,
      message: {
        type: xiosWindowsEvents.updateTheme,
        payload
      },
      logLabel: 'ThemeProvider > Xios windows'
    });

  // function to send theme value to main blotter iframe via IAB
  const notifyFlowBlotter = theme =>
    iabPublish({
      topic: flowBlotterTopicForChild,
      message: { theme },
      logLabel: 'ThemeProvider > blotter'
    });

  //when rfq popup is mounted it will send a message to tell us. We respond by telling it the current theme:
  const handleRFQNotificationMessage = useCallback(message => {
    const { type } = message;
    if (type === rfqNotificationActions.rfqNotificationPopupMounted) {
      console.log(`THEMER: popup asked for theme (kind of) so we gave it ${themeRef.current.value}`);
      notifyRFQPopup(themeRef.current.value);
    }
  }, []);

  //effect to listen for rfq popup load so we can send theme value
  useEffect(() => {
    const logLabel = 'ThemeProvider: listening for RFQ popup messages';
    iabSubscribe({
      topic: rfqNotificationTopicForParent,
      handler: handleRFQNotificationMessage,
      logLabel
    });

    return () =>
      iabUnsubscribe({
        topic: rfqNotificationTopicForParent,
        handler: handleRFQNotificationMessage,
        logLabel
      });
  }, [handleRFQNotificationMessage]);

  //effect to send messages via IAB when theme changes or main blotter sends message saying it is mounted
  useEffect(() => {
    notifyRFQPopup(theme.value);
    notifyXiosPopup(theme.value);
    if (isFlowBlotterMounted) notifyFlowBlotter(theme.value);
  }, [theme, isFlowBlotterMounted]);

  useEffect(() => {
    const asyncThisEffect = async () => {
      //we shouldn't run any code in here until we get current settings
      if (blotterUserSettings) {
        let realUserSettings;
        // if impersonating we need to get real user settings
        if (blotterUserSettings.User !== currentUser) {
          realUserSettings = await getUserSettings(currentUser).toPromise();
        } else {
          realUserSettings = blotterUserSettings;
        }
        const savedTheme = getSavedTheme(realUserSettings);
        // blotterUserSettingsLoaded flag confirms we already checked saved data for theme value, so we're not using the default here unless user has no saved data.
        if (theme && blotterUserSettingsLoaded) {
          // if theme has been changed in UI and no longer matches saved data, then update the saved data
          if (savedTheme && prevTheme.value !== theme.value && theme.value !== savedTheme.value) {
            console.log(`THEMER: trying to update theme on server`);
            updateUserThemeInSettings(currentUser, realUserSettings, theme, setBlotterUserSettings, impersonatedUser);
          }
          // if user has no saved theme, save to the default one
          if (!savedTheme) {
            console.log(`THEMER: setting theme on profile for the first time`);
            updateUserThemeInSettings(currentUser, realUserSettings, theme);
          }
        }
      }
    };
    asyncThisEffect();
  }, [
    currentUser,
    blotterUserSettings,
    setBlotterUserSettings,
    prevBlotterUserSettings,
    blotterUserSettingsLoaded,
    theme,
    prevTheme,
    impersonatedUser
  ]);

  useEffect(() => {
    if (blotterUserSettings && !blotterUserSettingsLoaded) {
      // set flag to true so this useEffect won't run more than once
      setBlotterUserSettingsLoaded(true);
      console.log(`THEMER: got initial settings from server`);
      const savedTheme = getSavedTheme(blotterUserSettings);
      // if saved user settings have a theme and it isn't the default one, use it
      if (savedTheme && savedTheme.value !== theme.value) {
        console.log(`THEMER: updating theme based on initial value from server`);
        setTheme(() => {
          themeRef.current = savedTheme;
          return savedTheme;
        });
      }
    }
  }, [blotterUserSettings, theme, blotterUserSettingsLoaded]);

  const value = {
    theme,
    toggleTheme
  };

  return <ThemeContext.Provider value={value}>{props.children}</ThemeContext.Provider>;
};
