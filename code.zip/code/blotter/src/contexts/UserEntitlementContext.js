import React, { useState, useEffect, useContext, createContext } from 'react';
import { filter, map } from 'rxjs/operators';
import * as entitlementService from '~services/entitlementService';
import { UserContext } from '~contexts/UserContext';
import { validateEmployeeInfo, mapUserEntitlement } from '~helpers/userSettings';

export const UserEntitlementContext = createContext();

export const UserEntitlementProvider = ({ children }) => {
  const { currentUser, impersonatedUser } = useContext(UserContext);
  const [userEntitlement, setUserEntitlement] = useState(null);
  const [impersonatedUserEntitlement, setImpersonatedUserEntitlement] = useState(null);

  useEffect(() => {
    if (currentUser) {
      entitlementService
        .getEmployeeInfo(currentUser)
        .pipe(
          filter(validateEmployeeInfo),
          map(mapUserEntitlement)
        )
        .subscribe(entitlement => setUserEntitlement(entitlement), () => setUserEntitlement(null));
    }
  }, [currentUser]);

  useEffect(() => {
    if (impersonatedUser) {
      entitlementService
        .getEmployeeInfo(impersonatedUser.id)
        .pipe(
          filter(validateEmployeeInfo),
          map(mapUserEntitlement)
        )
        .subscribe(
          entitlement => setImpersonatedUserEntitlement(entitlement),
          () => setImpersonatedUserEntitlement(null)
        );
    }
  }, [impersonatedUser]);

  const value = { userEntitlement, impersonatedUserEntitlement };

  return <UserEntitlementContext.Provider value={value}>{children}</UserEntitlementContext.Provider>;
};
