import React, { createContext, useReducer, useCallback } from 'react';

const initialState = {
  webSocketInitialized: false,
  ampsConnected: null,
  webSocketDisconnected: null,
  webSocketUser: null
};

const SET_WEBSOCKET_INITIALIZED = 'SET_WEBSOCKET_INITIALIZED';
const SET_AMPS_CONNECTED = 'SET_AMPS_CONNECTED';
const SET_WEBSOCKET_DISCONNECTED = 'SET_WEBSOCKET_DISCONNECTED';
const SET_AMPS_AND_WEBSOCKET_STATUS = 'SET_AMPS_AND_WEBSOCKET_STATUS';
const SET_WEBSOCKET_USER = 'SET_WEBSOCKET_USER';

function reducer(state, action) {
  switch (action.type) {
    case SET_WEBSOCKET_INITIALIZED:
      return {
        ...state,
        webSocketInitialized: action.payload.webSocketInitialized
      };
    case SET_AMPS_CONNECTED:
      return {
        ...state,
        ampsConnected: action.payload.ampsConnected
      };
    case SET_WEBSOCKET_DISCONNECTED:
      return {
        ...state,
        webSocketDisconnected: action.payload.webSocketDisconnected
      };
    case SET_AMPS_AND_WEBSOCKET_STATUS:
      return {
        ...state,
        ampsConnected: action.payload.ampsConnected,
        webSocketDisconnected: action.payload.webSocketDisconnected
      };
    case SET_WEBSOCKET_USER:
      return {
        ...state,
        webSocketUser: action.payload.webSocketUser
      };
    default:
      return state;
  }
}

export const WebSocketContext = createContext();

export const WebSocketProvider = props => {
  const [{ webSocketInitialized, ampsConnected, webSocketDisconnected, webSocketUser }, dispatch] = useReducer(
    reducer,
    initialState
  );

  const setWebSocketInitialized = useCallback(
    _webSocketInitialized =>
      dispatch({ type: SET_WEBSOCKET_INITIALIZED, payload: { webSocketInitialized: _webSocketInitialized } }),
    [dispatch]
  );

  const setAmpsConnected = useCallback(
    _ampsConnected => dispatch({ type: SET_AMPS_CONNECTED, payload: { ampsConnected: _ampsConnected } }),
    [dispatch]
  );

  const setWebSocketDisconnected = useCallback(
    _webSocketDisconnected =>
      dispatch({ type: SET_WEBSOCKET_DISCONNECTED, payload: { webSocketDisconnected: _webSocketDisconnected } }),
    [dispatch]
  );

  const setAmpsAndWebSocketStatus = useCallback(
    (_ampsConnected, _webSocketDisconnected) =>
      dispatch({
        type: SET_AMPS_AND_WEBSOCKET_STATUS,
        payload: {
          ampsConnected: _ampsConnected,
          webSocketDisconnected: _webSocketDisconnected
        }
      }),
    [dispatch]
  );

  const setWebSocketUser = useCallback(
    _webSocketUser => dispatch({ type: SET_WEBSOCKET_USER, payload: { webSocketUser: _webSocketUser } }),
    [dispatch]
  );

  const value = {
    webSocketInitialized,
    webSocketUser,
    ampsConnected,
    webSocketDisconnected,
    setWebSocketInitialized,
    setWebSocketUser,
    setAmpsConnected,
    setWebSocketDisconnected,
    setAmpsAndWebSocketStatus
  };

  return <WebSocketContext.Provider value={value}>{props.children}</WebSocketContext.Provider>;
};
