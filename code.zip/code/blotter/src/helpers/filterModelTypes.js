export const FILTER_MODEL_DYNAMIC_SET = 'dynamic_set';

export const FILTER_MODEL_SET = 'set';

export const FILTER_MODEL_TEXT = 'text';

export const FILTER_MODEL_NUMBER = 'number';

export const FILTER_MODEL_DATE = 'date';

export const isDynamicSetFilter = filterType => filterType === FILTER_MODEL_DYNAMIC_SET;

export const isSetFilter = filterType => filterType === FILTER_MODEL_SET;

export const isTextFilter = filterType => filterType === FILTER_MODEL_TEXT;

export const isNumberFilter = filterType => filterType === FILTER_MODEL_NUMBER;

export const isDateFilter = filterType => filterType === FILTER_MODEL_DATE;
