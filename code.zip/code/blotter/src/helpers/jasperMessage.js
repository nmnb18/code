import { strToNumber } from '~helpers/types';
import { getLegEnabledMainColumnNames } from '~services/columnDictionaryService';
import { RFQ_APP_NAME, FLOW_APP_NAME } from '~helpers/globals';
import { defaultMainGridId } from './jasperWebSocket';

export const WS_FIELDS = {
  SOWKEY: 'sowkey',
  COMMAND: 'command',
  ROWINDEX: 'rowIndex',
  SOURCE: 'source',
  LEGNO: 'legno',
  KEY_ID: 'key_id'
};

export const WS_MESSAGE_TYPE = {
  RFQ_MESSAGE: 'RFQMessage',
  RFQ_TOTALS: 'RFQTotals',
  FIELDS_MESSAGE: 'FieldsMessage'
};

export const WS_COMMANDS = {
  GROUP_BEGIN: 'GROUPBEGIN',
  NEW_MESSAGE_SOW: 'NEW_MESSAGE_SOW',
  GROUP_END: 'GROUPEND',
  NEW_MESSAGE: 'NEW_MESSAGE',
  UPDATE_MESSAGE: 'UPDATE_MESSAGE',
  DELETE_MESSAGE: 'DELETE_MESSAGE',
  ACK: 'ACK',
  SOW: 'SOW',
  CONNECT: 'CONNECT',
  DISCONNECT: 'DISCONNECT',
  CLEAR: 'CLEAR',
  ENTITLEMENT_ERROR: 'ENTITLEMENT_ERROR'
};

export const EXPORT_COMMANDS = {
  FETCH_DONE: 'FETCH_DONE'
};

export const FETCH_TRIGGERS = {
  EXPORT_TO_EXCEL_AS_DOWNLOAD: 'EXPORT_TO_EXCEL_AS_DOWNLOAD',
  EXPORT_TO_EXCEL_AND_OPEN: 'EXPORT_TO_EXCEL_AND_OPEN',
  COPY_TO_CLIPBOARD: 'COPY_TO_CLIPBOARD'
};

export const LEGNO = {
  MAIN: 0,
  L1: 1,
  L2: 2
};

export const RFQNLEGS = {
  MAIN: '1',
  L1: '2',
  L2: '3'
};

export const isMainRFQLeg = ({ legno }) => parseInt(legno) === LEGNO.MAIN;
export const isL1RFQLeg = ({ legno }) => parseInt(legno) === LEGNO.L1;
export const isL2RFQLeg = ({ legno }) => parseInt(legno) === LEGNO.L2;

export const LEG_FIELD_REGEX = /^(l1|l2)_/;

export const isLegIndicator = field => field === WS_FIELDS.LEGNO;

/**
 * Checks whether data is for a leg row or not.
 * Only use checkByKeyId if you think legno may be missing from data.
 * We may rework backend to always include legno in messages in future and remove this alternate method.
 * @param {object} elements
 * @param {boolean=} checkByKeyId
 * @returns {boolean}
 */
export const isLegRow = (elements, checkByKeyId = false) => {
  if (!elements) return false;

  if (checkByKeyId) {
    const { key_id } = elements;
    // trades never have legs. All trades key_ids start with 'Trade_'
    // inquirys never have legs. All inquirys key_ids start with 'Inquiry_'
    // rfqs always end in '_0', '_1', or '_2' based on leg no.
    if (!key_id || key_id.startsWith('Inquiry_') || key_id.startsWith('Trade_') || key_id.endsWith('_0')) return false;
    if (key_id.endsWith('_1') || key_id.endsWith('_2')) return true;
    console.error(`isLegRow checkByKeyID encountered a key_id that does not match any expected format: ${key_id}`);
    return false;
  }

  const { legno } = elements;
  const legnoValue = strToNumber(legno);
  return !!legnoValue;
};

export const hasLegs = elements => {
  if (!elements) return false;
  const { rfqnlegs } = elements;
  const numberOfLegs = strToNumber(rfqnlegs);
  return numberOfLegs > 1;
};

const getMainField = legField => {
  const legFieldRegex = new RegExp(LEG_FIELD_REGEX, 'i');
  return legField.replace(legFieldRegex, '');
};

export const isLegFieldValid = field => {
  const legFieldRegex = new RegExp(LEG_FIELD_REGEX, 'i');
  return legFieldRegex.test(field);
};

export const isLegFieldInValid = field => {
  const legFieldRegex = new RegExp(LEG_FIELD_REGEX, 'i');
  return !legFieldRegex.test(field);
};

export const isLegField = (elements, field) => {
  const legFields = Object.keys(elements)
    .filter(isLegFieldValid)
    .map(getMainField)
    .reduce((acc, cur) => {
      if (!acc.find(key => key === cur)) {
        acc.push(cur);
      }
      return acc;
    }, []);

  return legFields.find(legField => legField === field);
};

export const getLegFields = elements =>
  Object.keys(elements)
    .filter(isLegFieldValid)
    .map(getMainField)
    .reduce((acc, cur) => {
      if (!acc.find(key => key === cur)) {
        acc.push(cur);
      }
      return acc;
    }, []);

export const isLegKey = (legFields, field) => {
  const legKey = legFields.find(legField => legField === field);
  return !!legKey;
};

const miscCommands = [WS_COMMANDS.DISCONNECT, WS_COMMANDS.CONNECT, WS_COMMANDS.CLEAR, WS_COMMANDS.ENTITLEMENT_ERROR];

const mapRFQRecord = ({
  source,
  clientSubscriptionId,
  sowkey,
  command,
  elements,
  rowIndex,
  vpFirstRow,
  vpLastRow,
  isResorting,
  columnsDictionaries
}) => {
  const rowIndexValue = strToNumber(rowIndex);

  if (isLegRow(elements, true)) {
    // TODO: rewrite with simpler approach.
    // 1. get all legEnabled main leg field names
    // 2. loop through and A. delete any elements[legField] that are legEnabled main leg fields B. rename any leg refixed fields to unlegged.
    // (remember to handle special case for 'code' fields)

    const { key_id } = elements;
    const legno = key_id.slice(-1);
    const legPrefix = `l${legno}_`;
    const elementsWithLegFields = { ...elements };

    const useDictionary = source.endsWith(`_${defaultMainGridId}`) ? FLOW_APP_NAME : RFQ_APP_NAME;

    const legEnabledMainColumnNames = getLegEnabledMainColumnNames(columnsDictionaries[useDictionary]);

    const legEnabledMainFields = Object.keys(elements).filter(field => legEnabledMainColumnNames.includes(field));

    legEnabledMainFields.forEach(field => {
      const legField = legPrefix + field;
      if (field === 'code') {
        // console.log(`LegEnabled data > key_id: ${key_id} > setting 'code_main_value' to match 'code'`);
        elementsWithLegFields['code_main_value'] = elementsWithLegFields['code'];
      } else if (elements[legField]) {
        // console.log( `LegEnabled data > key_id: ${key_id} > using data from ${legField} (${elements[legField]}) for ${field}`);
        elementsWithLegFields[field] = elementsWithLegFields[legField];
      } else {
        // console.log( `LegEnabled data > key_id: ${key_id} > deleting data from ${field} (${elements[field]}) because we don't have any ${legField} data`);
        delete elementsWithLegFields[field];
      }
    });

    const legOnlyFields = Object.keys(elements).filter(field => {
      const unleggedField = field.replace(legPrefix, '');
      return field.startsWith(legPrefix) && !elements[unleggedField];
    });

    legOnlyFields.forEach(field => {
      const unleggedField = field.replace(legPrefix, '');
      if (elements[field]) {
        //console.log(`LegEnabled data > key_id: ${key_id} > using data from ${field} (${elements[field]}) for '${unleggedField}' (we didn't get a value for '${unleggedField}')`);
        elementsWithLegFields[unleggedField] = elements[field];
      }
    });

    return {
      source,
      clientSubscriptionId,
      sowkey,
      command,
      rowIndex: rowIndexValue,
      vpFirstRow,
      vpLastRow,
      isResorting,
      ...elementsWithLegFields
    };
  }

  return {
    source,
    clientSubscriptionId,
    sowkey,
    command,
    vpFirstRow,
    vpLastRow,
    isResorting,
    rowIndex: rowIndexValue,
    ...elements
  };
};

const mapRFQCommand = ({ source, clientSubscriptionId, command, vpFirstRow, vpLastRow }) => ({
  source,
  clientSubscriptionId,
  command,
  vpFirstRow,
  vpLastRow
});

const mapFieldCommand = ({ source, clientSubscriptionId, command, elements }) => ({
  source,
  clientSubscriptionId,
  command,
  elements
});

const mapFieldRecord = ({ source, clientSubscriptionId, sowkey, command, elements }) => {
  return {
    source,
    clientSubscriptionId,
    sowkey,
    command,
    elements
  };
};

const mapRFQMessage = ({
  source,
  clientSubscriptionId,
  command,
  elements,
  rowIndex,
  sowkey,
  vpFirstRow,
  vpLastRow,
  isResorting,
  columnsDictionaries
}) => {
  if (!elements && !miscCommands.includes(command)) return null;

  switch (command) {
    case WS_COMMANDS.GROUP_BEGIN:
    case WS_COMMANDS.GROUP_END:
    case WS_COMMANDS.ENTITLEMENT_ERROR:
      return mapRFQCommand({ source, clientSubscriptionId, command, vpFirstRow, vpLastRow });
    case WS_COMMANDS.NEW_MESSAGE_SOW:
    case WS_COMMANDS.NEW_MESSAGE:
    case WS_COMMANDS.UPDATE_MESSAGE:
    case WS_COMMANDS.DELETE_MESSAGE:
    case WS_COMMANDS.DISCONNECT:
    case WS_COMMANDS.CONNECT:
    case WS_COMMANDS.CLEAR:
    case WS_COMMANDS.SOW:
      return mapRFQRecord({
        source,
        clientSubscriptionId,
        command,
        elements,
        rowIndex,
        sowkey,
        vpFirstRow,
        vpLastRow,
        isResorting,
        columnsDictionaries
      });

    default:
      return {};
  }
};

const mapRFQTotals = ({ source, clientSubscriptionId, command, elements, type, vpFirstRow, vpLastRow }) => {
  const { RFQTotal } = elements;
  return {
    source,
    clientSubscriptionId,
    command,
    rfqTotal: RFQTotal,
    type,
    vpFirstRow,
    vpLastRow
  };
};

const fieldMessageHandler = {
  [WS_COMMANDS.GROUP_BEGIN]: fieldMessage => mapFieldCommand(fieldMessage),
  [WS_COMMANDS.GROUP_END]: fieldMessage => mapFieldCommand(fieldMessage),
  [WS_COMMANDS.NEW_MESSAGE_SOW]: fieldMessage => mapFieldRecord(fieldMessage),
  [WS_COMMANDS.NEW_MESSAGE]: fieldMessage => mapFieldRecord(fieldMessage),
  [WS_COMMANDS.UPDATE_MESSAGE]: fieldMessage => mapFieldRecord(fieldMessage),
  [WS_COMMANDS.DELETE_MESSAGE]: fieldMessage => mapFieldRecord(fieldMessage)
};

const mapFieldMessage = fieldMessage => {
  const { command, elements } = fieldMessage;
  if (!elements && !miscCommands.includes(command)) return null;

  const messageHandler = fieldMessageHandler[command];
  if (!messageHandler) return null;

  return messageHandler(fieldMessage);
};

export const mapMessage = (message, columnsDictionaries) => {
  const {
    source,
    data: { clientSubscriptionId, command, elements, rowIndex, sowkey, type, vpFirstRow, vpLastRow, isResorting }
  } = message;
  let response;

  if (type === WS_MESSAGE_TYPE.RFQ_MESSAGE) {
    response = mapRFQMessage({
      source,
      clientSubscriptionId,
      command,
      elements,
      rowIndex,
      sowkey,
      vpFirstRow,
      vpLastRow,
      isResorting,
      columnsDictionaries
    });
  } else if (type === WS_MESSAGE_TYPE.RFQ_TOTALS) {
    response = mapRFQTotals({ source, clientSubscriptionId, command, elements, type, vpFirstRow, vpLastRow });
  } else if (type === WS_MESSAGE_TYPE.FIELDS_MESSAGE) {
    response = mapFieldMessage({ source, clientSubscriptionId, command, elements, sowkey, type });
  }

  return response;
};

export function getType(message) {
  const { data } = message;
  if (!data) return '';
  const { type } = data;
  return type;
}
