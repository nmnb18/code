export const KEYS = {
  ESC: 27,
  ENTER: 13,
  UP: 38,
  DOWN: 40,
  BACKSPACE: 8
};
