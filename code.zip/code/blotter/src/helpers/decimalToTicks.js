/**
 * Returns an array consisting of the quotient and remainder of the given numbers.
 * @param {number} x
 * @param  {number=} y
 * @returns {[number,number]}
 */
const divmod = (x, y = 1) => [parseInt((x / y).toString()), x % y];

/**
 * @param {number} n
 * @returns {boolean}
 */
const hasFraction = n => n - parseInt(n.toString()) !== 0;

/**
 * @param {number} n
 * @returns {string}
 */
const zeroPadSingleDigit = n => (n < 10 ? '0' + n : n.toString());

/**
 *
 * @param {string} str
 * @param {number} index
 * @returns {[string, string]}
 */
const splitStringAtIndex = (str, index) => [str.slice(0, index), str.slice(index)];

/**
 * @param {string} decimalValueStr
 * @returns {string}
 */
export const dec2ticks = decimalValueStr => {
  const decimalValue = parseFloat(decimalValueStr);
  if (!isFinite(decimalValue)) {
    return '';
  }
  let [integerPart, fractionalPart] = divmod(Math.abs(decimalValue), 1);
  const sign = decimalValue < 0 ? '-' : '';

  if (hasFraction(decimalValue)) {
    let eighth = 0;
    let thirtyTwo = fractionalPart * 32;
    if (hasFraction(thirtyTwo)) {
      [thirtyTwo, eighth] = divmod(thirtyTwo, 1);
      eighth = parseInt((eighth * 8).toFixed());
      if (eighth === 8) {
        thirtyTwo = thirtyTwo + 1;
        eighth = 0;
      }
      if (thirtyTwo === 32) {
        thirtyTwo = 0;
        integerPart = integerPart + 1;
      }
    }

    const finalInteger = zeroPadSingleDigit(integerPart);
    const finalThirtyTwo = zeroPadSingleDigit(thirtyTwo);
    const finalEighth = eighth === 4 ? '+' : eighth.toString();

    return `${sign}${finalInteger}-${finalThirtyTwo}${finalEighth}`;
  }
  return `${sign}${integerPart}-000`;
};

/**
 *
 * @param {string} tickValue
 * @returns {string|null}
 */
export const ticks2dec = tickValue => {
  // if tick value not passed or wrong type, send null (may want to send something else instead)
  if (typeof tickValue !== 'string') return null;

  const sign = tickValue[0] === '-' ? '-' : '';
  const [integerPartStr, fractionalPartStr] = tickValue.split('-').filter(x => x);
  if (fractionalPartStr === '000') {
    return `${sign}${integerPartStr}.0`;
  }
  const integerPart = parseInt(integerPartStr);
  const [thirtyTwoStr, eighthStr] = splitStringAtIndex(fractionalPartStr, 2);
  const thirtyTwo = parseInt(thirtyTwoStr) / 32;
  const eighth = eighthStr === '+' ? 0.015625 : parseInt(eighthStr) / 256;
  const fractonalPart = thirtyTwo + eighth;
  const finalNumber = integerPart + fractonalPart;
  return `${sign}${finalNumber}`;
};

const halfeighth = 0.001953125;
const billionth = 0.000000001;

/**
 * @param {string} dec
 * @returns {[number, number]}
 */
export const tickRange = dec => {
  const lower = parseFloat(dec) - halfeighth;
  const upper = parseFloat(dec) + (halfeighth - billionth);
  return [lower, upper];
};
