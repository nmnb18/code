import ulog from 'ulog';

ulog.level = getLogLevel();

function getLogLevel() {
  const level = process.env.REACT_APP_LOGGING_LEVEL;
  const logLevel = { ERROR: 1, WARN: 2, INFO: 3, LOG: 4, DEBUG: 5, TRACE: 6 };
  return logLevel[level] ? logLevel[level] : ulog.level;
  // By default, the variable is initialised with browser logging level
}

// TODO: V2 of this API supports formatting at one place, which we will use to prefix the name of module in logs.
// Currently V2 is in beta, so we will wait.
const logFactory = (module = 'Application') => ulog(module);
console.log(`Log Level is: ${ulog.level}`);
export default logFactory;
