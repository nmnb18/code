import { hasItems } from 'flow-navigator-shared/dist/array';

const logLevels = ['log', 'warn', 'error', 'info', 'debug'];

export const extraLogSubjects = {
  RFQ: 'rfqPopup'
};

const extraLogSettings = process.env.REACT_APP_EXTRA_LOGGING_ARGS;

let _loggerUser;

const getExtraLogUsers = allData => {
  try {
    const subjects = allData.split('|').map(subjectData => {
      const [k, v] = subjectData.split(':').map(x => x.trim());
      const users = v.split(',').map(x => x.trim());
      return [k, users];
    });
    return subjects;
  } catch {
    return null;
  }
};

const extraLogUsersTuple = getExtraLogUsers(extraLogSettings);

/** @param {string} user */
export const setExtraLogsUser = user => {
  if (!extraLogSettings) {
    console.log('No extra logging set for any user. Only default logs will be saved.');
    return false;
  }
  _loggerUser = user;

  console.log('Setting extra logs user to ' + user);

  const subjects = extraLogUsersTuple.filter(subject => subject[1].includes(user)).map(subject => subject[0]);
  if (subjects.length > 0) {
    console.log(
      `This user has extra logging for ${subjects.length === 1 ? 'this subject' : 'These subjects'}: ${subjects.join(
        ', '
      )}.`
    );
  } else {
    console.log('This user is not assigned to any extra logging subjects. Only default logs will be saved.');
  }
};

const extraLogUsersObject = extraLogUsersTuple ? Object.fromEntries(extraLogUsersTuple) : null;

const extraLog = (level, subject, ...args) => {
  const users = extraLogUsersObject?.[subject];
  const currentUser = _loggerUser;
  if (currentUser && hasItems(users) && users.includes(currentUser)) {
    console[level](...args);
  }
};

const extraLoggers = logLevels.map(logLevel => [logLevel, extraLog.bind(null, logLevel)]);
export const extraLogger = Object.fromEntries(extraLoggers);
