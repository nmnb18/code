import isEqual from 'lodash/isEqual';
import { simpleJsTypes } from '~helpers/globals';

export const isPropertyEqual = (obj_a, obj_b, property) => {
  const value_a = obj_a[property];
  const value_b = obj_b[property];
  const type_a = typeof value_a;
  const type_b = typeof value_b;

  if (type_a !== type_b) return false;

  if (simpleJsTypes.includes(type_a)) {
    return value_a === value_b;
  } else if (type_a === 'object') {
    return isEqual(value_a, value_b);
  }

  return false;
};

export const isPartiallyEqual = (obj_a, obj_b, propertiesToCompare, logdiff = false) => {
  const diff = propertiesToCompare.filter(property => !isPropertyEqual(obj_a, obj_b, property));
  const propertiesAreEqual = diff.length === 0;
  if (logdiff) {
    const logMsg = propertiesAreEqual
      ? 'The properties compared are the same'
      : 'The following properties differ: ' + diff.join(', ');
    console.log(logMsg, obj_a, obj_b);
  }

  return propertiesAreEqual;
};

export const mapArrayToObject = array => {
  const mappedObj = {};
  if (!array) return mappedObj;
  array.map(arr => (mappedObj[arr[0]] = { ...arr[1] }));
  return mappedObj;
};
