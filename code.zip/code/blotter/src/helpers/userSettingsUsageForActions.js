import * as usageService from '~services/usageService';
import { FLOW_APP_NAME, RFQ_APP_NAME } from '~helpers/globals';

const sendUsage = (targetApp, payload) =>
  targetApp === FLOW_APP_NAME ? usageService.sendUsage(payload) : usageService.sendUsageForRFQ(payload);

const { RFQ_POPUP_VIEWS, VIEW, ENTITLEMENT_CONTROL, RFQ, COLUMN_CHOOSER } = usageService.actions;

const sendSwitchViewUsage = (targetApp, viewName) => {
  const payload = {
    userAction: 'View',
    notes: {
      AppName: FLOW_APP_NAME,
      Action: 'Switch View',
      Name: viewName
    }
  };
  sendUsage(targetApp, payload);
};

const sendDeleteViewUsage = (targetApp, editingView) => {
  const payload = {
    userAction: targetApp === RFQ_APP_NAME ? RFQ_POPUP_VIEWS : VIEW,
    notes: {
      AppName: FLOW_APP_NAME,
      Action: 'Delete',
      Name: editingView
    }
  };
  sendUsage(targetApp, payload);
};

const sendCreateViewUsage = (targetApp, typedViewName, inputDefaultIsChecked) => {
  const payload = {
    userAction: targetApp === RFQ_APP_NAME ? RFQ_POPUP_VIEWS : VIEW,
    notes: {
      AppName: FLOW_APP_NAME,
      Action: 'Create',
      Name: typedViewName,
      SetAsDefault: inputDefaultIsChecked ? 'Yes' : 'No'
    }
  };
  sendUsage(targetApp, payload);
};

const sendUpdateViewUsage = (targetApp, typedViewName) => {
  const payload = {
    userAction: targetApp === RFQ_APP_NAME ? RFQ_POPUP_VIEWS : VIEW,
    notes: {
      AppName: FLOW_APP_NAME,
      Action: 'Save',
      Name: typedViewName
    }
  };
  sendUsage(targetApp, payload);
};

const sendColumnChooserUsage = (targetApp, usageNotes) => {
  const payload = {
    userAction: COLUMN_CHOOSER,
    notes: {
      Action: usageNotes
    }
  };

  sendUsage(targetApp, payload);
};

const sendUsageForToggles = (targetApp, updatedToggles) => {
  const { RFQ_POPUP_TOGGLE, FLOW_BLOTTER_TOGGLE } = usageService.actions;
  const userAction = targetApp === RFQ_APP_NAME ? RFQ_POPUP_TOGGLE : FLOW_BLOTTER_TOGGLE;

  Object.entries(updatedToggles).forEach(([toggle, value]) => {
    const payload = {
      userAction,
      notes: {
        Toggle: toggle,
        Action: value ? 'ON' : 'OFF'
      }
    };
    sendUsage(targetApp, payload);
  });
};

const sendUsageForRFQPopupToggle = (targetApp, isRFQNotificationToggleOn) => {
  const payload = {
    userAction: RFQ,
    notes: { Action: isRFQNotificationToggleOn ? 'ON' : 'OFF' }
  };
  sendUsage(targetApp, payload);
};

const sendUpdateTradingDeskCoverageChoicesUsage = (targetApp, usageNotes) => {
  const payload = {
    userAction: ENTITLEMENT_CONTROL,
    notes: usageNotes
  };

  sendUsage(targetApp, payload);
};

export {
  sendColumnChooserUsage,
  sendCreateViewUsage,
  sendDeleteViewUsage,
  sendUpdateViewUsage,
  sendSwitchViewUsage,
  sendUsageForToggles,
  sendUsageForRFQPopupToggle,
  sendUpdateTradingDeskCoverageChoicesUsage
};
