import { BBG_SENDER } from './globals';
import * as usageService from '~services/usageService';
import { BloombergCommandFactory } from '~patterns/factory-method/bloombergCommand';

export const executeCommandWithUsage = (bloombergOptions, usageOptions) => {
  const { command, args } = bloombergOptions;
  const { commandLabel } = usageOptions;

  usageService.sendUsageForRFQ({
    userAction: usageService.actions.BBG_NAVIGATE,
    notes: {
      Selection: commandLabel,
      Command: command,
      Data: args,
      From: usageService.usageTriggers.rfqPopup
    }
  });

  const bloombergCommandFactory = new BloombergCommandFactory();
  const executeBBGCommand = bloombergCommandFactory.create(BBG_SENDER);
  executeBBGCommand(bloombergOptions);
};
