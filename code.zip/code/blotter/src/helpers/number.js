import { isNumber } from '~helpers/dataTypes';

export const formatNumber = value => {
  const unformattedTextNum = value.toString();
  if (unformattedTextNum.trim() === '') return null;

  const formattedNum = unformattedTextNum.replace(/,/g, '');

  if (formattedNum.includes('-')) return formattedNum;

  const isDecimal = formattedNum.indexOf('.') > -1;

  return isDecimal ? parseFloat(formattedNum) : parseInt(formattedNum);
};

/**
 * Returns a random integer
 *
 * @param {number} min The minimum number to be returned
 * @param {number} variance The largest difference allowed from the minimum
 *
 * @returns {number}
 */
export const randomInteger = (min = 0, variance = 1000) => {
  return min + Math.floor(Math.random() * variance);
};

export const isEmpty = str => isNumber(str) && str === 0;

export const isNotEmpty = str => isNumber(str) && str !== 0;

export const isInteger = value => isNumber(value) && Number.isInteger(value);

export const isDecimal = value => isNumber(value) && !Number.isInteger(value);
