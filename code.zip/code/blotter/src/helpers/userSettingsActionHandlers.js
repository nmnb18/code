import {
  setSessionData,
  updateFlowAppView,
  addFlowAppView,
  deleteFlowAppView,
  getRFQNotificationPopup,
  updateRFQNotificationPopupSetting,
  removeSessionData,
  updateSharedSettings,
  updateFilterSharedSettings,
  updateTradingDeskCoverageChoices,
  deleteTradingDeskCoverageChoices,
  updateDefaultCopyTemplate,
  updateCopyTemplate,
  deleteCopyTemplate,
  createCopyTemplate
} from '~helpers/flowAppSettingsUtils';
import * as usageForActions from '~helpers/userSettingsUsageForActions';
import { APP_NAME, RFQ_APP_NAME } from '~helpers/globals';
import { rfqNotificationService } from '~services/rfqNotificationService';
import { getMyDeskFromEntitlement } from './entitlement';

const getDefaultViewName = targetApp => (targetApp === APP_NAME ? 'DefaultView' : 'DefaultPopUpView');

const handleSwitchView = ({ viewName, flowAppSettings, targetApp }) => {
  const updatedFlowAppSettings = setSessionData(flowAppSettings, targetApp, {
    selectedView: viewName
  });
  usageForActions.sendSwitchViewUsage(targetApp, viewName);
  return updatedFlowAppSettings;
};

const handleColumnStateAndSortSave = ({ currentViewName, columnState, sortModel, flowAppSettings, targetApp }) => {
  const updatedFlowAppSettings = updateFlowAppView({
    flowAppSettings,
    targetApp,
    targetView: currentViewName,
    replace: false,
    update: {
      SortPriority: sortModel,
      ColumnState: columnState
    }
  });
  return updatedFlowAppSettings;
};

const handleCreateView = ({ resultView, inputDefaultIsChecked, typedViewName, flowAppSettings, targetApp }) => {
  let updatedFlowAppSettings = addFlowAppView({
    flowAppSettings,
    targetApp,
    newView: resultView
  });

  if (inputDefaultIsChecked) {
    updatedFlowAppSettings[getDefaultViewName(targetApp)] = typedViewName;
  }

  updatedFlowAppSettings = setSessionData(updatedFlowAppSettings, targetApp, {
    selectedView: typedViewName
  });

  usageForActions.sendCreateViewUsage(targetApp, typedViewName, inputDefaultIsChecked);

  return updatedFlowAppSettings;
};

const handleDeleteView = ({ targetApp, editingView, defaultView, readOnlyView, flowAppSettings }) => {
  let updatedFlowAppSettings = deleteFlowAppView({
    flowAppSettings,
    targetApp,
    targetView: editingView
  });

  if (editingView === defaultView) {
    updatedFlowAppSettings[getDefaultViewName(targetApp)] = readOnlyView;
  }

  updatedFlowAppSettings = setSessionData(updatedFlowAppSettings, targetApp, {
    selectedView: false
  });

  usageForActions.sendDeleteViewUsage(targetApp, editingView);

  return updatedFlowAppSettings;
};

const handleUpdateView = ({
  resultView,
  inputDefaultIsChecked,
  typedViewName,
  isEditing,
  currentViewName,
  defaultView,
  flowAppSettings,
  targetApp
}) => {
  let updatedFlowAppSettings = updateFlowAppView({
    flowAppSettings,
    targetApp,
    targetView: isEditing ? currentViewName : typedViewName,
    replace: !isEditing,
    update: isEditing
      ? {
          ViewName: typedViewName
        }
      : resultView
  });

  if (inputDefaultIsChecked) {
    updatedFlowAppSettings[getDefaultViewName(targetApp)] = typedViewName;
  } else if (currentViewName === defaultView) {
    updatedFlowAppSettings[getDefaultViewName(targetApp)] = 'Standard';
  }

  updatedFlowAppSettings = setSessionData(updatedFlowAppSettings, targetApp, {
    selectedView: typedViewName !== currentViewName ? typedViewName : currentViewName
  });

  usageForActions.sendUpdateViewUsage(targetApp, typedViewName, inputDefaultIsChecked);

  return updatedFlowAppSettings;
};

const handleColumnChooserSave = ({ targetApp, currentView, resultView, usageNotes, flowAppSettings }) => {
  const updatedFlowAppSettings = updateFlowAppView({
    flowAppSettings,
    targetApp,
    targetView: currentView,
    replace: true,
    update: resultView
  });

  usageForActions.sendColumnChooserUsage(targetApp, usageNotes);

  return updatedFlowAppSettings;
};

const handleToggleRFQPopup = ({ flowAppSettings, targetApp, toggledFrom }) => {
  const updatedRFQNotificationToggleOn = !getRFQNotificationPopup(flowAppSettings);
  console.log(
    `rfqPopup action: user toggled RFQ popup ${updatedRFQNotificationToggleOn ? 'on' : 'off'} from ${toggledFrom}`
  );

  let updatedFlowAppSettings = updateRFQNotificationPopupSetting(flowAppSettings, updatedRFQNotificationToggleOn);

  if (!updatedRFQNotificationToggleOn) {
    updatedFlowAppSettings = removeSessionData(updatedFlowAppSettings, RFQ_APP_NAME);
  }

  usageForActions.sendUsageForRFQPopupToggle(updatedRFQNotificationToggleOn);

  rfqNotificationService.setRFQPopupManuallyEnabledThisSession(targetApp, updatedRFQNotificationToggleOn);

  return updatedFlowAppSettings;
};

const handleUpdateToggles = ({ flowAppSettings, targetApp, setCustomToggles, updatedToggles }) => {
  const updatedFlowAppSettings = updateSharedSettings(flowAppSettings, targetApp, updatedToggles);
  setCustomToggles(updatedToggles, targetApp);
  usageForActions.sendUsageForToggles(targetApp, updatedToggles);
  return updatedFlowAppSettings;
};

const FILTER_TOGGLE = true;
const handleUpdateFilterToggles = ({ flowAppSettings, targetApp, setCustomToggles, updatedFilterToggles }) => {
  const updatedFlowAppSettings = updateFilterSharedSettings(flowAppSettings, targetApp, updatedFilterToggles);
  setCustomToggles(updatedFilterToggles, targetApp, FILTER_TOGGLE);
  usageForActions.sendUsageForToggles(targetApp, updatedFilterToggles);
  return updatedFlowAppSettings;
};

const handleUpdateTradingDeskCoverageChoices = ({
  flowAppSettings,
  targetApp,
  isCoverageSelected,
  isMyDeskSelected,
  userEntitlement,
  usageNotes
}) => {
  const updatedTradingDeskCoverageChoices = {
    coverage: isCoverageSelected,
    mydesk: isMyDeskSelected ? getMyDeskFromEntitlement(userEntitlement) : ''
  };
  const updatedFlowAppSettings = updateTradingDeskCoverageChoices(flowAppSettings, updatedTradingDeskCoverageChoices);

  usageForActions.sendUpdateTradingDeskCoverageChoicesUsage(targetApp, usageNotes);

  return updatedFlowAppSettings;
};

const handleDeleteTradingDeskCoverageChoices = ({ flowAppSettings }) => {
  const updatedFlowAppSettings = deleteTradingDeskCoverageChoices(flowAppSettings);

  return updatedFlowAppSettings;
};

const handleUpdateDefaultCopyTemplate = ({ flowAppSettings, selectedInDDLCopyTemplateName }) =>
  updateDefaultCopyTemplate(flowAppSettings, selectedInDDLCopyTemplateName);

const handleUpdateCopyTemplate = ({
  currentUser,
  flowAppSettings,
  selectedInDDLCopyTemplateName,
  activeColumns,
  inputDefaultIsChecked
}) => {
  let updatedFlowAppSettings = updateCopyTemplate({
    flowAppSettings,
    currentUser,
    selectedInDDLCopyTemplateName,
    activeColumns
  });

  const defaultCopyTemplate = inputDefaultIsChecked
    ? selectedInDDLCopyTemplateName
    : updatedFlowAppSettings.CopySettings[0].CopyTemplateName;

  updatedFlowAppSettings = updateDefaultCopyTemplate(updatedFlowAppSettings, defaultCopyTemplate);

  return updatedFlowAppSettings;
};

const handleCreateCopyTemplate = ({
  currentUser,
  flowAppSettings,
  typedCopyTemplateName,
  activeColumns,
  inputDefaultIsChecked
}) => {
  let updatedFlowAppSettings = createCopyTemplate({
    currentUser,
    flowAppSettings,
    typedCopyTemplateName,
    activeColumns
  });

  if (inputDefaultIsChecked) {
    updatedFlowAppSettings = updateDefaultCopyTemplate(updatedFlowAppSettings, typedCopyTemplateName);
  }

  return updatedFlowAppSettings;
};

const handleDeleteCopyTemplate = ({ flowAppSettings, selectedInDDLCopyTemplateName, inputDefaultIsChecked }) => {
  let updatedFlowAppSettings = deleteCopyTemplate({ flowAppSettings, selectedInDDLCopyTemplateName });

  if (inputDefaultIsChecked) {
    updatedFlowAppSettings = updateDefaultCopyTemplate(
      updatedFlowAppSettings,
      updatedFlowAppSettings.CopySettings[0].CopyTemplateName
    );
  }

  return updatedFlowAppSettings;
};

const actionHandlers = {
  SWITCH_VIEW: handleSwitchView,
  CREATE_VIEW: handleCreateView,
  UPDATE_VIEW: handleUpdateView,
  DELETE_VIEW: handleDeleteView,
  EDIT_COLUMNS: handleColumnChooserSave,
  EDIT_COLUMN_STATE_AND_SORT: handleColumnStateAndSortSave,
  TOGGLE_RFQ_POPUP: handleToggleRFQPopup,
  UPDATE_TOGGLES: handleUpdateToggles,
  UPDATE_FILTER_TOGGLES: handleUpdateFilterToggles,
  UPDATE_TRADING_DESK_COVERAGE_CHOICES: handleUpdateTradingDeskCoverageChoices,
  DELETE_TRADING_DESK_COVERAGE_CHOICES: handleDeleteTradingDeskCoverageChoices,
  UPDATE_DEFAULT_COPY_TEMPLATE: handleUpdateDefaultCopyTemplate,
  UPDATE_COPY_TEMPLATE: handleUpdateCopyTemplate,
  DELETE_COPY_TEMPLATE: handleDeleteCopyTemplate,
  CREATE_COPY_TEMPLATE: handleCreateCopyTemplate
};

const defaultHandler = () => null;

export const getActionHandler = type => actionHandlers[type] || defaultHandler;
