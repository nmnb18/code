export const strToNumber = value => (typeof value === 'string' ? +value : value);
