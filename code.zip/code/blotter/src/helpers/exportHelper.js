import XLSX from 'xlsx';

export const EXPORT_BATCH_SIZE = 75;

export const SELECTALL_CHECKBOX_STATE = {
  UNCHECK: 'UNCHECK',
  CHECK: 'CHECK',
  DASH: 'DASH',
  PARTIAL: 'PARTIAL'
};

export const isCheckboxStateUncheck = state => state === SELECTALL_CHECKBOX_STATE.UNCHECK;
export const isCheckboxStateCheck = state => state === SELECTALL_CHECKBOX_STATE.CHECK;
export const isCheckboxStateDash = state => state === SELECTALL_CHECKBOX_STATE.DASH;
export const isCheckboxStatePartial = state => state === SELECTALL_CHECKBOX_STATE.PARTIAL;

export const toggleSelectAllCheckboxStatus = currentStatus => {
  switch (currentStatus) {
    case SELECTALL_CHECKBOX_STATE.UNCHECK:
    case SELECTALL_CHECKBOX_STATE.PARTIAL:
      return SELECTALL_CHECKBOX_STATE.CHECK;
    case SELECTALL_CHECKBOX_STATE.CHECK:
    case SELECTALL_CHECKBOX_STATE.DASH:
      return SELECTALL_CHECKBOX_STATE.UNCHECK;
    default:
      return SELECTALL_CHECKBOX_STATE.UNCHECK;
  }
};

export const shapeData = data => {
  return data.map(obj => Object.values(obj));
};

export const shapeDataAndHeaders = function(headers, data) {
  const shapedData = data.map(obj => Object.values(obj));
  return [headers, ...shapedData];
};

export const exportExcelWithXLSX = function(
  headers,
  data,
  sheetName,
  fileName,
  executeCallback,
  disconnectExportDataCaching
) {
  try {
    const ws = XLSX.utils.aoa_to_sheet(shapeDataAndHeaders(headers, data));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
    /* generate XLSX file and send to client */
    XLSX.writeFile(wb, fileName);
    executeCallback();
    disconnectExportDataCaching();
  } catch (e) {
    console.log('Error while exporting to Excel Application ', e);
    executeCallback();
    disconnectExportDataCaching();
  }
};

export const getCurrentExcelProgressPercentage = ({ processedRecord, totalRecords }) => {
  return `${Math.floor((processedRecord * 100) / totalRecords)}%`;
};
