import cloneDeep from 'lodash/cloneDeep';

import {
  defaultRFQPopupSharedSettings,
  defaultFlowUserSharedSettings,
  defaultFlowFilterSharedSettings,
  defaultRFQPopupFilterSharedSettings
} from '~helpers/userSettings';
import * as settingsService from '~services/settingsService';
import { APP_NAME, FLOW_APP_NAME, RFQ_APP_NAME } from '~helpers/globals';

const isTargetFlowBlotter = targetApp => targetApp === FLOW_APP_NAME;
const isTargetRFQPopup = targetApp => targetApp === RFQ_APP_NAME; // eslint-disable-line

const userSettingsKeys = {
  AppName: 'AppName',
  CopySettings: 'CopySettings',
  DisplayOrder: 'DisplayOrder',
  DefaultCopyTemplate: 'DefaultCopyTemplate',
  DefaultView: 'DefaultView',
  DefaultPopUpView: 'DefaultPopUpView',
  Settings: 'Settings',
  FilterSharedSettings: 'FilterSharedSettings',
  RFQPopupFilterSharedSettings: 'RFQPopupFilterSharedSettings',
  SharedSettings: 'SharedSettings',
  RFQPopupSharedSettings: 'RFQPopupSharedSettings',
  Views: 'Views',
  PopUpViews: 'PopUpViews'
};

export const setSessionData = (flowAppSettings, AppName, newAppData) => {
  const updatedFlowAppSettings = cloneDeep(flowAppSettings);

  const { sessionData = {} } = updatedFlowAppSettings;
  updatedFlowAppSettings.sessionData = { ...sessionData, [AppName]: newAppData };

  return updatedFlowAppSettings;
};

export const removeSessionData = (flowAppSettings, AppName) => {
  const updatedFlowAppSettings = cloneDeep(flowAppSettings);
  if (updatedFlowAppSettings?.sessionData?.[AppName]) {
    delete updatedFlowAppSettings.sessionData[AppName];
  }

  return updatedFlowAppSettings;
};

export const getSessionData = flowAppSettings => flowAppSettings?.sessionData || {};

export const getViewsListRef = (flowAppSettings, targetApp) =>
  targetApp === APP_NAME ? flowAppSettings.Views : flowAppSettings.PopUpViews;

export const updateFlowAppView = ({ flowAppSettings, targetApp, targetView, replace, update }) => {
  const updatedAppSettings = cloneDeep(flowAppSettings);
  const updatedView = cloneDeep(update);
  const views = getViewsListRef(updatedAppSettings, targetApp);
  const viewIndex = views.findIndex(view => view.ViewName === targetView);

  if (replace) {
    views[viewIndex] = updatedView;
  } else if (views[viewIndex] && !views[viewIndex].ReadOnly) {
    views[viewIndex] = { ...views[viewIndex], ...updatedView };
  } else {
    return null;
  }

  return updatedAppSettings;
};

export const addFlowAppView = ({ flowAppSettings, targetApp, newView }) => {
  const updatedAppSettings = cloneDeep(flowAppSettings);
  const views = getViewsListRef(updatedAppSettings, targetApp);
  views.push(newView);

  return updatedAppSettings;
};

const getViewsPath = targetApp =>
  isTargetFlowBlotter(targetApp) ? userSettingsKeys.Views : userSettingsKeys.PopUpViews;

export const deleteFlowAppView = ({ flowAppSettings, targetApp, targetView }) => {
  const updatedflowAppSettings = cloneDeep(flowAppSettings);
  const viewsPath = getViewsPath(targetApp);

  updatedflowAppSettings[viewsPath] = updatedflowAppSettings[viewsPath].filter(view => view.ViewName !== targetView);

  return updatedflowAppSettings;
};

const getSharedSettingsPath = targetApp =>
  isTargetFlowBlotter(targetApp) ? userSettingsKeys.SharedSettings : userSettingsKeys.RFQPopupSharedSettings;
const getDefaultSharedSettings = targetApp =>
  isTargetFlowBlotter(targetApp) ? defaultFlowUserSharedSettings : defaultRFQPopupSharedSettings;

export const updateSharedSettings = (flowAppSettings, targetApp, sharedSettingsChanges) => {
  const updatedFlowApp = cloneDeep(flowAppSettings);
  const sharedSettingsPath = getSharedSettingsPath(targetApp);
  const defaultSharedSettings = getDefaultSharedSettings(targetApp);

  const currentSharedSettings = updatedFlowApp[sharedSettingsPath] || defaultSharedSettings;
  updatedFlowApp[sharedSettingsPath] = { ...currentSharedSettings, ...sharedSettingsChanges };

  return updatedFlowApp;
};

export const updateRFQNotificationPopupSetting = (flowAppSettings, updatedRFQNotificationPopup) => {
  const updatedFlowApp = cloneDeep(flowAppSettings);
  const sharedSettings = flowAppSettings.SharedSettings || defaultFlowUserSharedSettings;
  const updatedSharedSettings = { ...sharedSettings, RFQNotificationPopup: updatedRFQNotificationPopup };

  updatedFlowApp.SharedSettings = updatedSharedSettings;

  return updatedFlowApp;
};

const getFilterSharedSettingsPath = targetApp =>
  isTargetFlowBlotter(targetApp)
    ? userSettingsKeys.FilterSharedSettings
    : userSettingsKeys.RFQPopupFilterSharedSettings;
const getDefaultFilterSharedSettings = targetApp =>
  isTargetFlowBlotter(targetApp) ? defaultFlowFilterSharedSettings : defaultRFQPopupFilterSharedSettings;

export const updateFilterSharedSettings = (flowAppSettings, targetApp, filterSharedSettingsChanges) => {
  const updatedFlowApp = cloneDeep(flowAppSettings);
  const filterSharedSettingsPath = getFilterSharedSettingsPath(targetApp);
  const defaultFilterSharedSettings = getDefaultFilterSharedSettings(targetApp);

  const currentSharedSettings = updatedFlowApp[filterSharedSettingsPath] || defaultFilterSharedSettings;
  updatedFlowApp[filterSharedSettingsPath] = { ...currentSharedSettings, ...filterSharedSettingsChanges };

  return updatedFlowApp;
};

export const updateTradingDeskCoverageChoices = (flowAppSettings, updatedTradingDeskCoverageChoices) => {
  const updatedFlowApp = cloneDeep(flowAppSettings);

  updatedFlowApp['Settings']['TradingDeskCoverageChoices'] = updatedTradingDeskCoverageChoices;

  return updatedFlowApp;
};

export const deleteTradingDeskCoverageChoices = flowAppSettings => {
  const updatedFlowApp = cloneDeep(flowAppSettings);

  delete updatedFlowApp.Settings.TradingDeskCoverageChoices;

  return updatedFlowApp;
};

export const updateDefaultCopyTemplate = (flowAppSettings, selectedInDDLCopyTemplateName) => {
  const updatedFlowApp = cloneDeep(flowAppSettings);

  updatedFlowApp['DefaultCopyTemplate'] = selectedInDDLCopyTemplateName;

  return updatedFlowApp;
};

export const getRFQNotificationPopup = flowAppSettings =>
  flowAppSettings?.SharedSettings?.RFQNotificationPopup || false;

export const updateCopyTemplate = ({ currentUser, flowAppSettings, selectedInDDLCopyTemplateName, activeColumns }) => {
  const updatedFlowAppSettings = cloneDeep(flowAppSettings);
  const copyTemplateIndex = updatedFlowAppSettings.CopySettings.findIndex(
    ct => ct.CopyTemplateName === selectedInDDLCopyTemplateName
  );
  const resultCopyTemplate = settingsService.createAdditionalCopyTemplate(
    selectedInDDLCopyTemplateName,
    activeColumns,
    currentUser
  );
  updatedFlowAppSettings.CopySettings[copyTemplateIndex] = resultCopyTemplate;

  return updatedFlowAppSettings;
};

export const createCopyTemplate = ({ currentUser, flowAppSettings, activeColumns, typedCopyTemplateName }) => {
  const updatedFlowAppSettings = cloneDeep(flowAppSettings);
  const resultCopyTemplate = settingsService.createAdditionalCopyTemplate(
    typedCopyTemplateName,
    activeColumns,
    currentUser
  );
  updatedFlowAppSettings.CopySettings.push(resultCopyTemplate);

  return updatedFlowAppSettings;
};

export const deleteCopyTemplate = ({ flowAppSettings, selectedInDDLCopyTemplateName }) => {
  const updatedFlowAppSettings = cloneDeep(flowAppSettings);
  const copyTemplateIndex = updatedFlowAppSettings.CopySettings.findIndex(
    ct => ct.CopyTemplateName === selectedInDDLCopyTemplateName
  );
  updatedFlowAppSettings.CopySettings.splice(copyTemplateIndex, 1);

  return updatedFlowAppSettings;
};
