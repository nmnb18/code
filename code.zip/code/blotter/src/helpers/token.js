export const newToken = () => Date.now().toString();
