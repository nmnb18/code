import { COLUMNS, COLUMNS_TYPE } from '~helpers/columnStyles';
import { formatDateTime, getDateFromString, getTimeFromString, getDateTimeFromString } from '~helpers/dateHelper';
import { DATETIME } from '~constants/filters';
import { dec2ticks } from './decimalToTicks';
import { filterToggleStore } from '~patterns/singleton/filterToggleStore';
import { isDecimal } from '~helpers/number';
import { isNull, isUndefined } from '~helpers/dataTypes';

export const FORMATS = {
  countdown: 'HH:mm:ss'
};

const SINGLE_SPACE = ' ';
const BLANK_SPACE = '';
const EXPORT_TO_EXCEL = true;
const US_TREASURY_CODE = '9128';
const UST_PRICE_LIMIT = 20;
export const TIMEZONE_COLUMNS = ['time_utc'];
export const BASE_32 = 'base32';

const getDecimalFormattedValue = ({ numComma, value, decFormat, isExcelExport = false, columntype }) => {
  if (numComma) {
    const resultFixed = formatDecimals(value, decFormat);
    return isExcelExport ? decimalValueForExcel(resultFixed) : formatComma(resultFixed, columntype);
  }
  return formatDecimals(value, decFormat);
};

const shouldConvertPrice = (code = '', value) =>
  code.startsWith(US_TREASURY_CODE) && parseFloat(value) > UST_PRICE_LIMIT;

export const formatDateOrTime = (value, dateFormat) => {
  if (!value) return BLANK_SPACE;
  if (value === '0') return BLANK_SPACE;

  if (value.length <= 5) {
    //TODO: Need to understand this logic and convert it to helper function
    try {
      let spaces = 0;
      if (value < 3600) spaces += 3;
      else if (value < 60) spaces += 6;

      return new Date(value * 1000).toISOString().substr(11 + spaces, 8 - spaces);
    } catch (error) {
      return value;
    }
  }
  if (value.length === 15) {
    return formatDateTime(getDateTimeFromString(value), dateFormat);
  }
  if (value.length === 6) {
    return formatDateTime(getTimeFromString(value), dateFormat);
  } else if (value.length === 8) {
    return formatDateTime(getDateFromString(value), dateFormat);
  }
};

export const formatDecimals = (value, decFormat) => {
  if (!value) return BLANK_SPACE;

  try {
    return value && Number(value).toFixed(decFormat);
  } catch (error) {
    return value;
  }
};

// If column is 'INTEGER', return number value without any decimals, else return number value
const truncateIfInteger = (value, columntype) => {
  return columntype === COLUMNS_TYPE.INTEGER ? Math.trunc(value) : value;
};

export const formatComma = (value, columntype) => {
  if (!value) return BLANK_SPACE;

  const numValue = truncateIfInteger(value, columntype);

  /**
   * If numValue is an integer, apply commas to separate thousands, else just apply commas
   * to the first part of the number, and don't take care about decimals.
   */
  try {
    if (Number.isInteger(Number(numValue))) {
      return numValue.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    } else {
      const [firstPart, secondPart] = numValue.toString().split('.');
      const formattedFirstPart = firstPart.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      return `${formattedFirstPart}.${secondPart}`;
    }
  } catch (error) {
    return value;
  }
};

export const formatValue = ({ params, field, columntype, formatinstruction, codeinstruction }) => {
  const { RFQAXE } = COLUMNS;
  const { value, column } = params;

  if (column.colId === RFQAXE && !value) {
    return null;
  }

  if (!value) return BLANK_SPACE;

  const { data } = params;

  return applyFormatInstruction(value, { formatinstruction, codeinstruction, field }, columntype, false, data, null);
};

export const decimalValueForExcel = value => {
  if (!value) return BLANK_SPACE;

  return Number.parseFloat(value);
};

export const applyFormatInstruction = (
  value,
  { formatinstruction, codeinstruction, field } = {},
  columntype,
  isExcelExport = false,
  data,
  filterToggles
) => {
  if (!formatinstruction) {
    return value;
  }
  const { dateFormat, decFormat, numComma } = formatinstruction;

  // dateFormat includes Time, Exp, Expiration Time and Date
  if (dateFormat) {
    return formatDateOrTime(value, dateFormat);
  }

  if (numComma && !decFormat) {
    if (isExcelExport && field && filterToggles[field] && filterToggles[field].toggle) {
      const { denominator } = filterToggles[field].toggleOptions;
      const formattedValue = value / denominator;
      let customColumnType = columntype;

      const isValueDecimal = isDecimal(formattedValue);
      if (isValueDecimal) customColumnType = COLUMNS_TYPE.FLOAT;

      return formatComma(formattedValue, customColumnType);
    }

    if (codeinstruction && codeinstruction.denominatorInstruction) {
      const filterToggleState = filterToggleStore.get(field);

      if (filterToggleState) {
        const { showToggle, toggle, toggleOptions } = filterToggleState;
        const formattedValue = showToggle && toggle ? value / toggleOptions.denominator : value;
        const isValueDecimal = isDecimal(formattedValue);
        const customColumnType = showToggle && toggle && isValueDecimal ? COLUMNS_TYPE.FLOAT : columntype;

        return getDecimalFormattedValue({
          numComma,
          value: formattedValue,
          decFormat: toggleOptions.decFormat,
          isExcelExport,
          columntype: customColumnType
        });
      }
    }

    return isExcelExport ? Number.parseInt(value) : formatComma(value, columntype);
  }

  // "decFormat": "3" || "base32"
  // 4.333
  if (decFormat === BASE_32) {
    // UST price in 32nd
    // For US treasury people we need to show Our Price(rfqdealvalue) & Sent Price (adjustedrfqdealvalue) in 32nd format
    // So far that if CUSIP/ISIN(code) starts with 9128(US treasury) and price is more than 20 we have to convert both price in 32nd
    if (shouldConvertPrice(data.code, value)) return dec2ticks(value);

    // For value less than 20
    return getDecimalFormattedValue({
      numComma: true,
      value,
      decFormat: 3,
      isExcelExport,
      columntype
    });
  }

  if (decFormat) {
    return getDecimalFormattedValue({
      numComma,
      value,
      decFormat,
      isExcelExport,
      columntype
    });
  }

  return value;
};

export const padRightString = (value, filler, length) => {
  return (value ? `${value}` : BLANK_SPACE).padEnd(length, filler);
};

export const emptyIfZeroString = value => {
  return Number(value) === 0 ? BLANK_SPACE : value;
};

//TODO: This function should use date format instead of hardcoded YY
export const shrinkYears = (value, dateFormat) => {
  try {
    return dateFormat === 'YY' ? value.substring(2) : value;
  } catch (error) {
    return value;
  }
};

export const applyFormatInstructionForClipboard = (
  value,
  columntype,
  width,
  row,
  { copyTemplateFormat }, // codeinstruction
  filterToggles,
  field
) => {
  if (!copyTemplateFormat) return value;

  const { fieldJoiner, joinedColumn } = copyTemplateFormat;
  const formattedFirstValue = value
    ? formatSingleFieldWithCopyTemplate(value, columntype, copyTemplateFormat, row, field, filterToggles)
    : value;

  if (!joinedColumn) {
    return padRightString(formattedFirstValue, SINGLE_SPACE, width);
  }

  const joinFieldCopyTemplateFormat = copyTemplateFormat[joinedColumn];
  const formattedSecondValue = formatSingleFieldWithCopyTemplate(
    row[joinedColumn],
    columntype,
    joinFieldCopyTemplateFormat
  );
  const returnString =
    formattedFirstValue || formattedSecondValue
      ? `${formattedFirstValue}${fieldJoiner}${formattedSecondValue}`
      : BLANK_SPACE;
  return padRightString(returnString, SINGLE_SPACE, width);
};

const formatSingleFieldWithCopyTemplate = (value, columntype, copyTemplateFormat, row, field, filterToggles) => {
  let formattedValue = value;
  let customColumnType = columntype;

  if (field && filterToggles[field] && filterToggles[field].toggle) {
    const { denominator } = filterToggles[field].toggleOptions;
    formattedValue = value / denominator;
    const isValueDecimal = isDecimal(formattedValue);
    if (isValueDecimal) customColumnType = COLUMNS_TYPE.FLOAT;
  }

  let returnedValue = `${truncateIfInteger(formattedValue, customColumnType)}`;

  const { emptyIfZero, decFormat, dateFormat } = copyTemplateFormat;

  //emptyIfZero (True /False)
  if (emptyIfZero) {
    returnedValue = emptyIfZeroString(returnedValue);
  }

  //decFormat: {x},
  if (decFormat === BASE_32 && shouldConvertPrice(row.code, value)) {
    // UST price in 32nd
    // For US treasury people we need to show Our Price(rfqdealvalue) & Sent Price (adjustedrfqdealvalue) in 32nd format
    // So far that if CUSIP/ISIN(code) starts with 9128(US treasury) and price is more than 20 we have to convert both price in 32nd
    returnedValue = dec2ticks(value);
  } else if (decFormat) {
    returnedValue = formatDecimals(returnedValue, decFormat);
  }

  //dateFormat e.g. 'YY'
  if (dateFormat) {
    returnedValue = shrinkYears(value, dateFormat);
  }
  return returnedValue;
};

export const formatColumn = (field, value, columnsDictionary) => {
  const columnDef = columnsDictionary.sourceColumnNames.find(column => column.sourcecolumnname === field);
  if (!columnDef) return value;
  const { columntype, formatinstruction } = columnDef;

  return applyFormatInstruction(value, { formatinstruction, field }, columntype);
};

export const formatExcelExportColumn = ({ field, value, row, columnsDictionary, filterToggles }) => {
  const columnDef = columnsDictionary.sourceColumnNames.find(column => column.sourcecolumnname === field);
  if (!columnDef) return value;

  const { columntype, formatinstruction } = columnDef;

  if (TIMEZONE_COLUMNS.includes(field)) {
    formatinstruction.dateFormat = FORMATS.countdown;
  }

  return applyFormatInstruction(value, { formatinstruction, field }, columntype, EXPORT_TO_EXCEL, row, filterToggles);
};

export const formatExcelExportData = (data, headers, headerFields, columnsDictionary, filterToggles) => {
  return data.map(row => {
    const formattedRow = Object.keys(row)
      .filter(key => headerFields.includes(key))
      .reduce((acc, cur) => {
        if (acc[cur]) return acc;
        acc[cur] = formatExcelExportColumn({
          field: cur,
          value: row[cur],
          row,
          columnsDictionary,
          filterToggles
        });
        return acc;
      }, {});
    return headers.map(({ field }) => formattedRow[field]);
  });
};

export const formatCopyColumn = ({ field, value, row, width, columnsDictionary, filterToggles }) => {
  const columnDef = columnsDictionary.sourceColumnNames.find(column => column.sourcecolumnname === field);
  if (!columnDef) return value;

  const { columntype, codeinstruction, formatinstruction } = columnDef;
  const formattedValue = columntype === DATETIME ? formatDateOrTime(value, formatinstruction.dateFormat) : value;

  return codeinstruction.copyTemplateFormat
    ? applyFormatInstructionForClipboard(formattedValue, columntype, width, row, codeinstruction, filterToggles, field)
    : value;
};

export const formatCopyToClipboardData = (data, headers, headerFields, columnsDictionary, filterToggles) => {
  return data.map(row => {
    const formattedRow = Object.keys(row)
      .filter(key => headerFields.includes(key))
      .reduce((acc, cur) => {
        if (acc[cur]) return acc;
        const { width } = headers.find(header => header.field === cur);
        acc[cur] = formatCopyColumn({
          field: cur,
          value: row[cur],
          row,
          width,
          columnsDictionary,
          filterToggles
        });
        return acc;
      }, {});
    return headers.map(({ field, width }) =>
      !isNull(formattedRow[field]) && !isUndefined(formattedRow[field])
        ? formattedRow[field]
        : padRightString('', SINGLE_SPACE, width)
    );
  });
};

export const getFormatHeadersForCopy = headers => {
  return headers.map(header => padRightString(header.headerName, SINGLE_SPACE, header.width));
};
