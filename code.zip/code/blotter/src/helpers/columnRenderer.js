export const AXESIDE_NONE = 'NONE';
const RFQ_AXE_MATCH = '1';
const PRIORITY_AXE = {
  YES: '<span class="rfq-priority-axe-content">!</span>',
  NO_AXE: '<span class="rfq-priority-axe-content-noaxed">!</span>'
};

export const isAxeMatch = axematch => axematch === RFQ_AXE_MATCH;

export const showLiveAxeFlag = axeside => axeside && axeside !== AXESIDE_NONE;

export const getAxeClass = (axeside, axematch) => {
  if (!axeside) return '';

  const axeType = axeside.toLowerCase().replace(/\s/g, '');
  return `rfq-axed-content-${axeType} ${isAxeMatch(axematch) ? 'rfq-axed-content-axematched' : ''}`;
};

export const getLiveAxeContent = (axeside, axematch) => {
  if (!showLiveAxeFlag(axeside)) return '';

  const axeClass = getAxeClass(axeside, axematch);
  return getAxeContent(axeClass);
};

export const isPriorityAxeInvalid = priorityaxe =>
  !priorityaxe || priorityaxe === 'NO' || priorityaxe === 'NA' || priorityaxe === '';

export const getPriorityAxeContent = priorityaxe => {
  if (isPriorityAxeInvalid(priorityaxe)) {
    return '';
  }
  return PRIORITY_AXE[priorityaxe];
};

export const getAxeContent = axeClass => `<span class="rfq-axed-content ${axeClass}">AXE</span>`;
