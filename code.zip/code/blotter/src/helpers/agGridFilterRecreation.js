import { defaultFilterParam, formatFilterType, reverseFormatFilterType, parseSetFilterOptions } from '~helpers/filters';

import { CustomFilterFactory, filterTypes } from '~patterns/factory-method/customFilter';

import {
  FILTER_MODEL_SET,
  FILTER_MODEL_DYNAMIC_SET,
  FILTER_MODEL_TEXT,
  FILTER_MODEL_NUMBER,
  FILTER_MODEL_DATE
} from '~constants/filterModelTypes';
import { isEmpty, hasItems } from 'flow-navigator-shared/dist/array';

export const getAgGridFilter = filterList => {
  if (!filterList || isEmpty(filterList)) return null;

  const agGridFilter = filterList
    .map(filterElement => {
      switch (filterElement.filterType) {
        case FILTER_MODEL_SET:
          return `"${filterElement.field}": [${parseSetFilterOptions(filterElement.filter)}]`;
        case FILTER_MODEL_DYNAMIC_SET: {
          const { field, arrayFilter, textFilter, type } = filterElement;

          const ampsArrayFilter = arrayFilter ? `[${parseSetFilterOptions(arrayFilter)}]` : `[]`;
          const ampsTextFilter = textFilter || '';

          const filterValue = `
          {
            "type": "${reverseFormatFilterType(type)}",
            "textFilter": "${ampsTextFilter}",
            "arrayFilter": ${ampsArrayFilter}
          }`;

          return `"${field}": ${filterValue}`;
        }
        case FILTER_MODEL_TEXT:
          return `"${filterElement.field}": { 
            "filter": "${filterElement.filter[0]}",
            "type": "${reverseFormatFilterType(filterElement.type)}"
          }`;
        case FILTER_MODEL_NUMBER: //Do not refactor to combine with Text, because in the future we will have a second second param here.
          return `"${filterElement.field}": { 
            "filter": "${filterElement.filter[0]}",
            "type": "${reverseFormatFilterType(filterElement.type)}"
          }`;
        case FILTER_MODEL_DATE:
          return formatFilterObjectForDateInJsonString(filterElement);
        default:
          return null;
      }
    })
    .filter(Boolean)
    .join(',');

  const filtersTextFormat = `[{${agGridFilter}}]`;
  const filtersJsonFormat = JSON.parse(filtersTextFormat);

  return hasItems(filtersJsonFormat) ? filtersJsonFormat[0] : null;
};

export const getFilterList = (columnDefs, agGridFilterModel) => {
  const agGridFilterKeys = agGridFilterModel && Object.keys(agGridFilterModel);
  if (!agGridFilterKeys || agGridFilterKeys.length === 0) return [];

  const filterFactory = new CustomFilterFactory();

  return columnDefs
    .filter(({ field }) => agGridFilterKeys.includes(field))
    .map(col => {
      switch (agGridFilterModel[col.field].filterType) {
        case FILTER_MODEL_SET: {
          return filterFactory.createFilter(filterTypes.SetFilter, {
            field: col.field,
            headerName: col.headerName,
            filter: agGridFilterModel[col.field].filter
          });
        }
        case FILTER_MODEL_DYNAMIC_SET: {
          return filterFactory.createFilter(filterTypes.DynamicSetFilter, {
            field: col.field,
            headerName: col.headerName,
            arrayFilter: agGridFilterModel[col.field].arrayFilter,
            textFilter: agGridFilterModel[col.field].textFilter
          });
        }
        case FILTER_MODEL_TEXT: {
          return filterFactory.createFilter(filterTypes.TextFilter, {
            field: col.field,
            headerName: col.headerName,
            filter: [agGridFilterModel[col.field].filter || '', '']
          });
        }
        case FILTER_MODEL_NUMBER: {
          return filterFactory.createFilter(filterTypes.NumFilter, {
            field: col.field,
            headerName: col.headerName,
            filter: [agGridFilterModel[col.field].filter, agGridFilterModel[col.field].filterTo],
            type: agGridFilterModel[col.field].type && formatFilterType(agGridFilterModel[col.field].type.toLowerCase())
          });
        }
        case FILTER_MODEL_DATE:
          return formatFilterObjectForDate(col, agGridFilterModel);
        default:
          return defaultFilterParam(col);
      }
    });
};

export const applyFilterFormat = rawFilterList => {
  if (isEmpty(rawFilterList)) return [];

  const filterFactory = new CustomFilterFactory();

  return rawFilterList.map(rawFilter => {
    switch (rawFilter.filterType) {
      case FILTER_MODEL_SET: {
        return filterFactory.createFilter(filterTypes.SetFilter, {
          field: rawFilter.field,
          headerName: rawFilter.headerName,
          filter: rawFilter.filter
        });
      }
      case FILTER_MODEL_DYNAMIC_SET: {
        return filterFactory.createFilter(filterTypes.DynamicSetFilter, {
          field: rawFilter.field,
          headerName: rawFilter.headerName,
          arrayFilter: rawFilter.arrayFilter,
          textFilter: rawFilter.textFilter
        });
      }
      case FILTER_MODEL_TEXT: {
        return filterFactory.createFilter(filterTypes.TextFilter, {
          field: rawFilter.field,
          headerName: rawFilter.headerName,
          filter: rawFilter.filter
        });
      }
      case FILTER_MODEL_NUMBER: {
        return filterFactory.createFilter(filterTypes.NumFilter, {
          field: rawFilter.field,
          headerName: rawFilter.headerName,
          filter: rawFilter.filter,
          type: rawFilter.type
        });
      }
      case FILTER_MODEL_DATE:
        return rawFilter;
      default:
        return defaultFilterParam(rawFilter);
    }
  });
};

const formatFilterObjectForDateInJsonString = filterElement => {
  if (filterElement.customRange) {
    if (typeof filterElement.customRange === 'string') {
      return `"${filterElement.field}": { 
                "dateFrom": "${filterElement.filter[0]}",
                "dateTo": "${filterElement.filter[1]}",
                "customRange": "${filterElement.customRange}",
                "type": "${reverseFormatFilterType(filterElement.type)}"
              }`;
    } else {
      return `"${filterElement.field}": { 
                "dateFrom": "${filterElement.filter[0]}",
                "dateTo": "${filterElement.filter[1]}",
                "customRange": ${filterElement.customRange},
                "type": "${reverseFormatFilterType(filterElement.type)}"
              }`;
    }
  } else {
    return `"${filterElement.field}": { 
              "dateFrom": "${filterElement.filter[0]}",
              "dateTo": "${filterElement.filter[1]}",
              "type": "${reverseFormatFilterType(filterElement.type)}"
            }`;
  }
};

const formatFilterObjectForDate = (col, agGridFilterModel) => {
  const { dateFrom, dateTo, type, customRange } = agGridFilterModel[col.field];
  const filterObjectForDate = {
    field: col.field,
    headerName: col.headerName,
    filter: [dateFrom, dateTo],
    filterType: FILTER_MODEL_DATE,
    type: type && formatFilterType(type.toLowerCase())
  };
  return customRange ? { ...filterObjectForDate, customRange } : filterObjectForDate;
};
