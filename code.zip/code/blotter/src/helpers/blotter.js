import { JASPERSALES, RSMITH, FLOW, CLIENT, AXE } from '~helpers/globals';
import { jasperWs, applicationSettings } from '~services/apiConfig';
import { getQueryParam } from '~helpers/uri';

export const getFlowNavigatorUser = (currentUser, impersonatedUser) =>
  impersonatedUser ? impersonatedUser.id : currentUser;

/**
 * Create a url for displaying child blotter.
 *
 * @param {string} blotterName - Name of the blotter.
 * @param {string} blotterUser - Name of the user or user being impersonated.
 * @returns {string} Returns a url.
 */
export const getBlotterUrl = (blotterName, blotterUser, currentUser, theme = '') => {
  let url;

  if (blotterName === FLOW) {
    url = applicationSettings.flow.url;
    const prefixQuery = jasperWs.websocketPrefixQueryParam;
    const prefixQueryValue = getQueryParam(prefixQuery);
    if (prefixQueryValue) {
      url = `${url}?${prefixQuery}=${prefixQueryValue}`;
    }
  } else if (blotterName === AXE) {
    url = `${applicationSettings.axe.url}?impersonator=${currentUser}&uid=${blotterUser || JASPERSALES}&theme=${theme}`;
  } else if (blotterName === CLIENT) {
    url = `${applicationSettings.client.url}?impersonator=${currentUser}&uid=${blotterUser || RSMITH}&theme=${theme}`;
  }

  return url;
};

export const blotterConfiguration = {
  flow: process.env.REACT_APP_FLOW_BLOTTER_APP_TITLE,
  axe: process.env.REACT_APP_AXE_APP_TITLE,
  client: process.env.REACT_APP_CLIENT_APP_TITLE
};

export const getEnabledAppsConfig = blotterUserSettings => {
  let result = [];
  if (blotterUserSettings?.Applications) {
    result = blotterUserSettings.Applications.filter(
      ({ AppButtonVisible }) => AppButtonVisible === undefined || AppButtonVisible === true
    )
      .map(({ AppName, DisplayOrder }) => ({
        AppName,
        DisplayOrder,
        title: blotterConfiguration[AppName.toLowerCase()]
      }))
      .sort(({ DisplayOrder: a }, { DisplayOrder: b }) => a - b);
  }
  return result;
};
