export const SORT_ASC = 'asc';
export const SORT_DESC = 'desc';
export const SORT_NONE = null;

export const getSort = column => {
  if (column.isSortAscending()) return SORT_ASC;
  if (column.isSortDescending()) return SORT_DESC;

  return SORT_NONE;
};

export const ascCompare = (a, b) => {
  if (a < b) return -1;
  else if (a > b) return 1;
  return 0;
};

export const replacementSortingConfiguration = {
  transactioncreatedatetime_utc: 'transactioncreatedate_forsort',
  rfqcreatedate: 'transactioncreatedate_forsort',
  inquirycreatedate: 'transactioncreatedate_forsort',
  time_utc: 'transactioncreatetime_forsort',
  rfqcreatetime: 'transactioncreatetime_forsort',
  inquirycreatetime: 'transactioncreatetime_forsort'
};
