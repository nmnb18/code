import { APP_NAME } from './globals';
import * as settingsService from '~services/settingsService';
import * as columnDictionaryService from '~services/columnDictionaryService';
import * as integrationService from '~services/integrationService';
import { removeColumn, removeRepeatedColumn } from '~helpers/columnDefinition';
import { COLUMNS } from '~helpers/columnStyles';
import { applyFilterFormat } from '~helpers/agGridFilterRecreation';
import { processCustomRange } from '~helpers/filters';
import { hasItems } from 'flow-navigator-shared/dist/array';

export const getSelectedViewName = (userSettings, selectedView) =>
  selectedView ? selectedView.ViewName : settingsService.getSelectedPopUpViewName(userSettings, APP_NAME);

export const getColumnFilters = viewSettings => {
  const rawColumnFilters = hasItems(viewSettings.ColumnFilters) ? viewSettings.ColumnFilters : [];

  const formattedColumnFilters = applyFilterFormat(rawColumnFilters);

  return processCustomRange(formattedColumnFilters);
};

export const getDynamicSetFilterColumns = (viewSettings, dynamicSetFilters) => {
  if (!dynamicSetFilters) return null;

  const dynamicSetFilterColumnNames = dynamicSetFilters.map(({ sourcecolumnname }) => sourcecolumnname);
  const dynamicSetColumns = viewSettings.Columns.filter(({ ColName }) => dynamicSetFilterColumnNames.includes(ColName));

  return hasItems(dynamicSetColumns) ? dynamicSetColumns : null;
};

export const getColumnState = (viewSettings, columnDefs, addCheckboxColumn) => {
  const columnState = hasItems(viewSettings.ColumnState)
    ? viewSettings.ColumnState
    : columnDictionaryService.getDefaultColumnState(columnDefs);

  if (addCheckboxColumn) {
    const columnStateNoKeyId = removeColumn(columnState, 'key_id');
    return [integrationService.checkboxColumnState, ...columnStateNoKeyId];
  }

  return columnState;
};

export const getEnhancedColumnDefs = (columnDefs, columnsDictionary) => {
  const legColumnDefs = columnDictionaryService.getLegColumnDefinitions(columnDefs);
  const columnDefsWithLegs = [...columnDefs, ...legColumnDefs];
  const alwaysRequiredColumnDefs = columnDictionaryService.getAlwaysRequestColumnDefinitions(columnsDictionary);
  const nonRepeatedAlwaysRequestColumnDefs = removeRepeatedColumn(alwaysRequiredColumnDefs, columnDefsWithLegs);
  const columnDefsWithLegsNoKeyId = removeColumn(columnDefsWithLegs, 'key_id');
  return [...columnDefsWithLegsNoKeyId, ...nonRepeatedAlwaysRequestColumnDefs];
};

export const shouldLoadRatings = columnDefs => {
  if (!columnDefs) return false;

  const moodyColumn = columnDefs.find(item => item.field === COLUMNS.MOODY);
  const spColumn = columnDefs.find(item => item.field === COLUMNS.SP);

  return !!(moodyColumn || spColumn);
};
