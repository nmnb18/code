import { isAxeMatch } from './columnRenderer';

const shouldCheckStatus = (params, status) => {
  const { statusstr, recordtype } = params?.data;
  return statusstr && statusstr.toLowerCase() === status && recordtype === 'RFQ';
};

export const ROW_CLASS_RULES = {
  'row-bg-done': params => {
    if (!params?.data) return false;
    return shouldCheckStatus(params, 'done');
  },
  'row-bg-dealerrejected': params => {
    if (!params?.data) return false;
    return shouldCheckStatus(params, 'dealerrejected');
  },
  'row-bg-dealertimeout': params => {
    if (!params?.data) return false;
    return shouldCheckStatus(params, 'dealertimeout');
  },
  'row-bg-customertimeout': params => {
    if (!params?.data) return false;
    return shouldCheckStatus(params, 'customertimeout');
  },
  'row-bg-custrejected': params => {
    if (!params?.data) return false;
    return shouldCheckStatus(params, 'custrejected');
  },
  'row-axematch': params => {
    if (!params?.data) return false;
    return isAxeMatch(params?.data?.axematch);
  }
};
