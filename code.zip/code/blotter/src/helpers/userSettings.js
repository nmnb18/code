import * as userSettingsService from '~services/userSettingsService';
import { ADMIN_ROLE, FLOW_APP_NAME, RFQ_APP_NAME, APP_NAME } from '~helpers/globals';
import { mapEntitlementExtensionRules } from '~helpers/entitlement';
import { TOGGLE_FILTER_SIZE } from '~helpers/toggles';
import { getSessionData } from './flowAppSettingsUtils';
import cloneDeep from 'lodash/cloneDeep';

const checkForUsers = employeeInfo => !employeeInfo || !employeeInfo.users || !employeeInfo.users.length;

export const defaultFlowSettings = { RFQNotificationPopup: false };
export const defaultFlowUserSharedSettings = {
  LiveOnly: false,
  MeOnly: true,
  AxeDirectionMatch: false
};
export const defaultRFQPopupSharedSettings = {
  LiveOnly: true,
  MeOnly: false,
  AxeOnly: false,
  AxeDirectionMatch: false
};

export const defaultFlowFilterSharedSettings = {
  [TOGGLE_FILTER_SIZE]: false
};
export const defaultRFQPopupFilterSharedSettings = {
  [TOGGLE_FILTER_SIZE]: false
};

export const defaultViewSettings = {
  defaultView: 'Standard',
  defaultLastTimeForcedPopUpView: 0,
  defaultLastForcedPopUpView: ''
};

export const replaceSharedSettings = (destinationUserSettings, sourceUserSettings) => {
  const userSharedSettings = getUserSharedSettings(sourceUserSettings);
  const flowAppRef = getFlowAppFromSettings(destinationUserSettings);
  flowAppRef.SharedSettings = { ...userSharedSettings };
};

export const copySessionData = (destinationUserSettings, sourceUserSettings) => {
  const sourceFlowAppRef = getFlowAppFromSettings(sourceUserSettings);
  const destinationflowAppRef = getFlowAppFromSettings(destinationUserSettings);
  const sessionData = getSessionData(sourceFlowAppRef);
  destinationflowAppRef.sessionData = cloneDeep(sessionData);
};

export const getFlowAppFromSettings = userSettings =>
  userSettings && userSettings.Applications && userSettings.Applications.find(app => app.AppName === FLOW_APP_NAME);

export const updateRFQNotificationPopupSetting = (userSettings, appName, updatedRFQNotificationPopup) => {
  const flowApp = userSettingsService.getApplication(userSettings, appName);
  const flowSettings = flowApp.SharedSettings || defaultFlowUserSharedSettings;

  const updatedFlowSettings = { ...flowSettings, RFQNotificationPopup: updatedRFQNotificationPopup };
  const updatedFlowApp = { ...flowApp, SharedSettings: updatedFlowSettings };
  const updatedUserSettings = {
    ...userSettings,
    Applications: [...userSettings.Applications.filter(app => app.AppName !== appName), updatedFlowApp]
  };

  return updatedUserSettings;
};

export const getRFQNotificationPopup = (userSettings, appName) => {
  const flowApp = userSettingsService.getApplication(userSettings, appName);
  if (!flowApp) return false;

  const { SharedSettings } = flowApp;
  const isRFQNotificationToggleOnForBlotterUser = SharedSettings ? SharedSettings.RFQNotificationPopup : false;
  return isRFQNotificationToggleOnForBlotterUser;
};

export const validateEmployeeInfo = employeeInfo => employeeInfo && employeeInfo.users;

export const mapUserEntitlement = employeeInfo => {
  if (checkForUsers(employeeInfo)) return null;

  const {
    name,
    level3,
    primaryRole,
    entitlementExtensionRules,
    appoptions: { admin: isAdmin = false, developer: isDeveloper = false } = {}
  } = employeeInfo.users[0];

  return {
    name,
    level3,
    role: isAdmin ? ADMIN_ROLE : primaryRole,
    isAdmin,
    isDeveloper,
    primaryRole,
    entitlementExtensionRules: mapEntitlementExtensionRules(entitlementExtensionRules)
  };
};

const getUpdatedSharedSettings = (flowApp, source, sharedSettingsChanges) => {
  let updatedFlowApp = {};
  switch (source) {
    case RFQ_APP_NAME: {
      const rfqPopupSharedSettings = flowApp.RFQPopupSharedSettings || defaultRFQPopupSharedSettings;
      updatedFlowApp = { ...flowApp, RFQPopupSharedSettings: { ...rfqPopupSharedSettings, ...sharedSettingsChanges } };
      break;
    }
    case APP_NAME: {
      const flowUserSharedSettings = flowApp.SharedSettings || defaultFlowUserSharedSettings;
      updatedFlowApp = { ...flowApp, SharedSettings: { ...flowUserSharedSettings, ...sharedSettingsChanges } };
      break;
    }
    default:
      break;
  }
  return updatedFlowApp;
};

export const updateUserSharedSettings = (userSettings, appName, sharedSettingsChanges, source) => {
  const flowApp = userSettingsService.getApplication(userSettings, appName);
  const updatedFlowApp = getUpdatedSharedSettings(flowApp, source, sharedSettingsChanges);
  const updatedUserSettings = {
    ...userSettings,
    Applications: [...userSettings.Applications.filter(app => app.AppName !== appName), updatedFlowApp]
  };

  return updatedUserSettings;
};

export const getUserSharedSettings = userSettings => {
  const flowApp = getFlowAppFromSettings(userSettings);
  if (!flowApp) return null;

  const { SharedSettings } = flowApp;
  return { ...defaultFlowUserSharedSettings, ...SharedSettings };
};

export const getRFQPopupSharedSettings = userSettings => {
  const flowApp = getFlowAppFromSettings(userSettings);
  if (!flowApp) return null;

  const { RFQPopupSharedSettings } = flowApp;
  return { ...defaultRFQPopupSharedSettings, ...RFQPopupSharedSettings };
};

export const getFilterToggleSharedSettings = userSettings => {
  const flowApp = getFlowAppFromSettings(userSettings);
  if (!flowApp) return null;

  const { FilterSharedSettings } = flowApp;
  return { ...defaultFlowFilterSharedSettings, ...FilterSharedSettings };
};

export const getRFQPopupFilterToggleSharedSettings = userSettings => {
  const flowApp = getFlowAppFromSettings(userSettings);
  if (!flowApp) return null;

  const { RFQPopupFilterSharedSettings } = flowApp;
  return { ...defaultRFQPopupFilterSharedSettings, ...RFQPopupFilterSharedSettings };
};
