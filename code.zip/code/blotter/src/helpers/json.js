function isJson(text) {
  if (typeof text !== 'string') {
    return false;
  }

  try {
    JSON.parse(text);
    return true;
  } catch (_) {
    return false;
  }
}

export { isJson };
