import { isString } from '~helpers/dataTypes';

export const isEmpty = str => isString(str) && str === '';

export const isNotEmpty = str => isString(str) && str !== '';
