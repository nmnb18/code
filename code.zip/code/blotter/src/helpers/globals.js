export const APP_NAME = 'Flow';
export const FLOW_APP_NAME = 'Flow';
export const RFQ_APP_NAME = 'FlowRFQNotification';
export const ADMIN_ROLE = 'Admin';
export const APP_PLATFORM = 'Flow Navigator';

export const LIVE_ONLY = 'LIVE ONLY';
export const ME_ONLY = 'ME ONLY';
export const AXE_ONLY = 'AXE ONLY';
export const AXE_DIRECTION_MATCH = 'AXE DIRECTION MATCH';

export const postMessageActions = {
  closingBlotterApp: 'closingBlotterApp',
  switchingBlotterApp: 'SWITCHING_BLOTTER_APP',
  changesFound: 'CHANGES_FOUND',
  addInquiry: 'CONTAINER_ADD_INQUIRY',
  manageInquiry: 'CONTAINER_MANAGE_INQUIRY',
  addPortfolio: 'CONTAINER_ADD_PORTFOLIO',
  managePortfolio: 'CONTAINER_MANAGE_PORTFOLIO',
  assignUser: 'ASSIGN_USER',
  assignEntitlement: 'ASSIGN_ENTITLEMENT',
  assignImpersonated: 'ASSIGN_IMPERSONATED',
  assignUserSettings: 'ASSIGN_USERSETTINGS',
  assignRFQNotificationPopupState: 'ASSIGN_RFQ_NOTIFICATION_POPUP_STATE',
  childContentReady: 'CHILD_CONTENT_READY',
  webSocketConnectionOff: 'WS_CONNECTION_OFF',
  webSocketConnectionOn: 'WS_CONNECTION_ON',
  wsConnectionChange: 'WS_CONNECTION_CHANGE',
  updatedUserSettings: 'UPDATED_USER_SETTINGS',
  currentUserSettings: 'CURRENT_USER_SETTINGS',
  requestForUserSettings: 'REQUEST_FOR_USER_SETTINGS',
  reload: 'RELOAD'
};

export const BLOTTER_CONTAINER_URL = process.env.REACT_APP_BLOTTER_CONTAINER_URL;
export const CLOSING_BLOTTER_APP = 'closingBlotterApp';
export const CONTAINER_ADD_INQUIRY = 'CONTAINER_ADD_INQUIRY';
export const CONTAINER_ADD_INQUIRY_TITLE = 'Add Inquiry';
export const CONTAINER_ADD_INQUIRY_URL = process.env.REACT_APP_AXEJAM_URL + 'inquiry';
export const CONTAINER_MANAGE_INQUIRY = 'CONTAINER_MANAGE_INQUIRY';
export const CONTAINER_MANAGE_INQUIRY_TITLE = 'Manage Inquiry';
export const CONTAINER_MANAGE_INQUIRY_URL = process.env.REACT_APP_AXEJAM_URL + 'manageinquiries';
export const CONTAINER_ADD_PORTFOLIO = 'CONTAINER_ADD_PORTFOLIO';
export const CONTAINER_ADD_PORTFOLIO_TITLE = 'Add Portfolio';
export const CONTAINER_ADD_PORTFOLIO_URL = process.env.REACT_APP_AXEJAM_URL + 'addportfolio';
export const CONTAINER_MANAGE_PORTFOLIO = 'CONTAINER_MANAGE_PORTFOLIO';
export const CONTAINER_MANAGE_PORTFOLIO_TITLE = 'Manage Portfolio';
export const CONTAINER_MANAGE_PORTFOLIO_URL = process.env.REACT_APP_AXEJAM_URL + 'editportfolio';

export const CONTAINER_BOND_DASHBOARD = 'CONTAINER_BOND_DASHBOARD';
export const CONTAINER_BOND_DASHBOARD_TITLE = 'Bond Details';
export const CONTAINER_BOND_DASHBOARD_URL = process.env.REACT_APP_AXEJAM_URL + 'analyze';
export const CONTAINER_CUSTOMER_DASHBOARD = 'CONTAINER_CUSTOMER_DASHBOARD';
export const CONTAINER_CUSTOMER_DASHBOARD_TITLE = 'Customer Details';
export const CONTAINER_TICKER = 'CONTAINER_TICKER';
export const CONTAINER_TICKER_TITLE = 'Ticker Details';
export const CONTAINER_EDIT_INQUIRY = 'CONTAINER_EDIT_INQUIRY';
export const CONTAINER_EDIT_INQUIRY_TITLE = 'Edit Inquiry';
export const CONTAINER_EDIT_INQUIRY_URL = process.env.REACT_APP_AXEJAM_URL + 'inquiry';

export const FRAME_CONTAINER = 'frameContainer';
export const FRAME_TITLE = 'Flow';
export const FRAME_TITLE_ALT = 'Flow Blotter App';
export const JASPERSALES = 'jaspersales';
export const RSMITH = 'rsmith';
export const MAXIMIZED = 'maximized';
export const FLOW = process.env.REACT_APP_FLOW_BLOTTER_APP_TITLE;
export const AXE = process.env.REACT_APP_AXE_APP_TITLE;
export const CLIENT = process.env.REACT_APP_CLIENT_APP_TITLE;
export const JASPER = 'Jasper';
export const PROJECT_VERSION = process.env.REACT_APP_VERSION;

export const BREADCRUMB_FILTERS_MERGE_BREAKPOINT = process.env.REACT_APP_AG_GRID_BREADCRUMB_FILTERS_MERGE_BREAKPOINT;
export const ALLOWED_LEVEL3_FOR_INQUIRY =
  process.env.REACT_APP_ALLOWED_LEVEL3_FOR_INQUIRY === 'NONE' ? '' : process.env.REACT_APP_ALLOWED_LEVEL3_FOR_INQUIRY;
export const ALLOWED_PRIMARY_ROLES_FOR_INQUIRY =
  process.env.REACT_APP_ALLOWED_PRIMARY_ROLES_FOR_INQUIRY === 'NONE'
    ? ''
    : process.env.REACT_APP_ALLOWED_PRIMARY_ROLES_FOR_INQUIRY;

export const MADISON_ASSIST_LINK = process.env.REACT_APP_MADISON_ASSIST_LINK;
export const AG_GRID_AUTOSAVE_INTERVAL = process.env.REACT_APP_AG_GRID_AUTOSAVE_INTERVAL;
export const AG_GRID_FILTER_CHANGED_INTERVAL = process.env.REACT_APP_AG_GRID_FILTER_CHANGED_INTERVAL;

export const INITIAL_RFQ_REQUEST_END_RANGE = 15;
export const BLOOMBERG_TERMINAL_WINDOW = '1-BLOOMBERG';
export const BBG_SENDER = process.env.REACT_APP_BBGSENDER;
export const BBG_COMMAND_CONSOLE = 'BloombergCommandConsole';
export const BBG_SEND_KEYS = 'BBGSendKeys';

export const customRenderingColumns = {
  code: true,
  clientname: true,
  ticker: true,
  axeside: true,
  description: true,
  tooltipColumns: {
    clientname: true
  },
  priorityaxe: true
};
export const columnsHavingBloombergIBChat = ['clientname', 'custusername'];
export const columnsHavingBloombergDataCommands = ['code', 'description'];
export const columnsHavingBondDetailsOption = ['code', 'description'];
export const columnsHavingClientDetailsOption = ['clientname'];

export const simpleJsTypes = ['string', 'number', 'boolean', 'bigint', 'undefined', 'symbol'];
export const themes = [
  {
    label: 'Dark',
    value: 'dark'
  },
  {
    label: 'Light',
    value: 'light'
  }
];
export const DEFAULT_THEME = 'dark';
export const FORCE_DEFAULT_THEME_CLASS = 'forceDefaultTheme';
