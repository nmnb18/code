import { wait } from './promisify';

const fin = window.fin;

export const getFinApplication = async () => await fin.Application.getCurrent();

export const getFinFrame = async () => await fin.Frame.getCurrent();

export const getFinWindow = async () => await fin.Window.getCurrent();

export const getMainFinWindow = async () => {
  const finApp = await getFinApplication();
  return await finApp.getWindow();
};

export const getFinWindowState = async () => {
  const finWindow = await getFinWindow();
  return await getWindowState(finWindow);
};

export const getMainFinWindowBounds = async () => {
  const finWindow = await getMainFinWindow();
  return await finWindow.getBounds();
};

export const getWindowState = async finWindow => {
  if (!finWindow) return null;

  return await finWindow.getState();
};

export const createNewFinWindow = async windowOptions => await fin.Window.create(windowOptions);

export const getChildFinWindow = async name => {
  const currentApplication = await getFinApplication();
  const children = await currentApplication.getChildWindows();
  if (!children) return null;

  return children.find(child => child.identity.name === name);
};

export const getEnvironmentVariable = async name => await fin.System.getEnvironmentVariable(name);

export const openExternalBrowser = async (url, onSuccess, onError) => {
  fin.System.openUrlWithBrowser(url).then(onSuccess, onError);
};

/**
 * Function to force an openfin window to the front of all open windows.
 * In some scenarios autoshow and bringToFront do not work as expected.
 * Eg - if user minimizes main app and uses another app. Setting alwaysOnTop briefly does seem to work consistently.
 * @param {import('openfin/_v2/main').Window} finWindow
 * @returns {Promise<void>}
 */
export const forceFinWindowToFront = async finWindow => {
  console.log('rfqPopup forceFinWindowToFront() triggered');
  if (!finWindow) return;
  await finWindow.updateOptions({ alwaysOnTop: true });
  await wait(50);
  await finWindow.updateOptions({ alwaysOnTop: false });
};
