const FI_TECHNOLOGY = 'FI Technology';
const ROLE_TRADER = 'Trader';
export const tradingChoices = 'TradingDeskCoverageChoices';

export const uiEntitlementOptions = {
  VISIBLE: 'Visible',
  ME_ONLY_VISIBLE: 'MeOnlyVisible',
  RFQ_POPUP_VISIBLE: 'RFQPopUpVisible',
  INQUIRY_VISIBLE: 'InquiryVisible',
  PORTFOLIO_VISIBLE: 'PortfolioVisible',
  SEARCH_BAR_VISIBLE: 'SearchBarVisible',
  XIOS_POPUP_VISIBLE: 'XiosPopUpVisible'
};

export const isTechnologyUser = level3 => FI_TECHNOLOGY === level3;

export const isTechOrAdminUser = (isAdmin, level3) => isAdmin || isTechnologyUser(level3);

const getTradingDeskCoverageFromEntitlement = userEntitlement => {
  return userEntitlement.entitlementExtensionRules.find(entitlement => entitlement.appTopic === tradingChoices);
};

const checkUserEntitlement = userEntitlement =>
  !userEntitlement ||
  !userEntitlement.entitlementExtensionRules ||
  userEntitlement.entitlementExtensionRules.length === 0;

export const getUserEntitledTradingOptions = userEntitlement => {
  if (checkUserEntitlement(userEntitlement)) return null;

  const tradingDeskCoverage = getTradingDeskCoverageFromEntitlement(userEntitlement);
  if (!tradingDeskCoverage) return null;

  return { ...tradingDeskCoverage.uiInstruction, isMydeskOptionAvailable: isMydeskAvailable(tradingDeskCoverage) };
};

const isMydeskAvailable = tradingDeskCoverage => !!tradingDeskCoverage?.backendInstruction.MyDesk;

const getBackendInstructionString = backendInstruction => {
  const backendInstructionString = Object.keys(backendInstruction).map(key => {
    return `"${key.toLowerCase()}": '${backendInstruction[key]}'`;
  });
  return backendInstructionString.toString();
};

export const getMyDeskFromEntitlement = userEntitlement => {
  if (checkUserEntitlement(userEntitlement)) return null;
  const tradingDeskCoverage = getTradingDeskCoverageFromEntitlement(userEntitlement);
  if (!tradingDeskCoverage || !isMydeskAvailable(tradingDeskCoverage)) return null;
  return tradingDeskCoverage.backendInstruction.MyDesk;
};

export const getBackendInstructions = userEntitlement => {
  if (checkUserEntitlement(userEntitlement)) return null;
  const tradingDeskCoverage = getTradingDeskCoverageFromEntitlement(userEntitlement);
  if (!tradingDeskCoverage) return null;
  const { backendInstruction } = tradingDeskCoverage;
  if (!backendInstruction) return null;
  return getBackendInstructionString(backendInstruction);
};

export const checkForMyDeskOption = (userEntitledOptions, isMyDeskSelected) => {
  const { Visible, isMydeskOptionAvailable } = userEntitledOptions || {};
  return Visible ? isMyDeskSelected : isMydeskOptionAvailable;
};

export const checkForCoverageOption = userEntitledOptions => !!userEntitledOptions?.Visible;

export const showEntitlementOption = (entitlement, property) => {
  const userEntitledOptions = getUserEntitledTradingOptions(entitlement);
  return userEntitledOptions ? userEntitledOptions[property] : true;
};

const isOneOrUndefined = value => value === '1' || value === undefined;

const mapTradingExtRule = tradingExtRule => {
  const { uiInstruction } = tradingExtRule;
  const mappedUIInstructions = Object.fromEntries(
    Object.values(uiEntitlementOptions).map(property => [property, isOneOrUndefined(uiInstruction[property])])
  );

  return { ...tradingExtRule, uiInstruction: mappedUIInstructions };
};

export const mapEntitlementExtensionRules = entitlementExtensionRules => {
  const tradingExtRule = entitlementExtensionRules.find(extRule => extRule.appTopic === tradingChoices);
  if (!tradingExtRule) return entitlementExtensionRules;

  const otherExtRules = entitlementExtensionRules.filter(extRule => extRule.appTopic !== tradingChoices);
  return [...otherExtRules, mapTradingExtRule(tradingExtRule)];
};

export const userIsTrader = userEntitlement => {
  if (!userEntitlement) return false;
  return userEntitlement.primaryRole === ROLE_TRADER;
};
