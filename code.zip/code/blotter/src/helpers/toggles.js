import { FLOW_APP_NAME, RFQ_APP_NAME } from '~helpers/globals';

export const TOGGLE_LIVE_ONLY = 'LiveOnly';
export const TOGGLE_ME_ONLY = 'MeOnly';
export const TOGGLE_AXE_ONLY = 'AxeOnly';
export const TOGGLE_AXE_DIRECTION_MATCH = 'AxeDirectionMatch';
export const allToggles = [TOGGLE_AXE_ONLY, TOGGLE_ME_ONLY, TOGGLE_LIVE_ONLY, TOGGLE_AXE_DIRECTION_MATCH];

export const TOGGLE_FILTER_SIZE = 'SizeFormat';
export const allFilterToggles = [TOGGLE_FILTER_SIZE];

const validSources = [RFQ_APP_NAME, FLOW_APP_NAME];

export const validToggles = {
  [RFQ_APP_NAME]: [TOGGLE_LIVE_ONLY, TOGGLE_ME_ONLY, TOGGLE_AXE_ONLY, TOGGLE_AXE_DIRECTION_MATCH],
  [FLOW_APP_NAME]: [TOGGLE_LIVE_ONLY, TOGGLE_ME_ONLY, TOGGLE_AXE_DIRECTION_MATCH]
};

export const getUpdatedToggles = (payload, source) => {
  if (!validSources.includes(source)) {
    return {};
  } else {
    return Object.keys(payload)
      .filter(toggle => validToggles[source].includes(toggle))
      .reduce((updatedToggles, toggle) => {
        updatedToggles[toggle] = payload[toggle];
        return updatedToggles;
      }, {});
  }
};

export const toggleUsageActionAll = 'All';
export const availableToggles = [TOGGLE_AXE_ONLY, TOGGLE_ME_ONLY, TOGGLE_LIVE_ONLY, TOGGLE_AXE_DIRECTION_MATCH];
export const availableFilterToggles = [TOGGLE_FILTER_SIZE];

const togglesConfiguration = {
  [TOGGLE_LIVE_ONLY]: {
    label: 'LIVE ONLY',
    breadCrumbText: 'Live',
    resettable: true,
    hasBreadcrumb: true
  },
  [TOGGLE_ME_ONLY]: {
    label: 'ME ONLY',
    resettable: false,
    hasBreadcrumb: false
  },
  [TOGGLE_AXE_DIRECTION_MATCH]: {
    label: 'AXE DIRECTION MATCH',
    breadCrumbText: 'Axe Direction Match',
    resettable: true,
    hasBreadcrumb: true
  },
  [TOGGLE_AXE_ONLY]: {
    label: 'AXE ONLY',
    resettable: true,
    hasBreadcrumb: false
  }
};

export const filterTogglesConfiguration = {
  [TOGGLE_FILTER_SIZE]: {
    label: 'Size in thousands',
    breadCrumbText: 'Size (000s)',
    field: 'size',
    instructionField: 'denominatorInstruction',
    resettable: true,
    hasBreadcrumb: true
  }
};

export const filterToggleConfigurationMapping = {
  size: TOGGLE_FILTER_SIZE
};

const filterToggles = filterKey =>
  Object.entries(togglesConfiguration)
    .filter(([, toggleConfig]) => toggleConfig[filterKey])
    .map(([toggle]) => toggle);

export const getToggleLabel = toggleKey => togglesConfiguration[toggleKey].label;
export const getBreadcrumbTextForToggle = toggleKey => togglesConfiguration[toggleKey].breadCrumbText;
export const togglesWithBreadcrumb = filterToggles('hasBreadcrumb');
export const resettableToggles = filterToggles('resettable');

export const getTogglesToReset = toggles =>
  resettableToggles
    .filter(toggleKey => toggles[toggleKey])
    .reduce((togglesToUpdate, toggleKey) => ({ ...togglesToUpdate, [toggleKey]: false }), {});

export const filterValidToggles = toggles =>
  Object.keys(toggles)
    .filter(key => availableToggles.includes(key))
    .reduce((acc, curr) => ({ ...acc, [curr]: toggles[curr] }), {});

export const filterValidFilterToggles = toggles =>
  Object.keys(toggles)
    .filter(key => availableFilterToggles.includes(key))
    .reduce((acc, curr) => ({ ...acc, [curr]: toggles[curr] }), {});
