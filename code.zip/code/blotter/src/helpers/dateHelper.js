import { subDays, differenceInDays } from 'date-fns';
import { zonedTimeToUtc, format } from 'date-fns-tz';

export const DATE_FORMAT = 'MM/dd/yyyy';
export const TIME_FORMAT = 'HH:mm:ss';
export const DATE_FORMAT_LENGTH = 10;
export const today = new Date();
export const yesterday = subDays(today, 1);
export const START_STRING = 'start';
export const TWELVEMONTH_STRING = '12 months';
export const PLACEHOLDER_DATESTART = '10/20/2020';
export const PLACEHOLDER_DATEEND = '10/20/2024';
export const END_STRING = 'end';
export const ranges = [7, 30, 60, 90, 'Today', 'Yesterday', 'FYTD'];
export const TODAY_STRING = 'Today';
export const YESTERDAY_STRING = 'Yesterday';
export const FYTD_STRING = 'FYTD';
export const YEAR_STRING_LC = 'year';
export const ONE_STRING = '1';
export const MIN_STRING_LC = 'min';
export const MAX_STRING_LC = 'max';
export const DATE_COMPARE = {
  FIRST_AFTER_SECOND: 1,
  FIRST_BEFORE_SECOND: -1,
  FIRST_EQUAL_SECOND: 0
};
export const UTC_DATE_FORMAT = 'MM-dd-yyyy';
const TIME_FORMAT_REGEX = /HH:?mm:?ss/;
const TIMEZONE_SHORT_FORMAT = 'zzz';
const TIMEZONE_LONG_FORMAT = 'OOOO (zzzz)';

/**
 * Get a formatted full date and time for users current timezone.
 * @param {number | string | Date} ms The datetime you want to convert from.
 * @returns {string} eg: 03/26/2021 13:00:00 GMT+08:00 (China Standard Time).
 */
export const getFullDate = ms => {
  return format(new Date(ms), `${DATE_FORMAT} ${TIME_FORMAT} ${TIMEZONE_LONG_FORMAT}`);
};

// Format and return fiscal date depend on current year
export const getFiscalDate = currentYear => {
  return new Date(`12/01/${currentYear - 1}`);
};

// Calculate difference in two dates by days, endDate > satrtDate
export const getDifferenceInDatesByDays = (startDate, endDate) => {
  return differenceInDays(endDate, startDate);
};

// Formats the given Date object in output format
export const formatDateTime = (inputDate, outputFormat) => {
  try {
    return format(inputDate, outputFormat).toUpperCase();
  } catch (error) {
    return inputDate;
  }
};

// Convert and format the given date based on timezone
export const convertDateTimeToLocalTimezone = (value, optionalInfo, outputFormat) => {
  if (!value || !optionalInfo) return value;

  const { rfqcreatedate, rfqcreatetime, timezone, appendLocalTimezone } = optionalInfo;
  // If timezone is present, then we will create single date & time string and pass it to same funtion
  const newValue = rfqcreatedate && rfqcreatetime ? `${rfqcreatedate} ${rfqcreatetime}` : value;

  try {
    const timeUTCFormatted = zonedTimeToUtc(getDateTimeFromString(newValue), timezone);
    const localTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

    return format(timeUTCFormatted, appendTimezoneToValue(outputFormat, appendLocalTimezone), {
      timeZone: localTimezone
    }).toUpperCase();
  } catch (error) {
    return value;
  }
};

// Append timezone if the field is time and formatinstruction to append is true
export const appendTimezoneToValue = (outputFormat, appendLocalTimezone) => {
  return TIME_FORMAT_REGEX.test(outputFormat) && appendLocalTimezone
    ? `${outputFormat} ${TIMEZONE_SHORT_FORMAT}`
    : outputFormat;
};

// Accepts input value in the format yyyyMMdd or yyyy-MM-dd
export const getDateFromString = value => {
  try {
    const [, year, month, day] = value.match(/(\d{4})-?(\d{2})-?(\d{2})/);
    if (month > 12 || day > 31) {
      return value;
    }
    const tempDate = new Date(year, month - 1, day);
    return tempDate;
  } catch (error) {
    return value;
  }
};

// Accepts input value in the format HHmmss or HH:mm:ss or HH-mm-ss
export const getTimeFromString = value => {
  try {
    const [, hours, minutes, seconds] = value.match(/(\d{2})-?(\d{2})-?(\d{2})/);
    let tempDate = new Date();
    tempDate.setHours(hours);
    tempDate.setMinutes(minutes);
    tempDate.setSeconds(seconds);
    return tempDate;
  } catch (error) {
    return value;
  }
};

// Accepts input value in the format "yyyyMMdd HHmmss" or "yyyy-MM-dd HH:mm:ss" or "yyyy-MM-dd HH-mm-ss"
export const getDateTimeFromString = value => {
  try {
    const [, year, month, day, hours, minutes, seconds] = value.match(
      /(\d{4})[-, /]?(\d{2})[-, /]?(\d{2}) (\d{2})[-, :]?(\d{2})[-, :]?(\d{2})/
    );
    if (month > 12 || day > 31) {
      return value;
    }
    const tempDateStr = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}Z`;
    //const tempDate = new Date(year, month - 1, day, hours, minutes, seconds);
    return new Date(tempDateStr);
  } catch (error) {
    return value;
  }
};

// Accepts time in HHmmss and return HH:mm:ss
export const getFormattedTimeString = value => value.match(/(.{1,2})/g).join(':');

export const dateTimeToUTC = datetime => {
  if (!datetime) return '';
  return new Date(datetime).toUTCString();
};

export const formatUTCDate = (date, dateFormat) => format(date, dateFormat);

export const getUTCDate = (date, time) => dateTimeToUTC(`${date} ${time}`).replace(' GMT', '');;

export const formatTimeValue = value => {
  const valueLen = value.length;
  if (valueLen === 6) return value;
  
  if(valueLen > 6) {
    return value.substr(0, 6);
  }

  const remainingCharLen = 6 - valueLen;
  const appendString = '0'.repeat(remainingCharLen);
  return `${value}${appendString}`;
}