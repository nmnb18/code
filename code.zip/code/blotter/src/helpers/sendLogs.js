import { getEnvironmentName } from '~services/apiConfig';
import { wait } from './promisify';

const fin = window.fin;

export const sendLogAsync = async (onSuccess, onError = () => {}) => {
  const app = await fin.Application.getCurrent();
  try {
    await app.sendApplicationLog();
    onSuccess();
  } catch (error) {
    onError();
    console.error(error);
  }
};

const initialTimeoutSeconds = Number(process.env.REACT_APP_SETLOGNAME_INITIAL_TIMEOUT);
const subsequentTimeoutSeconds = Number(process.env.REACT_APP_SETLOGNAME_SUBSEQUENT_TIMEOUT);

export const setLogName = async (username, timeout = initialTimeoutSeconds) => {
  const environmentName = getEnvironmentName();
  const application = await fin.Application.getCurrent();

  await wait(timeout * 1000);
  try {
    await application.setAppLogUsername(`${username}_${environmentName}`);
    console.log(`Username was set to ${username}_${environmentName} for logging purposes`);
  } catch (err) {
    if (err.message.includes('AppLogger is not registered')) {
      console.log(`AppLogger not ready yet. Retrying in ${subsequentTimeoutSeconds} seconds...`);
      setLogName(username, subsequentTimeoutSeconds);
    } else {
      console.error(err);
    }
  }
};
