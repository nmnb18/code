/**
 * A promise wrapper around settimeout - use in async functions or when chaining thens.
 * @param {number} ms
 * @returns {Promise<void>}
 */
export const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
