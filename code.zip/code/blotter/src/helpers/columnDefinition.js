export const removeColumn = (sourceColumns, colId) =>
  sourceColumns.filter(sourceColumn => sourceColumn.colId !== colId);

export const removeRepeatedColumn = (sourceColumns, repeatedColumns) => {
  const sourceColumnsKey = sourceColumns.map(item => item.field);
  const repeatedColumnsKey = repeatedColumns.map(item => item.field);
  const nonRepeatedSourceKeys = sourceColumnsKey.filter(sourcekey => !repeatedColumnsKey.includes(sourcekey));
  return sourceColumns.filter(sourceColumn => nonRepeatedSourceKeys.includes(sourceColumn.field));
};
