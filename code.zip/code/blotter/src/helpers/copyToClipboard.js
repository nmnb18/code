import { shapeDataAndHeaders } from '~helpers/exportHelper';

// This array of key/value pair are Join field pairs. Currently Column Dictionary doesn't guide
// which field should be treated as primary and which one to be secondary.
const FIELD_JOINER_LOOKUP = [['rfqbbgask', 'rfqbbgbid']];

export const createHtmlTable = (headers, data) => {
  if (!headers.length || !data.length) {
    return '';
  }
  const tableHeader = `<tr>${headers.map(headerItem => `<th>${headerItem}</th>`)}</tr>`;
  const tableBody = `<tbody>${data.map(
    dataItem => `<tr>${dataItem.map(item => `<td>${item || ''}</td>`)}</tr>`
  )}</tbody>`;
  const table = `<table>${tableHeader}${tableBody}</table>`;
  return table.replace(/,/g, '');
};

export const copyHtmlToClipboard = ({ headers, data }) => {
  if (data && data.length > 0) {
    const htmlData = createHtmlTable(headers, data);
    const stringData = createSingleLineString(headers, data);
    function listener(e) {
      e.clipboardData.setData('text/html', htmlData);
      e.clipboardData.setData('text/plain', stringData);
      e.preventDefault();
    }
    document.addEventListener('copy', listener);
    document.execCommand('copy');
    document.removeEventListener('copy', listener);
  }
};

//TODO: Headers should be included based on Template Setting configuration
const createSingleLineString = (headers, data) => {
  const shapedData = shapeDataAndHeaders(headers, data)
    .map(row => row.join('   '))
    .join('\r\n');
  return `\r\n${shapedData}`;
};

export const getHeaderFieldsForCopy = headers => {
  const fieldJoinerLookupMap = new Map(FIELD_JOINER_LOOKUP);
  let headerFieldsCopy = headers.map(header => header.field);
  let headersCopy = headers;
  fieldJoinerLookupMap.forEach((value, key) => {
    if (headerFieldsCopy.includes(key)) {
      // Find location of key and value in HeaderField
      const keyIndex = headerFieldsCopy.indexOf(key);
      const valueIndex = headerFieldsCopy.indexOf(value);
      let joinHeader1 = headersCopy[keyIndex];
      let joinHeader2 = headersCopy[valueIndex];
      joinHeader1.headerName = `${joinHeader1.headerName}-${joinHeader2.headerName}`;
      joinHeader1.width = joinHeader1.headerName.length + joinHeader2.headerName.length + 1;
      headersCopy.splice(keyIndex, 1, joinHeader1);
      headersCopy.splice(valueIndex, 1);
    }
  });
  return headersCopy;
};
