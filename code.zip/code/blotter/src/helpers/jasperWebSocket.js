import { jasperWs } from '~services/apiConfig';
import {
  FILTER_MODEL_SET,
  FILTER_MODEL_DYNAMIC_SET,
  FILTER_MODEL_NUMBER,
  FILTER_MODEL_DATE
} from '~constants/filterModelTypes';
import { defaultFilterRange } from '~helpers/proxyService';
import { RFQ_APP_NAME } from '~helpers/globals';
import { SELECTALL_CHECKBOX_STATE } from '~helpers/exportHelper';
import { COLUMNS } from '~helpers/columnStyles';
import {
  getUserEntitledTradingOptions,
  checkForCoverageOption,
  showEntitlementOption,
  uiEntitlementOptions,
  checkForMyDeskOption,
  getBackendInstructions
} from './entitlement';
import { replacementSortingConfiguration } from './sort';
import { DATE_FORMAT, today, START_STRING, END_STRING } from './dateHelper';
import { format } from 'date-fns';
import { hasItems } from 'flow-navigator-shared/dist/array';
import { isNotEmpty } from '~helpers/string';
import { getDateTimeString } from './dateFormatter';
import { ticks2dec, tickRange } from './decimalToTicks';

export const WS_ACTIONS = {
  SUBSCRIBE: '"subscribe"',
  UNSUBSCRIBE: '"unsubscribe"',
  SOW: '"sow"',
  SUBSCRIBE_MULTI: '"subscribe_multi"',
  UNSUBSCRIBE_RANGE: '"unsubscribe_range"',
  UNSUBSCRIBE_MULTI: '"unsubscribe_multi"'
};

export const UNSUBSCRIBE_RANGE = 'RANGE';
export const UNSUBSCRIBE_MULTI = 'MULTI';

export const unsubscribeTargetActions = {
  [UNSUBSCRIBE_RANGE]: WS_ACTIONS.UNSUBSCRIBE_RANGE,
  [UNSUBSCRIBE_MULTI]: WS_ACTIONS.UNSUBSCRIBE_MULTI
};

export const defaultMainGridId = 'flowBlotter';
export const defaultRfqGridId = 'rfqNotification';
export const exportDataSourceId = 'exportDataSource';
export const defaultMultiFilterFlowId = 'multiFilterFlowBlotter';
export const defaultMultiFilterRfqGridId = 'multiFilterRfqNotification';
export const defaultFlowBlotterMiniTicketPanelId = 'flowBlotterMiniTicketPanel';

export const defaultOrderBy = {
  [defaultMainGridId]: [
    '/recordtypesortint desc',
    '/transactioncreatedate_forsort desc',
    '/rfqclosed asc',
    '/transactioncreatetime_forsort desc'
  ],
  [defaultRfqGridId]: ['/transactioncreatedate_forsort desc', '/rfqclosed asc', '/transactioncreatetime_forsort desc'],
  [exportDataSourceId]: [
    '/recordtypesortint desc',
    '/transactioncreatedate_forsort desc',
    '/rfqclosed asc',
    '/transactioncreatetime_forsort desc'
  ]
};

const CONTAINS_START_END_DATE = 2;
const NOT_LIVE_RFQ_TRADE_STATUSES = ['Passed'];
const NOT_LIVE_INQUIRY_STATUSES = ['Trader rejected', 'Expired', 'Filled', 'Cancelled', 'Not Routed'];

const REFERENCE_FIELDS_KEYS = {
  time_utc: 'transactioncreatedatetime_utc',
  rfqdealvalue_32: 'rfqdealvalue',
  adjustedrfqdealvalue_32: 'adjustedrfqdealvalue'
};
export const getRequestCommand = ({
  subscriptionInstanceId,
  firstRow,
  lastRow,
  columnDefs,
  filterList = [],
  sortList = [],
  toggles,
  newCriteria,
  impersonatingUser,
  gridId,
  appName = RFQ_APP_NAME,
  isCoverageSelected,
  isMyDeskSelected,
  entitlement
}) => {
  const totalsFlag = firstRow === defaultFilterRange.firstRow && lastRow === defaultFilterRange.lastRow;
  const fields = columnDefs.map(({ field }) => field).join(',');
  const paramFields = `"fields":"${fields}",`;
  const paramTotals = `"totals":${totalsFlag},`;
  const paramFirstRow = `"vpFirstRow":${firstRow},`;
  const paramLastRow = `"vpLastRow":${lastRow},`;
  const paramCriteriaChanged = `"newCriteria":${newCriteria}`;
  const paramAppName = `"columnDictionary":"${appName}"`;
  const paramImpersonating = impersonatingUser ? `,"impersonating":"${impersonatingUser}"` : '';
  const paramFilter = parseFilterMessage(filterList, toggles, null, gridId);
  const paramSort = parseSortMessage(sortList, gridId);

  // user entitlement options
  const userEntitledOptions = getUserEntitledTradingOptions(entitlement);
  const paramCoverage = checkForCoverageOption(userEntitledOptions) ? `,"coverage":${!!isCoverageSelected}` : '';
  const paramDesk = checkForMyDeskOption(userEntitledOptions, isMyDeskSelected)
    ? `,${getBackendInstructions(entitlement)}`
    : '';

  const meOnlyOptionAvailable = showEntitlementOption(entitlement, uiEntitlementOptions.ME_ONLY_VISIBLE);

  const paramMeOnly = `"meOnly":${meOnlyOptionAvailable && !!toggles.MeOnly}`;

  const payload = `{${paramFields}${paramTotals}${paramFirstRow}${paramLastRow}${paramFilter}${paramSort},${paramCriteriaChanged}${paramImpersonating},${paramMeOnly},${paramAppName}${paramCoverage}${paramDesk}}`;
  const clientInstance = `"${subscriptionInstanceId}"`;
  const clientSubscriptionId = `"${getSubscriptionInstanceRequestId(subscriptionInstanceId)}"`;

  return `[${WS_ACTIONS.SUBSCRIBE},${jasperWs.topic},${clientInstance},${clientSubscriptionId},${payload}]`;
};

export const getUnsubscribeRequestCommand = (subscriptionInstanceId, target) => {
  if (!subscriptionInstanceId) return null;

  const unsubscribeCommand = !target ? WS_ACTIONS.UNSUBSCRIBE : unsubscribeTargetActions[target];
  const clientInstance = `"${subscriptionInstanceId}"`;
  const clientSubscriptionId = `"${getSubscriptionInstanceRequestId(subscriptionInstanceId)}"`;

  return `[${unsubscribeCommand},${jasperWs.topic},${clientInstance},${clientSubscriptionId},{}]`;
};

export const getExportRequestCommand = ({
  subscriptionInstanceId,
  firstRow,
  lastRow,
  columnDefs,
  filterList = [],
  sortList = [],
  toggles,
  newCriteria,
  impersonatingUser,
  gridId,
  selectAllCheckboxStatus,
  selectedRowsValue,
  isCoverageSelected,
  isMyDeskSelected,
  entitlement
}) => {
  const totalsFlag = false;
  const fields = columnDefs.map(({ field }) => field).join(',');
  const paramFields = `"fields":"${fields}",`;
  const paramTotals = `"totals":${totalsFlag},`;
  const paramFirstRow = `"vpFirstRow":${firstRow},`;
  const paramLastRow = `"vpLastRow":${lastRow},`;
  const paramCriteriaChanged = `"newCriteria":${newCriteria}`;
  const paramImpersonating = impersonatingUser ? `,"impersonating":"${impersonatingUser}"` : '';

  // if selectAllCheckboxStatus is DASH then we need to add the key_id exclude filter
  const excludedKeyIds = selectAllCheckboxStatus === SELECTALL_CHECKBOX_STATE.DASH ? selectedRowsValue : null;
  const paramFilter = parseFilterMessage(filterList, toggles, excludedKeyIds, gridId);
  const paramSort = parseSortMessage(sortList, gridId);

  // if selectAllCheckboxStatus is PARTIAL then we need to add sowKeys parameter
  const paramSowKeys =
    selectAllCheckboxStatus === SELECTALL_CHECKBOX_STATE.PARTIAL ? `,"sowKeys":"${selectedRowsValue.join(',')}"` : '';

  const userEntitledOptions = getUserEntitledTradingOptions(entitlement);
  const paramCoverage = checkForCoverageOption(userEntitledOptions) ? `,"coverage":${!!isCoverageSelected}` : '';
  const paramDesk = checkForMyDeskOption(userEntitledOptions, isMyDeskSelected)
    ? `,${getBackendInstructions(entitlement)}`
    : '';
  const meOnlyOptionAvailable = showEntitlementOption(entitlement, uiEntitlementOptions.ME_ONLY_VISIBLE);
  const paramMeOnly = `"meOnly":${meOnlyOptionAvailable && !!toggles.MeOnly}`;

  const payload = `{${paramFields}${paramTotals}${paramFirstRow}${paramLastRow}${paramFilter}${paramSort},${paramCriteriaChanged}${paramImpersonating},${paramMeOnly}${paramSowKeys}${paramCoverage}${paramDesk}}`;
  const clientInstance = `"${subscriptionInstanceId}"`;
  const clientSubscriptionId = `"${getSubscriptionInstanceRequestId(subscriptionInstanceId)}"`;
  return `[${WS_ACTIONS.SOW},${jasperWs.topic},${clientInstance},${clientSubscriptionId},${payload}]`;
};

export const getMultiFilterRequestCommand = ({
  subscriptionInstanceId,
  multiFilterFields = [],
  filterList = [],
  toggles,
  impersonatingUser,
  gridId,
  appName = RFQ_APP_NAME,
  isCoverageSelected,
  isMyDeskSelected,
  entitlement
}) => {
  const paramFields = `"fields":${JSON.stringify(multiFilterFields)},`;
  const paramFilter = parseFilterMessage(filterList, toggles, null, gridId);
  const paramAppName = `"columnDictionary":"${appName}"`;
  const paramImpersonating = impersonatingUser ? `,"impersonating":"${impersonatingUser}"` : '';

  const userEntitledOptions = getUserEntitledTradingOptions(entitlement);
  const paramCoverage = checkForCoverageOption(userEntitledOptions) ? `,"coverage":${isCoverageSelected}` : '';
  const paramDesk = checkForMyDeskOption(userEntitledOptions, isMyDeskSelected)
    ? `,${getBackendInstructions(entitlement)}`
    : '';
  const meOnlyOptionAvailable = showEntitlementOption(entitlement, uiEntitlementOptions.ME_ONLY_VISIBLE);
  const paramMeOnly = `"meOnly":${meOnlyOptionAvailable && !!toggles.MeOnly}`;

  const payload = `{${paramFields}${paramFilter}${paramImpersonating},${paramMeOnly},${paramAppName}${paramCoverage}${paramDesk}}`;
  const clientInstance = `"${subscriptionInstanceId}"`;
  const clientSubscriptionId = `"${getSubscriptionInstanceRequestId(subscriptionInstanceId)}"`;

  return `[${WS_ACTIONS.SUBSCRIBE_MULTI},${jasperWs.topic},${clientInstance},${clientSubscriptionId},${payload}]`;
};

/**
 * Create an id for websocket instance connection.
 *
 * @param {Object} params
 * @param {string=} params.prefix - Used to allow multiple instances of same 'app environment' to run on same machine.
 * @param {string} params.environment - Which environment this is - LOCAL, PRODUS, PRODUK, etc.
 * @param {string} params.signedInUser - User name of signed in user.
 * @param {string} params.flowNavigatorUser - Impersonated user or same as signedInUser if not impersonating.
 * @param {string} params.computerId - Id of current computer.
 * @param {string} params.appId - Name of the app.
 * @param {string} params.gridId - Name of the specific grid.
 * @returns {string|null} Returns a string to use.
 */
export const getSubscriptionInstanceId = ({
  prefix,
  environment,
  signedInUser,
  flowNavigatorUser,
  computerId,
  appId,
  gridId
}) => {
  if (environment && signedInUser && flowNavigatorUser && computerId) {
    return `${
      prefix ? prefix + '_' : ''
    }${environment}_${signedInUser}_${flowNavigatorUser}_${computerId}_${appId}_${gridId}`;
  }
  return null;
};

export const getSubscriptionInstanceRequestId = subscriptionInstance =>
  `${subscriptionInstance}_${Date.now().toString()}`;

export const getConnectionStatus = ampsConnected => {
  if (typeof ampsConnected !== 'boolean') return '';
  return ampsConnected ? 'on' : 'off';
};

const parseSortMessage = (sortList, gridId) => {
  const defaultOrderByConfiguration = defaultOrderBy[gridId] ? defaultOrderBy[gridId] : [];

  const sortingParams = [];
  if (sortList && sortList.length > 0) {
    sortList.forEach(oSort => {
      const { colId, sort } = oSort;
      if (colId && sort) {
        const paramColId = replacementSortingConfiguration[colId] || colId;
        sortingParams.push(`/${paramColId} ${sort}`);
      }
    });
  }

  // Custom sorting configuration for Flow blotter grid
  if (gridId === defaultMainGridId) {
    const defaultOrderByColumns = defaultOrderByConfiguration.map(col => col.replace(/\/| desc| asc/gi, ''));
    const selectedSortingColumns = sortingParams.map(col => col.replace(/\/| desc| asc/gi, ''));

    // Validate that each default orderBy column was not selected by the user
    defaultOrderByColumns.forEach(defaultOrderByCol => {
      const isDefaultColSelected = selectedSortingColumns.includes(defaultOrderByCol);
      // if default sorting column was not selected
      if (!isDefaultColSelected) {
        // find its default configuration
        const defaultColumnConfiguration = defaultOrderByConfiguration.find(conf => conf.includes(defaultOrderByCol));
        // add it to the sortingParams array
        if (defaultColumnConfiguration) sortingParams.push(defaultColumnConfiguration);
      }
    });
  } else {
    sortingParams.push(...defaultOrderByConfiguration);
  }

  return ',"orderBy":"' + sortingParams.join() + '"';
};

const getFilterByField = (filterList, field) => {
  if (!filterList) return null;

  return filterList.find(filterItem => filterItem.field === field);
};

const hasRecordTypeFilter = (filters, filterArr) => {
  if (!filters || !filters.length) return false;

  return filters.some(v => filterArr.includes(v));
};

const AND = ' AND ';

const parseFilterMessage = (filterList, toggles, excludedKeyIds, gridId) => {
  const { LiveOnly, AxeDirectionMatch } = toggles;
  const filterMessageFromFilterListWithAnd = mapToAmpsFilter(filterList)
    .filter(Boolean)
    .join(AND);

  let toggleOnLiveMessage = null;
  if (LiveOnly) {
    let statusArr = [];

    if (gridId === defaultRfqGridId) {
      statusArr = [...NOT_LIVE_RFQ_TRADE_STATUSES];
    } else {
      const recordTypeFilter = getFilterByField(filterList, 'recordtype');

      if (recordTypeFilter) {
        const hasRFQOrTradesFilter = hasRecordTypeFilter(recordTypeFilter.filter, ['RFQ', 'Trade']);
        const hasInquiriesFilter = hasRecordTypeFilter(recordTypeFilter.filter, ['Inquiry']);

        if (hasInquiriesFilter) {
          if (hasRFQOrTradesFilter) {
            // Inquiry + RFQ/Trades = All
            statusArr = [...NOT_LIVE_RFQ_TRADE_STATUSES, ...NOT_LIVE_INQUIRY_STATUSES];
          } else {
            // Inquiry
            statusArr = [...NOT_LIVE_INQUIRY_STATUSES];
          }
        } else {
          // RFQ/Trade
          statusArr = [...NOT_LIVE_RFQ_TRADE_STATUSES];
        }
      } else {
        // ALL = RFQ/Trade/Inquiry
        statusArr = [...NOT_LIVE_RFQ_TRADE_STATUSES, ...NOT_LIVE_INQUIRY_STATUSES];
      }
    }

    toggleOnLiveMessage = `(/rfqclosed=0 OR (/rfqclosed_delay IS NULL AND /rfqclosed=1)) AND (/statusstr NOT IN (${statusArr
      .map(s => `'${s}'`)
      .join(',')}))`;
  } else if ((gridId === defaultRfqGridId || gridId === defaultMultiFilterRfqGridId) && !LiveOnly) {
    const todayDate = format(today, DATE_FORMAT);
    toggleOnLiveMessage = `(/transactioncreatedatetime_utc BETWEEN '${getDateTimeString(
      todayDate,
      null,
      START_STRING
    )}' AND '${getDateTimeString(todayDate, null, END_STRING)}')`;
  }

  let axeDirectionMatchMessage = null;
  if (AxeDirectionMatch) {
    axeDirectionMatchMessage = '(/axematch=1)';
  }

  let excludedKeyIdsMessage = null;
  if (excludedKeyIds) {
    const formattedExcludedKeyIds = excludedKeyIds.map(keyId => `'${keyId}'`).join(',');
    excludedKeyIdsMessage = `(/key_id NOT IN (${formattedExcludedKeyIds}))`;
  }

  let rfqRecordTypeMessage = null;
  if (gridId === defaultRfqGridId) {
    rfqRecordTypeMessage = `(/recordtype IN('RFQ', 'Inquiry')) AND ((/mymarketidformatted IN('TWEB','MAX','BBG','BONDVIS','PIL')) )`;
  }

  const cleanedUpArrayListFromExtraFilters = [
    filterMessageFromFilterListWithAnd,
    toggleOnLiveMessage,
    excludedKeyIdsMessage,
    rfqRecordTypeMessage,
    axeDirectionMatchMessage
  ]
    .filter(element => element !== null && element !== '')
    .join(AND);

  return `"filter": "${cleanedUpArrayListFromExtraFilters}"`;
};

const BLANKS_VALUE = '';
const BACKSLASH = String.fromCharCode(92);

const isNumberFilter = filterType => filterType === FILTER_MODEL_NUMBER;
const isDateFilter = filterType => filterType === FILTER_MODEL_DATE;
const isSetFilter = filterType => filterType === FILTER_MODEL_SET;
const isDynamicSetFilter = filterType => filterType === FILTER_MODEL_DYNAMIC_SET;

const sanitizeArrayFiltersForAmps = filterOptionArray =>
  filterOptionArray.filter(Boolean).map(option => option.replaceAll("'", BACKSLASH + BACKSLASH + "'"));

const generateAmpsInFilter = (field, filterValuesArray) => {
  const hasBlanks = filterValuesArray.includes(BLANKS_VALUE);
  return `((/${field} IN(${`'${sanitizeArrayFiltersForAmps(filterValuesArray).join("','")}'`})) ${
    hasBlanks ? ' OR (/' + field + ' IS NULL)' : ''
  })`;
};

const mapToAmpsFilter = filterList => {
  let dateFilter, timeFilter;

  let ampsFilter = filterList.map(element => {
    if (isSetFilter(element.filterType) && hasItems(element.filter)) {
      //The filter will be a IN value
      if (element.field === COLUMNS.PRIORITY_AXE) {
        const priorityaxeFilters = element.filter
          .map(priorityAxe =>
            priorityAxe === 'NO'
              ? `(/${element.field} IN('NO', 'NO_AXE') OR /${element.field} is NULL)`
              : `(/${element.field} IN('${priorityAxe}'))`
          )
          .join(' OR ');
        return priorityaxeFilters;
      }

      const setFilter = generateAmpsInFilter(element.field, element.filter);
      return setFilter;
    } else if (
      isDynamicSetFilter(element.filterType) &&
      (hasItems(element.arrayFilter) || isNotEmpty(element.textFilter))
    ) {
      const { field, arrayFilter, textFilter } = element;
      const hasArrayFilter = hasItems(arrayFilter);
      const hasTextFilter = Boolean(textFilter);
      const ampsFilter = [];

      if (hasTextFilter) {
        ampsFilter.push(`(INSTR_I(/${field}, '${textFilter}') != 0)`);
      }

      if (hasArrayFilter) {
        ampsFilter.push(generateAmpsInFilter(field, arrayFilter));
      }

      return hasItems(ampsFilter) ? `(${ampsFilter.join(' OR ')})` : '';
    } else if (element.filter && element.filter.length === CONTAINS_START_END_DATE) {
      if (isNumberFilter(element.filterType)) {
        //The filter is a direct number value
        let { type, field, filter } = element;
        const value = filter[0];

        if (REFERENCE_FIELDS_KEYS[field]) {
          field = REFERENCE_FIELDS_KEYS[field];
        }

        if (String(value).includes('-')) {
          const rawDecimal = ticks2dec(value);
          const [lower, upper] = tickRange(rawDecimal);
          return `(/${field} BETWEEN '${lower}' AND '${upper}')`;
        } else if (isNotEmpty(type)) {
          return `(/${field} ${type} ${value})`;
        } else {
          return `(/${field} = ${value})`;
        }
      } else if (isDateFilter(element.filterType)) {
        dateFilter = element;
        return '';
      } else if (element.filterType === 'text' && element.headerName === 'Time') {
        timeFilter = element;
        return '';
      } else {
        return `(INSTR_I(/${element.field}, '${element.filter[0]}') != 0)`;
      }
    } else {
      return '';
    }
  });

  if (dateFilter && timeFilter) {
    const datetimeFilterString = `(/${dateFilter.field} BETWEEN '${getDateTimeString(
      dateFilter.filter[0],
      timeFilter.filter[0],
      START_STRING
    )}' AND '${getDateTimeString(dateFilter.filter[1], timeFilter.filter[0], END_STRING)}')`;
    ampsFilter = [...ampsFilter, datetimeFilterString];
  } else if (dateFilter && !timeFilter) {
    let dateFilterString = '';
    if (dateFilter.type && dateFilter.type !== '') {
      if (dateFilter.filter.length === CONTAINS_START_END_DATE) {
        dateFilterString = `(/${dateFilter.field} BETWEEN '${getDateTimeString(
          dateFilter.filter[0],
          null,
          START_STRING
        )}' AND '${getDateTimeString(dateFilter.filter[1], null, END_STRING)}')`;
      } else {
        dateFilterString = `(/${dateFilter.field} ${dateFilter.type} '${dateFilter.filter[0]}')`;
      }
    } else {
      if (dateFilter.filter.length === CONTAINS_START_END_DATE) {
        dateFilterString = `(/${dateFilter.field} BETWEEN '${getDateTimeString(
          dateFilter.filter[0],
          null,
          START_STRING
        )}' AND '${getDateTimeString(dateFilter.filter[1], null, END_STRING)}')`;
      } else {
        dateFilterString = `(/${dateFilter.field} = '${dateFilter.filter[0]}')`;
      }
    }
    ampsFilter = [...ampsFilter, dateFilterString];
  } else if (!dateFilter && timeFilter) {
    const timeFilterString = `(INSTR_I(/${REFERENCE_FIELDS_KEYS[timeFilter.field]}, '${getDateTimeString(
      null,
      timeFilter.filter[0],
      ''
    )}') != 0)`;
    ampsFilter = [...ampsFilter, timeFilterString];
  }

  return ampsFilter;
};

const MAX_REQUEST_SIZE = process.env.REACT_APP_JASPER_WS_MAX_REQUEST_SIZE;

export const isWSRequestSizeOk = request => !!(request.length <= parseInt(MAX_REQUEST_SIZE));
