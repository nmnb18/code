export const getClosestValue = (option, availableOptions) => {
  if (!availableOptions || availableOptions.length === 0) return;
  const exactMatch = availableOptions.find(o => o.toLowerCase() === option);
  if (exactMatch) return exactMatch;
  const partialMatch = availableOptions.filter(o => o.toLowerCase().includes(option));

  return partialMatch;
};

export const parseSetValue = (value, availableOptions) => {
  if (!availableOptions || availableOptions.length === 0) return;
  const options = value.split(',').map(o => o.trim().toLowerCase());
  const closestMatchs = options.map(o => getClosestValue(o, availableOptions)).flat();
  const validOptions = [...new Set(closestMatchs.filter(Boolean))];

  return validOptions;
};
