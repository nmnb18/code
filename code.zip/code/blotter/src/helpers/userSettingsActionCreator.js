import { userSettingsSyncTopic } from '~services/openfinConfig';
import { RFQ_APP_NAME } from '~helpers/globals';
import { iabPublish } from '~services/openfinService';

export const dispatchAction = action =>
  iabPublish({
    topic: userSettingsSyncTopic,
    message: { ...action, origin: RFQ_APP_NAME },
    logLabel: userSettingsSyncTopic
  });

export const actionTypes = {
  SWITCH_VIEW: 'SWITCH_VIEW',
  CREATE_VIEW: 'CREATE_VIEW',
  UPDATE_VIEW: 'UPDATE_VIEW',
  DELETE_VIEW: 'DELETE_VIEW',
  EDIT_COLUMNS: 'EDIT_COLUMNS',
  EDIT_COLUMN_STATE_AND_SORT: 'EDIT_COLUMN_STATE_AND_SORT',
  TOGGLE_RFQ_POPUP: 'TOGGLE_RFQ_POPUP',
  UPDATE_TOGGLES: 'UPDATE_TOGGLES',
  UPDATE_FILTER_TOGGLES: 'UPDATE_FILTER_TOGGLES',
  UPDATE_TRADING_DESK_COVERAGE_CHOICES: 'UPDATE_TRADING_DESK_COVERAGE_CHOICES',
  DELETE_TRADING_DESK_COVERAGE_CHOICES: 'DELETE_TRADING_DESK_COVERAGE_CHOICES',
  UPDATE_DEFAULT_COPY_TEMPLATE: 'UPDATE_DEFAULT_COPY_TEMPLATE',
  CREATE_COPY_TEMPLATE: 'CREATE_COPY_TEMPLATE',
  UPDATE_COPY_TEMPLATE: 'UPDATE_COPY_TEMPLATE',
  DELETE_COPY_TEMPLATE: 'DELETE_COPY_TEMPLATE'
};

const doUpdateTradingDeskCoverageChoices = payload => ({
  type: actionTypes.UPDATE_TRADING_DESK_COVERAGE_CHOICES,
  reload: false,
  syncWithServer: true,
  updateImpersonatedUserProfile: true,
  payload
});

const doDeleteTradingDeskCoverageChoices = payload => ({
  type: actionTypes.DELETE_TRADING_DESK_COVERAGE_CHOICES,
  reload: false,
  syncWithServer: true,
  updateImpersonatedUserProfile: true,
  payload
});

const doSwitchView = payload => ({
  type: actionTypes.SWITCH_VIEW,
  reload: false,
  syncWithServer: false,
  updateImpersonatedUserProfile: false,
  payload
});

const doCreateView = payload => ({
  type: actionTypes.CREATE_VIEW,
  reload: payload.reload ?? true,
  syncWithServer: true,
  updateImpersonatedUserProfile: true,
  payload
});

const doUpdateView = payload => ({
  type: actionTypes.UPDATE_VIEW,
  reload: payload.reload ?? true,
  syncWithServer: true,
  updateImpersonatedUserProfile: true,
  payload
});

const doDeleteView = payload => ({
  type: actionTypes.DELETE_VIEW,
  reload: true,
  syncWithServer: true,
  updateImpersonatedUserProfile: true,
  payload
});

const doColumnChooserSave = payload => ({
  type: actionTypes.EDIT_COLUMNS,
  reload: true,
  syncWithServer: true,
  updateImpersonatedUserProfile: true,
  payload
});

const doColumnStateAndSortSave = payload => ({
  type: actionTypes.EDIT_COLUMN_STATE_AND_SORT,
  reload: false,
  syncWithServer: true,
  updateImpersonatedUserProfile: true,
  payload
});

const doToggleRFQPopup = payload => ({
  type: actionTypes.TOGGLE_RFQ_POPUP,
  reload: false,
  syncWithServer: true,
  updateImpersonatedUserProfile: false,
  payload
});

const doUpdateToggles = payload => ({
  type: actionTypes.UPDATE_TOGGLES,
  reload: false,
  syncWithServer: true,
  updateImpersonatedUserProfile: false,
  payload
});

const doUpdateFilterToggles = payload => ({
  type: actionTypes.UPDATE_FILTER_TOGGLES,
  reload: false,
  syncWithServer: true,
  updateImpersonatedUserProfile: false,
  payload
});

const doUpdateDefaultCopyTemplate = payload => ({
  type: actionTypes.UPDATE_DEFAULT_COPY_TEMPLATE,
  reload: false,
  syncWithServer: true,
  updateImpersonatedUserProfile: true,
  payload
});

const doCreateCopyTemplate = payload => ({
  type: actionTypes.CREATE_COPY_TEMPLATE,
  reload: true,
  syncWithServer: true,
  updateImpersonatedUserProfile: true,
  payload
});

const doUpdateCopyTemplate = payload => ({
  type: actionTypes.UPDATE_COPY_TEMPLATE,
  reload: true,
  syncWithServer: true,
  updateImpersonatedUserProfile: true,
  payload
});

const doDeleteCopyTemplate = payload => ({
  type: actionTypes.DELETE_COPY_TEMPLATE,
  reload: true,
  syncWithServer: true,
  updateImpersonatedUserProfile: true,
  payload
});

export const viewsActions = {
  switch: payload => dispatchAction(doSwitchView(payload)),
  create: payload => dispatchAction(doCreateView(payload)),
  update: payload => dispatchAction(doUpdateView(payload)),
  delete: payload => dispatchAction(doDeleteView(payload)),
  editColumns: payload => dispatchAction(doColumnChooserSave(payload)),
  editColumnStateAndSort: payload => dispatchAction(doColumnStateAndSortSave(payload))
};

export const sharedSettingsActions = {
  toggleRFQPopup: payload => dispatchAction(doToggleRFQPopup(payload)),
  updateToggles: payload => dispatchAction(doUpdateToggles(payload)),
  updateFilterToggles: payload => dispatchAction(doUpdateFilterToggles(payload))
};

export const tradingDeskCoverageChoicesActions = {
  update: payload => dispatchAction(doUpdateTradingDeskCoverageChoices(payload)),
  delete: payload => dispatchAction(doDeleteTradingDeskCoverageChoices(payload))
};

export const copyActions = {
  create: payload => dispatchAction(doCreateCopyTemplate(payload)),
  update: payload => dispatchAction(doUpdateCopyTemplate(payload)),
  delete: payload => dispatchAction(doDeleteCopyTemplate(payload)),
  updateDefaultCopyTemplate: payload => dispatchAction(doUpdateDefaultCopyTemplate(payload))
};
