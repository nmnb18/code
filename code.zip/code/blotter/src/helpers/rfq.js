import { strToNumber } from '~helpers/types';

export const getRFQRowDetail = (rows, legno) => rows.find(row => strToNumber(row.legno) === legno);

export const sortRFQRows = RFQs => {
  const copyRFQs = [...RFQs];

  return copyRFQs.sort((a, b) => {
    if (a.legno > b.legno) return 1;
    if (a.legno < b.legno) return -1;
    return 0;
  });
};
