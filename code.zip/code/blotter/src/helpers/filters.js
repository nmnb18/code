import {
  TODAY_STRING,
  YESTERDAY_STRING,
  FYTD_STRING,
  getDifferenceInDatesByDays,
  today,
  getFiscalDate
} from '~helpers/dateHelper';
import { FILTER_MODEL_TEXT, FILTER_MODEL_DATE, FILTER_MODEL_DYNAMIC_SET } from '~helpers/filterModelTypes';
import {
  FILTER_RANGE_EQUALS,
  FILTER_RANGE_LESS_X,
  FILTER_RANGE_LESS_EQUAL_X,
  FILTER_RANGE_GREAT_X,
  FILTER_RANGE_GREAT_EQUAL_X
} from '~constants/filters';
import { BASE_32 } from './rfqFormatters';

export const parseSetFilterOptions = filterValues => filterValues.map(filterValue => `"${filterValue}"`).join(',');

export const defaultFilterParam = col => {
  return {
    field: col.field,
    headerName: col.headerName,
    filter: [],
    filterType: FILTER_MODEL_TEXT,
    type: null
  };
};

export const isEmpty = str => {
  return !str || 0 === str.length;
};

export const formatFilterType = filterType => {
  switch (filterType) {
    case FILTER_RANGE_EQUALS:
      return '';
    case FILTER_RANGE_LESS_X:
      return '<';
    case FILTER_RANGE_LESS_EQUAL_X:
      return '<=';
    case FILTER_RANGE_GREAT_X:
      return '>';
    case FILTER_RANGE_GREAT_EQUAL_X:
      return '>=';
    default:
      return '';
  }
};

export const reverseFormatFilterType = filterType => {
  switch (filterType) {
    case '':
      return 'equals';
    case '<':
      return 'lessThan';
    case '<=':
      return 'lessThanOrEqual';
    case '>':
      return 'greaterThan';
    case '>=':
      return 'greaterThanOrEqual';
    default:
      return 'equals';
  }
};

//Special interaction with Date Advance Filter: When the user Selects Today, yesterday, 7, 30 or more.
export const processCustomRange = columnFilters =>
  columnFilters.map(currentFilter => {
    if (isValidDateFilter(currentFilter)) {
      let dateToAlterFrom = new Date();
      let dateToAlterTo = new Date();

      let daysToSubstract = 0;
      if (currentFilter.customRange !== TODAY_STRING) {
        if (currentFilter.customRange === YESTERDAY_STRING) {
          daysToSubstract = 1;

          const day = dateToAlterTo.getDay();
          if (day === 1) {
            //Today is Monday
            daysToSubstract = 3;
          }
          if (day === 0) {
            //Today is Sunday
            daysToSubstract = 2;
          }
        } else if (currentFilter.customRange === FYTD_STRING) {
          daysToSubstract = getDifferenceInDatesByDays(getFiscalDate(today.getFullYear()), today);
        } else {
          daysToSubstract = parseInt(currentFilter.customRange);
        }
      }
      dateToAlterFrom.setDate(dateToAlterFrom.getDate() - daysToSubstract);

      //Restore Date Format
      if (currentFilter.filter && currentFilter.filter.length > 1) {
        currentFilter.filter[0] = restoreDateFormat(dateToAlterFrom);
        if (currentFilter.customRange === YESTERDAY_STRING) {
          currentFilter.filter[1] = restoreDateFormat(dateToAlterFrom);
        } else {
          currentFilter.filter[1] = restoreDateFormat(dateToAlterTo);
        }
      }
    }

    return currentFilter;
  });

export const restoreDateFormat = alteredDate => {
  //Restore Date Format
  const dd = String(alteredDate.getDate()).padStart(2, '0');
  const mm = String(alteredDate.getMonth() + 1).padStart(2, '0'); //January is 0!
  const yyyy = alteredDate.getFullYear();

  return mm + '/' + dd + '/' + yyyy;
};

const VALID_DATE_FILTER_LENGTH = 2;

const isValidDateFilter = currentFilter =>
  currentFilter.filterType === FILTER_MODEL_DATE &&
  currentFilter.customRange &&
  currentFilter.filter.length === VALID_DATE_FILTER_LENGTH;

export function hasFilter(filterObj) {
  return filterObj && filterObj.filter && filterObj.filter.length > 0 && filterObj.filter[0] !== '';
}

export function addFilter(newFilter, filters) {
  const newFilters = {
    ...filters,
    [newFilter.field]: newFilter
  };

  return newFilters;
}

export const getColumnFilterValue = (column, filters) => {
  const columnFilter = filters[column.colId];
  return columnFilter ? columnFilter.filter : '';
};

export const hasFilterChanged = (model, filter) => {
  if (model.filterType === FILTER_MODEL_DYNAMIC_SET) {
    return model.textFilter !== filter;
  }

  return model.filter !== filter;
};

export const getNumModelValue = (model, { formatinstruction }) => {
  if (model) {
    const { filter } = model;
    const { decFormat } = formatinstruction;
    if (decFormat === BASE_32) return filter;

    if (`${filter || ''}`.trim() !== '') return Number(filter);

    return null;
  }

  return null;
};

export const hasDenominator = colDef =>
  !!colDef?.filterParams?.columnDefinition?.codeinstruction?.denominatorInstruction;
