export const moveFilterComponentToTheLeft = customFilterContainer => {
  const windowWidth = window.innerWidth;
  const componentWidth = customFilterContainer.offsetWidth;

  //The "Style" for the Div that encapsulates the Filters
  //is calculated in real time when creating the grid,
  //based on the Column at the 0 index and adding space to the left, via the "Left" style.
  const parentElementOfContainer = containerParentElement(customFilterContainer);
  const currentLeftValueOfComponent = parentElementOfContainer.style['left'];

  //We set the current "Left" value
  let newLeftValueForStyle = parseInt(currentLeftValueOfComponent);

  //We compare the Current Left Value with the Current Window Width minus the Width of the component
  //Dependending how far we are from the border we change the "left" value if necesary.
  if (windowWidth) {
    const windowBorderTolerance = windowWidth - componentWidth;
    if (newLeftValueForStyle > windowBorderTolerance) {
      newLeftValueForStyle = newLeftValueForStyle - componentWidth;
    }
  }

  //After the evaluation, we re assign the value to the "left" inline styling
  parentElementOfContainer.style['left'] = newLeftValueForStyle + 'px';
  parentElementOfContainer.classList.add('ag-menu--active');
};

//AgGrid does a "in-line styling" for this on the containing '.ag-menu' item that it generates
//The try catch is just in case.
const containerParentElement = containerFilter => {
  try {
    return containerFilter.closest('.ag-menu');
  } catch {
    return;
  }
};

export const focusTextBox = containerElement => {
  const elementTextBox = containerElement.querySelector('input[type="text"]');
  if (elementTextBox) {
    elementTextBox.focus();
  }
};
