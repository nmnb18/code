import {
  CONTAINER_EDIT_INQUIRY,
  CONTAINER_BOND_DASHBOARD,
  CONTAINER_CUSTOMER_DASHBOARD,
  CONTAINER_TICKER
} from '~helpers/globals';

import { iabPublish } from '~services/openfinService';

export const windowState = {
  NORMAL: 'normal',
  MAXIMIZED: 'maximized',
  MINIMIZED: 'minimized',
  RESTORED: 'restored'
};

export const popupDefaultRfqOptions = {
  autoShow: true,
  resizable: true,
  maximizable: true,
  saveWindowState: false,
  frame: false,
  minWidth: 1040,
  minHeight: 680,
  cornerRounding: {
    width: 5,
    height: 5
  }
};

export const popupDefaultOptions = {
  autoShow: true,
  resizable: true,
  maximizable: false,
  saveWindowState: false,
  frame: false,
  defaultCentered: true,
  cornerRounding: {
    width: 5,
    height: 5
  }
};

export const popupSecurityOptions = {
  permissions: {
    ExternalWindow: {
      wrap: true
    },
    System: {
      getAllExternalWindows: true,
      launchExternalProcess: true,
      readRegistryValue: false,
      terminateExternalProcess: true
    }
  }
};

export const popupIframeOptions = {
  api: {
    iframe: {
      crossOriginInjection: true
    }
  }
};

const typeSelector = {
  code: CONTAINER_BOND_DASHBOARD,
  clientname: CONTAINER_CUSTOMER_DASHBOARD,
  ticker: CONTAINER_TICKER,
  statusstr: CONTAINER_EDIT_INQUIRY,
  description: CONTAINER_BOND_DASHBOARD
};

const envSuffix = process.env.REACT_APP_ENVIRONMENT;

export const topicForUpdatingXiosWindows = `xios-window-update-topic-${envSuffix}`;
export const topicForCreatingXiosWindows = `xios-window-create-topic-${envSuffix}`;
export const xiosWindowsEvents = {
  updateTheme: 'XIOS_WINDOW_UPDATE_THEME',
  createWindow: 'XIOS_WINDOW_OPEN'
};

const getXiosIdentifierValue = (popUpType, targetData) => {
  if (popUpType === CONTAINER_CUSTOMER_DASHBOARD) {
    return targetData.paramMonikerClient;
  } else if (popUpType === CONTAINER_EDIT_INQUIRY) {
    return targetData.paramId;
  } else if (popUpType === CONTAINER_BOND_DASHBOARD) {
    return targetData.paramIsin;
  } else if (popUpType === CONTAINER_TICKER) {
    return targetData.ticker;
  }
  return targetData.paramValue;
};

export const requestXiosWindowFromGrid = (eventAction, currentUser, signedInUser) => {
  const userData = {
    realUser: currentUser,
    signedInUser
  };
  const popupType = typeSelector[eventAction.target.paramField];
  const identifier = getXiosIdentifierValue(popupType, eventAction.target);

  requestXiosWindow({ userData, popupType, identifier });
};

export const requestXiosWindow = payload =>
  iabPublish({
    topic: topicForCreatingXiosWindows,
    message: {
      type: xiosWindowsEvents.createWindow,
      payload
    },
    logLabel: 'Request Xios windows'
  });
