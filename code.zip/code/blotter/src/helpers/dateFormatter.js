import { format } from 'date-fns';
import {
  START_STRING,
  UTC_DATE_FORMAT,
  getFormattedTimeString,
  getUTCDate,
  formatUTCDate,
  formatTimeValue
} from './dateHelper';
export const DATE_UTC_FORMAT = 'yyyyMMdd';
export const TIME_UTC_FORMAT = 'HHmmss';
export const DISPLAY_TIME_FORMAT = 'HH:mm:ss zzz';
export const DISPLAY_DATE_FORMAT = 'MMM-dd-yyyy';

const START_TIME = '00:00:00';
const END_TIME = '24:00:00';

export const dateFormatter = value => {
  try {
    const date = value.split('/').join('');
    const [, month, day, year] = date.match(/(\d{2})-?(\d{2})-?(\d{4})/);
    const iMonth = parseInt(month);
    const iDay = parseInt(day);
    const iYear = parseInt(year);

    return format(new Date(iYear, iMonth - 1, iDay), 'MM/dd/yy').toUpperCase();
  } catch (error) {
    return value;
  }
};

export const getDateInLogFormat = () => format(new Date(), 'MM/dd HH:mm:ss:SSS');

export const getDateTimeString = (date, time, type) => {
  if (!date && !time) return '';
  if (date && !time) {
    const startEndString = type === START_STRING ? START_TIME : END_TIME;
    const utcDate = getUTCDate(date, startEndString);
    return formatUTCDate(new Date(utcDate), `${DATE_UTC_FORMAT} ${TIME_UTC_FORMAT}`);
  } else if (!date && time) {
    const tempTime = formatTimeValue(time);
    const formattedTime = getFormattedTimeString(tempTime);
    const currentDate = formatUTCDate(new Date(), UTC_DATE_FORMAT);
    const utcDate = getUTCDate(currentDate, formattedTime);
    return formatUTCDate(new Date(utcDate), `${TIME_UTC_FORMAT}`);
  } else if (date && time) {
    const tempTime = formatTimeValue(time);
    const formattedTime = getFormattedTimeString(tempTime);
    const utcDate = getUTCDate(date, formattedTime);
    return formatUTCDate(new Date(utcDate), `${DATE_UTC_FORMAT} ${TIME_UTC_FORMAT}`);
  }
};

export const formatWSDate = dateString => {
  if (dateString) {
    const splittedDate = dateString.split('/');
    return splittedDate[2] + splittedDate[0] + splittedDate[1];
  }
  return '';
};
