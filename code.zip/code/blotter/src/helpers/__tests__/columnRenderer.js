import { getLiveAxeContent, getHistAxeContent, getPriorityAxeContent } from '~helpers/columnRenderer';

describe('columnRenderer', () => {
  describe('Live axe content', () => {
    test('Live axe has an invalid value', () => {
      const result = getLiveAxeContent();
      expect(result).toBe('');
    });

    test('Live axe has NONE value', () => {
      const result = getLiveAxeContent('NONE');
      expect(result).toBe('');
    });

    test('Live axe has BUY value', () => {
      const result = getLiveAxeContent('BUY');
      expect(result).toBe('<span class="rfq-axed-content rfq-axed-content-buy">AXE</span>');
    });

    test('Live axe has SELL value', () => {
      const result = getLiveAxeContent('SELL');
      expect(result).toBe('<span class="rfq-axed-content rfq-axed-content-sell">AXE</span>');
    });

    test('Live axe has BOTH value', () => {
      const result = getLiveAxeContent('BOTH');
      expect(result).toBe('<span class="rfq-axed-content rfq-axed-content-both">AXE</span>');
    });
  });

  describe('Priority axe content', () => {
    test('Priority axe has an invalid value', () => {
      const result = getPriorityAxeContent();
      expect(result).toBe('');
    });

    test('Priority axe has 0 value', () => {
      const result = getPriorityAxeContent('0');
      expect(result).toBe('');
    });

    test('Priority axe has 1 value', () => {
      const result = getPriorityAxeContent('1');
      expect(result).toBe('<span class="rfq-priority-axe-content">!</span>');
    });
  });
});
