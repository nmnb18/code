import {
  updateRFQNotificationPopupSetting,
  getRFQNotificationPopup,
  validateEmployeeInfo,
  mapUserEntitlement
} from '../userSettings';

const userSetttings = {
  User: '',
  Applications: [{ AppName: 'Flow', Settings: {} }],
  AlertSettings: {}
};

describe('userSettings', () => {
  describe('update rfq notification popup settings', () => {
    test('when toggle on', () => {
      const toggleOn = true;
      const result = updateRFQNotificationPopupSetting(userSetttings, 'Flow', toggleOn);
      expect(result.Applications[0].Settings.RFQNotificationPopup).toBe(toggleOn);
    });

    test('when toggle off', () => {
      const toggleOn = false;
      const result = updateRFQNotificationPopupSetting(userSetttings, 'Flow', toggleOn);
      expect(result.Applications[0].Settings.RFQNotificationPopup).toBe(toggleOn);
    });
  });

  describe('get rfp notification popup current state when', () => {
    test('toggled on', () => {
      const userSettingsCopy = { ...userSetttings };
      userSettingsCopy.Applications[0].Settings = {
        RFQNotificationPopup: true
      };
      const result = getRFQNotificationPopup(userSettingsCopy, 'Flow');
      expect(result).toBe(true);
    });

    test('toggled off', () => {
      const userSettingsCopy = { ...userSetttings };
      userSettingsCopy.Applications[0].Settings = {
        RFQNotificationPopup: false
      };
      const result = getRFQNotificationPopup(userSettingsCopy, 'Flow');
      expect(result).toBe(false);
    });

    test('other than Flow app', () => {
      const userSettingsCopy = { ...userSetttings };
      userSettingsCopy.Applications[0].Settings = {
        RFQNotificationPopup: true
      };
      const result = getRFQNotificationPopup(userSettingsCopy, 'Test-Flow');
      expect(result).toBe(false);
    });
  });

  test('validate employee info', () => {
    const employeeInfo = {
      users: [{}]
    };
    const result = validateEmployeeInfo(employeeInfo);
    expect(result).toStrictEqual([{}]);
  });

  describe('map user with entitlement', () => {
    const employeeInfo = {
      users: [
        {
          name: 'Test User',
          level3: 'FI Technology',
          primaryRole: 'Technology',
          appoptions: { admin: true },
          entitlementExtensionRules: []
        }
      ]
    };
    test('check if user exist in entitlement', () => {
      const employeeInfoCopy = { ...employeeInfo, users: [] };
      const result = mapUserEntitlement(employeeInfoCopy);
      expect(result).toBe(null);
    });

    test('get name from user entitlement info', () => {
      const result = mapUserEntitlement(employeeInfo);
      expect(result.name).toBe('Test User');
    });

    test('get level3 from user entitlement info', () => {
      const result = mapUserEntitlement(employeeInfo);
      expect(result.level3).toBe('FI Technology');
    });
    test('get primaryRole from user entitlement info', () => {
      const result = mapUserEntitlement(employeeInfo);
      expect(result.primaryRole).toBe('Technology');
    });
    test('get entitlementExtensionRules from user entitlement info', () => {
      const result = mapUserEntitlement(employeeInfo);
      expect(result.entitlementExtensionRules).toStrictEqual([]);
    });
    test('get entitlementExtensionRules from user entitlement info', () => {
      const result = mapUserEntitlement(employeeInfo);
      expect(result.role).toStrictEqual('Admin');
    });
    test('get isAdmin from user entitlement info', () => {
      const result = mapUserEntitlement(employeeInfo);
      expect(result.isAdmin).toStrictEqual(true);
    });
  });
});
