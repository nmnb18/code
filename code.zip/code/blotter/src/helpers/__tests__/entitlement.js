import {
  getMyDeskFromEntitlement,
  getUserEntitledTradingOptions,
  checkForMyDeskOption,
  checkForCoverageOption,
  getBackendInstructions
} from '../entitlement';

const userEntitlement = {
  entitlementExtensionRules: [
    {
      appTopic: 'TradingDeskCoverageChoices',
      uiInstruction: { Visible: '1' },
      backendInstruction: { MyDesk: 'US High Yield' }
    }
  ]
};

describe('entitlement', () => {
  test('get mydesk from entitlement', () => {
    const result = getMyDeskFromEntitlement(userEntitlement);
    expect(result).toBe('US High Yield');
  });

  describe('get empty mydesk value', () => {
    test('due to invalid entitlementExtensionRules configuration in user entitlement', () => {
      const userEntitlementCopy = { ...userEntitlement };
      userEntitlementCopy.entitlementExtensionRules = undefined;
      const result = getMyDeskFromEntitlement(userEntitlementCopy);
      expect(result).toBe(null);
    });

    test('due to invalid appTopic value in user entitlement', () => {
      const userEntitlementCopy = { ...userEntitlement, entitlementExtensionRules: [{ appTopic: 'Random' }] };
      //userEntitlementCopy.entitlementExtensionRules[0].appTopic = 'Random topic';
      const result = getMyDeskFromEntitlement(userEntitlementCopy);
      expect(result).toBe(null);
    });

    test('due to invalid backendInstruction configuration in user entitlement', () => {
      const userEntitlementCopy = { ...userEntitlement, entitlementExtensionRules: [{ backendInstruction: {} }] };
      const result = getMyDeskFromEntitlement(userEntitlementCopy);
      expect(result).toBe(null);
    });

    test('due to invalid MyDesk value in user entitlement', () => {
      const userEntitlementCopy = { ...userEntitlement, entitlementExtensionRules: [{ MyDesk: '' }] };
      const result = getMyDeskFromEntitlement(userEntitlementCopy);
      expect(result).toBe(null);
    });
  });

  test('user is entitled to see both coverage and mydesk option', () => {
    const result = getUserEntitledTradingOptions(userEntitlement);
    expect(result.isTradingOptionVisible).toBe(true);
    expect(result.isMydeskOptionAvailable).toBe('US High Yield');
  });

  describe('check for my desk option', () => {
    const userEntitledOptions = {
      isTradingOptionVisible: true,
      isMydeskOptionAvailable: true
    };
    test('user is entitled and my desk is also slected', () => {
      const result = checkForMyDeskOption(userEntitledOptions, true);
      expect(result).toBe(true);
    });

    test('user is entitled but my desk is not slected', () => {
      const result = checkForMyDeskOption(userEntitledOptions, false);
      expect(result).toBe(false);
    });
  });

  describe('check for coverage option', () => {
    test('user is entitle and coverage option is selected', () => {
      const userEntitledOptions = {
        isTradingOptionVisible: true
      };
      const result = checkForCoverageOption(userEntitledOptions);
      expect(result).toBe(true);
    });

    test('user is entitle and coverage option is selected', () => {
      const userEntitledOptions = {
        isTradingOptionVisible: false
      };
      const result = checkForCoverageOption(userEntitledOptions);
      expect(result).toBe(false);
    });
  });

  describe('get backend instructions', () => {
    const backendInstruction = { MyDesk: 'High Yield', PersonaColumns: 'testUser&TestUser1' };
    const userEntitlementCopy = {
      ...userEntitlement,
      entitlementExtensionRules: [
        {
          appTopic: 'TradingDeskCoverageChoices',
          uiInstruction: { Visible: '1' },
          backendInstruction
        }
      ]
    };
    const result = getBackendInstructions(userEntitlementCopy);
    expect(result).toBe(`"mydesk": 'High Yield',"personacolumns": 'testUser&TestUser1'`);
  });
});
