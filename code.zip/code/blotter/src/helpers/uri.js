/**
 * Get query parameter from current url for the provided key.
 *
 * @param {string} key - The parameter you want to query.
 * @returns {string|null} Returns the parameter if it exists or null if it doesn't.
 */
export const getQueryParam = key => {
  const params = new URLSearchParams(window.location.search);
  return params.get(key);
};
