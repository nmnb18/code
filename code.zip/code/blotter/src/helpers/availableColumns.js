// If user's level3 is 'FI Technology' he should be able to see all columns
// otherwise, only the columns that have "available" flag set to "true"
export const getAvailableColumns = (columns, isTech) => (isTech ? columns : columns.filter(col => col.available));
