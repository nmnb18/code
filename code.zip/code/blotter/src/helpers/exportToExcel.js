import { WS_FIELDS } from '~helpers/jasperMessage';

export const appendFormatForDateTypes = header => {
  const { columnType, formatInstruction } = header;
  let dateFormat = formatInstruction ? formatInstruction.dateFormat : null;

  if (dateFormat && columnType && columnType === 'DATETIME') {
    if (dateFormat.indexOf('zzz') > -1) {
      dateFormat = dateFormat.replace(' zzz', '');
    }
    return `${columnType}^${dateFormat}`;
  } else {
    return columnType;
  }
};

export const isAvailableColumnDef = columnDef => {
  if (!columnDef) return false;

  return !columnDef.hide && columnDef.headerName && columnDef.field !== WS_FIELDS.KEY_ID;
};

export const mapToHeaderDefs = enhancedColumnDef => {
  const { headerName, field, columnType, formatInstruction } = enhancedColumnDef;

  return {
    headerName,
    field,
    columnType,
    formatInstruction
  };
};

export const mapToExcelColumnDef = columnDef => {
  const {
    field,
    headerName,
    width,
    hide,
    columntype: columnType,
    formatinstruction: formatInstruction,
    codeinstruction
  } = columnDef;

  return {
    field,
    headerName,
    columnType,
    formatInstruction,
    codeinstruction,
    width,
    hide
  };
};
