export const defaultFilterRange = { firstRow: -1, lastRow: -1 };
