import { filter } from 'rxjs/operators';

/*
 * isValidViewportRange is a custom RxJs operator and it will emit an events only for valid viewPortRange values
 * Any viewport that is different from range { firstRow: 0, lastRow: -1 } is consider valid
 * Invalid viewport range ({ firstRow: 0, lastRow: -1 }) is called when the grid is resseted
 * and it won't trigger any new request of data to the websocket
 */
export const isValidViewportRange = () =>
  filter(viewPortRange => !(viewPortRange.firstRow === 0 && viewPortRange.lastRow === -1));
