import {
  defaultMainGridId,
  defaultRfqGridId,
  exportDataSourceId,
  defaultMultiFilterRfqGridId,
  defaultMultiFilterFlowId,
  getSubscriptionInstanceId
} from '~helpers/jasperWebSocket';
import { blooterContainerAppId, flowBlotterAppId, getEnvironmentName } from '~services/apiConfig';
import { getQueryParam } from '~helpers/uri';
import { jasperWs } from '~services/apiConfig';

/**
 * Enhance 'user' subscription instance data with 'platform' variables.
 *
 * @param {Object} params
 * @param {string} params.signedInUser - User name of signed in user.
 * @param {string} params.flowNavigatorUser - Impersonated user or same as signedInUser if not impersonating.
 * @param {string} params.computerId - Id of current computer.
 * @returns {{signedInUser: string, flowNavigatorUser: string, computerId: string, environment: string, prefix?: string}} Returns the object with extra properties.
 */
const getSubscriptionConfiguration = ({ signedInUser, flowNavigatorUser, computerId }) => {
  const subscriptionConfiguration = {
    environment: getEnvironmentName(),
    signedInUser,
    flowNavigatorUser,
    computerId
  };
  const prefix = getQueryParam(jasperWs.websocketPrefixQueryParam);
  return prefix ? { ...subscriptionConfiguration, prefix } : subscriptionConfiguration;
};

export const getSubscriptionsInstances = ({ signedInUser, flowNavigatorUser, computerId }) => {
  const subscriptionConfiguration = getSubscriptionConfiguration({
    signedInUser,
    flowNavigatorUser,
    computerId
  });

  const rfqSubscriptionInstanceId = getSubscriptionInstanceId({
    appId: blooterContainerAppId,
    gridId: defaultRfqGridId,
    ...subscriptionConfiguration
  });

  const rfqMultiFilterSourceInstanceId = getSubscriptionInstanceId({
    appId: blooterContainerAppId,
    gridId: defaultMultiFilterRfqGridId,
    ...subscriptionConfiguration
  });

  const flowSubscriptionInstanceId = getSubscriptionInstanceId({
    appId: flowBlotterAppId,
    gridId: defaultMainGridId,
    ...subscriptionConfiguration
  });

  const flowMultiFilterSourceInstanceId = getSubscriptionInstanceId({
    appId: flowBlotterAppId,
    gridId: defaultMultiFilterFlowId,
    ...subscriptionConfiguration
  });

  const exportDataSourceInstanceId = getSubscriptionInstanceId({
    appId: flowBlotterAppId,
    gridId: exportDataSourceId,
    ...subscriptionConfiguration
  });

  return {
    rfqSubscriptionInstanceId,
    rfqMultiFilterSourceInstanceId,
    flowSubscriptionInstanceId,
    flowMultiFilterSourceInstanceId,
    exportDataSourceInstanceId
  };
};
