import { COLUMNS } from '~helpers/columnStyles';

export const updateRatingFilters = (ofilterList, ratingFilters) => {
  const filter_ratingmoody = ofilterList && ofilterList.find(item => item.field === COLUMNS.MOODY);
  const filter_ratingmoody_index = ofilterList && ofilterList.findIndex(item => item.field === COLUMNS.MOODY);
  const filter_rating_s_and_p = ofilterList && ofilterList.find(item => item.field === COLUMNS.SP);
  const filter_rating_s_and_p_index = ofilterList && ofilterList.findIndex(item => item.field === COLUMNS.SP);

  const newMoodyMatches = [];
  const newSPMatches = [];

  if ((filter_ratingmoody || filter_rating_s_and_p) && Object.keys(ratingFilters).length) {
    if (filter_ratingmoody) {
      filter_ratingmoody.filter.map(filterItem => {
        const moody_matches =
          ratingFilters &&
          ratingFilters.moody &&
          ratingFilters.moody.filter(item => item.rating_normalized === filterItem);
        return newMoodyMatches.push(...moody_matches);
      });
    }

    if (filter_rating_s_and_p) {
      filter_rating_s_and_p.filter.map(filterItem => {
        const s_p_matches =
          ratingFilters && ratingFilters.sp && ratingFilters.sp.filter(item => item.rating_normalized === filterItem);
        return newSPMatches.push(...s_p_matches);
      });
    }

    const newMoodyFilters = newMoodyMatches.map(item => item.rating_raw);
    const newSPFilters = newSPMatches.map(item => item.rating_raw);

    if (filter_ratingmoody_index > -1) {
      ofilterList[filter_ratingmoody_index] = {
        ...ofilterList[filter_ratingmoody_index],
        filter: newMoodyFilters,
        originalFilter: filter_ratingmoody.filter
      };
    }

    if (filter_rating_s_and_p_index > -1) {
      ofilterList[filter_rating_s_and_p_index] = {
        ...ofilterList[filter_rating_s_and_p_index],
        filter: newSPFilters,
        originalFilter: filter_rating_s_and_p.filter
      };
    }
  }

  return ofilterList;
};
