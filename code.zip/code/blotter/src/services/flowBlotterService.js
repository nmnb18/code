import { Subject } from 'rxjs';
import { takeUntil, switchMap, tap } from 'rxjs/operators';
import {
  flowBlotterTopicForChild,
  flowBlotterTopicForParent,
  flowBlotterEventsTopicForChild,
  flowBlotterUserSettingsTopicForChild,
  flowBlotterChangesFoundTopicForParent,
  rfqFlowBlotterTopicForChild,
  multiFilterFlowBlotterTopicForChild,
  flowBlotterActions
} from '~services/openfinConfig';
import { WS_COMMANDS } from '~helpers/jasperMessage';
import { iabSubscribe, iabUnsubscribe, iabPublish } from '~services/openfinService';

const FlowBlotterLog = 'Flow Blotter Bus for Parent';
const FlowBlotterEventsLog = 'Flow Blotter Events Topic for Parent';
const FlowBlotterCustomActionLog = 'Flow Blotter Custom Action Topic for Parent';
const FlowBlotterSwitchBlotterLog = 'Flow Blotter Switch Blotter Topic for Parent';
const RFQFlowBlotterLog = 'RFQ Flow Blotter Bus for Parent';
const MultiFilterFlowBlotterLog = 'Multi Filter Flow Blotter Bus for Parent';

class FlowBlotterService {
  constructor() {
    // Subject for push data from websocket to Flow Blotter
    this.dataSource$ = new Subject();

    // Subject for push filter data from websocket to Flow Blotter
    this.multiFilterSource$ = new Subject();

    // Subject for handling close application request
    this.flowBlotterRequestClose$ = new Subject();

    // Subject for start publishing data to Flow Blotter app
    this.startPublishFlag$ = new Subject();

    // Subject for stop publishing data to Flow Blotter app
    this.stopPublishFlag$ = new Subject();

    // Variable for store signed in user
    this.signedInUser = null;

    // Variable for store current blotter user
    this.blotterUser = null;

    // Variable for store current blotter computer
    this.blotterComputer = null;

    // Variable for store current flow blotter subscription instance Id, it's based on current username and computer.
    this.subscriptionInstanceId = null;
    this.isSourceSubscribedToWS = null;

    // Variable for store a reference to the handleRequestData function
    this.requestData = null;

    // Variable for store a reference to the handleRequestData function
    this.requestUnsubscribe = null;

    // Variable for store a reference to the onUnsubscribeRange function
    this.unsubscribeRange = null;

    // Variable for store current multi filter subscription instance Id
    this.multiFilterSourceInstanceId = null;
    this.isMultifilterSubscribedToWS = null;

    // Variable for store current blotter user settings. Later on user settings will be passed to Flow Blotter
    this.blotterUserSettings = null;

    // Getters
    this.getAssignedBlotterUser = null;
    this.getUserEntitlement = null;

    // Setters
    this.isFlowBlotterMounted = null;

    this.handlers = {
      [flowBlotterActions.mounted]: () => {
        const payload = this.getAssignedBlotterUser();
        this.setFlowBlotterMounted(true);
        this.sendEvent({ type: flowBlotterActions.assignBlotterUser, payload });
      },
      [flowBlotterActions.requestUserSettings]: () => {
        const payload = this.getBlotterUserSettings();
        this.sendBlotterUserSettings(payload);
      },
      [flowBlotterActions.requestUserEntitlement]: () => {
        const payload = this.getUserEntitlement();
        this.sendEvent({ type: flowBlotterActions.setUserEntitlement, payload });
      },
      [flowBlotterActions.flowBlotterGridReadyForReceiveData]: () => {
        this.turnPublishFlagOn();
      },
      [flowBlotterActions.flowBlotterRequestData]: payload => {
        const { requestCommand } = payload;
        this.requestData && this.requestData(requestCommand);
      },
      [flowBlotterActions.flowBlotterClose]: () => {
        this.turnPublishFlagOff();
        this.flowBlotterRequestClose$.next('CLOSE_APP');
      },
      [flowBlotterActions.flowBlotterRequestUnsubscribe]: ({ subscriptionInstanceId }) => {
        if (subscriptionInstanceId === this.subscriptionInstanceId) {
          this.turnPublishFlagOff();
        }
        this.handleUnsubscribe(subscriptionInstanceId);
      },
      [flowBlotterActions.flowBlotterRequestUnsubscribeRange]: () => {
        this.handleUnsubscribeRange();
      },
      [flowBlotterActions.flowBlotterRequestMultiFilter]: payload => {
        const { requestCommand } = payload;
        this.requestData && this.requestData(requestCommand);
      }
    };
  }

  initPublishFlow = () => {
    this.publishFlowSubscription = this.startPublishFlag$
      .pipe(
        switchMap(() =>
          this.dataSource$.pipe(
            tap(({ command }) => {
              if (command === WS_COMMANDS.GROUP_BEGIN) this.isSourceSubscribedToWS = true;
            }),
            takeUntil(this.stopPublishFlag$)
          )
        )
      )
      .subscribe(message => this.sendRFQMessage(message));

    this.publishMultiFilterFlowSubscription = this.startPublishFlag$
      .pipe(
        switchMap(() =>
          this.multiFilterSource$.pipe(
            tap(({ command }) => {
              if (command === WS_COMMANDS.GROUP_BEGIN) this.isMultifilterSubscribedToWS = true;
            }),
            takeUntil(this.stopPublishFlag$)
          )
        )
      )
      .subscribe(message => this.sendMultiFilterMessage(message));
  };

  removePublishFlow = () => {
    this.publishFlowSubscription && this.publishFlowSubscription.unsubscribe();
  };

  setInitialConfiguration = (
    currentUser,
    currentComputer,
    subscriptionInstanceId,
    multiFilterSourceInstanceId,
    signedInUser
  ) => {
    this.blotterUser = currentUser;
    this.blotterComputer = currentComputer;
    this.subscriptionInstanceId = subscriptionInstanceId;
    this.multiFilterSourceInstanceId = multiFilterSourceInstanceId;
    this.signedInUser = signedInUser;

    this.isSourceSubscribedToWS = false;
    this.isMultifilterSubscribedToWS = false;
    this.blotterUserSettings = null;
  };

  setUserSettings = userSettings => {
    this.blotterUserSettings = userSettings;
  };

  setHandlers = (onRequestData, onUnsubscribe, onUnsubscribeRange) => {
    this.requestData = onRequestData;
    this.requestUnsubscribe = onUnsubscribe;
    this.unsubscribeRange = onUnsubscribeRange;
  };

  setGetters = ({ getAssignedBlotterUser, getBlotterUserSettings, getUserEntitlement }) => {
    this.getAssignedBlotterUser = getAssignedBlotterUser;
    this.getBlotterUserSettings = getBlotterUserSettings;
    this.getUserEntitlement = getUserEntitlement;
  };

  setSetters = ({ setFlowBlotterMounted }) => {
    this.setFlowBlotterMounted = setFlowBlotterMounted;
  };

  turnPublishFlagOn = () => {
    this.startPublishFlag$.next('ON');
  };

  turnPublishFlagOff = () => {
    this.stopPublishFlag$.next('OFF');
  };

  initBlotterSubscription = () =>
    iabSubscribe({
      topic: flowBlotterTopicForParent,
      handler: this.handleMessage,
      logLabel: FlowBlotterLog
    });

  removeBlotterSubscription = () =>
    iabUnsubscribe({
      topic: flowBlotterTopicForParent,
      handler: this.handleMessage,
      logLabel: FlowBlotterLog
    });

  handleMessage = message => {
    const { type, payload } = message;
    const handler = this.handlers[type];
    handler && handler(payload);
  };

  sendMessage = message =>
    iabPublish({
      topic: flowBlotterTopicForChild,
      message,
      logLabel: FlowBlotterLog
    });

  sendEvent = event =>
    iabPublish({
      topic: flowBlotterEventsTopicForChild,
      message: event,
      logLabel: FlowBlotterEventsLog
    });

  sendRFQMessage = message =>
    iabPublish({
      topic: rfqFlowBlotterTopicForChild,
      message,
      logLabel: RFQFlowBlotterLog
    });

  sendMultiFilterMessage = message =>
    iabPublish({
      topic: multiFilterFlowBlotterTopicForChild,
      message,
      logLabel: MultiFilterFlowBlotterLog
    });

  sendBlotterUserSettings = payload =>
    iabPublish({
      topic: flowBlotterUserSettingsTopicForChild,
      message: payload,
      logLabel: FlowBlotterCustomActionLog
    });

  sendSwitchBlotterResponse = message =>
    iabPublish({
      topic: flowBlotterChangesFoundTopicForParent,
      message,
      logLabel: FlowBlotterSwitchBlotterLog
    });

  handleUnsubscribe = subscriptionInstanceId => {
    if (this.isSourceSubscribedToWS) {
      const unSubscribeId = subscriptionInstanceId ?? this.subscriptionInstanceId;
      this.requestUnsubscribe && this.requestUnsubscribe(unSubscribeId);
    }
    this.isSourceSubscribedToWS = false;
  };

  handleUnsubscribeRange = () => {
    this.unsubscribeRange && this.unsubscribeRange(this.subscriptionInstanceId);
  };

  handleMultiFilterUnsubscription = () => {
    if (this.isMultifilterSubscribedToWS) {
      this.requestUnsubscribe && this.requestUnsubscribe(this.multiFilterSourceInstanceId, true);
    }
    this.isMultifilterSubscribedToWS = false;
  };
}

const flowBlotterService = new FlowBlotterService();

export { flowBlotterService };
