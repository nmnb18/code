import { Subject, of } from 'rxjs';
import * as applicationLauncherService from '~services/applicationLauncherService';

import { switchMap, takeUntil, tap, map, mergeMap } from 'rxjs/operators';

const START_PROCESS_LOG = 'START PROCESS';
const CONTINUE_PROCESS_LOG = 'CONTINUE PROCESS';
const STOP_PROCESS_LOG = 'STOP PROCESS';

const SPACE = '" "';
const DASH = '-';
const SINGLE_PIPE = '|';
const COLUMN_SEPARATOR = SINGLE_PIPE;
const ROW_SEPARATOR = '#*#';
const HEADER = 'header';
const LASTBATCH = 'lastbatch';
const ARG_SEPARATOR = '‡';
const HEADER_DATA_SEPARATOR = SINGLE_PIPE;

class ExcelExportBatchService {
  constructor(data, headerDataTypes, batchSize, fileName, callback, processedRecord$) {
    this.data = data;
    this.headerDataTypes = headerDataTypes;
    this.batchSize = batchSize;
    this.fileName = fileName;
    this.callback = callback;
    this.index = 0;
    this.totalItems = data.length;
    this.totalBatches = Math.ceil(data.length / batchSize);
    this.batchNumber = 0;
    this.recordsProcessed = 0;
    this.startBatchProcess = new Subject();
    this.stopBatchProcess = new Subject();
    this.processedRecord$ = processedRecord$;
  }

  getNextBatch = (_data, _index) => _data.slice(_index, _index + this.batchSize);

  asyncProcessObservable = _data => {
    return of(_data.length).pipe(
      tap(() => {
        this.asyncExportTask(this.index, _data, this.headerDataTypes, this.fileName);
      })
    );
  };

  asyncExportTask = (_index, _data, _headerDataTypes, _fileName) => {
    let dataToExport = '';
    let lastbatchHeaderFlag = DASH;
    if (_index === 0 && _index + this.batchSize >= this.totalItems) {
      // Single batch
      lastbatchHeaderFlag = `${LASTBATCH}${SINGLE_PIPE}${HEADER}`;
    } else if (_index === 0) {
      // first batch
      lastbatchHeaderFlag = HEADER;
    } else if (_index + this.batchSize >= this.totalItems) {
      //last batch
      lastbatchHeaderFlag = LASTBATCH;
    }

    _data.forEach(function(arr) {
      dataToExport =
        dataToExport +
        arr
          .map(x => `${x ? x : SPACE}`)
          .join(COLUMN_SEPARATOR)
          .concat(ROW_SEPARATOR);
    });

    dataToExport = dataToExport.slice(0, -1 * ROW_SEPARATOR.length);
    let headerDataTypesAsString = _headerDataTypes && _headerDataTypes.join(HEADER_DATA_SEPARATOR);

    // Format of command and sample
    // {argument separator (must be single character)}{column separator}{argument separator}{file name}{argument separator}{column datatypes separator}{column datatypes}{argument separator}{first row of batch index}{argument separator}{lastbatch|header (last batch and first batch indicators)}{argument separator}{headers and rows}"
    // ‡#*#‡|‡1624284475601‡|‡STRING|STRING|INTEGER|STRING|DATETIME^HH:mm:ss|STRING|STRING|STRING|STRING|STRING|STRING|INTEGER|FLOAT|FLOAT|STRING|DATETIME^MMM-dd-yyyy|STRING|STRING|STRING|STRING|STRING|STRING|STRING‡1‡lastbatch|header‡Priority|Live Axe|Exp|Status|Time|Source|Client Name|Client Trader|CUSIP/ISIN|Description|Client B/S|Size|Our Price|Sent Price|Currency|Date|RFQ Source|Salesperson|Trader Name|S&P|Moody|RegS/144a|Market#*#NO|NONE|04:57|QuoteRequested|10:07:52|RFQ|MARKET AXESS HOLDINGS INC|mktxdax|46284VAE1|IRM 5 1/4 03/15/28 144A|SELL|950,000|104.625|" "|USD|JUN-21-2021|MAX|frank altomaro|" "|BB-|Ba3|144A|US High Yield

    const args = {
      ExcelImporter1: `"${ROW_SEPARATOR}" "${COLUMN_SEPARATOR}" "${_fileName}" "${headerDataTypesAsString}" "${_index +
        1}" "${lastbatchHeaderFlag}" ${dataToExport}`,
      ExcelImporter2: `${ARG_SEPARATOR}${ROW_SEPARATOR}${ARG_SEPARATOR}${COLUMN_SEPARATOR}${ARG_SEPARATOR}${_fileName}${ARG_SEPARATOR}${HEADER_DATA_SEPARATOR}${ARG_SEPARATOR}${headerDataTypesAsString}${ARG_SEPARATOR}${_index +
        1}${ARG_SEPARATOR}${lastbatchHeaderFlag}${ARG_SEPARATOR}${dataToExport}`
    };

    applicationLauncherService.execute({
      alias: process.env.REACT_APP_EXCELIMPORTER_ALIAS,
      args: args[process.env.REACT_APP_EXCELIMPORTER_ALIAS],
      successCallback: this.onSuccess,
      failureCallback: this.onError
    });
  };

  setUpProcess = () => {
    this.data$ = of(this.data);
    this.index = 0;
    this.startBatchProcess$ = this.startBatchProcess.asObservable();
    this.stopBatchProcess$ = this.stopBatchProcess.asObservable();

    this.startBatchProcess$
      .pipe(
        switchMap(() => this.data$),
        map(allData => this.getNextBatch(allData, this.index)),
        mergeMap(batch => this.asyncProcessObservable(batch)),
        tap(value => (this.index += value)),
        takeUntil(this.stopBatchProcess$)
      )
      .subscribe(rowsProcessed => {
        this.recordsProcessed += rowsProcessed;
        this.processedRecord$.next({
          processedRecord: this.recordsProcessed - 1,
          totalRecords: this.totalItems - 1
        });
        console.log(`Number of records Processed are ${this.recordsProcessed} / ${this.totalItems}`);
      });
  };

  startProcess = () => {
    console.log('Excel Export Started.');
    this.startBatchProcess.next(START_PROCESS_LOG);
  };

  continueProcess = () => {
    console.log('Excel export in progress .......');
    this.startBatchProcess.next(CONTINUE_PROCESS_LOG);
  };

  stopProcess = () => {
    console.log('Excel Export finished.');
    this.stopBatchProcess.next(STOP_PROCESS_LOG);
    this.callback();
  };

  processExecutionCompleted = () => {
    if (this.index < this.totalItems) {
      this.continueProcess();
    } else {
      this.stopProcess();
    }
  };

  onSuccess = processIdentity => {
    console.log(`Excel Export > exe batch complete > Process Id is ${processIdentity.uuid}`);
    this.processExecutionCompleted();
  };

  onError = err => {
    console.log('Error: ', err);
    this.processExecutionCompleted();
  };
}

export default ExcelExportBatchService;
