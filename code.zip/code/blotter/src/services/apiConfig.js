export const applicationId = process.env.REACT_APP_BLOTTER_CONTAINER_APP_ID;
export const blooterContainerAppId = process.env.REACT_APP_BLOTTER_CONTAINER_APP_ID;
export const flowBlotterAppId = process.env.REACT_APP_FLOW_BLOTTER_APP_ID;

export const jasperWs = {
  url: process.env.REACT_APP_JASPER_WS_ENDPOINT,
  multiSelectUrl: process.env.REACT_APP_JASPER_WS_MULTI_SELECT_ENDPOINT,
  topic: process.env.REACT_APP_JASPER_WS_TOPIC,
  reconnectMinimumInterval: Number(process.env.REACT_APP_JASPER_WS_RECONNECT_MINIMUM_DELAY),
  reconnectAttemptTime: Number(process.env.REACT_APP_JASPER_WS_RECONNECT_ATTEMPT_TIME),
  reconnectVariability: Number(process.env.REACT_APP_JASPER_WS_RECONNECT_DELAY_VARIABILITY),
  failSafe: process.env.REACT_APP_JASPER_WS_FAIL_SAFE,
  websocketPrefixQueryParam: 'wsprefix'
};

export const jasperApi = {
  url: process.env.REACT_APP_JASPER_API_ENDPOINT
};

export const apis = {
  userSettings: 'user-settings',
  dictionaries: 'column-dictionaries',
  entitlement: 'entitlement',
  usage: 'usage',
  ping: 'ping'
};

export const environmentList = {
  LOCAL: 'LOCAL',
  'LOCAL-UAT': 'LOCAL-UAT',
  'LOCAL-US': 'LOCAL-US',
  'LOCAL-UK': 'LOCAL-UK',
  DEV: 'DEV',
  TEST: 'TEST',
  UAT: 'UAT',
  US: 'US', // PROD US
  UK: 'UK' // PROD UK
};

const currentEnv = process.env.REACT_APP_ENVIRONMENT;

export const getEnvironmentName = () => {
  return environmentList[currentEnv] || '';
};

export const renewCookieInterval = parseInt(process.env.REACT_APP_RENEW_COOKIE_INTERVAL);

export const pingApi = (includeUserInfo = false, includeHaltRedirect = false) => {
  const queryParamsArr = [];

  if (includeUserInfo) queryParamsArr.push('userinfo=true');
  if (includeHaltRedirect) queryParamsArr.push('haltRedirect');

  const queryParams = queryParamsArr.length ? `?${queryParamsArr.join('&')}` : '';

  return `${jasperApi.url}/${apis.ping}${queryParams}`;
};

export const employeeInfoApi = userName => `${jasperApi.url}/${apis.entitlement}/employeeInfo?windowslogin=${userName}`;

export const impersonatedUsersApi = (appPlatform, userName) =>
  `${jasperApi.url}/${apis.entitlement}/impersonatedUsers?appPlatform=${appPlatform}&userName=${userName}&limit=5`;

export const searchPersonApi = value => `${jasperApi.url}/${apis.entitlement}/personSearch?username=${value}`;

export const usageApi = () => `${jasperApi.url}/${apis.usage}`;

export const searchBoxByTypeApi = (userName, value, type, impersonater) => {
  let url = `${applicationSettings.searchBoxByTypeApi}?filter=${value}&uid=${userName}&type=${type}`;
  if (impersonater) {
    return `${url}&impersonator=${impersonater}`;
  }
  return url;
};

export const settingsApi = user => `${jasperApi.url}/${apis.userSettings}/users/${user}`;

export const ratingsApi = () => `${jasperApi.url}/rating`;

export const columnDictionaryApi = appName => `${jasperApi.url}/${apis.dictionaries}/${appName}`;

export const applicationSettings = {
  flow: {
    name: process.env.REACT_APP_FLOW_BLOTTER_APP_TITLE,
    url: process.env.REACT_APP_FLOW_BLOTTER_APP_URL,
    active: true
  },
  axe: {
    name: process.env.REACT_APP_AXE_APP_TITLE,
    url: process.env.REACT_APP_AXE_APP_URL,
    active: false
  },
  client: {
    name: process.env.REACT_APP_CLIENT_APP_TITLE,
    url: process.env.REACT_APP_CLIENT_APP_URL,
    active: false
  },
  searchBoxByTypeApi: process.env.REACT_APP_SEARCHBOX_BY_TYPE_API,
  suggestionApi: process.env.REACT_APP_SUGGESTION_API,
  blotterContainerURL: process.env.REACT_APP_BLOTTER_CONTAINER_URL,
  blotterContainerName: process.env.REACT_APP_BLOTTER_CONTAINER_NAME,
  rfqNotificationPopupName: process.env.REACT_APP_RFQ_NOTIFICATION_POPUP_NAME
};
