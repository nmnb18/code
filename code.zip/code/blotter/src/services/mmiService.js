export const HIDE = 'hide';
export const CLOSE_CONTROL = 'close-wnd';
export const MINIMIZE_CONTROL = 'min-wnd';
export const MAXIMIZE_CONTROL = 'max-wnd';
export const RFQ_POPUP_CONTROL = 'rfq-popup';
export const RESTART = 'restart';

export const mmiControlsDefaultState = {
  showCloseControl: true,
  showMaximizeControl: true,
  showMinimizeControl: true,
  showRFQPopupControl: true
};

export const showControl = (options, controlKey) => options[controlKey] !== HIDE;
