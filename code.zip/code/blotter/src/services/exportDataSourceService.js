import { Subject } from 'rxjs';
import { takeUntil, switchMap, filter } from 'rxjs/operators';
import {
  exportDataSourceTopicForChild,
  exportDataSourceTopicForParent,
  exportDataSourceActions,
  rfqExportDataSourceTopicForChild
} from '~services/openfinConfig';
import { FLOW_APP_NAME } from '~helpers/globals';
import { exportData } from './exportService';
import { EXPORT_COMMANDS, FETCH_TRIGGERS } from '~helpers/jasperMessage';
import { createExportDataCacheService } from './exportDataCacheService';
import { isAvailableColumnDef, mapToHeaderDefs, appendFormatForDateTypes } from '~helpers/exportToExcel';
import { formatExcelExportData, getFormatHeadersForCopy, formatCopyToClipboardData } from '~helpers/rfqFormatters';

import * as settingsService from '~services/settingsService';
import { getHeaderFieldsForCopy } from '~helpers/copyToClipboard';
import { mapArrayToObject } from '~helpers/object';
import { iabSubscribe, iabUnsubscribe, iabPublish } from '~services/openfinService';

const ExportDataSourceLog = 'Export Data Source Bus for Parent';
const RFQExportDataSourceLog = 'RFQ Export Data Source Bus for Parent';
class ExportDataSourceService {
  constructor() {
    // Subject for push data from websocket to Flow Blotter
    this.dataSource$ = new Subject();

    // Subject for start publishing data to Flow Blotter app
    this.startPublishFlag$ = new Subject();

    // Subject for stop publishing data to Flow Blotter app
    this.stopPublishFlag$ = new Subject();

    // Subect for handling export
    this.dataFlowSubject$ = new Subject();
    this.fetchingStatusSubject = new Subject();
    this.fetchingStatusSubject$ = this.fetchingStatusSubject.asObservable();
    this.rfqExportDataSource = new Subject();
    this.rfqExportDataSource$ = this.rfqExportDataSource.asObservable();
    this.subscriptionIdSubject$ = new Subject();
    this.processedRecordSubject = new Subject();
    this.processedRecordSubject$ = this.processedRecordSubject.asObservable();
    // Variable for store signed in user
    this.signedInUser = null;

    // Variable for store current blotter user
    this.blotterUser = null;

    // Variable for store current blotter computer
    this.blotterComputer = null;

    // Variable for store current flow blotter subscription instance Id, it's based on current username and computer.
    this.subscriptionInstanceId = null;

    // Variable for store a reference to the handleRequestData function
    this.requestData = null;

    this.columnDefs = null;

    this.columnsDictionary = null;

    this.trigger = '';

    this.referenceKeysArray = [];

    this.filterToggleEntries = {};

    this.handlers = {
      [exportDataSourceActions.exportDataSourceReadyForReceiveData]: () => {
        this.turnPublishFlagOn();
      },
      [exportDataSourceActions.exportDataSourceRequestData]: payload => {
        this.setupExportDataCacheService();
        const { requestCommand } = payload;
        this.filterToggleEntries = mapArrayToObject(requestCommand?.filterToggleEntries);
        this.requestData && this.requestData(requestCommand);
      }
    };
  }

  initPublishFlow = () => {
    this.publishFlowSubscription = this.startPublishFlag$
      .pipe(switchMap(() => this.dataSource$.pipe(takeUntil(this.stopPublishFlag$))))
      .subscribe(message => {
        this.sendRFQMessage(message);
      });
    this.dataFlowSubscription = this.dataFlowSubject$
      .pipe(filter(value => value && value.command === EXPORT_COMMANDS.FETCH_DONE))
      .subscribe(({ data }) => this.handleData(data));
  };

  removePublishFlow = () => {
    this.publishFlowSubscription && this.publishFlowSubscription.unsubscribe();
    this.dataFlowSubscription && this.dataFlowSubscription.unsubscribe();
  };

  setInitialConfiguration = (currentUser, currentComputer, subscriptionInstanceId, signedInUser) => {
    this.blotterUser = currentUser;
    this.blotterComputer = currentComputer;
    this.subscriptionInstanceId = subscriptionInstanceId;
    this.signedInUser = signedInUser;
  };

  handleData = data => {
    if (this.trigger !== FETCH_TRIGGERS.COPY_TO_CLIPBOARD) {
      this.handleExportToExcel(data, this.trigger);
    } else {
      this.handleCopyToClipboard(data, this.trigger);
    }
  };

  getCopyTemplateColDef = () => {
    const copyTemplateList = settingsService.getCopyTemplatesList(this.userSettings, FLOW_APP_NAME);
    const selectedCopyTemplate =
      this.selectedInDDLCopyTemplateName &&
      copyTemplateList &&
      copyTemplateList.find(copyTemplate => copyTemplate.CopyTemplateName === this.selectedInDDLCopyTemplateName);
    return selectedCopyTemplate ? selectedCopyTemplate.Columns : [];
  };

  handleCopyToClipboard = (data, trigger) => {
    const findMaxWidth = (max, x) => (`${x}`.length > max ? `${x}`.length : max);
    const width = value => (value ? value.length : 0);

    const copyTemplateColDef = this.getCopyTemplateColDef();
    const headersCopy = copyTemplateColDef.map(({ displayname, colId }) => {
      const customToggleConfiguration = this.filterToggleEntries[colId];
      const hasCustomHeaderName =
        customToggleConfiguration && customToggleConfiguration.showToggle && customToggleConfiguration.toggle;
      const headerName = hasCustomHeaderName ? customToggleConfiguration.toggleOptions.breadCrumbText : displayname;

      return {
        headerName,
        field: colId,
        width: data.map(x => x[colId]).reduce((max, x) => findMaxWidth(max, x), width(headerName))
      };
    });

    const headers = getHeaderFieldsForCopy(headersCopy);
    const headerFields = headers.map(header => header.field);
    const headerRow = getFormatHeadersForCopy(headers);

    const dataRows = formatCopyToClipboardData(
      data,
      headers,
      headerFields,
      this.columnsDictionary,
      this.filterToggleEntries
    );

    exportData({
      target: trigger,
      payload: {
        headers: headerRow,
        data: dataRows
      },
      callback: this.handleEndFetchingData,
      disconnectExportDataCaching: this.disconnectExportDataCaching
    });
  };

  handleExportToExcel = (data, trigger) => {
    if (!this.columnDefs) return;
    const headerDefs = this.columnDefs.filter(isAvailableColumnDef).map(mapToHeaderDefs);
    const headers = headerDefs.map(({ field, headerName }) => {
      const customToggleConfiguration = this.filterToggleEntries[field];
      const hasCustomHeaderName =
        customToggleConfiguration && customToggleConfiguration.showToggle && customToggleConfiguration.toggle;

      return hasCustomHeaderName ? customToggleConfiguration.toggleOptions.breadCrumbText : headerName;
    });
    const headerDataTypes = headerDefs.map(header => appendFormatForDateTypes(header));
    const headerFields = headerDefs.map(header => header.field);
    const dataRows = formatExcelExportData(
      data,
      headerDefs,
      headerFields,
      this.columnsDictionary,
      this.filterToggleEntries
    );

    exportData({
      target: trigger,
      payload: {
        headers,
        data: dataRows,
        headerDataTypes
      },
      callback: this.handleEndFetchingData,
      disconnectExportDataCaching: this.disconnectExportDataCaching,
      processedRecord$: this.processedRecordSubject
    });
  };

  setHandlers = handleRequestData => {
    this.requestData = handleRequestData;
  };

  turnPublishFlagOn = () => {
    this.startPublishFlag$.next('ON');
  };

  turnPublishFlagOff = () => {
    this.stopPublishFlag$.next('OFF');
  };

  initBlotterSubscription = () =>
    iabSubscribe({
      topic: exportDataSourceTopicForParent,
      handler: this.handleMessage,
      logLabel: ExportDataSourceLog
    });

  removeBlotterSubscription = () =>
    iabUnsubscribe({
      topic: exportDataSourceTopicForParent,
      handler: this.handleMessage,
      logLabel: ExportDataSourceLog
    });

  setReferenceKeys = columns => {
    columns.forEach(col => {
      if (col?.codeinstruction?.referenceKey) {
        this.referenceKeysArray.push({ colId: col.sourcecolumnname, referenceKey: col.codeinstruction.referenceKey });
      }
    });
  };

  handleMessage = message => {
    const { type, payload } = message;
    if (payload && payload.requestCommand) {
      const {
        columnDefs,
        columnsDictionary,
        trigger,
        userSettings,
        selectedInDDLCopyTemplateName
      } = payload.requestCommand;
      this.columnDefs = columnDefs;
      this.columnsDictionary = columnsDictionary;
      this.trigger = trigger;
      this.userSettings = userSettings;
      this.selectedInDDLCopyTemplateName = selectedInDDLCopyTemplateName;
      if (this.columnsDictionary) {
        this.setReferenceKeys(this.columnsDictionary.sourceColumnNames);
      }
    }
    const handler = this.handlers[type];
    handler && handler(payload);
  };

  sendMessage = message =>
    iabPublish({
      topic: exportDataSourceTopicForChild,
      message,
      logLabel: ExportDataSourceLog
    });

  sendRFQMessage = message => {
    iabPublish({
      topic: rfqExportDataSourceTopicForChild,
      message,
      logLabel: RFQExportDataSourceLog
    });
    this.rfqExportDataSource.next(message);
  };

  //Export New Code
  handleStartFetchingData = () => this.fetchingStatusSubject.next(true);

  handleEndFetchingData = () => {
    this.fetchingStatusSubject.next(false);
  };

  disconnectExportDataCaching = () => {
    this.exportDataCacheService && this.exportDataCacheService.disconnect();
  };

  setupExportDataCacheService = () => {
    this.exportDataCacheService = createExportDataCacheService(
      this.subscriptionIdSubject$,
      this.rfqExportDataSource.asObservable(),
      this.dataFlowSubject$,
      this.handleStartFetchingData,
      this.referenceKeysArray
    );
  };
}

const exportDataSourceService = new ExportDataSourceService();

export { exportDataSourceService };
