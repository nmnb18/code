import { interval, Subject, of, asapScheduler } from 'rxjs';
import { switchMap, delay, debounceTime, filter, tap, takeUntil, map } from 'rxjs/operators';
import SortedMap from 'collections/sorted-map';
import { WS_COMMANDS, WS_FIELDS } from '~helpers/jasperMessage';
import { viewportDataSourceEvents } from './viewportDataSource';
import { isValidViewportRange } from '~helpers/customOperators';
import { strToNumber } from '~helpers/types';
import { jasperWs } from './apiConfig';
import { format } from 'date-fns';
import logFactory from '~helpers/logFactory';
import { defaultFilterRange } from '~helpers/proxyService';
import { extraLogger, extraLogSubjects } from '~helpers/logger';

const log = logFactory('proxyService');

const reRenderInterval = 50;
const deferredRenderInterval = 500;
const scrollInterval = 250;
const turnOffRenderInterval = 101;
const selectOnlyFirstNewRFQInterval = 250;
const SELECT_RFQ = 'SELECT_RFQ';
const requiresRender = true;
const renderUpdatesInterval = 1000;

const logNew = false;
const logUpdate = false;
const logUpdateIteration = false;
const logDelete = false;
const logDeleteIteration = false;
const logRenderingRelated = false;
const logSetViewport = false;
const logMetrics = false;

const isInViewportRange = (index, firstRow, lastRow) => firstRow <= index && index <= lastRow;

const canCommandUpdateViewPortRange = command =>
  command === WS_COMMANDS.NEW_MESSAGE_SOW ||
  command === WS_COMMANDS.NEW_MESSAGE ||
  command === WS_COMMANDS.UPDATE_MESSAGE ||
  command === WS_COMMANDS.DELETE_MESSAGE ||
  command === WS_COMMANDS.GROUP_BEGIN ||
  command === WS_COMMANDS.GROUP_END ||
  command === WS_COMMANDS.CLEAR ||
  command === WS_COMMANDS.ENTITLEMENT_ERROR;

export function createProxyService(
  subscriptionInstance$,
  data$,
  filter$,
  onRequest,
  onRowCountChange,
  proxyOptions,
  checkboxEvent$,
  onConnectionChange,
  onRFQEvent,
  onViewportReady,
  unsubscribeRange
) {
  function ProxyService(
    _subscriptionInstance$,
    _data$,
    _filter$,
    _onRequest,
    _onRowCountChange,
    _proxyOptions,
    _checkboxEvent$,
    _onConnectionChange,
    _onRFQEvent,
    _onViewportReady,
    _unsubscribeRange
  ) {
    this.referenceKeysArray = [];
    // Observables
    this.subsInstance$ = _subscriptionInstance$;
    this.source$ = _data$;
    this.filter$ = _filter$;
    this.requestData = _onRequest;
    this.rowCountChange = _onRowCountChange;
    this.options = _proxyOptions;
    this.checkboxEvent$ = _checkboxEvent$;
    this.setConnection = _onConnectionChange;
    this.sendRFQEvent = _onRFQEvent;
    this.viewportReady = _onViewportReady;
    this.unsubscribeRange = _unsubscribeRange;

    this.renderingTimestamp = null;
    this.context = {};
    this.subscriptionId = null;
    this.renderRange = null;
    this.newCriteria = false;
    this.forceViewportInitialAssignment = false;
    this.isFirstNewRFQ = true;
    this.rfqLegMap = new Map();
    this.skipFirstUnsubscribeRangeRequest = true;
    this.isFirstTotalFromNewFilter = true;

    this.isGridCacheBlocked = false;
    this.saveFirstRowIndexFromCurrentRequest = true;
    this.firstRowIndexFromCurrentRequest = null;
    this.temporaryLastRowIndexFromCurrentRequest = null;
    this.clientSubscriptionId = null;

    this.isRenderingGroup = false;
    this.startRenderGroupFlag$ = new Subject();
    this.stopRenderGroupFlag$ = new Subject();

    this.isRenderingUpdates = false;
    this.startRenderUpdatesFlag$ = new Subject();
    this.stopRenderUpdatesFlag$ = new Subject();
    this.setViewportRange$ = new Subject();

    // Deferred updates queue
    this.renderGroupInterval$ = interval(reRenderInterval);
    this.renderUpdatesInterval$ = interval(deferredRenderInterval);
    this.deferredUpdates = new SortedMap();

    /*
     * Subscription instance observable provide the current subscription instance Id
     * The subscription instance Id will be used for filter the data that the proxy service instance might use
     */
    this.subsIntanceSubscription =
      this.subsInstance$ && this.subsInstance$.subscribe(subscriptionId => (this.subscriptionId = subscriptionId));

    /*
     * Filter observable indicates that a new filter will be applied on the Grid
     */
    this.filterSubscription =
      this.filter$ &&
      this.filter$.subscribe(({ newCriteria }) => {
        // Set shouldUpdateViewportRange flag to true, so the very first record that belongs to the requested viewport range came in
        // the viewport range will be updated
        this.shouldUpdateViewportRange = true;

        // Block grid cache before send a new subscription to the WS
        this.isGridCacheBlocked = true;

        // Force to reset ag-grid component by setting the row count to zero
        this.sendEventAsync({ eventType: viewportDataSourceEvents.RESET });

        // Assign values to the renderFlag before request more data to the websocket
        this.renderRange = { ...defaultFilterRange };

        // Only when a new filter event has been applied update the filterCriteria flag to true
        this.newCriteria = newCriteria;

        // Set isFirstTotalFromNewFilter to true because we are expecting to get a new RFQTotal for the new filter
        this.isFirstTotalFromNewFilter = true;

        // Send new request command to the websocket using the default filter range
        this.requestData({ ...defaultFilterRange, newCriteria });
      });

    /*
     * RenderFlag observable will handle the render logic
     * meaning, if the renderFlag is "ON" (it has a "defined" value)
     * it will emit an event each "20ms" which will end up sending results to the viewport
     * once the renderFlag is "OFF" (it is "null")
     * it will stop emitting events, meaning we are not sending more results to the viewport
     */
    this.renderFlagSubscription = this.startRenderGroupFlag$ //this.renderFlagSubject
      // this.renderFlagSubscription = this.renderFlagSubject
      .pipe(
        switchMap(renderRange => {
          this.renderRange = renderRange;

          return this.renderGroupInterval$.pipe(
            filter(() => this.shouldRenderGroup()),
            takeUntil(this.stopRenderGroupFlag$)
          );
        })
      )
      .subscribe(() => {
        // this block is executed as long as the "renderFlag" has a defined value
        logRenderingRelated && log.info('subscribe > sendResultsToViewport');

        // this block is executed as long as "isRenderingGroup" flag is false
        const { firstRow, lastRow } = this.renderRange;
        const firstRowIndexFromCurrentRequest = this.firstRowIndexFromCurrentRequest;
        const lastRowIndexFromCurrentRequest = this.temporaryLastRowIndexFromCurrentRequest;

        this.sendResultsToViewport(firstRow, lastRow, firstRowIndexFromCurrentRequest, lastRowIndexFromCurrentRequest);
      });

    this.renderUpdatesFlagSubscription = this.startRenderUpdatesFlag$
      .pipe(
        switchMap(() =>
          this.renderUpdatesInterval$.pipe(
            filter(() => this.shouldRenderUpdate()),
            takeUntil(this.stopRenderUpdatesFlag$)
          )
        )
      )
      .subscribe(() => {
        const t0 = performance.now();

        this.isRenderingUpdates = true;
        const deferredUpdatesSnapshot = this.deferredUpdates.clone();
        this.deferredUpdates.clear();

        const contextCopy = { ...this.context };
        const { gridCache: gridCacheSnapshot, viewportFirstRow, viewPortLastRow } = contextCopy;

        const rowDataMap = {};
        let hasDataToSend = false;

        deferredUpdatesSnapshot
          .filter((_rowIndexAction, rowIndexTask) => isInViewportRange(rowIndexTask, viewportFirstRow, viewPortLastRow))
          .forEach((_rowIndexAction, rowIndexTask) => {
            rowDataMap[rowIndexTask] = gridCacheSnapshot.has(rowIndexTask) ? gridCacheSnapshot.get(rowIndexTask) : null;
            if (!hasDataToSend) hasDataToSend = true;
          });

        if (hasDataToSend) {
          this.sendEventAsync({
            eventType: viewportDataSourceEvents.ROW_DATA,
            rowDataMap,
            options: { update: true },
            updatesSnapshot: deferredUpdatesSnapshot.toObject()
          });
        }

        const t1 = performance.now();
        logRenderingRelated && log.info('Render deferred updates took ' + (t1 - t0) + ' milliseconds.');
        this.isRenderingUpdates = false;
      });

    /*
     * setViewportRange observable will debounce scroll events until "100ms" of no scroll events pass
     * then it will emit a event with the last scroll event information
     */
    this.setViewportRangeSubscription = this.setViewportRange$
      .pipe(debounceTime(scrollInterval, asapScheduler), isValidViewportRange())
      .subscribe(({ firstRow, lastRow }) => this.setViewportRange(firstRow, lastRow));

    /*
     * checkboxEvent observable will emit value that indicates the current state of
     * the "select all" checkbox and the selected or unselected checkboxes
     */
    this.checkboxEventSubscription =
      this.checkboxEvent$ &&
      this.checkboxEvent$.subscribe(checkboxEventValue => this.setAutoSelectState(checkboxEventValue));

    this.processMessageHandler = null;
    this.defineMessageHandler = () => {
      const { failSafe } = jasperWs;

      if (failSafe === 'Y') {
        this.processMessageHandler = value => {
          try {
            this.processMessage(value);
          } catch (e) {
            console.log('Error in processMessageHandler triggered grid reload:');
            console.error(e);

            // Reset viewport flags
            this.firstRowIndexFromCurrentRequest = null;
            this.temporaryLastRowIndexFromCurrentRequest = null;

            this.filter$.next({ newCriteria: true });
          }
        };
      } else {
        this.processMessageHandler = value => this.processMessage(value);
      }
    };
    this.defineMessageHandler();

    /*
     * source observable will handle the flow of formatted messages that comes in from the websocket
     */
    this.sourceSubscription = this.source$
      .pipe(
        map(message => {
          if (this.referenceKeysArray.length > 0) {
            this.referenceKeysArray.forEach(({ colId, referenceKey }) => {
              if (!message[colId]) {
                message[colId] = message[referenceKey];
              }
            });
          }
          return message;
        }),
        tap(() => this.updateRenderingTimestamp())
      )
      .subscribe(value => this.processMessageHandler(value));
  }

  ProxyService.prototype.processMessage = function(value) {
    const { command } = value;

    if (canCommandUpdateViewPortRange(command) && this.shouldUpdateViewportRange) {
      this.handleUpdateViewPortRange(value);
    }

    if (command === WS_COMMANDS.ACK) {
      extraLogger.log(
        extraLogSubjects.RFQ,
        `rfqPopup proxyService.processMessage: '${command}'. Totals is ${value.rfqTotal}`
      );
      this.setTotalRecords(value.rfqTotal);
    } else if (command === WS_COMMANDS.GROUP_BEGIN) {
      extraLogger.log(extraLogSubjects.RFQ, `rfqPopup proxyService.processMessage: '${command}'.`);
      this.handleGroupBegin(value);
    } else if (command === WS_COMMANDS.UPDATE_MESSAGE) {
      extraLogger.log(extraLogSubjects.RFQ, `rfqPopup proxyService.processMessage: '${command}'.`);
      if (!this.isGridCacheBlocked) {
        this.updateMessage(value);
      } else {
        extraLogger.warn(extraLogSubjects.RFQ, 'rfqPopup proxyService blocked');
      }
    } else if (command === WS_COMMANDS.NEW_MESSAGE) {
      extraLogger.log(
        extraLogSubjects.RFQ,
        `rfqPopup proxyService.processMessage: '${command}': /key_id="${value.key_id_dup}".`
      );
      if (!this.isGridCacheBlocked) {
        this.addNewMessage(value);
      } else {
        extraLogger.warn(extraLogSubjects.RFQ, 'rfqPopup proxyService blocked');
      }
    } else if (command === WS_COMMANDS.DELETE_MESSAGE) {
      extraLogger.log(
        extraLogSubjects.RFQ,
        `rfqPopup proxyService.processMessage: '${command}': /key_id="${value.key_id_dup}".`
      );
      if (!this.isGridCacheBlocked) {
        this.deleteMessage(value);
      } else {
        extraLogger.warn(extraLogSubjects.RFQ, 'rfqPopup proxyService blocked');
      }
    } else if (command === WS_COMMANDS.NEW_MESSAGE_SOW) {
      extraLogger.log(
        extraLogSubjects.RFQ,
        `rfqPopup proxyService.processMessage: '${command}': /key_id="${value.key_id_dup}".`
      );
      if (!this.isGridCacheBlocked) {
        this.addNewMessageSow(value);
      } else {
        extraLogger.warn(extraLogSubjects.RFQ, 'rfqPopup proxyService blocked');
      }
    } else if (command === WS_COMMANDS.GROUP_END) {
      extraLogger.log(extraLogSubjects.RFQ, `rfqPopup proxyService.processMessage: '${command}'.`);
      this.handleGroupEnd(value);
    } else if (command === WS_COMMANDS.ENTITLEMENT_ERROR) {
      this.notifyOnEntitlementError();
    } else if (command === WS_COMMANDS.DISCONNECT) {
      this.updateConnectionStatus(false);
    } else if (command === WS_COMMANDS.CONNECT) {
      this.updateConnectionStatus(true);
    }
  };

  ProxyService.prototype.turnRenderGroupFlagOn = function({ firstRow, lastRow }) {
    logRenderingRelated && log.info('turnRenderGroupFlagOn', firstRow, lastRow);
    this.startRenderGroupFlag$.next({ firstRow, lastRow });
  };

  ProxyService.prototype.turnRenderGroupFlagOff = function() {
    logRenderingRelated && log.info('turnRenderGroupFlagOff');
    this.stopRenderGroupFlag$.next('off');
  };

  ProxyService.prototype.turnRenderUpdatesFlagOn = function() {
    logRenderingRelated && log.info('turnRenderUpdatesFlagOn');
    this.startRenderUpdatesFlag$.next('on');
  };

  ProxyService.prototype.turnRenderUpdatesFlagOff = function() {
    logRenderingRelated && log.info('turnRenderUpdatesFlagOff');
    this.stopRenderUpdatesFlag$.next('off');
  };

  ProxyService.prototype.handleUpdateViewPortRange = function(value) {
    const { command, vpFirstRow, vpLastRow } = value;

    const contextCopy = { ...this.context };
    const { viewportFirstRow, viewPortLastRow } = contextCopy;

    if (command === WS_COMMANDS.CLEAR) {
      // Once CLEAR command came in reset the gridConnection properties
      const resettedContext = this.resetContext();
      this.context = { ...resettedContext };
      this.isGridCacheBlocked = false;
    } else if (viewportFirstRow !== vpFirstRow || viewPortLastRow !== vpLastRow) {
      // Once new ViewPort ranges came in update current viewportFirstRow and viewPortLastRow
      this.shouldUpdateViewportRange = false;
      this.context = {
        ...contextCopy,
        // set the new viewport range
        viewportFirstRow: vpFirstRow,
        viewPortLastRow: vpLastRow
      };
    }
  };

  ProxyService.prototype.handleGroupBegin = function(value) {
    const { vpFirstRow, vpLastRow, clientSubscriptionId } = value;

    // Set flag variable for store the very first new message from new viewport range
    this.saveFirstRowIndexFromCurrentRequest = true;

    // Each time we process a GROUP_BEGIN message we will update the clientSubscriptionId
    if (this.clientSubscriptionId !== clientSubscriptionId) this.clientSubscriptionId = clientSubscriptionId;

    // Once GROUP_BEGIN command came in disable updates rendering
    this.turnRenderUpdatesFlagOff();

    const contextCopy = { ...this.context };
    const { rowsInViewport } = contextCopy;
    rowsInViewport.clear();

    this.context = { ...contextCopy, rowsInViewport };

    // use GROUP_BEGIN's range as new rendering range for viewport
    // this.saveFirstRowIndexFromCurrentRequest = true;
    this.turnRenderGroupFlagOn({ firstRow: vpFirstRow, lastRow: vpLastRow });
  };

  ProxyService.prototype.handleGroupEnd = function(value) {
    const { vpFirstRow, vpLastRow, clientSubscriptionId } = value;

    logMetrics &&
      log.info('started processing GROUP END', vpFirstRow, '-', vpLastRow, ' | ', format(new Date(), 'hh:mm:ss:SSS'));

    // of('GROUP_END', asapScheduler).subscribe(() => {
    this.delayExecution(
      WS_COMMANDS.GROUP_END,
      () => {
        const contextCopy = { ...this.context };
        const { viewportFirstRow, viewPortLastRow } = contextCopy;

        logRenderingRelated &&
          log.info('GROUP_END > connection', 'viewportFirstRow', viewportFirstRow, 'viewPortLastRow', viewPortLastRow);
        logRenderingRelated && log.info('GROUP_END > message', 'vpFirstRow', vpFirstRow, 'vpLastRow', vpLastRow);
        logRenderingRelated &&
          log.info('GROUP_END > same range', viewportFirstRow === vpFirstRow && viewPortLastRow === vpLastRow);

        // if the viewport range (firstrow or lastrow) is equal to group end message range (firstrow or lastrow) then turn the render execution off
        // otherwise, skip turning the render execution off

        // if (vpFirstRow === viewportFirstRow || vpLastRow === viewPortLastRow) {

        logRenderingRelated &&
          log.info(
            'GROUP_END > same clientSubscriptionId',
            this.clientSubscriptionId,
            clientSubscriptionId,
            this.clientSubscriptionId === clientSubscriptionId
          );

        // if the GROUP_END messages belongs to the current clientSubscriptionId then:
        // 1. Turn group render process OFF
        // 2. Turn update render process ON
        if (this.clientSubscriptionId === clientSubscriptionId) {
          logRenderingRelated &&
            log.info('GROUP_END > turnRenderGroupFlagOff', 'vpFirstRow', vpFirstRow, 'vpLastRow', vpLastRow);

          this.turnRenderGroupFlagOff();

          // enable rendering updates once we have rendered the new viewport range
          this.turnRenderUpdatesFlagOn();
        }

        this.notifyOnGroupEnd();

        logMetrics &&
          log.info(
            'finished processing GROUP END, render flag OFF',
            vpFirstRow,
            '-',
            vpLastRow,
            ' | ',
            format(new Date(), 'hh:mm:ss:SSS')
          );
      },
      turnOffRenderInterval
    );
    // });
  };

  ProxyService.prototype.addNewMessageSow = function(rfqMessage) {
    // gridCache = rfqRecordCache => ordinal: { rfq }
    // indexMap = sowKeyToOrdinal => sowkey: ordinal
    const { sowkey, rowIndex, command } = rfqMessage;
    if (this.saveFirstRowIndexFromCurrentRequest) {
      this.saveFirstRowIndexFromCurrentRequest = false;
      this.firstRowIndexFromCurrentRequest = rowIndex;
    }
    this.temporaryLastRowIndexFromCurrentRequest = rowIndex;
    logRenderingRelated && log.info(command, rowIndex, sowkey);

    const contextCopy = { ...this.context };
    const { indexMap, gridCache } = contextCopy;

    indexMap.set(sowkey, rowIndex);
    gridCache.set(rowIndex, { ...rfqMessage });

    // Update grid connection before next render
    this.context = { ...contextCopy };
  };

  ProxyService.prototype.addNewMessage = function(rfqMessage) {
    // gridCache = rfqRecordCache => ordinal: { rfq }
    // indexMap = sowKeyToOrdinal => sowkey: ordinal
    const contextCopy = { ...this.context };
    const { viewportFirstRow, viewPortLastRow, indexMap, gridCache } = contextCopy;
    const { sowkey, rowIndex } = rfqMessage;

    // Add new sowkey to indexMap
    indexMap.set(sowkey, rowIndex);

    logNew && log.info('========================================►►');
    logNew &&
      log.info(
        // eslint-disable-next-line
        ' ➕ adding new rfq: ' + sowkey + ', ' + 'rowIndex: ' + rowIndex,
        ':: ' + (log.level >= log.INFO ? new Date().toString() : null)
      );
    logNew && log.info('viewportFirstRow', viewportFirstRow, 'viewPortLastRow', viewPortLastRow);
    // Array.from(gridCache)
    logNew &&
      log.info(
        '➖ before addition: ',
        log.level >= log.INFO ? JSON.stringify(gridCache.toJSON().map(([k, v]) => ({ [k]: v.sowkey }))) : null
      );

    // if new RFQ message is within the viewport range
    //if (isInViewportRange(rowIndex, viewportFirstRow, viewPortLastRow)) {
    // indexMap.set(sowkey, rowIndex);

    const startingPoint = this.getLastIndexFromGridCache(); // lastIndexFromGridCache > viewPortLastRow ? viewPortLastRow : lastIndexFromGridCache;
    logNew && log.info('addNewMessage > startingPoint', startingPoint);

    // Slide all rows DOWN
    // keep decreasing row index, from last row in my cache until the new RFQ index

    for (let i = startingPoint; i >= rowIndex; i--) {
      const tempRow = gridCache.get(i);
      gridCache.set(i + 1, tempRow);
      indexMap.set(tempRow.sowkey, i + 1);
    }

    // Add new rfqMessage in my cache
    gridCache.set(rowIndex, { ...rfqMessage });

    // Setup grid connection properties before start rendering new values from the cache
    // Clear the map that indicates if a row is in the viewport or not
    // rowsInViewport.clear();

    // Update grid connection properties before next render
    this.context = { ...contextCopy };

    const newLastIndexFromGridCache = this.getLastIndexFromGridCache(requiresRender);
    logNew && log.info('addNewMessage > newLastIndexFromGridCache', newLastIndexFromGridCache);
    // this.sendResultsToViewport(viewportFirstRow, newLastIndexFromGridCache);

    logNew && log.info('addNewMessage > sendResultsToViewport', rowIndex, newLastIndexFromGridCache);
    // this.sendResultsToViewport(rowIndex, newLastIndexFromGridCache);
    // this.selectNewRFQ(rowIndex);
    this.addDeferredRenderTask('NEW_MESSAGE', rowIndex, newLastIndexFromGridCache);

    if (this.options && this.options.notifyOnNewMessage) {
      this.handleRFQEvent(WS_COMMANDS.NEW_MESSAGE, rfqMessage);
    }

    /*} else {
      log.info('❌❌ rowIndex ' + rowIndex + ' not in viewPort range, so added right away');
      gridCache.set(rowIndex, { ...rfqMessage });*/

    // Add new rfqMessage in my cache

    // we don't need to manually ordered the gridcache
    /*
      if (rowIndex < firstRow || rowIndex < this.getLastIndexFromGridCache()) {
        log.info('sorting..');
        //sometimes new messages from old subscriptions are still catching up but they can't be placed at the end of the cache
        //we can't just ignore them either because the cache will then be out of sync,
        //if we go back to the previous range again we may recieve an update for something non-existent
        const mergedMap = new Map(
          [...gridCache].sort((a, b) => {
            return parseInt(a) - parseInt(b);
          })
        );
        gridCache = mergedMap;
      }
      */
    //}

    // Array.from(gridCache)
    logNew &&
      log.info(
        '➕ after addition: ',
        log.level >= log.INFO ? JSON.stringify(gridCache.toJSON().map(([k, v]) => ({ [k]: v.sowkey }))) : null
      );
  };

  ProxyService.prototype.updateMessage = function(rfqMessage) {
    // gridCache = rfqRecordCache => ordinal: { rfq }
    // indexMap = sowKeyToOrdinal => sowkey: ordinal
    const contextCopy = { ...this.context };
    const { viewportFirstRow, viewPortLastRow, gridCache, indexMap } = contextCopy;
    const { sowkey, rowIndex, isResorting } = rfqMessage;

    // if RFQ exists, get values from existing rfq record and apply changes on it
    if (indexMap.has(sowkey)) {
      const existingRFQIndex = indexMap.get(sowkey);
      const existingRFQ = gridCache.get(existingRFQIndex);

      // Ignore field that comes in the RFQ message but are not required for the final user or can't change
      const notAllowedFields = [
        WS_FIELDS.SOWKEY,
        WS_FIELDS.COMMAND,
        WS_FIELDS.ROWINDEX,
        WS_FIELDS.SOURCE,
        WS_FIELDS.KEY_ID,
        WS_FIELDS.LEGNO
      ];

      const rfqAllowedFields = Object.keys(rfqMessage).filter(
        field => rfqMessage[field] && !notAllowedFields.includes(field)
      );

      logUpdate && log.info('========================================►►');
      logUpdate &&
        log.info(
          // eslint-disable-next-line
          '🔄 updating rfq: ' + sowkey + ', ' + 'new rowIndex: ' + rowIndex,
          'old rowIndex',
          existingRFQIndex,
          ':: ' + (log.level >= log.INFO ? new Date().toString() : null)
        );
      logUpdate && log.info('existingRFQ', existingRFQ);
      logUpdate && log.info('viewportFirstRow', viewportFirstRow, 'viewPortLastRow', viewPortLastRow);
      // Array.from(gridCache)
      logUpdate &&
        log.info(
          '🔄 before update: ',
          log.level >= log.INFO ? JSON.stringify(gridCache.toJSON().map(([k, v]) => ({ [k]: v.sowkey }))) : null
        );

      let rfqUpdates;
      // if rfqAllowedFields has any valid column then build the rfqUpdates object with the rfq changes
      if (rfqAllowedFields.length) {
        rfqUpdates = rfqAllowedFields.reduce((acc, cur) => ({ ...acc, [cur]: rfqMessage[cur] }), {});
      }

      // if there is not changes to update in the viewport, exit updateMessage method
      if (!rfqUpdates) return;

      if (existingRFQIndex === rowIndex) {
        // Viewport's setDataValue method expected following format:
        // arr = [{ rowIndex: 1, columnId: 'id', newValue: '1234' }]
        let columnChanges;
        columnChanges = rfqAllowedFields.map(key => ({
          rowIndex: existingRFQIndex,
          columnId: key,
          newValue: rfqMessage[key]
        }));

        if (columnChanges && columnChanges.length) {
          logUpdate && log.info('indexes are the same,, updating right away');
          // Only update values in my cache
          gridCache.set(rowIndex, { ...existingRFQ, ...rfqUpdates });

          // Update values on the current GridConnectionId
          this.context = { ...contextCopy };

          const rowDataMap = {
            [rowIndex]: { ...existingRFQ, ...rfqUpdates }
          };

          logUpdate && log.info('Update Message', rowDataMap);

          // Replace the "update cells" approach with the "create new row" approach
          // We change the previous approach because we noticed that updating styles and classes were taking longer to refresh
          // So we decided to go with the "replace whole row" approach and the rendering performance increased a bit

          if (!isResorting) {
            this.addDeferredRenderTask('UPDATE_MESSAGE', rowIndex, rowIndex);
          }

          // this.sendEventAsync({
          //   eventType: viewportDataSourceEvents.ROW_DATA,
          //   rowDataMap: rowDataMap
          // });
        }
      } else {
        // if the existing RFQ has changed its rowIndex position
        // TODO: Move the existingRFQIndex to its new position
        // 1. Remove existing item from its previous position (slide rows up)
        // 2. Add existing item in its new position (slide rows down)
        // const isNewIndexGreaterThanOldIndex = rowIndex > existingRFQIndex;

        // New index is greater than previous index
        // As intance, move row from index 4 to index 7

        const isExistingRowIndexInViewportRange = isInViewportRange(
          existingRFQIndex,
          viewportFirstRow,
          viewPortLastRow
        ); // step 1 delete
        const isNewRowIndexInViewportRange = isInViewportRange(rowIndex, viewportFirstRow, viewPortLastRow); // step 2 insert
        let lastIndexFromGridCache = this.getLastIndexFromGridCache();
        // Step 1: Delete row from existing rowIndex
        indexMap.delete(sowkey);
        if (!isResorting) {
          // execute deletion
          logUpdate && log.info('updateMessage > Step 1 Deletion > lastIndexFromGridCache', lastIndexFromGridCache);
          const endingPoint = lastIndexFromGridCache;
          // Slide all the rows UP
          // keep increasing row index, from the deleted RFQ index until last row in my cache
          for (let i = existingRFQIndex; i < endingPoint; i++) {
            const tempRow = gridCache.get(i + 1);
            logUpdateIteration && log.info('moving index ' + (i + 1) + ' to ' + i);
            gridCache.set(i, tempRow);
            indexMap.set(tempRow.sowkey, i);
          }
          gridCache.delete(endingPoint);
        } else {
          gridCache.delete(existingRFQIndex);
        }

        // Step 2: Add row in new rowIndex
        indexMap.set(sowkey, rowIndex);
        // if (isNewRowIndexInViewportRange) {
        // execute addition
        lastIndexFromGridCache = this.getLastIndexFromGridCache();
        const startingPoint = lastIndexFromGridCache;
        logUpdate &&
          log.info(
            'addNewMessage > Step 2 Inser > lastIndexFromGridCache',
            lastIndexFromGridCache,
            'startingPoint',
            startingPoint
          );
        // Slide all rows DOWN
        // keep decreasing row index, from last row in my cache until the new RFQ index
        for (let i = startingPoint; i >= rowIndex; i--) {
          const tempRow = gridCache.get(i);
          if (!tempRow) log.info('tmpRow', gridCache.get(i), 'i', i);
          logUpdateIteration && log.info('moving index ' + i + ' to ' + (i + 1));
          gridCache.set(i + 1, tempRow);
          indexMap.set(tempRow.sowkey, i + 1);
        }
        //  }
        // Add new rfqMessage in my cache
        // gridCache.set(rowIndex, { ...rfqMessage });
        gridCache.set(rowIndex, { ...existingRFQ, ...rfqUpdates });

        // Step 3: Render viewport

        /*
        if (rowIndex > existingRFQIndex) {
          // Delete sowkey from indexMap
          indexMap.delete(sowkey);

          if (isNewRowIndexInViewportRange) {
            log.info('rowIndex', rowIndex, 'is greater than existingRFQIndex', existingRFQIndex);
            // slide rows UP
            //if existingRFQIndex happens to be outside of viewport range we don't want to slide starting from there
            const startingPoint = existingRFQIndex >= viewportFirstRow ? existingRFQIndex : viewportFirstRow;

            for (let i = startingPoint; i < rowIndex; i++) {
              const tempRow = gridCache.get(i + 1);
              log.info('moving index ' + (i + 1) + ' to ' + i);
              gridCache.set(i, tempRow);
              indexMap.set(tempRow.sowkey, i);
            }
            // gridCache.delete(rowIndex); // check if is necessary
          }

          gridCache.set(rowIndex, { ...existingRFQ, ...rfqUpdates });
          // Add new sowkey to indexMap
          indexMap.set(sowkey, rowIndex);
        } else {
          // New index is less than previous index
          // As intance, move row from index 7 to index 4

          // Delete sowkey from indexMap
          indexMap.delete(sowkey);

          if (isNewRowIndexInViewportRange) {
            // if rowIndex < existingRFQIndex -> slide rows DOWN
            log.info('rowIndex', rowIndex, 'is lesser than existingRFQIndex', existingRFQIndex);
            //if existingRFQIndex happens to be outside of viewport range we don't want to slide starting from there
            const startingPoint = existingRFQIndex <= viewPortLastRow ? existingRFQIndex : viewPortLastRow;
            for (let i = startingPoint - 1; i >= rowIndex; i--) {
              const tempRow = gridCache.get(i);
              log.info('moving index ' + i + ' to ' + (i + 1));
              gridCache.set(i + 1, tempRow);
              indexMap.set(tempRow.sowkey, i + 1);
            }
            // gridCache.delete(rowIndex); // check if is necessary
          }

          gridCache.set(rowIndex, { ...existingRFQ, ...rfqUpdates });
          // Add new sowkey to indexMap
          indexMap.set(sowkey, rowIndex);
        }
        */

        if (isNewRowIndexInViewportRange || isExistingRowIndexInViewportRange) {
          // Setup grid connection properties before start rendering new values from the cache
          // Clear the map that indicates if a row is in the viewport or not
          // rowsInViewport.clear();

          // Update grid connection properties before next render
          this.context = { ...contextCopy };

          let rfqnlegs = 0;
          if (existingRFQ) rfqnlegs = strToNumber(existingRFQ.rfqnlegs);

          // Check if RFQ has LEGs
          // If RFQ has LEGs (meaning rfqnlegs > 1) we will defer the render of those rows
          // until all the records that belongs to the same RFQ (we use the key_id_rfq_group as identifier) are correctly ordered
          if (rfqnlegs > 1) {
            // Create the legArray with size equals to rfqnlegs because we need to know when all the records for this rfq are ordered
            let legArr = new Array(rfqnlegs);
            const keyIdRFQGroup = existingRFQ.key_id_rfq_group;

            // Check if keyIdRFQGroup already exist in the rfqLegMap
            if (this.rfqLegMap.has(keyIdRFQGroup)) {
              // Update the rowIndex property for each item in the legArray using the indexMap which has been updated due to last execution of updateMessage method
              legArr = updateRowIndexinLegArray(this.rfqLegMap.get(keyIdRFQGroup), indexMap);
            }

            // Update legArray item of position legno with latest rowIndex value from indexMap
            legArr[existingRFQ.legno] = { sowkey, rowIndex: indexMap.get(sowkey) };

            // Update the rfqLegMap value with latest legArray data for our current keyIdRFQGroup
            this.rfqLegMap.set(keyIdRFQGroup, legArr);

            if (isLegArrayFilled(legArr)) {
              // Check that all items in legArray are defined and has the property rowIndex
              if (isLegArrayOrdered(legArr)) {
                // Check that all items are ordered (meaning M, L1, L2)
                const { firstRowIndex, lastRowIndex } = getViewportRangeFromLegArray(legArr);

                this.rfqLegMap.delete(keyIdRFQGroup);

                logUpdate && log.info('updateMessage > sendResultsToViewport', firstRowIndex, lastRowIndex);

                if (!isResorting) {
                  this.addDeferredRenderTask('UPDATE_MESSAGE', firstRowIndex, lastRowIndex);
                }

                // this.sendResultsToViewport(firstRowIndex, lastRowIndex);
              }
            }
          } else {
            let r1 = viewportFirstRow;
            let r2 = viewPortLastRow;

            if (isNewRowIndexInViewportRange && isExistingRowIndexInViewportRange) {
              //both are within range
              r1 = Math.min(existingRFQIndex, rowIndex);
              r2 = Math.max(existingRFQIndex, rowIndex);
            } else if (isNewRowIndexInViewportRange && !isExistingRowIndexInViewportRange) {
              //incoming is not within range
              r1 = rowIndex;
              r2 = this.getLastIndexFromGridCache(requiresRender);
            } else if (isExistingRowIndexInViewportRange && !isNewRowIndexInViewportRange) {
              //existing record is leaving the viewport
              r1 = existingRFQIndex;
              r2 = this.getLastIndexFromGridCache(requiresRender);
            }

            // If the RFQ has no LEGS (meaning rfqnlegs === 1) we will render it right away
            logUpdate && log.info('updateMessage > sendResultsToViewport', r1, r2);

            if (!isResorting) {
              this.addDeferredRenderTask('UPDATE_MESSAGE', r1, r2);
            }

            // this.sendResultsToViewport(r1, r2);
          }
        }
      }

      // Array.from(gridCache)
      logUpdate &&
        log.info(
          '🔄 after update: ',
          log.level >= log.INFO ? JSON.stringify(gridCache.toJSON().map(([k, v]) => ({ [k]: v.sowkey }))) : null
        );
    }
  };

  ProxyService.prototype.deleteMessage = function(rfqMessage) {
    // gridCache = rfqRecordCache => ordinal: { rfq }
    // indexMap = sowKeyToOrdinal => sowkey: ordinal
    const contextCopy = { ...this.context };
    const { viewportFirstRow, viewPortLastRow, gridCache, indexMap } = contextCopy;
    const { sowkey } = rfqMessage;

    // Get cachedRowIndex using the RFQ sowkey value
    const cachedRowIndex = indexMap.get(sowkey);

    // Delete sowkey from indexMap
    indexMap.delete(sowkey);
    // if deleted RFQ message is within the viewport range

    logDelete && log.info('========================================►►');
    logDelete &&
      log.info(
        '➖ received delete order for value ' + sowkey + ' and rowIndex: ' + cachedRowIndex,
        ':: ' + (log.level >= log.INFO ? new Date().toString() : null)
      );
    logDelete && log.info('viewportFirstRow', viewportFirstRow, 'viewPortLastRow', viewPortLastRow);
    // Array.from(gridCache)
    logDelete &&
      log.info(
        '➖ before deletion: ',
        log.level >= log.INFO ? JSON.stringify(gridCache.toJSON().map(([k, v]) => ({ [k]: v.sowkey }))) : null
      );

    // if (isInViewportRange(cachedRowIndex, viewportFirstRow, viewPortLastRow)) {
    const lastIndexFromGridCache = this.getLastIndexFromGridCache();
    logDelete && log.info('deleteMessage > lastIndexFromGridCache', lastIndexFromGridCache);

    const endingPoint = lastIndexFromGridCache;

    // Slide all the rows UP
    // keep increasing row index, from the deleted RFQ index until last row in my cache
    for (let i = cachedRowIndex; i < endingPoint; i++) {
      const tempRow = gridCache.get(i + 1);
      if (!tempRow) continue;
      logDeleteIteration && log.info('moving index ' + (i + 1) + ' to ' + i);
      gridCache.set(i, tempRow);
      indexMap.set(tempRow.sowkey, i);
    }
    gridCache.delete(endingPoint);

    // Setup grid connection properties before start rendering new values from the cache
    // Clear the map that indicates if a row is in the viewport or not
    // rowsInViewport.clear();

    // Update grid connection properties before next render
    this.context = { ...contextCopy };

    const newLastIndexFromGridCache = this.getLastIndexFromGridCache(requiresRender);
    logDelete && log.info('deleteMessage > newLastIndexFromGridCache', newLastIndexFromGridCache);

    // Check if the deleted row is outside the viewport range, in such case we keep the same bottom range/firstrowIndex
    // const newFirstRowIndex = cachedRowIndex > newLastIndexFromGridCache ? viewportFirstRow : cachedRowIndex;

    // this.sendResultsToViewport(newFirstRowIndex, newLastIndexFromGridCache);

    logDelete &&
      log.info(
        'deleteMessage > sendResultsToViewport',
        cachedRowIndex,
        cachedRowIndex > newLastIndexFromGridCache ? cachedRowIndex : newLastIndexFromGridCache
      );

    this.addDeferredRenderTask(
      'DELETE_MESSAGE',
      cachedRowIndex,
      cachedRowIndex > newLastIndexFromGridCache ? cachedRowIndex : newLastIndexFromGridCache
    );
    // this.sendResultsToViewport(
    //   cachedRowIndex,
    //   cachedRowIndex > newLastIndexFromGridCache ? cachedRowIndex : newLastIndexFromGridCache
    // );

    if (this.options && this.options.notifyOnRFQDeleted) {
      this.handleRFQEvent(WS_COMMANDS.DELETE_MESSAGE, rfqMessage);
    }
    /* } else {
      log.info('❌❌ rowIndex ' + cachedRowIndex + ' not in viewPort range, so deleted');
      gridCache.delete(cachedRowIndex);
    }*/

    // Array.from(gridCache)
    logDelete &&
      log.info(
        '➖ after deletion: ',
        log.level >= log.INFO ? JSON.stringify(gridCache.toJSON().map(([k, v]) => ({ [k]: v.sowkey }))) : null
      );
  };

  ProxyService.prototype.setTotalRecords = function(total) {
    this.rowCountChange && this.rowCountChange(total);

    const isFirstTotalFromNewFilter = this.isFirstTotalFromNewFilter;
    if (isFirstTotalFromNewFilter) {
      this.isFirstTotalFromNewFilter = false;
      const skipUnsubscribeRange = this.skipFirstUnsubscribeRangeRequest;

      if (skipUnsubscribeRange) this.skipFirstUnsubscribeRangeRequest = false;
      if (!skipUnsubscribeRange && !total) this.unsubscribeRange();
    }

    this.sendEventAsync({
      eventType: viewportDataSourceEvents.ROW_COUNT_CHANGED,
      rowCount: total
    });
  };

  ProxyService.prototype.emitViewportRangeEvent = function({ firstRow, lastRow }) {
    this.setViewportRange$.next({ firstRow, lastRow });
  };

  ProxyService.prototype.connect = function(viewportEventListener) {
    this.context = {
      viewportEventListener,
      viewportFirstRow: 0,
      viewPortLastRow: -1,
      requestedViewportFirstRow: 0,
      requestedViewportLastRow: -1,
      rowsInViewport: new Map(),
      gridCache: new SortedMap(),
      indexMap: new Map()
    };

    if (this.options && this.options.notifyOnViewportReady) {
      this.viewportReady && this.viewportReady();
    }
  };

  ProxyService.prototype.resetContext = function() {
    const contextCopy = { ...this.context };
    const { rowsInViewport, gridCache, indexMap } = contextCopy;

    // Clear Maps
    rowsInViewport.clear();
    gridCache.clear();
    indexMap.clear();

    // Clear rfqLegMap in case of reset grid in case a new filter was applied
    this.rfqLegMap.clear();

    return {
      ...contextCopy,
      viewportFirstRow: 0,
      viewPortLastRow: -1,
      requestedViewportFirstRow: 0,
      requestedViewportLastRow: -1
    };
  };

  ProxyService.prototype.sendEventAsync = function(event) {
    const contextCopy = { ...this.context };
    const { viewportEventListener } = contextCopy;
    viewportEventListener(event);
  };

  ProxyService.prototype.disconnect = function() {
    // unsubscribe from observables
    this.subsIntanceSubscription.unsubscribe && this.subsIntanceSubscription.unsubscribe();
    this.sourceSubscription.unsubscribe && this.sourceSubscription.unsubscribe();
    this.filterSubscription.unsubscribe && this.filterSubscription.unsubscribe();
    this.renderFlagSubscription.unsubscribe && this.renderFlagSubscription.unsubscribe();
    this.renderUpdatesFlagSubscription.unsubscribe && this.renderUpdatesFlagSubscription.unsubscribe();
    this.setViewportRangeSubscription.unsubscribe && this.setViewportRangeSubscription.unsubscribe();
    this.checkboxEventSubscription &&
      this.checkboxEventSubscription.unsubscribe &&
      this.checkboxEventSubscription.unsubscribe();
  };

  ProxyService.prototype.setViewportRange = function(firstRow, lastRow) {
    log.info('setViewportRange > firstRow', firstRow, 'lastRow', lastRow);
    logSetViewport && log.info('setViewportRange > firstRow', firstRow, 'lastRow', lastRow);
    const contextCopy = { ...this.context };

    // Update values on the current GridConnectionId
    this.context = {
      ...contextCopy,
      requestedViewportFirstRow: firstRow,
      requestedViewportLastRow: lastRow
    };

    // Set shouldUpdateViewportRange flag to true, so the very first record that belongs to the requested viewport range came in
    // the viewport range will be updated
    this.shouldUpdateViewportRange = true;

    // Turn ON the renderFlag by assigning it values before request more data to the websocket
    // renderflag will change once we receive the group begin message
    // this.renderRange = { firstRow, lastRow };

    // If newCriteria is true (the very first request after viewport calculate the new range)
    // Send the newCriteria flag in the next websocket request command
    if (this.newCriteria) {
      // Make a copy of the current filter criteria flag
      const newCriteria = this.newCriteria;

      // Set the current criteria flag to false
      this.newCriteria = !newCriteria;

      // Send new request command to the websocket including newCriteria flag
      this.requestData({ firstRow, lastRow, newCriteria });
    } else {
      // If newCriteria is false
      // Don't send the newCriteria flag in the next websocket request command
      this.requestData({ firstRow, lastRow });
    }

    this.turnRenderUpdatesFlagOff();
  };

  ProxyService.prototype.sendResultsToViewport = function(
    firstRow,
    lastRow,
    firstRowIndexFromCurrentRequest,
    lastRowIndexFromCurrentRequest
  ) {
    if (firstRow < 0 || lastRow < firstRow) {
      log.warn(`firstRow (${firstRow}) or lastRow (${lastRow}) is not valid`);
      return;
    }

    // Set "isRendering" flag to "true"  to indicate that we will skip any new rendering until we finish the current render
    this.isRenderingGroup = true;
    logRenderingRelated && log.info('sendResultsToViewport > isRenderingGroup > before', this.isRenderingGroup);

    const t0 = performance.now();
    logRenderingRelated &&
      log.info(
        'sendResultsToViewport > range',
        firstRow,
        lastRow,
        'firstRowIndexFromCurrentRequest',
        firstRowIndexFromCurrentRequest,
        'lastRowIndexFromCurrentRequest',
        lastRowIndexFromCurrentRequest
      );

    const contextCopy = { ...this.context };
    const { gridCache, rowsInViewport } = contextCopy;
    const rowDataMap = {};
    let hasDataToSend = false;

    const startPoint =
      typeof firstRowIndexFromCurrentRequest === 'number'
        ? firstRowIndexFromCurrentRequest > firstRow
          ? firstRowIndexFromCurrentRequest
          : firstRow
        : firstRow;

    const endPoint =
      typeof lastRowIndexFromCurrentRequest === 'number'
        ? lastRowIndexFromCurrentRequest < lastRow
          ? lastRowIndexFromCurrentRequest
          : lastRow
        : lastRow;

    logRenderingRelated && log.info('sendResultsToViewport > startPoint', startPoint);
    logRenderingRelated && log.info('sendResultsToViewport > endPoint', endPoint);

    for (let i = startPoint; i <= endPoint; i++) {
      if (rowsInViewport.has(i)) {
        continue;
      }

      if (gridCache.has(i)) {
        rowDataMap[i] = gridCache.get(i);
        rowsInViewport.set(i, true);
      } else {
        rowDataMap[i] = null; // gridCache.get(i);
        // We don't add the rowsInViewport in the Map because we want to override this row later on
        // rowsInViewport.set(i, true);
      }

      if (!hasDataToSend) {
        hasDataToSend = true;
      }
    }

    logRenderingRelated &&
      log.info('sendResultsToViewport > hasDataToSend', hasDataToSend, Object.keys(rowDataMap).length);
    logRenderingRelated &&
      log.info('sendResultsToViewport', log.level >= log.INFO ? JSON.stringify(Object.keys(rowDataMap)) : null);

    if (hasDataToSend) {
      this.context = { ...contextCopy };

      logMetrics && log.info('sending row data:', rowDataMap, ' | ', format(new Date(), 'hh:mm:ss:SSS'));

      this.sendEventAsync({
        eventId: format(new Date(), 'hh:mm:ss:SSS'),
        eventType: viewportDataSourceEvents.ROW_DATA,
        rowDataMap: rowDataMap
      });
    }

    const t1 = performance.now();
    logRenderingRelated && log.info('sendResultsToViewport took ' + (t1 - t0) + ' milliseconds.');
    this.isRenderingGroup = false;
    logRenderingRelated && log.info('sendResultsToViewport> isRenderingGroup > after', this.isRenderingGroup);
  };

  ProxyService.prototype.getRowCount = function() {
    const contextCopy = { ...this.context };
    const { gridCache } = contextCopy;
    return Object.keys(gridCache).length;
  };

  ProxyService.prototype.getLastIndexFromGridCache = function(isRendering) {
    const contextCopy = { ...this.context };
    const { gridCache, viewPortLastRow } = contextCopy;

    if (!gridCache) return -1;

    const keysArray = gridCache.keysArray();
    if (!keysArray.length) return -1;

    if (isRendering) return keysArray.reverse().find(x => x <= viewPortLastRow);

    const lastRowIndex = keysArray.pop();
    let lastRowInActiveRange = viewPortLastRow;

    if (lastRowIndex > viewPortLastRow) {
      for (let i = viewPortLastRow; i <= lastRowIndex; i++) {
        if (gridCache.has(i)) {
          lastRowInActiveRange = i;
        } else {
          break;
        }
      }
      return lastRowInActiveRange;
    }
    return lastRowIndex;
  };

  ProxyService.prototype.setAutoSelectState = function(checkboxEventValue) {
    this.sendEventAsync({
      eventType: viewportDataSourceEvents.SELECT_ALL_CHECKBOX_CHANGED,
      checkboxEventValue
    });
  };

  ProxyService.prototype.handleRFQEvent = function(rfqEventType, data) {
    const rfqEventPayload = {
      type: rfqEventType,
      data
    };
    this.sendRFQEvent(rfqEventPayload);
  };

  ProxyService.prototype.selectNewRFQ = function(rowIndex) {
    if (this.options && this.options.forceSelectNewRFQ) {
      if (this.isFirstNewRFQ) {
        this.isFirstNewRFQ = false;
        this.delayExecution(
          SELECT_RFQ,
          () => this.sendEventAsync({ eventType: viewportDataSourceEvents.SELECT_ROW, rowIndex }),
          selectOnlyFirstNewRFQInterval
        );
      } else {
        this.sendEventAsync({ eventType: viewportDataSourceEvents.SELECT_ROW, rowIndex });
      }
    }
  };

  ProxyService.prototype.delayExecution = function(eventType, callback, delayInterval) {
    of(eventType)
      .pipe(delay(delayInterval))
      .subscribe(() => callback());
  };

  ProxyService.prototype.resetRowsInViewport = function() {
    const contextCopy = { ...this.context };
    const { rowsInViewport } = contextCopy;

    // Clear Maps
    rowsInViewport.clear();
    this.context = { ...contextCopy };
  };

  ProxyService.prototype.updateConnectionStatus = function(status) {
    if (this.setConnection) this.setConnection(status);
  };

  ProxyService.prototype.notifyOnGroupEnd = function() {
    if (this.options && this.options.notifyOnGroupEnd) this.handleRFQEvent(WS_COMMANDS.GROUP_END);
  };

  ProxyService.prototype.notifyOnEntitlementError = function() {
    if (this.options && this.options.notifyOnEntitlementError) this.handleRFQEvent(WS_COMMANDS.ENTITLEMENT_ERROR);
  };

  ProxyService.prototype.simulateViewportInitialAssignment = function(rfqTotal) {
    if (this.options && this.options.forceInitialRender && !this.forceViewportInitialAssignment && rfqTotal) {
      this.forceViewportInitialAssignment = !this.forceViewportInitialAssignment;

      // Set initial viewport range on the renderFlag
      this.renderRange = { firstRow: 0, lastRow: rfqTotal - 1 };

      // Set initial values on the current GridConnectionId
      const contextCopy = { ...this.context };

      this.context = {
        ...contextCopy,
        viewportFirstRow: 0,
        viewPortLastRow: rfqTotal - 1
      };
    }
  };

  ProxyService.prototype.addDeferredRenderTask = function(action, firstRow, lastRow) {
    if (firstRow === lastRow) {
      this.deferredUpdates.set(firstRow, action);
      return;
    }

    for (let i = firstRow; i <= lastRow; i++) {
      this.deferredUpdates.set(i, action);
    }
  };

  ProxyService.prototype.setReferenceKeys = function(columns) {
    columns.forEach(col => {
      if (col.codeinstruction && col.codeinstruction.referenceKey) {
        this.referenceKeysArray.push({ colId: col.sourcecolumnname, referenceKey: col.codeinstruction.referenceKey });
      }
    });
  };

  ProxyService.prototype.updateRenderingTimestamp = function() {
    const now = Date.now();

    this.renderingTimestamp = now + renderUpdatesInterval;
  };

  ProxyService.prototype.shouldRenderGroup = function() {
    const now = Date.now();

    return !this.isRenderingGroup && now < this.renderingTimestamp;
  };

  ProxyService.prototype.shouldRenderUpdate = function() {
    const now = Date.now();

    return !this.isRenderingUpdates && now < this.renderingTimestamp;
  };

  return new ProxyService(
    subscriptionInstance$,
    data$,
    filter$,
    onRequest,
    onRowCountChange,
    proxyOptions,
    checkboxEvent$,
    onConnectionChange,
    onRFQEvent,
    onViewportReady,
    unsubscribeRange
  );
}

// Check that all the items in the legArray are correctly ordered
function isLegArrayOrdered(arr) {
  for (let i = 0; i < arr.length - 1; i++) {
    if (!arr[i + 1] || arr[i + 1].rowIndex <= arr[i].rowIndex) return false;
  }
  return true;
}

// Check that all the items in the legArray are defined and have the property rowIndex
function isLegArrayFilled(arr) {
  for (let i = 0; i < arr.length; i++) {
    if (!arr[i] || arr[i].rowIndex === undefined) return false;
  }
  return true;
}

// Return the first and last rowIndex values from the legArray
function getViewportRangeFromLegArray(arr) {
  const legArr = [...arr];
  const { rowIndex: firstRowIndex } = legArr.shift();
  const { rowIndex: lastRowIndex } = legArr.pop();
  return { firstRowIndex, lastRowIndex };
}

// Update the legArray rowIndex properties for all items using the indexMap
function updateRowIndexinLegArray(arr, indexMap) {
  const legArr = [...arr];

  return legArr.map(item => {
    if (!item) return item;

    return indexMap.has(item.sowkey)
      ? {
          sowkey: item.sowkey,
          rowIndex: indexMap.get(item.sowkey)
        }
      : item;
  });
}
