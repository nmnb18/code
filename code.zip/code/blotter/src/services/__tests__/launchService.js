import { shouldRecordUsage } from '../launcherService';
import { skipUsageRecordAfterRestartMinute } from '../openfinConfig';

describe('launchService', () => {
  let realDate;
  describe('shouldRecordUsage', () => {
    test('return true if current time now is less than restarts time', () => {
      const realDateNow = Date.now.bind(global.Date);
      const dateNowStub = jest.fn(() => 1511760535852);
      global.Date.now = dateNowStub;
      const result = shouldRecordUsage('5', skipUsageRecordAfterRestartMinute);
      expect(result).toBe(true);
      global.Date.now = realDateNow;
    });
    test('return false for 2mins after application restarts', () => {
      const currentDate = new Date('2021-01-27T15:15:49.484Z');
      realDate = Date;
      global.Date = class extends Date {
        constructor(date) {
          if (date) {
            return super(date);
          }
          return currentDate;
        }
      };
      const result = shouldRecordUsage('15:15', skipUsageRecordAfterRestartMinute);
      expect(result).toBe(false);
      global.Date = realDate;
    });

    test('return true after 2mins of application restarts', () => {
      const currentDate = new Date('2021-01-27T15:15:49.484Z');
      realDate = Date;
      global.Date = class extends Date {
        constructor(date) {
          if (date) {
            return super(date);
          }
          return currentDate;
        }
      };
      const result = shouldRecordUsage('5', skipUsageRecordAfterRestartMinute);
      expect(result).toBe(true);
      global.Date = realDate;
    });
  });
});
