import {
  getCustomCellRenderer,
  getCustomCellRendererParams,
  isColumnResizable,
  getMinWidth
} from '~services/integrationService';
import { customRenderingColumns } from '~helpers/globals';

describe('integrationService', () => {
  describe('getCustomCellRenderer', () => {
    test('column have custom cell renderer', () => {
      const sourcecolumnname = 'axeside';
      const result = getCustomCellRenderer(sourcecolumnname, customRenderingColumns);
      expect(result).not.toBeNull();
      expect(result).toBeInstanceOf(Function);
    });

    test('column have not custom cell renderer', () => {
      const sourcecolumnname = 'axeside1';
      const result = getCustomCellRenderer(sourcecolumnname, customRenderingColumns);
      expect(result).toBeNull();
    });
  });

  describe('getCustomCellRendererParams', () => {
    test('column have custom cell renderer parameters', () => {
      const sourcecolumnname = 'axeside';
      const result = getCustomCellRendererParams(sourcecolumnname, customRenderingColumns, 'jvento');
      expect(result).not.toBeNull();
      expect(result.columnCallback).toBeInstanceOf(Function);
      expect(result.currentUser).toBe('jvento');
    });

    test('column have not custom cell renderer parameters', () => {
      const sourcecolumnname = 'axeside1';
      const result = getCustomCellRendererParams(sourcecolumnname, customRenderingColumns, 'jvento');
      expect(result).toBeNull();
    });
  });
  describe('isColumnResizable', () => {
    test('column is resizable', () => {
      const codeinstruction = { minWidth: 20, styleName: 'col-tag-axe' };
      const result = isColumnResizable(codeinstruction);
      expect(result).toBeTruthy();
    });

    test('column is not resizable', () => {
      const codeinstruction = { styleName: 'col-tag-axe' };
      const result = isColumnResizable(codeinstruction);
      expect(result).toBeFalsy();
    });
  });

  describe('getMinWidth', () => {
    test('column have minimum width', () => {
      const codeinstruction = { minWidth: 20, styleName: 'col-tag-axe' };
      const result = getMinWidth(codeinstruction);
      expect(result).toEqual(20);
    });

    test('column have not minimum width', () => {
      const codeinstruction = { styleName: 'col-tag-axe' };
      const result = getMinWidth(codeinstruction);
      expect(result).toEqual(null);
    });
  });
});
