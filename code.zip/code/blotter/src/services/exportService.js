import { createExcelExportService } from '~services/excelExportService';
import { FETCH_TRIGGERS } from '~helpers/jasperMessage';
import { copyHtmlToClipboard } from '~helpers/copyToClipboard';

export const exportData = ({ target, payload, callback, processedRecord$, disconnectExportDataCaching }) => {
  switch (target) {
    case FETCH_TRIGGERS.EXPORT_TO_EXCEL_AS_DOWNLOAD:
    case FETCH_TRIGGERS.EXPORT_TO_EXCEL_AND_OPEN: {
      return createExcelExportService(payload, target, callback, processedRecord$, disconnectExportDataCaching);
    }
    case FETCH_TRIGGERS.COPY_TO_CLIPBOARD: {
      copyHtmlToClipboard(payload);
      callback();
      disconnectExportDataCaching();
      return;
    }
    default:
      return;
  }
};
