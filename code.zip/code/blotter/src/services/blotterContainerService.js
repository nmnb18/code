import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import * as usageService from '~services/usageService';
import { flowBlotterService } from '~services/flowBlotterService';

const rfqPopupToggleDebounceTime = 500;

class BlotterContainerService {
  constructor() {
    this.blotterContainerRequestClose$ = new Subject();
    this.toggleRFQPopup$ = new Subject();
  }

  initFlow = () => {
    this.toggleRFQPopupSubscription = this.toggleRFQPopup$
      .pipe(debounceTime(rfqPopupToggleDebounceTime))
      .subscribe(({ isRFQNotificationToggleOn, blotterUserSettings, flowNavigatorUser }) => {
        usageService.sendUsage({
          userAction: usageService.actions.RFQ,
          notes: { Action: isRFQNotificationToggleOn ? 'ON' : 'OFF' }
        });

        flowBlotterService.sendMessage({ userSettings: blotterUserSettings });
      });
  };

  toggleRFQPopup = ({ isRFQNotificationToggleOn, blotterUserSettings, flowNavigatorUser }) => {
    this.toggleRFQPopup$.next({
      isRFQNotificationToggleOn,
      blotterUserSettings,
      flowNavigatorUser
    });
  };

  closeApp = () => {
    this.blotterContainerRequestClose$.next('CLOSE_APP');
  };
}

const blotterContainerService = new BlotterContainerService();

export { blotterContainerService };
