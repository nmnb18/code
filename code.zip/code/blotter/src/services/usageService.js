import { of, Subject } from 'rxjs';
import { catchError, concatMap } from 'rxjs/operators';
import {
  appUsageRecordingTopic,
  applicationRestartHourUTC,
  skipUsageRecordAfterRestartMinute
} from '~services/openfinConfig';
import {
  APP_NAME,
  APP_PLATFORM,
  CONTAINER_ADD_INQUIRY_TITLE,
  CONTAINER_ADD_PORTFOLIO_TITLE,
  CONTAINER_MANAGE_INQUIRY_TITLE,
  CONTAINER_MANAGE_PORTFOLIO_TITLE
} from '~helpers/globals';
import { jasperPut } from './jasperApiService';
import { usageApi } from './apiConfig';
import { shouldRecordUsage } from './launcherService';
import { applicationRestartTimezone } from '~services/openfinConfig';
import { hasItems } from 'flow-navigator-shared/dist/array';
import { iabPublish } from '~services/openfinService';

const usageActions$ = new Subject();

const actionsWithoutNotes = {
  OVERNIGHT_RESTARTS: 'Overnight Restart',
  LAUNCH: 'Application Launch',
  CLOSE_APP: 'Application Close',
  RETURN_SELF: 'Return to self',
  FOCUSED: 'Application Focused',
  CLEAR_SORTING: 'Clear Sorting',
  CONTAINER_ADD_INQUIRY_TITLE,
  CONTAINER_ADD_PORTFOLIO_TITLE,
  CONTAINER_MANAGE_INQUIRY_TITLE,
  CONTAINER_MANAGE_PORTFOLIO_TITLE,
  MADISON_ASSIST_NAVIGATE: 'Madison Assist Navigate'
};

export const actions = {
  ...actionsWithoutNotes,
  NAVIGATE: 'Navigate',
  IMPERSONATE: 'Impersonate',
  RFQ: 'RFQ Popup',
  SEARCH: 'Search',
  COPY: 'Copy',
  SAVE: 'Save',
  VIEW: 'View',
  QUICK_FILTER: 'Quick Filter',
  PERSONAL_TRANSACTION: 'Personal Transaction',
  LIVE_RECORDS: 'Live Records',
  AXE_DIRECTION_MATCH_FILTER: 'Axe Direction Match',
  SIZE_IN_THOUSANDS_FILTER: 'Size 000s',
  APPLY_FILTER: 'Apply Filter',
  RESET_FILTER: 'Reset Filter',
  SORTING: 'Sorting',
  BLOTTER_CLICK: 'Blotter Click',
  RFQ_CLICK: 'RFQ Popup Click',
  CLEAR_FILTER: 'Clear Filter',
  COLUMN_CHOOSER: 'Column Chooser',
  BBG_NAVIGATE: 'BBG Navigate',
  RIGHT_CLICK: 'Right Click',
  ENTITLEMENT_CONTROL: 'Entitlement Control',
  RFQ_POPUP_TOGGLE: 'RFQ Popup Toggles',
  RFQ_POPUP_VIEWS: 'RFQ Popup Views',
  VIEW_ADD_COLUMN: 'Add',
  VIEW_REMOVE_COLUMN: 'Remove',
  VIEW_PIN_COLUMN: 'Pin',
  VIEW_UNPIN_COLUMN: 'Unpin',
  FLOW_BLOTTER_TOGGLE: 'Flow Blotter Toggles',
  CHANGE_THEME: 'Change Theme'
};

export const BLOTTER_CLICK_ACTION_LABELS = {
  clientname: 'Client Details',
  code: 'Bond Details',
  description: 'Bond Details'
};

export const usageTriggers = {
  flowBlotter: 'Flow Blotter',
  rfqPopup: 'RFQ Popup'
};

const updateUsage = payload => {
  let { AppName, UserAction, Notes } = payload[0];
  if (Notes && JSON.stringify(Notes).length > 500) {
    Notes = JSON.stringify(Notes).slice(0, 497) + '...';
    payload[0].Notes = Notes;
  }
  console.log(`USAGE (${AppName}): ${UserAction} ${hasItems(Object.keys(Notes)) ? JSON.stringify(Notes) : ''}`);
  const url = usageApi();
  return jasperPut(url, payload);
};

// Variables for keep a references to the currentUser and impersonatedUser states from the UserContext
let blotterCurrentUser = null;
let blotterImpersonatedUser = null;
let blotterApp = APP_NAME;

export const setUser = user => (blotterCurrentUser = user);

export const setImpersonatedUser = impersonatedUser => {
  blotterImpersonatedUser = impersonatedUser ? { id: impersonatedUser.id, name: impersonatedUser.name } : null;
};
export const setBlotterApp = appName => (blotterApp = appName);

export const sendUsage = ({ userAction, notes = {} }) => {
  if (!shouldRecordUsage(applicationRestartHourUTC, applicationRestartTimezone, skipUsageRecordAfterRestartMinute))
    return;

  const payLoad = getStandardPayLoad(userAction, blotterCurrentUser, blotterApp, blotterImpersonatedUser, notes);
  usageActions$.next([payLoad]);
};

export const sendUsageForRFQ = ({ userAction, notes }) => {
  if (!shouldRecordUsage(applicationRestartHourUTC, applicationRestartTimezone, skipUsageRecordAfterRestartMinute))
    return;

  const payload = { userAction, notes };

  iabPublish({
    topic: appUsageRecordingTopic,
    message: payload,
    logLabel: 'Usage publish'
  });
};

const enhanceNotes = (impersonatedUser, notes) => ({
  Notes: {
    ...(impersonatedUser && { LoginAs: impersonatedUser }),
    ...notes
  }
});

const getStandardPayLoad = (userAction, currentUser, appName, impersonatedUser, notes) => {
  const basePayload = {
    UserAction: userAction,
    UserName: currentUser,
    AppName: appName,
    AppPlatform: APP_PLATFORM
  };
  const shouldIncludeNotes = !Object.values(actionsWithoutNotes).includes(userAction);
  const optionalNotes = shouldIncludeNotes ? enhanceNotes(impersonatedUser, notes) : { Notes: {} };

  return { ...basePayload, ...optionalNotes };
};

export const initUpdateUsageSubscription = () => {
  return usageActions$
    .pipe(
      concatMap(payload =>
        updateUsage(payload).pipe(
          catchError(err => {
            console.log(`Error sending USAGE: ${JSON.stringify(err)} `);
            return of(null);
          })
        )
      )
    )
    .subscribe();
};
