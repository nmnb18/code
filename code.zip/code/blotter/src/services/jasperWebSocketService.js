import { throwError, Subject } from 'rxjs';
import { catchError, map, filter, withLatestFrom, tap } from 'rxjs/operators';
import { jasperWs } from './apiConfig';
import { isJson } from '~helpers/json';
import { WS_COMMANDS, mapMessage, getType } from '~helpers/jasperMessage';
import { WSSubscriptionService } from './WSSubscriptionService/WSSubscriptionService';

const jasperWSLog = 'Jasper Websocket connection';

const NO_PROVIDED_USER = 'No Provided User';

const shouldApplyFilterOnCommand = command =>
  command === WS_COMMANDS.GROUPBEGIN ||
  command === WS_COMMANDS.NEW_MESSAGE_SOW ||
  command === WS_COMMANDS.GROUPEND ||
  command === WS_COMMANDS.UPDATE_MESSAGE ||
  command === WS_COMMANDS.NEW_MESSAGE ||
  command === WS_COMMANDS.DELETE_MESSAGE;

const getParamFromUrl = (url, key) => {
  const params = new URL(url).searchParams;

  return params.get(key);
};

const logWsWarningError = message => {
  const { type, command, elements, sowkey } = message.data;
  if (!type && command === 'WARNING') {
    console.error(`Websocket connection error: ${elements}`);
  } else if (message.source.includes('rfqNotification')) {
    if (elements.key_id_dup) {
      console.log(`rfqPopup WS message: '${command}': /key_id="${elements.key_id_dup}"`);
    } else {
      if (command === WS_COMMANDS.ACK) {
        console.log(`rfqPopup WS message: '${command}'. Totals is ${elements.RFQTotal}`);
      } else {
        console.log(`rfqPopup WS message: '${command}'. sowkey: ${sowkey}`);
      }
    }
  }
};

/**
 * This class will be a generic implemetation of WebSocket provided by Server Side.
 * Individual react component can use this as a base and can customise based on
 * their need by passing appropriate filters.
 */
export class JasperWebSocketService {
  /**
   * Constructor for JasperWebSocketService
   * @param wsMessageTypeToSubscribe Array of WS Message Types to be subscribed. We will use these to filter the messages.
   */
  constructor(wsMessageTypeToSubscribe, wsFilterSubject, wsUrl) {
    this.jasperWebSocket = null;
    this.wSSubscriptionService = null;
    this.wsMessageTypeToSubscribe = wsMessageTypeToSubscribe;
    this.columnsDictionaries = null;
    this.wsFilterSubject = wsFilterSubject;
    this.jasperSubject = new Subject();
    this.ampsStatusSubject = new Subject();

    this.jasperWebSocketConfig = {
      url: wsUrl,
      reconnectMinimumInterval: jasperWs.reconnectMinimumInterval,
      reconnectAttemptTime: jasperWs.reconnectAttemptTime,
      reconnectVariability: jasperWs.reconnectVariability,
      serializer: msg => msg,
      deserializer: ({ data }) => {
        if (isJson(data)) {
          return JSON.parse(data);
        } else {
          return data;
        }
      },
      onOpenConnection: event => {
        const {
          target: { url }
        } = event;
        const user = (getParamFromUrl(url, 'user') || NO_PROVIDED_USER).toUpperCase();
        console.log(`${jasperWSLog} open for user ${user} at ${new Date().toString()}`);
      },
      onClosingConnection: () => {
        console.log(`${jasperWSLog} closer process started at ${new Date().toString()}`);
      },
      onCloseConnection: event => {
        const {
          target: { url }
        } = event;
        const user = (getParamFromUrl(url, 'user') || NO_PROVIDED_USER).toUpperCase();
        console.log(`${jasperWSLog} closed for user ${user} at ${new Date().toString()}`);
      }
    };
  }

  connect(params, columnsDictionaries) {
    const {
      serializer,
      deserializer,
      onOpenConnection,
      onCloseConnection,
      onClosingConnection,
      reconnectMinimumInterval,
      reconnectAttemptTime,
      reconnectVariability
    } = this.jasperWebSocketConfig;

    let { url } = this.jasperWebSocketConfig;
    if (params) {
      const queryString = Object.keys(params)
        .map(key => `${key}=${params[key]}`)
        .join('&');
      url = `${url}?${queryString}`;
    }

    this.columnsDictionaries = columnsDictionaries;

    this.wSSubscriptionService = new WSSubscriptionService(
      url,
      serializer,
      deserializer,
      onOpenConnection,
      onCloseConnection,
      onClosingConnection,
      reconnectMinimumInterval,
      reconnectAttemptTime,
      reconnectVariability
    );

    this.jasperWebSocket = this.wSSubscriptionService.getWebSocket$();

    const jasperWS$ = this.jasperWebSocket.pipe(
      tap(message => logWsWarningError(message)),
      filter(message => this.wsMessageTypeToSubscribe.includes(getType(message)))
    );
    const filterWS$ = this.wsFilterSubject;

    jasperWS$
      .pipe(
        withLatestFrom(filterWS$),
        // filter(this.handleWsFilterOnWsMessage),
        map(this.handleWsMessage),
        tap(this.handleAmpsStatusChange),
        catchError(this.handleWsErrorMessage)
      )
      .subscribe(value => this.jasperSubject.next(value));
  }

  close() {
    const skipReconnect = true;
    this.jasperWebSocket.complete();
    this.jasperWebSocket.close(skipReconnect);
    this.jasperWebSocket = null;
  }

  send(message) {
    this.jasperWebSocket && this.jasperWebSocket.send(message);
  }

  handleWsFilterOnWsMessage = ([message, wsFilter]) => {
    if (!wsFilter) return true;
    if (wsFilter && wsFilter.source !== message.source) return true;
    if (!shouldApplyFilterOnCommand(message.data.command)) return true;

    return message.data.vpFirstRow === wsFilter.vpFirstRow && message.data.vpLastRow === wsFilter.vpLastRow;
  };

  handleAmpsStatusChange = message => {
    const { command } = message;

    if (command === WS_COMMANDS.DISCONNECT) {
      this.ampsStatusSubject.next(false);
    } else if (command === WS_COMMANDS.CONNECT) {
      this.ampsStatusSubject.next(true);
    }
  };

  handleWsMessage = ([message]) => mapMessage(message, this.columnsDictionaries);

  handleWsErrorMessage = error => {
    console.log(`Error at ${new Date().toString()} ` + error);
    return throwError('Jasper Websocket error', error);
  };

  get datasource() {
    return this.jasperSubject && this.jasperSubject.asObservable();
  }

  get connectionStatus() {
    return this.jasperWebSocket && this.jasperWebSocket.connectionStatus;
  }

  get ampsStatus() {
    return this.ampsStatusSubject && this.ampsStatusSubject.asObservable();
  }

  get dataSourceFilterSubject() {
    return this.wsFilterSubject;
  }
}
