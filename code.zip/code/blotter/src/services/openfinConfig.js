export const appUsageRecordingTopic = process.env.REACT_APP_USAGE_RECORDING_TOPIC;
export const applicationToggleRFQTopic = process.env.REACT_APP_RFQ_POPUP_TOGGLE_TOPIC;
export const applicationRestartHourUTC = process.env.REACT_APP_APPLICATION_RESTART_HOUR_UTC;
export const applicationRestartTimezone = process.env.REACT_APP_APPLICATION_RESTART_TIMEZONE;
export const applicationSendLogsOffsetMinutes = process.env.REACT_APP_APPLICATION_SEND_LOGS_OFFSET;
export const appUserSettingsTopic = process.env.REACT_APP_USER_SETTINGS_TOPIC;
export const appUserSharedSettingsTopic = process.env.REACT_APP_USER_SHARED_SETTINGS_TOPIC;
export const skipUsageRecordAfterRestartMinute = process.env.REACT_APP_SKIP_USAGE_RECORD_AFTER_RESTART_MINUTE;
export const recordOvernightRestartSecond = parseInt(process.env.REACT_APP_RECORD_OVERNIGHT_RESTART_SECOND);

export const userSettingsSyncTopic = process.env.REACT_APP_USER_SETTINGS_SYNC_TOPIC;

export const rfqNotificationTopicForChild = process.env.REACT_APP_RFQ_NOTIFICATION_TOPIC_FOR_CHILD;
export const rfqNotificationTopicForParent = process.env.REACT_APP_RFQ_NOTIFICATION_TOPIC_FOR_PARENT;

export const rfqNotificationActions = {
  rfqNotificationPopupMounted: 'RFQ_NOTIFICATION_POPUP_MOUNTED',
  rfqNotificationPopupClose: 'RFQ_NOTIFICATION_POPUP_CLOSE',
  rfqNotificationGridReadyForReceiveData: 'RFQ_NOTIFICATION_GRID_READY_FOR_RECEIVE_DATA',
  rfqNotificationForceSelectNewRFQ: 'RFQ_NOTIFICATION_FORCE_SELECT_NEW_RFQ',
  rfqNotificationSendStateChanges: 'RFQ_NOTIFICATION_SEND_STATE_CHANGES',
  rfqNotificationSendRFQMessage: 'RFQ_NOTIFICATION_SEND_RFQ_MESSAGE',
  rfqNotificationSendStepMessage: 'RFQ_NOTIFICATION_SEND_STEP_MESSAGE',
  rfqNotificationRequestData: 'RFQ_NOTIFICATION_REQUEST_DATA',
  rfqNotificationPopupToggle: 'RFQ_NOTIFICATION_POPUP_TOGGLE',
  rfqNotificationRequestUnsubscribeRange: 'RFQ_NOTIFICATION_REQUEST_UNSUBSCRIBE_RANGE',
  rfqNotificationRequestMultiFilter: 'RFQ_NOTIFICATION_REQUEST_MULTI_FILTER',
  rfqNotificationSendMultiFilterMessage: 'RFQ_NOTIFICATION_SEND_MULTI_FILTER_MESSAGE',
  rfqNotificationPopupReload: 'RFQ_NOTIFICATION_POPUP_RELOAD',
  rfqNotificationUpdateTheme: 'RFQ_NOTIFICATION_UPDATE_THEME',
  rfqNotificationReloadCommand: 'RFQ_NOTIFICATION_POPUP_RELOAD_COMMAND'
};

/* Flow blotter topics */
export const flowBlotterTopicForChild = process.env.REACT_APP_FLOW_BLOTTER_TOPIC_FOR_CHILD;
export const flowBlotterTopicForParent = process.env.REACT_APP_FLOW_BLOTTER_TOPIC_FOR_PARENT;

export const flowBlotterEventsTopicForChild = process.env.REACT_APP_FLOW_BLOTTER_EVENTS_TOPIC_FOR_CHILD;
export const flowBlotterEventsTopicForParent = process.env.REACT_APP_FLOW_BLOTTER_EVENTS_TOPIC_FOR_PARENT;

export const flowBlotterUserSettingsTopicForChild = process.env.REACT_APP_FLOW_BLOTTER_USER_SETTINGS_TOPIC_FOR_CHILD;
export const flowBlotterUserSettingsTopicForParent = process.env.REACT_APP_FLOW_BLOTTER_USER_SETTINGS_TOPIC_FOR_PARENT;

export const flowBlotterChangesFoundTopicForChild = process.env.REACT_APP_FLOW_BLOTTER_CHANGES_FOUND_TOPIC_FOR_CHILD;
export const flowBlotterChangesFoundTopicForParent = process.env.REACT_APP_FLOW_BLOTTER_CHANGES_FOUND_TOPIC_FOR_PARENT;

export const rfqFlowBlotterTopicForChild = process.env.REACT_APP_RFQ_FLOW_BLOTTER_TOPIC_FOR_CHILD;
export const rfqFlowBlotterTopicForParent = process.env.REACT_APP_RFQ_FLOW_BLOTTER_TOPIC_FOR_PARENT;

export const multiFilterRFQBlotterPopupTopicForChild =
  process.env.REACT_APP_MULTI_FILTER_RFQ_BLOTTER_POPUP_TOPIC_FOR_CHILD;
export const multiFilterFlowBlotterTopicForChild = process.env.REACT_APP_MULTI_FILTER_FLOW_BLOTTER_TOPIC_FOR_CHILD;

export const flowBlotterActions = {
  mounted: 'FLOW_BLOTTER_MOUNTED',
  closingBlotterApp: 'FLOW_BLOTTER_CLOSING_APP',
  switchingBlotterApp: 'FLOW_BLOTTER_SWITCHING_BLOTTER_APP',
  reloadBlotterApp: 'FLOW_BLOTTER_RELOAD_APP',
  updatedUserSettings: 'FLOW_BLOTTER_UPDATED_USER_SETTINGS',

  assignBlotterUser: 'FLOW_BLOTTER_ASSIGN_BLOTTER_USER',
  flowBlotterClose: 'FLOW_BLOTTER_CLOSE',
  flowBlotterGridReadyForReceiveData: 'FLOW_BLOTTER_GRID_READY_FOR_RECEIVE_DATA',
  flowBlotterRequestData: 'FLOW_BLOTTER_REQUEST_DATA',
  flowBlotterRequestUnsubscribe: 'FLOW_BLOTTER_REQUEST_UNSUBSCRIBE',
  flowBlotterRequestUnsubscribeRange: 'FLOW_BLOTTER_REQUEST_UNSUBSCRIBE_RANGE',
  flowBlotterRequestMultiFilter: 'FLOW_BLOTTER_REQUEST_MULTI_FILTER',

  requestUserSettings: 'FLOW_BLOTTER_REQUEST_USER_SETTINGS',
  setUserSettings: 'FLOW_BLOTTER_SET_USER_SETTINGS',
  requestUserEntitlement: 'FLOW_BLOTTER_REQUEST_USER_ENTITLEMENT',
  setUserEntitlement: 'FLOW_BLOTTER_SET_USER_ENTITLEMENT'
};

export const exportDataSourceTopicForChild = process.env.REACT_APP_EXPORT_DATA_SOURCE_TOPIC_FOR_CHILD;
export const exportDataSourceTopicForParent = process.env.REACT_APP_EXPORT_DATA_SOURCE_TOPIC_FOR_PARENT;

export const rfqExportDataSourceTopicForChild = process.env.REACT_APP_RFQ_EXPORT_DATA_SOURCE_TOPIC_FOR_CHILD;
export const rfqExportDataSourceTopicForParent = process.env.REACT_APP_RFQ_EXPORT_DATA_SOURCE_TOPIC_FOR_PARENT;

export const exportDataSourceActions = {
  exportDataSourceReadyForReceiveData: 'EXPORT_DATA_SOURCE_READY_FOR_RECEIVE_DATA',
  exportDataSourceRequestData: 'EXPORT_DATA_SOURCE_REQUEST_DATA'
};

export const flowNavigatorConfigurationTopic = process.env.REACT_APP_FLOW_NAVIGATOR_CONFIGURATION_TOPIC;

export const configurationActions = {
  flowNavigatorSetOptions: 'FN_OPTIONS'
};
