const fin = window.fin;

export const DATA_COMMANDS = {
  YAS: {
    command: 'YAS',
    legs: '1'
  },
  DES: {
    command: 'DES',
    legs: '1'
  },
  SS: {
    command: 'SS',
    legs: '2'
  },
  BFLY: {
    command: 'BFLY',
    legs: '3'
  },
  ALLQ: {
    command: 'ALLQ',
    legs: '1'
  },
  HDS: {
    command: 'HDS',
    legs: '1'
  },
  DDIS: {
    command: 'DDIS',
    legs: '1'
  },
  YTC: {
    command: 'YTC',
    legs: '1'
  },
  QR: {
    command: 'QR',
    legs: '1'
  },
  CN: {
    command: 'CN',
    legs: '1'
  },
  AGGD: {
    command: 'AGGD',
    legs: '1'
  }
};

export const IBCHAT_COMMAND = {
  label: 'IB CHAT',
  command: 'SCHAT'
};

export const BBG_TERMINAL_TYPE = 'DDE';

export const executeBBGSendKeysCommand = ({
  command,
  args,
  listener = () => {},
  onSuccess = () => {},
  onError = () => {},
  bloombergTerminalWindow
}) => {
  if (!command || !args) {
    console.error(`Bloomberg integration fail. Invalid command or arguments were provided.`);
  }

  let formattedArgs;
  if (typeof args === 'string') {
    formattedArgs = args;
  } else if (typeof args === 'object' && Array.isArray(args)) {
    formattedArgs = args.join(' ');
  } else {
    console.error(`Bloomberg ${command} command fail. Invalid arguments were provided`);
  }

  // TODO: Remove following 2 lines once integration to bloomberg is done
  console.log('Executing following Bloomberg command');
  console.log(`${bloombergTerminalWindow} ${command} ${formattedArgs}`);

  fin.System.launchExternalProcess({
    alias: 'BBGSendKeys',
    arguments: `${bloombergTerminalWindow} ${command} ${formattedArgs}`,
    listener
  })
    .then(onSuccess)
    .catch(onError);
};

export const executeBBGCommandConsole = ({
  command,
  args,
  listener = () => {},
  onSuccess = () => {},
  onError = () => {},
  bloombergTerminalWindow
}) => {
  if (!command || !args) {
    console.error(`Bloomberg integration fail. Invalid command or arguments were provided.`);
  }
  let commandType = 'SIMPLE';
  if (
    command === DATA_COMMANDS.SS.command ||
    command === DATA_COMMANDS.BFLY.command ||
    command === IBCHAT_COMMAND.command
  ) {
    commandType = 'COMPLEX';
  }
  let formattedArgs;
  if (typeof args === 'string') {
    formattedArgs = args;
  } else if (typeof args === 'object' && Array.isArray(args)) {
    formattedArgs = args.join(' ');
  } else {
    console.error(`Bloomberg ${command} command fail. Invalid arguments were provided`);
  }

  // TODO: Remove following 2 lines once integration to bloomberg is done
  console.log('Executing following Bloomberg Console command');
  console.log(`"${bloombergTerminalWindow}" ${BBG_TERMINAL_TYPE} ${commandType} ${command} "${formattedArgs}"`);

  fin.System.launchExternalProcess({
    alias: 'BloombergCommandConsole',
    arguments: `"${bloombergTerminalWindow}" ${BBG_TERMINAL_TYPE} ${commandType} ${command} "${formattedArgs}"`,
    listener
  })
    .then(onSuccess)
    .catch(onError);
};
