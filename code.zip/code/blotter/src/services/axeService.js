import { get } from './apiService';
import { searchBoxByTypeApi } from './apiConfig';

import { CONTAINER_BOND_DASHBOARD, CONTAINER_CUSTOMER_DASHBOARD, CONTAINER_TICKER } from '~helpers/globals';

export const clientType = {
  CUSIP: CONTAINER_BOND_DASHBOARD,
  CUSTOMER: CONTAINER_CUSTOMER_DASHBOARD,
  TICKER: CONTAINER_TICKER
};

export const searchType = {
  CLIENT: 'Client Details',
  TICKER: 'Bond Details',
  CUSIP: 'Bond Details'
};

export const searchApiType = {
  CUSTOMER: 'customer',
  BOND: 'bond',
  TICKER: 'ticker'
};

export const getClientsByType = (userName, value, type, impersonater) => {
  const url = searchBoxByTypeApi(userName, value, type, impersonater);
  return get(url);
};
