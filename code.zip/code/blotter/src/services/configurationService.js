import { Subject } from 'rxjs';

class ConfigurationService {
  static instance;

  constructor() {
    this.configuration$ = new Subject();
  }

  static getInstance() {
    if (!ConfigurationService.instance) {
      ConfigurationService.instance = new ConfigurationService();
    }

    return ConfigurationService.instance;
  }

  initWindowOptionsSubscription = setWindowOptions => {
    return this.configuration$.subscribe(options => {
      setWindowOptions(options);
    });
  };

  updateWindowOptions = message => {
    const {
      payload: { options }
    } = message;

    this.configuration$.next(options);
  };
}

const configurationService = ConfigurationService.getInstance();

export { configurationService };
