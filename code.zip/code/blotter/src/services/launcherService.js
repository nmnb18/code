import * as openfinService from '~services/openfinService';
import { getFullDate } from '~helpers/dateHelper';
import { APP_PLATFORM } from '~helpers/globals';
import { sendLogAsync } from '~helpers/sendLogs';
import * as usageService from '~services/usageService';
import { recordOvernightRestartSecond, applicationSendLogsOffsetMinutes } from '~services/openfinConfig';

const milliSecondsInSecond = 1000;
const milliSecondsInMinute = 60000;
const milliSecondsInHour = 3600000;
const milliSecondsInDay = 86400000;

const localTz = 'LOCAL';
const utcTz = 'UTC';

const timezones = {
  [localTz]: 'LOCAL',
  [utcTz]: 'UTC'
};

function isUTCTimezone(timezone) {
  return utcTz === timezone;
}

function getDatetime(time, timezone) {
  const isUTC = isUTCTimezone(timezone);
  return {
    currentHourMillis: (isUTC ? time.getUTCHours() : time.getHours()) * milliSecondsInHour,
    currentMinutesMillis: (isUTC ? time.getUTCMinutes() : time.getMinutes()) * milliSecondsInMinute,
    currentSecondMillis: (isUTC ? time.getUTCSeconds() : time.getSeconds()) * milliSecondsInSecond,
    currentMillis: isUTC ? time.getUTCMilliseconds() : time.getMilliseconds()
  };
}

function calculateRestartTime(restartHour, restartTimezone) {
  const timezone = timezones[restartTimezone] || utcTz;

  const time = restartHour.split(':');
  const currentTime = new Date();
  const { currentHourMillis, currentMinutesMillis, currentSecondMillis, currentMillis } = getDatetime(
    currentTime,
    timezone
  );

  const currentTimeinMillis = currentHourMillis + currentMinutesMillis + currentSecondMillis + currentMillis;
  const targetTimeMillis = time[0] * milliSecondsInHour + (time[1] ? time[1] * milliSecondsInMinute : 0);

  let milliSecondsTillHour = targetTimeMillis - currentTimeinMillis;

  //if we're past the specified hour the substraction will be negative
  if (milliSecondsTillHour < 0) {
    //increase by one day
    milliSecondsTillHour += milliSecondsInDay;
  }

  return milliSecondsTillHour;
}

export const shouldRecordUsage = (restartHour, restartTimezone, skipUsageRecordAfterRestartMinute) => {
  const milliSecondsTillRestart = calculateRestartTime(restartHour, restartTimezone);

  if (Date.now() < milliSecondsTillRestart) return true;

  const restartTime = Date.now() + milliSecondsTillRestart - milliSecondsInDay;
  const skipUsageRecordingTime = skipUsageRecordAfterRestartMinute * milliSecondsInMinute;
  const milliSecondsTillUsageRecordIsNotAllowed = restartTime + skipUsageRecordingTime;

  return Date.now() > milliSecondsTillUsageRecordIsNotAllowed;
};

export const scheduleRestart = (restartHour, restartTimezone) => {
  const milliSecondsTillRestart = calculateRestartTime(restartHour, restartTimezone);
  const milliSecondsTillRecordOvernightRestart = milliSecondsTillRestart - recordOvernightRestartSecond;

  const restartAt = Date.now() + milliSecondsTillRestart;
  console.log(`${APP_PLATFORM} will restart at ${getFullDate(restartAt)}`);

  setTimeout(() => {
    usageService.sendUsage({ userAction: usageService.actions.OVERNIGHT_RESTARTS });
  }, milliSecondsTillRecordOvernightRestart);

  setTimeout(() => {
    openfinService.scheduleRestart();
    openfinService.quitApplication();
  }, milliSecondsTillRestart);
};

export const scheduleSendLogs = (restartHour, restartTimezone) => {
  const milliSecondsTillHour = calculateRestartTime(restartHour, restartTimezone);

  // we use a random offset of up to one hour to prevent all users sending logs to server at exact same time
  const randomOffset = Math.ceil(Math.random() * (milliSecondsInMinute * parseInt(applicationSendLogsOffsetMinutes)));

  const sendLogsInMs = milliSecondsTillHour - randomOffset;
  const humanReadableDate = getFullDate(Date.now() + sendLogsInMs);

  console.log(`${APP_PLATFORM} will send logs at ${humanReadableDate}`);

  const onSuccess = () => {
    console.log(`Logs were sent at scheduled time: ${humanReadableDate}`);
  };

  setTimeout(() => {
    sendLogAsync(onSuccess);
  }, sendLogsInMs);
};
