import { WS_COMMANDS, EXPORT_COMMANDS } from '~helpers/jasperMessage';

export function createExportDataCacheService(
  subscriptionInstance$,
  dataSource$,
  dataFlowSubject,
  startFetchingDataCallback,
  referenceKeysArray
) {
  function exportDataCacheService(subsInstance$, source$, flowSubject, startFetchCallback, referenceKeysArray) {
    this.subscriptionId = null;
    this.startCaching = false;
    this.cache = null;
    this.referenceKeysArray = referenceKeysArray;
    // Observables
    this.subsInstance$ = subsInstance$;
    this.source$ = source$;
    this.flowSubject = flowSubject;
    this.startFetchCallback = startFetchCallback;

    /*
     * Subscription instance observable provide the current subscription instance Id
     * The subscription instance Id will be used for filter the data that the proxy cache service instance might use
     */
    this.subsIntanceSubscription =
      this.subsInstance$ && this.subsInstance$.subscribe(value => (this.subscriptionId = value));

    /*
     * This subscription will fetch all SOW based on criteria provided from WebSocket. We will start data caching upon GROUP_BEGIN message
     and makr completion based on GROUP_END
     */
    this.sourceSubscription = this.source$
      //.pipe(filter(value => value.source === this.subscriptionId))
      .subscribe(value => {
        const { command } = value;
        if (command === WS_COMMANDS.GROUP_BEGIN && !this.startCaching) {
          this.startCaching = !this.startCaching;
          this.cache = [];
          this.startFetchCallback();
        }

        if (command === WS_COMMANDS.SOW && this.startCaching) {
          if (this.referenceKeysArray.length > 0) {
            this.referenceKeysArray.forEach(({ colId, referenceKey }) => {
              if (!value[colId]) {
                value[colId] = value[referenceKey];
              }
            });
          }
          this.cache.push(value);
        }
        if (command === WS_COMMANDS.GROUP_END && this.startCaching && this.cache.length > 0) {
          this.startCaching = false;
          this.flowSubject.next({ command: EXPORT_COMMANDS.FETCH_DONE, data: [...this.cache] });
          this.cache = [];
        }
      });
  }

  exportDataCacheService.prototype.disconnect = function() {
    // unsubscribe from observables
    console.log('disconnect');
    this.subsIntanceSubscription.unsubscribe && this.subsIntanceSubscription.unsubscribe();
    this.sourceSubscription.unsubscribe && this.sourceSubscription.unsubscribe();
  };

  return new exportDataCacheService(
    subscriptionInstance$,
    dataSource$,
    dataFlowSubject,
    startFetchingDataCallback,
    referenceKeysArray
  );
}
