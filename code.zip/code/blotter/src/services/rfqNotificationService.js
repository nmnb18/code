import { Subject, BehaviorSubject, from } from 'rxjs';
import { takeUntil, switchMap, filter, tap, concatMap, exhaustMap, distinctUntilChanged } from 'rxjs/operators';
import { createNewFinWindow, forceFinWindowToFront, getChildFinWindow } from '~helpers/openfin';
import { WS_COMMANDS } from '~helpers/jasperMessage';
import { BLOTTER_CONTAINER_URL } from '~helpers/globals';
import {
  rfqNotificationTopicForChild,
  rfqNotificationTopicForParent,
  rfqNotificationActions,
  multiFilterRFQBlotterPopupTopicForChild
} from '~services/openfinConfig';
import { applicationSettings } from '~services/apiConfig';
import { applicationIdentity } from '~services/openfinService';
import { windowState, popupDefaultRfqOptions, popupIframeOptions, popupSecurityOptions } from '~helpers/popups';
import { defaultRFQPopupSharedSettings, defaultRFQPopupFilterSharedSettings } from '~helpers/userSettings';
import { iabSubscribe, iabUnsubscribe, iabPublish } from '~services/openfinService';

const BlotterPopupLog = 'Blotter Popup Bus for Parent';
const RFQBlotterPopupLog = 'RFQ Blotter Popup Bus for Parent';
const MultiFilterRFQBlotterPopupLog = 'Multi Filter RFQ Blotter Popup for Child';

const toggleRFQPopupOnEvent = 'toggleRFQPopupOn';
const RFQPopupCreated = 'RFQ Popup created';
const RFQPopupRestored = 'RFQ Popup restored';

const rfqNotificationSteps = {
  STEP_1: 'RFQ_POPUP_STEP_1'
};

const { rfqNotificationPopupName } = applicationSettings;

const toggleRFQNotificationStates = {
  ON: 'ON',
  OFF: 'OFF',
  RESET: 'RESET'
};

export const fbEvents = {
  SWITCH_VIEW: 'switch-view',
  READY_TO_FETCH: 'ready-to-fetch',
  FETCH: 'fetch'
};

class RFQNotificationService {
  constructor() {
    // This variable tracks if the user manually switched the rfq popup toggle on from user setting menu
    this.RFQPopupManuallyEnabledThisSession = false;

    // Variable that holds a reference to the object that represents the openfin child window that contains the rfq popup
    this.rfqPopupWin = null;

    // Flag to check if RFQ Popup was already mounted
    this.isPopupAlreadyMounted = false;

    // Flag for check if RFQ Notification service has been subscribed to the WS throught its subjects
    // By default, RFQ Notification service is not subscribed to WS
    this.isRFQNotificationServiceSubscribedToWS = false;

    // Flag for ignore messages that cames in before new GROUP_BEGIN or ACK commands.
    // By default, we won't ignore any RFQ message
    this.rfqNotificationIgnoreMessages = true;

    // Variable for store the RFQ message that need to be auto-selected in RFQ Notification popup
    this.rfqNotificationPopupTriggerMessage = null;

    // Variable for store the RFQ Notification popup closed state
    // By default, the RFQ Notification popup is closed
    this.isRFQNotificationPopupClosed = true;

    // Variable for store the RFQ Notification popup being created state
    // By default, the RFQ Notification begin created state is false
    this.isRFQNotificationPopupBeingCreated = false;

    // Variable for store signed in user
    this.signedInUser = null;

    // Variable for store current blotter user
    this.blotterUser = null;

    // variable to hold the user entitlement object
    this.entitlement = null;

    // Variable for store current blotter computer
    this.blotterComputer = null;

    // Variable for store impersonated user
    this.impersonatedUser = null;
    this.impersonating = null;

    // Variable for store toggle options (LiveOnly, MeOnly, AxeOnly, AxeDirectionMatch)
    this.rfqToggles = null;

    // Variable for store filter toggle options (SizeFormat)
    this.rfqFilterToggles = null;

    // Variable for store current RFQ subscription instance Id, it's based on current username and computer.
    this.rfqSubscriptionInstanceId = null;

    // Variable for store current multi filter RFQ subscription instance Id
    this.multiFilterSourceInstanceId = null;

    // Variable for store current RFQ Notification column dictionary. Later on column dictionary will be passed to RFQ Notification popup
    this.rfqNotificationsColumnsDictionary = null;

    // Variable for store current blotter user settings. Later on user settings will be passed to RFQ Notification popup
    this.blotterUserSettings = null;

    // Variable for store current connection status. Later on connection status will be passed to RFQ Notification popup
    this.ampsConnected = null;
    this.webSocketDisconnected = null;

    // Variable for store a reference for handleRequestData function that belongs to App
    this.requestData = null;

    // Variable for store a reference for handleRFQNotificationToggleChange function that belongs to App
    this.toggleRFQPopup = null;

    // Variable for store a reference for handleUnsubscribe function that belongs to App
    this.requestUnsubscribe = null;

    // Subject for push data from websocket to RFQ Container
    this.dataSource$ = new Subject();

    // Subject for push data out from RFQ Container to RFQ Notification service, this data will end up in RFQ Notification popup
    this.rfqNotificationCache$ = null;

    // Subject for start publishing data to RFQ Notification popup
    this.startPublishFlag$ = new Subject();

    // Subject for stop publishing data to RFQ Notification popup
    this.stopPublishFlag$ = new Subject();

    //subject for applying subscription filter, arriving messages will compare attributes to attributes passed here
    this.jasperWebSocketFilterSubject = new BehaviorSubject(null);

    // Subject for push newest requested range for filter rfq messages in ProxyCacheService
    this.rfqNotificationRequestedRangeSubject = new Subject();

    // Subject for push an event for handling popup window state change: show popup or create popup
    this.rfqNotificationPopupToggleOn$ = new Subject();

    // Subject for push an event for toggle RFQ Popup
    this.toggleRFQPopup$ = new Subject();

    // Subscriptions
    this.rfqNotificationPopupSubscription = null;
    this.rfqNotificationPopupMultiFilterSubscription = null;
    this.rfqNotificationPopupToggleOnSubscription = null;

    // Variable for handling the reloading flow
    this.isReloading = false;

    // Variable for store a reference to the onUnsubscribeRange function
    this.unsubscribeRange = null;

    // Subject for push multi filter data from websocket to RFQ Popup
    this.multiFilterSource$ = new Subject();
    this.isRFQNotificationMultifilterSubscribedToWS = null;

    this.handlers = {
      [rfqNotificationActions.rfqNotificationPopupReload]: () =>
        this.requestUnsubscribe && this.requestUnsubscribe(this.rfqSubscriptionInstanceId),
      [rfqNotificationActions.rfqNotificationPopupClose]: () => {
        this.isRFQNotificationPopupClosed = true;
        this.rfqNotificationIgnoreMessages = true;
        if (this.rfqPopupWin) this.rfqPopupWin.removeListener('reloaded', this.handleRFQPopupReload);
      },
      [rfqNotificationActions.rfqNotificationPopupMounted]: () => {
        this.isReloading = false;
        const rfqToggles = this.rfqToggles || defaultRFQPopupSharedSettings;
        const rfqFilterToggles = this.rfqFilterToggles || defaultRFQPopupFilterSharedSettings;

        const payload = {
          signedInUser: this.signedInUser,
          subscriptionInstanceId: this.rfqSubscriptionInstanceId,
          multiFilterSourceInstanceId: this.multiFilterSourceInstanceId,
          columnsDictionary: this.rfqNotificationsColumnsDictionary,
          userSettings: this.blotterUserSettings,
          ampsConnected: this.ampsConnected,
          webSocketDisconnected: this.webSocketDisconnected,
          impersonatedUser: this.impersonatedUser,
          impersonatingUser: this.impersonating,
          entitlement: this.entitlement,
          rfqToggles,
          rfqFilterToggles
        };

        if (!this.isPopupAlreadyMounted) {
          this.isPopupAlreadyMounted = true;
        } else {
          this.rfqNotificationPopupTriggerMessage = {};
        }
        this.sendStateChangesToRFQNotification(payload);
      },
      [rfqNotificationActions.rfqNotificationGridReadyForReceiveData]: () => {
        this.turnPublishFlagOn();
      },
      [rfqNotificationActions.rfqNotificationRequestData]: payload => {
        const { requestCommand } = payload;
        const { firstRow, lastRow, subscriptionInstanceId } = requestCommand;
        this.jasperWebSocketFilterSubject.next({
          source: subscriptionInstanceId,
          vpFirstRow: firstRow,
          vpLastRow: lastRow
        });
        this.rfqNotificationRequestedRangeSubject.next({ firstRow, lastRow });
        this.requestData && this.requestData(requestCommand);
      },
      [rfqNotificationActions.rfqNotificationPopupToggle]: payload => {
        const { rfqToggles, source } = payload;
        this.toggleRFQPopup && this.toggleRFQPopup({ updatedRfqToggles: rfqToggles, source });
      },
      [rfqNotificationActions.rfqNotificationRequestUnsubscribeRange]: () => {
        this.handleUnsubscribeRange();
      },
      [rfqNotificationActions.rfqNotificationRequestMultiFilter]: payload => {
        const { requestCommand } = payload;
        this.requestData && this.requestData(requestCommand);
      }
    };
  }

  setRFQPopupManuallyEnabledThisSession = (value, updatedRFQNotificationToggleOn) => {
    // force show the rfq popup straight away:
    updatedRFQNotificationToggleOn && this.openRFQNotificationPopup(this.blotterUser, this.blotterComputer);

    this.RFQPopupManuallyEnabledThisSession = value;
  };

  setUserSettings = userSettings => {
    this.blotterUserSettings = userSettings;
  };

  setColumnDictionary = columnsDictionary => {
    this.rfqNotificationsColumnsDictionary = columnsDictionary;
  };

  setEntitlement = entitlement => {
    this.entitlement = entitlement;
  };

  setConnectionStatus = ({ ampsConnected, webSocketDisconnected }) => {
    this.ampsConnected = ampsConnected;
    this.webSocketDisconnected = webSocketDisconnected;
  };

  setInitialConfiguration = async (
    currentUser,
    currentComputer,
    subscriptionInstanceId,
    multiFilterSourceInstanceId,
    signedInUser,
    impersonatedUser,
    entitlement,
    impersonating
  ) => {
    this.blotterUser = currentUser;
    this.blotterComputer = currentComputer;
    this.rfqSubscriptionInstanceId = subscriptionInstanceId;
    this.multiFilterSourceInstanceId = multiFilterSourceInstanceId;
    this.signedInUser = signedInUser;
    this.impersonatedUser = impersonatedUser;
    this.entitlement = entitlement;
    this.impersonating = impersonating;

    this.isRFQNotificationServiceSubscribedToWS = false;
    this.rfqNotificationIgnoreMessages = true;
    this.rfqNotificationPopupTriggerMessage = null;
    this.isRFQNotificationPopupClosed = true;
    this.isRFQNotificationPopupBeingCreated = false;
    this.blotterUserSettings = null;
    this.requestData = null;
    this.isRFQNotificationMultifilterSubscribedToWS = false;

    const rfqNotificationPopup = await getChildFinWindow(rfqNotificationPopupName);

    if (rfqNotificationPopup) {
      rfqNotificationPopup.close(true);
      this.isRFQNotificationPopupClosed = true;
    }

    this.toggleRFQPopupSubscription = this.toggleRFQPopup$.pipe(distinctUntilChanged()).subscribe(({ status }) => {
      if (status === toggleRFQNotificationStates.RESET) return;

      if (status === toggleRFQNotificationStates.ON) this.turnRFQNotificationOn();
      else this.turnRFQNotificationOff();
    });

    this.toggleRFQPopup$.next({ status: toggleRFQNotificationStates.RESET });
  };

  removeRFQPopupSubscriptionsOnChangeUser = () => {
    this.unsubscribeToRFQNotificationSubscriptions();

    if (this.toggleRFQPopupSubscription && !this.toggleRFQPopupSubscription.closed) {
      this.toggleRFQPopupSubscription.unsubscribe();
    }
  };

  setToggles = rfqToggles => {
    this.rfqToggles = { ...rfqToggles };
  };

  setFilterToggles = rfqFilterToggles => {
    this.rfqFilterToggles = { ...rfqFilterToggles };
  };

  initRFQNotificationCache$ = () => {
    this.rfqNotificationCache$ = new Subject();
  };

  turnPublishFlagOn = async () => {
    const rfqNotificationPopup = await getChildFinWindow(rfqNotificationPopupName);

    if (rfqNotificationPopup) {
      // re-subscribe rfq notification subscription
      this.startPublishFlag$.next('ON');
      this.isRFQNotificationPopupClosed = false;
      this.sendStepMessageToRFQNotification({ step: rfqNotificationSteps.STEP_1 });
    }
  };

  turnPublishFlagOff = () => {
    this.stopPublishFlag$.next('OFF');
  };

  initPopupSubscription = () => {
    iabSubscribe({
      topic: rfqNotificationTopicForParent,
      handler: this.handleRFQNotificationMessage,
      BlotterPopupLog
    });

    iabSubscribe({
      topic: multiFilterRFQBlotterPopupTopicForChild,
      handler: this.handleMultiFilterMessage,
      MultiFilterRFQBlotterPopupLog
    });
  };

  removePopupSubscription = () => {
    iabUnsubscribe({
      topic: rfqNotificationTopicForParent,
      handler: this.handleRFQNotificationMessage,
      BlotterPopupLog
    });

    iabUnsubscribe({
      topic: multiFilterRFQBlotterPopupTopicForChild,
      handler: this.handleMultiFilterMessage,
      MultiFilterRFQBlotterPopupLog
    });
  };

  handleRFQNotificationMessage = message => {
    const { type, payload } = message;
    const handler = this.handlers[type];

    handler && handler(payload);
  };

  handleNotifyNewRFQ = async rfqMessage => {
    if (this.isRFQNotificationPopupClosed && !this.rfqNotificationPopupTriggerMessage) {
      this.rfqNotificationPopupTriggerMessage = { ...rfqMessage };

      // unsubscribe RFQ notification subscription
      this.turnPublishFlagOff();
      this.requestUnsubscribe && this.requestUnsubscribe(this.rfqSubscriptionInstanceId);
    }

    if (this.isRFQNotificationToggleOn) {
      this.rfqNotificationPopupToggleOn$.next(toggleRFQPopupOnEvent);
    }
  };

  setHandlers = (handleRequestData, handleRFQNotificationToggleChange, handleUnsubscribe, onUnsubscribeRange) => {
    this.requestData = handleRequestData;
    this.toggleRFQPopup = handleRFQNotificationToggleChange;
    this.requestUnsubscribe = handleUnsubscribe;
    this.unsubscribeRange = onUnsubscribeRange;
  };

  toggleRFQNotification = status => {
    this.toggleRFQPopup$.next({ status: status ? toggleRFQNotificationStates.ON : toggleRFQNotificationStates.OFF });
  };

  turnRFQNotificationOn = () => {
    this.isRFQNotificationToggleOn = true;
    this.isRFQNotificationServiceSubscribedToWS = true;

    this.rfqNotificationPopupSubscription = this.startPublishFlag$
      .pipe(
        switchMap(() =>
          this.rfqNotificationCache$.pipe(
            filter(() => !this.isRFQNotificationPopupClosed),
            tap(() => {
              if (this.rfqNotificationPopupTriggerMessage) {
                const newRFQMessageToBeSelected = { ...this.rfqNotificationPopupTriggerMessage };
                this.rfqNotificationPopupTriggerMessage = null;

                this.sendRFQMessage(
                  { name: rfqNotificationPopupName, ...applicationIdentity },
                  rfqNotificationTopicForChild,
                  {
                    type: rfqNotificationActions.rfqNotificationForceSelectNewRFQ,
                    payload: newRFQMessageToBeSelected
                  }
                );
              }
            }),
            tap(({ command }) => {
              if (command === WS_COMMANDS.GROUP_BEGIN || command === WS_COMMANDS.CLEAR) {
                this.rfqNotificationIgnoreMessages = false;
              }
            }),
            filter(message => !this.rfqNotificationIgnoreMessages || message.command === WS_COMMANDS.ACK),
            takeUntil(this.stopPublishFlag$)
          )
        )
      )
      .subscribe(message =>
        this.sendRFQMessage({ name: rfqNotificationPopupName, ...applicationIdentity }, rfqNotificationTopicForChild, {
          type: rfqNotificationActions.rfqNotificationSendRFQMessage,
          payload: message
        })
      );

    this.rfqNotificationPopupMultiFilterSubscription = this.startPublishFlag$
      .pipe(
        switchMap(() =>
          this.multiFilterSource$.pipe(
            filter(() => !this.isRFQNotificationPopupClosed),
            tap(({ command }) => {
              if (command === WS_COMMANDS.GROUP_BEGIN) this.isRFQNotificationMultifilterSubscribedToWS = true;
            }),
            takeUntil(this.stopPublishFlag$)
          )
        )
      )
      .subscribe(message =>
        this.sendRFQMessage({ name: rfqNotificationPopupName, ...applicationIdentity }, rfqNotificationTopicForChild, {
          type: rfqNotificationActions.rfqNotificationSendMultiFilterMessage,
          payload: message
        })
      );

    this.rfqNotificationPopupToggleOnSubscription = this.rfqNotificationPopupToggleOn$
      .pipe(
        exhaustMap(() => {
          const rfqPopupWindowPromise = getChildFinWindow(rfqNotificationPopupName);

          return from(rfqPopupWindowPromise).pipe(
            concatMap(async rfqNotificationPopup => {
              if (rfqNotificationPopup) {
                await this.restoreRFQNotificationPopup(rfqNotificationPopup);
                return RFQPopupRestored;
              } else {
                await this.openRFQNotificationPopup(this.blotterUser, this.blotterComputer);
                return RFQPopupCreated;
              }
            })
          );
        })
      )
      .subscribe(() => {});
  };

  unsubscribeToRFQNotificationSubscriptions = () => {
    this.rfqNotificationPopupSubscription && this.rfqNotificationPopupSubscription.unsubscribe();
    this.rfqNotificationPopupMultiFilterSubscription && this.rfqNotificationPopupMultiFilterSubscription.unsubscribe();
    this.rfqNotificationPopupToggleOnSubscription && this.rfqNotificationPopupToggleOnSubscription.unsubscribe();
  };

  turnRFQNotificationOff = async () => {
    this.isRFQNotificationToggleOn = false;
    this.turnPublishFlagOff();

    if (this.isRFQNotificationServiceSubscribedToWS) {
      this.requestUnsubscribe && this.requestUnsubscribe(this.rfqSubscriptionInstanceId);
    }
    this.isRFQNotificationServiceSubscribedToWS = false;

    if (this.isRFQNotificationMultifilterSubscribedToWS) {
      this.requestUnsubscribe && this.requestUnsubscribe(this.multiFilterSourceInstanceId, true);
    }
    this.isRFQNotificationMultifilterSubscribedToWS = false;

    this.unsubscribeToRFQNotificationSubscriptions();

    if (this.rfqNotificationCache$) {
      this.rfqNotificationCache$.complete();
      this.rfqNotificationCache$ = null;
    }

    if (!this.isRFQNotificationPopupClosed) {
      const rfqNotificationPopup = await getChildFinWindow(rfqNotificationPopupName);
      if (rfqNotificationPopup) {
        rfqNotificationPopup.close(true);
        this.isRFQNotificationPopupClosed = true;
      }
    }
  };

  sendMessage = (destination, topic, message) =>
    iabPublish({
      source: destination,
      topic,
      message,
      logLabel: BlotterPopupLog
    });

  sendRFQMessage = (destination, topic, message) =>
    iabPublish({
      source: destination,
      topic,
      message,
      logLabel: RFQBlotterPopupLog
    });

  restoreRFQNotificationPopup = async rfqNotificationPopup => {
    try {
      const rfqNotificationPopupState = await rfqNotificationPopup.getState();
      if (rfqNotificationPopupState === windowState.MAXIMIZED) {
        await rfqNotificationPopup.maximize();
      } else {
        await rfqNotificationPopup.restore();
      }

      forceFinWindowToFront(rfqNotificationPopup);
    } catch (error) {
      console.warn('User closed RFQ popup just as another RFQ was processing.');
    }
  };

  handleRFQPopupReload = () => {
    if (!this.isReloading) {
      this.isReloading = true;
      this.turnPublishFlagOff();
      this.requestUnsubscribe && this.requestUnsubscribe(this.rfqSubscriptionInstanceId);
    }
  };

  openRFQNotificationPopup = async (currentFinUser, currentFinComputer) => {
    if (this.isRFQNotificationPopupBeingCreated) return;

    const winOption = {
      name: rfqNotificationPopupName,
      url: `${BLOTTER_CONTAINER_URL}rfq`,
      customData: {
        popUpTitle: 'RFQ Notification',
        currentFinUser,
        currentFinComputer
      },
      ...popupDefaultRfqOptions,
      ...popupIframeOptions,
      ...popupSecurityOptions
    };

    this.isRFQNotificationPopupBeingCreated = true;
    this.rfqPopupWin = await createNewFinWindow(winOption);
    forceFinWindowToFront(this.rfqPopupWin);
    this.isRFQNotificationPopupBeingCreated = false;
    this.rfqPopupWin.addListener('reloaded', this.handleRFQPopupReload);
  };

  sendStateChangesToRFQNotification = async payload => {
    const rfqNotificationPopup = await getChildFinWindow(rfqNotificationPopupName);

    if (rfqNotificationPopup) {
      this.sendMessage(applicationIdentity, rfqNotificationTopicForChild, {
        type: rfqNotificationActions.rfqNotificationSendStateChanges,
        payload
      });
    }
  };

  sendReloadCommand = () =>
    this.sendMessage(applicationIdentity, rfqNotificationTopicForChild, {
      type: rfqNotificationActions.rfqNotificationReloadCommand
    });

  sendStepMessageToRFQNotification = async payload => {
    const rfqNotificationPopup = await getChildFinWindow(rfqNotificationPopupName);

    if (rfqNotificationPopup) {
      this.sendMessage(applicationIdentity, rfqNotificationTopicForChild, {
        type: rfqNotificationActions.rfqNotificationSendStepMessage,
        payload
      });
    }
  };

  handleUnsubscribeRange = () => {
    this.unsubscribeRange && this.unsubscribeRange(this.rfqSubscriptionInstanceId);
  };

  handleMultiFilterMessage = message => {
    this.multiFilterSource$.next(message);
  };
}

const rfqNotificationService = new RFQNotificationService();

export { rfqNotificationService, rfqNotificationSteps };
