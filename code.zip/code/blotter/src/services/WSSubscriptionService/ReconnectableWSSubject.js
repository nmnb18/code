import { Subject, Observable } from 'rxjs';
import { share } from 'rxjs/operators';
import { WebSocketSubject } from 'rxjs/webSocket';
import { randomInteger } from '~helpers/number';

export class ReconnectableWSSubject extends Subject {
  constructor({
    url,
    serializer,
    deserializer,
    onOpenConnection,
    onCloseConnection,
    onClosingConnection,
    reconnectMinimumInterval,
    reconnectAttemptTime,
    reconnectVariability
  }) {
    super();

    this.socket = null;
    this.connectionObserver = null;
    this.skipReconnect = false;
    this.isReconnecting = false;
    this.reconnectMinimumInterval = reconnectMinimumInterval;
    this.reconnectAttemptTime = reconnectAttemptTime;
    this.reconnectVariability = reconnectVariability;

    this.connectionStatus = new Observable(observer => {
      this.connectionObserver = observer;
    }).pipe(share());

    this.wsSubjectConfig = {
      url: url,
      serializer: serializer,
      deserializer: deserializer,

      openObserver: {
        next: event => {
          onOpenConnection(event);
          this.skipReconnect = false;
          this.connectionObserver.next(true);
        }
      },
      closingObserver: {
        next: () => {
          onClosingConnection();
        }
      },
      closeObserver: {
        next: event => {
          this.socket = null;
          onCloseConnection(event);
          if (!this.skipReconnect) this.connectionObserver.next(false);
        }
      }
    };

    this.connect();

    this.connectionStatus.subscribe(isConnected => {
      if (typeof isConnected === 'boolean' && !isConnected) {
        this.reconnect();
      } else if (this.isReconnecting && isConnected) {
        this.isReconnecting = false;
      }
    });
  }

  connect() {
    console.log('Creating new WS connection');
    this.socket = new WebSocketSubject(this.wsSubjectConfig);
    this.socket &&
      this.socket.subscribe(
        m => {
          this.next(m); /// when receiving a message, we just send it to our Subject
        },
        error => {
          console.error(`WS connection error: ${error.type}`);
          if (error.currentTarget.readyState === WebSocket.CLOSED) this.socket = null;
        }
      );
  }

  reconnect() {
    this.isReconnecting = true;
    const amendedMinimumInterval = this.reconnectMinimumInterval - this.reconnectAttemptTime;
    const timeout = randomInteger(amendedMinimumInterval, this.reconnectVariability);
    console.log(`WS connection attempting to reconnect in ${Math.round((timeout + this.reconnectAttemptTime) / 1000)}`);
    setTimeout(() => {
      this.connect();
    }, timeout);
  }

  send(data) {
    console.log(`Sending WS message: ${data}`);
    if (this.socket) {
      this.socket.next(data);
    }
  }

  close(skipReconnect) {
    this.skipReconnect = skipReconnect;
    console.log(`Closing WS connection`);
    if (this.socket) {
      this.socket.complete();
      this.socket = null;
    }
  }
}
