import { ReconnectableWSSubject } from './ReconnectableWSSubject';

export class WSSubscriptionService {
  constructor(
    targetUrl,
    targetSerializer,
    targetDeserializer,
    onOpenConnection,
    onCloseConnection,
    onClosingConnection,
    reconnectMinimumInterval,
    reconnectAttemptTime,
    reconnectVariability
  ) {
    this.webSocket = null;
    this.webSocketConfig = {
      url: targetUrl,
      serializer: targetSerializer,
      deserializer: targetDeserializer,
      onOpenConnection: onOpenConnection,
      onCloseConnection: onCloseConnection,
      onClosingConnection: onClosingConnection,
      reconnectMinimumInterval,
      reconnectAttemptTime,
      reconnectVariability
    };
  }

  getWebSocket$() {
    if (this.webSocket) {
      return this.webSocket;
    } else {
      this.webSocket = new ReconnectableWSSubject(this.webSocketConfig);
      return this.webSocket;
    }
  }
}
