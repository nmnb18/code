import { jasperGet } from './jasperApiService';
import { ratingsApi } from './apiConfig';
import { appUserSharedSettingsTopic, appUserSettingsTopic } from './openfinConfig';
import { RFQ_APP_NAME } from '~helpers/globals';
import { iabPublish } from '~services/openfinService';

const getApplicationByName = (dataSettings, AppName) => {
  if (dataSettings && dataSettings.Applications && AppName) {
    const application = dataSettings.Applications.find(el => el.AppName === AppName);
    return application ? application : null;
  }
  return null;
};

const getSettings = (dataSettings, AppName) => {
  const application = getApplicationByName(dataSettings, AppName);
  return application ? application.Settings : null;
};

const UpdateUserSharedSettings = 'Update User Shared Settings Bus for Parent';

const requestUpdateUserSharedSettings = (metadata, payload, { source }) =>
  iabPublish({
    topic: appUserSharedSettingsTopic,
    message: { metadata, payload, source },
    logLabel: UpdateUserSharedSettings
  });

const getDefaultViewName = (dataSettings, AppName) => {
  const application = getApplicationByName(dataSettings, AppName);
  if (!application) return null;

  return application.DefaultPopUpView;
};

const getDefaultPopUpViewName = (userSettings, AppName) => {
  const application = getApplicationByName(userSettings, AppName);
  if (!application) return null;

  return application.DefaultPopUpView;
};

const getSelectedPopUpViewName = (userSettings, AppName) => {
  const application = getApplicationByName(userSettings, AppName);
  if (!application) return null;
  const { selectedView } = getAppSessionData(userSettings, AppName);

  return selectedView || application.DefaultPopUpView;
};

export const getAppSessionData = (userSettings, AppName) => {
  const application = getApplicationByName(userSettings, AppName);
  return application?.sessionData?.[RFQ_APP_NAME] || {};
};

const getViewsList = (dataSettings, AppName) => {
  const application = getApplicationByName(dataSettings, AppName);
  return application ? application.PopUpViews : null;
};

const createSettingsColumn = (columnName, sizeWidth, sortOrder) => {
  return {
    ColName: columnName,
    size: sizeWidth,
    sort: sortOrder
  };
};

const createAdditionalView = (viewName, newColumnDefinition, filterList, columnState, sortingFromViewSettings) => {
  const columnList = newColumnDefinition.map(column =>
    createSettingsColumn(column.colId, column.actualWidth, column.sort)
  );
  return {
    ViewName: viewName,
    Version: 1.0,
    LastModifiedBy: 'UserName',
    SortPriority: sortingFromViewSettings,
    Columns: columnList,
    ColumnFilters: filterList,
    ColumnState: columnState,
    AdvancedFilters: []
  };
};

const getReadOnlyViewName = (dataSettings, AppName) => {
  const application = getApplicationByName(dataSettings, AppName);
  return application ? application.PopUpViews.find(view => view.ReadOnly).ViewName : null;
};
const processFilterList = (finalActiveColumns, filterList) => {
  return finalActiveColumns
    .map(oFilter => {
      return filterList.find(({ field }) => field === oFilter.colId);
    })
    .filter(element => {
      return element !== undefined;
    });
};
const UpdateUserSettings = 'Update User Settings Bus for Parent';
const updateUserSettings = (currentUser, payload) =>
  iabPublish({
    topic: appUserSettingsTopic,
    message: { username: currentUser, payload },
    logLabel: UpdateUserSettings
  });

const getCopyTemplatesList = (dataSettings, AppName) => {
  const application = getApplicationByName(dataSettings, AppName);
  return application ? application.CopySettings : null;
};

export const getRatings = () => {
  const url = ratingsApi();
  return jasperGet(url);
};

const createAdditionalCopyTemplate = (copyTemplateName, newColumnDefinition, userName) => {
  const columnList = newColumnDefinition.map(column => createCopyTemplateColumn(column.colId, column.displayname));
  return {
    CopyTemplateName: copyTemplateName,
    Version: 1.0,
    LastModifiedBy: userName,
    LasModifiedOn: getCurrentDateTime(),
    Columns: columnList
  };
};

const createCopyTemplateColumn = (colId, displayname) => {
  return {
    colId: colId,
    displayname: displayname
  };
};

const getCurrentDateTime = () => {
  const today = new Date();
  const date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
  const time = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
  return date + ' ' + time;
};

export {
  getApplicationByName,
  getSettings,
  requestUpdateUserSharedSettings,
  getDefaultViewName,
  getViewsList,
  createAdditionalView,
  getReadOnlyViewName,
  processFilterList,
  getCopyTemplatesList,
  updateUserSettings,
  getDefaultPopUpViewName,
  getSelectedPopUpViewName,
  createAdditionalCopyTemplate
};
