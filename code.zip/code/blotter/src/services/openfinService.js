import { APP_NAME, APP_PLATFORM } from '~helpers/globals';

const fin = window.fin;

export const deleteCacheOnExit = () => {
  fin.System.deleteCacheOnExit()
    .then(() => console.log('Schedule a task for delete cache on exit.'))
    .catch(err => console.log(`Could not schedule a task for delete cache on exit`, err));
};

export const showVersion = async () => {
  const app = await getApplication();
  const info = await app.getInfo();
  console.log(`${APP_PLATFORM} is running OpenFin on ${info.runtime.version} version`);

  if (info.manifest)
    info.manifest.appAssets.forEach(asset => {
      console.log(`${APP_PLATFORM} is using ${asset.alias} on ${asset.version} version`);
    });
};

export const closeApplication = async () => {
  const app = await getApplication();
  console.log('Closing application');
  app.close(true);
};

async function getApplication() {
  return fin.Application.getCurrent();
}

export const quitApplication = async () => {
  try {
    const app = await getApplication();
    await app.quit();
    console.log('Application quitted.');
  } catch (err) {
    console.log(`Failure in quitting the application:`, err);
  }
};

export const scheduleRestart = async () => {
  try {
    const application = await getApplication();
    await application.scheduleRestart();
    console.log('Schedule a task for restart the application.');
  } catch (err) {
    console.log(`Could not schedule a task for restarting the application:`, err);
  }
};

export const applicationRegisterUser = user => {
  async function registerUser() {
    const app = await getApplication();
    return await app.registerUser(user, APP_NAME);
  }

  registerUser()
    .then(() => console.log(`${APP_NAME} app registration for user ${user} success`))
    .catch(({ message }) => console.log(`${APP_NAME} app registration for user ${user} fail. Error: ${message}`));
};

/**
 * Gets current apps UUID.
 * @returns {{uuid: string}} Returns a stripped down Openfin Identity object.
 */
const getApplicationIdentity = () => ({ uuid: fin.me.identity.uuid });
export const applicationIdentity = getApplicationIdentity();

/**
 * Subscribes to messages from the specified application on the specified topic.
 * @param {{topic: string, handler: Function, logLabel: string}}
 */
export const iabSubscribe = ({
  source = applicationIdentity,
  topic,
  handler,
  logLabel,
  onSuccess = () => {},
  onFail = () => {}
}) => {
  fin.InterApplicationBus.subscribe(source, topic, handler)
    .then(() => {
      console.log(`${logLabel} - Subscribe success`);
      onSuccess();
    })
    .catch(err => {
      console.warn(`${logLabel} - Subscribe fail`, err.message);
      onFail();
    });
};

/**
 * Unsubscribes to messages from the specified application on the specified topic.
 * @param {{topic: string, handler: Function, logLabel: string}}
 */
export const iabUnsubscribe = ({
  source = applicationIdentity,
  topic,
  handler,
  logLabel,
  onSuccess = () => {},
  onFail = () => {}
}) => {
  fin.InterApplicationBus.unsubscribe(source, topic, handler)
    .then(() => {
      console.log(`${logLabel} - Unsubscribe success`);
      onSuccess();
    })
    .catch(err => {
      console.warn(`${logLabel} - Unsubscribe fail`, err.message);
      onFail();
    });
};

/**
 * Publishes a message to all applications running on OpenFin Runtime that are subscribed to the specified topic.
 * @param {{topic: string, message: Object, logLabel: string}}
 */
export const iabPublish = ({ topic, message, logLabel }) => {
  fin.InterApplicationBus.publish(topic, message).catch(err =>
    console.warn(`${logLabel} - Publish message fail`, err.message)
  );
};
