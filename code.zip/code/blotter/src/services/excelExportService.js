import { exportExcelWithXLSX, shapeDataAndHeaders, EXPORT_BATCH_SIZE } from '~helpers/exportHelper';
import { FETCH_TRIGGERS } from '~helpers/jasperMessage';
import ExcelExportBatchService from './excelExportBatchService';
//import ExcelExportBatchService from '~services/excelExportBatchService';

export function createExcelExportService(
  payload,
  fetchTrigger,
  callback,
  processedRecordSubject,
  disconnectExportDataCaching
) {
  function ExportExcel(_payload, _callback, processedRecordSubject, disconnectExportDataCaching) {
    const { headers, data, headerDataTypes } = _payload;

    this.data = data;
    this.headers = headers;
    this.headerDataTypes = headerDataTypes;
    this.callback = _callback;
    // Prepare the inputs
    let timestamp = new Date().getTime();
    this.fileName = `exportdata-${timestamp}.xlsx`;
    this.sheetName = 'Data Export';

    if (fetchTrigger === FETCH_TRIGGERS.EXPORT_TO_EXCEL_AND_OPEN) {
      // Approach 1: Excel export using Desktop utility, we will launch this utility using openfin's launchExternalProcess

      const data = shapeDataAndHeaders(this.headers, this.data);
      const batchServiceObservables = new ExcelExportBatchService(
        data,
        this.headerDataTypes,
        EXPORT_BATCH_SIZE,
        timestamp,
        this.callback,
        processedRecordSubject
      );
      batchServiceObservables.setUpProcess();
      batchServiceObservables.startProcess();
      disconnectExportDataCaching();
    } else if (fetchTrigger === FETCH_TRIGGERS.EXPORT_TO_EXCEL_AS_DOWNLOAD) {
      // Approach 2: Excel export using XLSX API.
      exportExcelWithXLSX(
        this.headers,
        this.data,
        this.sheetName,
        this.fileName,
        this.callback,
        disconnectExportDataCaching
      );
    }
  }

  ExportExcel.prototype.executeCallback = function() {
    console.log('Callback Executed');
    this.callback && this.callback();
  };

  return new ExportExcel(payload, callback, processedRecordSubject, disconnectExportDataCaching);
}
