import { map } from 'rxjs/operators';

/*
 *
 * mapToJasperResponse is a custom RxJs operator for map from a Jasper response object
 * This operator will emit a value with the response message within the whole response object
 */
export const mapFromJasperResponse = () => {
  return map(res => res && res.data && res.data.response);
};
