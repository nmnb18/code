import { Subject } from 'rxjs';
import { multiFilterRFQBlotterPopupTopicForChild } from '~services/openfinConfig';
import { iabSubscribe, iabUnsubscribe } from '~services/openfinService';

const MultiFilterRFQBlotterPopupLog = 'Multi Filter RFQ Blotter Popup for Child';

export const fbEvents = {
  SWITCH_VIEW: 'switch-view',
  READY_TO_FETCH: 'ready-to-fetch',
  FETCH: 'fetch'
};
class MultiFilterService {
  constructor() {
    this.multiFilterSource$ = new Subject();
    this.multiFilterRequestHandler$ = new Subject();
    this.multiFilterEvent = '';
    this.multiFilterField = '';
  }

  initSubscription = () =>
    iabSubscribe({
      topic: multiFilterRFQBlotterPopupTopicForChild,
      handler: this.handleMultiFilterMessage,
      logLabel: MultiFilterRFQBlotterPopupLog
    });

  removeSubscription = () =>
    iabUnsubscribe({
      topic: multiFilterRFQBlotterPopupTopicForChild,
      handler: this.handleMultiFilterMessage,
      logLabel: MultiFilterRFQBlotterPopupLog
    });

  handleMultiFilterMessage = message => {
    this.multiFilterSource$.next(message);
  };

  setMultiFilterField = multiFilterField => {
    this.multiFilterField = multiFilterField;
  };

  setMultiFilterEvent = event => {
    this.multiFilterEvent = event;
  };

  clearMultiFilter = () => {
    this.multiFilterField = '';
  };

  hasSwitchedView = () => this.multiFilterEvent === fbEvents.SWITCH_VIEW;

  shouldSendMultiFilterRequest = field => this.multiFilterField !== field;

  sendMultiFilterRequest = params => this.multiFilterRequestHandler$.next(params);

  get multiFiltersSource$() {
    return this.multiFilterSource$.asObservable();
  }

  get multiFilterRequest$() {
    return this.multiFilterRequestHandler$.asObservable();
  }
}

const multiFilterService = new MultiFilterService();

export { multiFilterService };
