import { throwError, from } from 'rxjs';
import { fromFetch } from 'rxjs/fetch';
import { catchError, switchMap } from 'rxjs/operators';

const HTTP_VERBS = {
  GET: 'GET',
  POST: 'POST',
  PUT: 'PUT',
  DELETE: 'DELETE'
};

export function get(url, customOptions = {}) {
  const promise$ = fromFetch(url, customOptions);

  return promise$.pipe(
    switchMap(handleResponse),
    catchError(handleError)
  );
}

export function put(url, payload, customOptions = {}) {
  const options = getOptions(HTTP_VERBS.PUT, payload, customOptions);
  const promise$ = fromFetch(url, options);

  return promise$.pipe(
    switchMap(handleResponse),
    catchError(handleError)
  );
}

function getOptions(method, payload, customOptions = {}) {
  return {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    ...customOptions
  };
}

function handleResponse(response) {
  if (response.ok) {
    // OK return data
    return from(response.json());
  }
  // Server is returning a status requiring the client to try something else.
  return throwError({ error: true, message: `Error ${response.status}` });
}

function handleError(err) {
  // Network or other error
  return throwError({ error: true, message: err.message });
}
