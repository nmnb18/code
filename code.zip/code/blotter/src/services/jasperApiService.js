import { mapFromJasperResponse } from './jasperOperators';
import { get, put } from './apiService';

/**@type object */
const CORS_BASE_OPTIONS = { credentials: 'include', redirect: 'follow' };
export const NO_CORS_CONFIGURATION_OPTIONS = { mode: 'no-cors', ...CORS_BASE_OPTIONS };
export const CORS_CONFIGURATION_OPTIONS = { mode: 'cors', ...CORS_BASE_OPTIONS };

export function jasperGet(url) {
  const promise$ = get(url, CORS_CONFIGURATION_OPTIONS);

  return promise$.pipe(mapFromJasperResponse());
}

export function jasperPut(url, payload) {
  const promise$ = put(url, payload, CORS_CONFIGURATION_OPTIONS);

  return promise$.pipe(mapFromJasperResponse());
}
