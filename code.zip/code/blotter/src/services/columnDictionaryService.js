import { jasperGet } from './jasperApiService';
import { columnDictionaryApi } from './apiConfig';
import { formatValue } from '~helpers/rfqFormatters';

export const getApplicationColumns = appName => {
  const url = columnDictionaryApi(appName);
  return jasperGet(url);
};

export const getRequiredColumns = ({ sourceColumnNames: columns }) => columns.filter(({ required }) => required);

const hiddenDefaultColumnDefinition = field => {
  return {
    headerName: field,
    field: field,
    width: 75,
    hide: true,
    valueFormatter: params =>
      formatValue({ params, field, columntype: null, formatinstruction: null, codeinstruction: null })
  };
};

export const getAlwaysRequestColumnDefinitions = ({ sourceColumnNames: columns }) =>
  columns
    .filter(({ codeinstruction }) => codeinstruction && codeinstruction.alwaysRequest)
    .map(({ sourcecolumnname }) => hiddenDefaultColumnDefinition(sourcecolumnname));

export const getLegColumnDefinitions = columnDefs => {
  const legFields = [];

  columnDefs.forEach(columnDef => {
    const { legEnabled } = columnDef;
    if (legEnabled) {
      const { field } = columnDef;
      legFields.push(hiddenDefaultColumnDefinition(`l1_${field}`));
      legFields.push(hiddenDefaultColumnDefinition(`l2_${field}`));
    }
  });

  return legFields;
};

/**
 * @returns {string[]}
 */
export const getLegEnabledMainColumnNames = ({ sourceColumnNames: columns }) =>
  columns.filter(column => column.codeinstruction?.legEnabled).map(column => column.sourcecolumnname);

export const filterColumnDefinitions = columnDefs => columnDefs.filter(columnDef => columnDef);

export const getDefaultColumnState = columns => {
  return columns
    .filter(e => e && e.colId)
    .map(({ colId, width }) => ({
      colId,
      hide: false,
      aggFunc: null,
      width,
      pivotIndex: null,
      pinned: null,
      rowGroupIndex: null
    }));
};
export const combineColumnDefinitions = (baseColumns, additionalColumns) => {
  if (!baseColumns) return [];

  const columns = [];
  baseColumns.forEach(col => {
    const column = columns.find(c => c.field === col.field);
    if (!column) {
      columns.push(col);
    }
  });

  if (!additionalColumns) return columns;

  additionalColumns.forEach(arrColumns => {
    arrColumns.forEach(col => {
      const column = columns.find(c => c.field === col.field);
      if (!column) {
        columns.push(col);
      }
    });
  });

  return columns;
};
