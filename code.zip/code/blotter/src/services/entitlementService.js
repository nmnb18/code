import { jasperGet } from './jasperApiService';
import { map } from 'rxjs/operators';
import { employeeInfoApi, impersonatedUsersApi, searchPersonApi } from './apiConfig';
import { ALLOWED_LEVEL3_FOR_INQUIRY, ALLOWED_PRIMARY_ROLES_FOR_INQUIRY } from '~helpers/globals';
import { uiEntitlementOptions, showEntitlementOption } from '~helpers/entitlement';

const roleTrader = 'Trader';

export const getEmployeeInfo = userName => {
  const url = employeeInfoApi(userName);
  return jasperGet(url);
};

export const getImpersonatedUsers = (appPlatform, userName) => {
  const url = impersonatedUsersApi(appPlatform, userName);
  return jasperGet(url);
};

export const searchPersons = value => {
  const url = searchPersonApi(value);
  return jasperGet(url).pipe(map(rawPerson => rawPerson && rawPerson.users.map(getUserInformation)));
};

// Check if user belongs to Level 3 or in primary roles group, if so then we need to show Add/Manage Inquiry
export const isInquiryAllowed = userEntitlement => {
  if (!userEntitlement) return false;
  if (userEntitlement.primaryRole === roleTrader) {
    return showEntitlementOption(userEntitlement, uiEntitlementOptions.INQUIRY_VISIBLE);
  }
  const allowedLevel3 = formattedList(ALLOWED_LEVEL3_FOR_INQUIRY);
  const allowedPrimaryRoles = formattedList(ALLOWED_PRIMARY_ROLES_FOR_INQUIRY);
  const { level3, primaryRole } = userEntitlement;

  return !!(isValueAllowed(allowedLevel3, level3) || isValueAllowed(allowedPrimaryRoles, primaryRole));
};

const getUserInformation = ({ windowsLogin, name, level3, jobTitle, primaryRole }) => ({
  id: windowsLogin && windowsLogin.toLowerCase(),
  name,
  level3,
  role: jobTitle,
  primaryRole,
  blocked: !windowsLogin || !name
});

const isValueAllowed = (list, value) => {
  // list is not empty and value is included in the list
  return !!(list.length && list.includes(value));
};

const formattedList = (list, splitByKey = ',') => {
  return list.split(splitByKey).filter(x => x);
};
