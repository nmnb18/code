import { jasperGet, jasperPut } from './jasperApiService';
import cloneDeep from 'lodash/cloneDeep';
import { settingsApi } from './apiConfig';
import { Subject } from 'rxjs';
import { switchMap, mapTo, tap } from 'rxjs/operators';

const userSettingsActions$ = new Subject();

export const getUserSettings = username => {
  const url = settingsApi(username);
  return jasperGet(url);
};

export const updateUserSettings = (username, payload) => {
  const userSetting = updateUsernameInSetting(username, payload);
  const url = settingsApi(username);
  return jasperPut(url, userSetting);
};

export const updateUserThemeInSettings = async (
  username,
  currentSettings,
  theme,
  setBlotterUserSettings,
  impersonatedUser
) => {
  console.log(`THEMER: updateUserThemeInSettings called`);

  const userSettings = cloneDeep(currentSettings);

  let savedTheme = getSavedTheme(userSettings);

  // check we need to do this (already handled in function that calls this so can probably remove this check):
  if (theme.value !== savedTheme?.value) {
    // update the theme object
    userSettings.Theme = theme;

    updateUserSettings(username, userSettings)
      .pipe()
      .subscribe(() => {
        console.log(`THEMER: Theme was updated in ${username} settings to ${theme.value}`);
        if (!impersonatedUser && setBlotterUserSettings) {
          setBlotterUserSettings(userSettings);
        }
      });
  }
};

export const getApplication = (userSettings, appName) => {
  if (!userSettings || !appName) return null;

  const applications = userSettings.Applications;
  if (!applications) return null;

  return applications.find(app => app.AppName === appName);
};

export const updateApplicationSettings = (userSettings, appName, updatedAppSettings) => {
  if (updatedAppSettings === null) return userSettings;
  const updatedUserSettings = cloneDeep(userSettings);
  const appIndex = updatedUserSettings.Applications.findIndex(app => app.AppName === appName);
  if (appIndex === -1) return userSettings;
  updatedUserSettings.Applications[appIndex] = cloneDeep(updatedAppSettings);

  return updatedUserSettings;
};

const updateUsernameInSetting = (username, settingPayload) => {
  if (settingPayload && settingPayload.User) return settingPayload;
  return { ...settingPayload, User: username };
};

export const initUpdateUserSettingsSubscription = setBlotterUserSettings => {
  return userSettingsActions$
    .pipe(
      tap(({ payload, skipUpdateUserSettings = false }) => {
        if (!skipUpdateUserSettings) setBlotterUserSettings(payload);
      }),
      switchMap(({ username, payload, skipUpdateUserSettings = false }) =>
        updateUserSettings(username, payload).pipe(mapTo({ payload, skipUpdateUserSettings }))
      )
    )
    .subscribe();
};

export const saveAndRehydrateUserSettings = ({ username, payload }) => {
  if (!username || !payload) return;
  userSettingsActions$.next({ username, payload });
};

const getApplicationByName = (userSettings, AppName) => {
  if (userSettings && userSettings.Applications && AppName) {
    const application = userSettings.Applications.find(app => app.AppName === AppName);
    return application;
  }

  return null;
};

export const removeAppSessionData = (userSettings, AppName) => {
  const updatedUserSettings = cloneDeep(userSettings);
  const application = getApplicationByName(updatedUserSettings, AppName);
  if (application?.sessionData) {
    delete application.sessionData;
  }

  return updatedUserSettings;
};

export const getPopupViewSettings = (userSettings, AppName, ViewName) => {
  const application = getApplicationByName(userSettings, AppName);
  if (!application) return null;

  if (!application.PopUpViews || !application.PopUpViews.length) return null;

  const targetView = ViewName || application.DefaultPopUpView;
  const view = application.PopUpViews.find(el => el.ViewName === targetView);

  return view;
};

export const getSettings = (userSettings, AppName) => {
  const application = getApplicationByName(userSettings, AppName);
  if (!application) return null;

  return application.Settings;
};

export const getSavedTheme = userSettings => {
  if (!userSettings) return null;
  return userSettings.Theme;
};
