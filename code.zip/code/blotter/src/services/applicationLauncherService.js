const fin = window.fin;

/**
 * Launches specified external process and fires callbacks on completion.
 * Must include one of 'path' or 'alias'.
 * @param {Object} ApplicationLauncherOptions
 * @param {string=} ApplicationLauncherOptions.alias
 * @param {string=} ApplicationLauncherOptions.path
 * @param {string|string[]} ApplicationLauncherOptions.args
 * @param {function()=} ApplicationLauncherOptions.successCallback
 * @param {function()=} ApplicationLauncherOptions.failureCallback
 */
export const execute = ({
  alias,
  path,
  args,
  successCallback = processIdentity => {
    console.log('Process ID:' + processIdentity);
  },
  failureCallback = err => {
    console.log('Error: ' + err);
  }
}) => {
  if (!alias && !path) {
    console.error('Alias or Path is must.');
  }

  let formattedArgs;
  if (typeof args === 'string') {
    formattedArgs = args;
  } else if (typeof args === 'object' && Array.isArray(args)) {
    formattedArgs = args.join(' ');
  } else {
    console.error(`Invalid arguments were provided`);
  }
  // 'arguments' is a reserved keyword in Strict Mode so typescript doesn't let us use without quotes.
  // but prettier auto-removes the quotes if you just wrap the word in them.
  // so we are using computed keys with strings.
  // but eslint sees that as pointless, so we tell it to ignore this line.
  // eslint-disable-next-line no-useless-computed-key
  let params = alias ? { alias, ['arguments']: formattedArgs } : { path, ['arguments']: formattedArgs };

  fin.System.launchExternalProcess(params)
    .then(successCallback)
    .catch(failureCallback);
};
