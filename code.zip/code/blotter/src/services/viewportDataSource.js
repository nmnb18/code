import {
  SELECTALL_CHECKBOX_STATE,
  isCheckboxStateUncheck,
  isCheckboxStateCheck,
  isCheckboxStateDash,
  isCheckboxStatePartial
} from '~helpers/exportHelper';
import logFactory from '~helpers/logFactory';
import { WS_COMMANDS } from '~helpers/jasperMessage';
import { format } from 'date-fns';

const log = logFactory('viewportDataSource');
const logRenderingRelated = false;
const logRenderingMetrics = false;

export const viewportDataSourceEvents = {
  ROW_COUNT_CHANGED: 'rowCountChanged',
  ROW_DATA: 'rowData',
  DATA_UPDATED: 'dataUpdated',
  RESET: 'reset',
  SELECT_ROW: 'selectRow',
  SELECT_ALL_CHECKBOX_CHANGED: 'selectAllCheckboxChanged'
};

export const REMOVE_OTHER_SELECTIONS = true;

export function createViewportDatasource(proxyService, autoSelectFeatureOn = false, viewportOptions, handleRFQEvent) {
  function ViewportDatasource(proxyService, autoSelect, _viewportOptions, _handleRFQEvent) {
    this.proxyService = proxyService;
    this.autoSelectFeatureOn = autoSelect;

    this.viewportOptions = _viewportOptions;
    this.sendRFQEvent = _handleRFQEvent;

    this.proxyService.connect(this.eventListener.bind(this));

    this.selectAllStatus = SELECTALL_CHECKBOX_STATE.UNCHECK;
    this.customCheckboxList = [];
  }

  ViewportDatasource.prototype.setViewportRange = function(firstRow, lastRow) {
    this.proxyService.emitViewportRangeEvent({ firstRow, lastRow });
  };

  ViewportDatasource.prototype.init = function(params) {
    this.params = params;
  };

  ViewportDatasource.prototype.destroy = function() {
    this.proxyService.disconnect();
  };

  ViewportDatasource.prototype.eventListener = function(event) {
    switch (event.eventType) {
      case viewportDataSourceEvents.ROW_COUNT_CHANGED:
        this.onRowCountChanged(event);
        break;
      case viewportDataSourceEvents.ROW_DATA:
        this.onRowData(event);
        break;
      case viewportDataSourceEvents.DATA_UPDATED:
        this.onDataUpdated(event);
        break;
      case viewportDataSourceEvents.RESET:
        this.onReset();
        break;
      case viewportDataSourceEvents.SELECT_ROW:
        this.onSelectRow(event);
        break;
      case viewportDataSourceEvents.SELECT_ALL_CHECKBOX_CHANGED:
        this.onSelectAllCheckboxChanged(event);
        break;
      default:
        break;
    }
  };

  ViewportDatasource.prototype.onRowData = function(event) {
    const { rowDataMap, options, updatesSnapshot } = event;
    logRenderingMetrics && log.info('we have data to render', ' | ', format(new Date(), 'hh:mm:ss:SSS'));

    if (options && options.update) {
      const t0 = performance.now();
      logRenderingRelated && log.info('onRowData > update');

      // execute updates 5 by 5
      const defaultBatchSize = 5;
      let iterator = 0;
      let pendingRenders = Object.keys(rowDataMap).length;
      let endingPoint = pendingRenders - defaultBatchSize >= 0 ? defaultBatchSize : pendingRenders;
      let updatesBatch;
      let partialRender = 0;

      logRenderingMetrics && log.info('updating', Object.keys(rowDataMap).length);

      for (const rowIndex in rowDataMap) {
        logRenderingRelated && log.info('before > iterator', iterator, 'endingPoint', endingPoint);
        if (iterator === 0) {
          updatesBatch = {};
        }

        updatesBatch[rowIndex] = rowDataMap[rowIndex];
        iterator++;
        pendingRenders--;

        if (iterator === endingPoint) {
          logRenderingRelated && log.info('partial render', partialRender, JSON.stringify(Object.keys(updatesBatch)));
          partialRender++;
          iterator = 0;
          endingPoint = pendingRenders - defaultBatchSize >= 0 ? defaultBatchSize : pendingRenders;

          logRenderingRelated &&
            log.info('after > iterator', iterator, 'endingPoint', endingPoint, 'pendingRenders', pendingRenders);

          const tt0 = performance.now();
          this.params.setRowData(updatesBatch);

          // Once the rowData has been rendered in the viewport, we can perform other actions on those rows
          if (this.viewportOptions && this.viewportOptions.notifyOnNewMessage) {
            Object.entries(updatesBatch).forEach(([rowIndex, row]) => {
              const updatedRowAction = updatesSnapshot[rowIndex];
              if (updatedRowAction && updatedRowAction === 'NEW_MESSAGE') {
                this.handleRFQEvent(WS_COMMANDS.NEW_MESSAGE, row);
              }
            });
          }

          /*const nodesToRefresh = Object.keys(updatesBatch)
            .map(rowIndex => this.params.getRow(rowIndex))
            .filter(n => n);
          logRenderingRelated && log.info('nodesToRefresh', nodesToRefresh);*/
          //          agGridApi.refreshCells({ rowNodes: nodesToRefresh });

          const tt1 = performance.now();
          const ttotalTime = tt1 - tt0;

          logRenderingMetrics &&
            log.info(`partial render took ${ttotalTime}ms`, ' | ', format(new Date(), 'hh:mm:ss:SSS'));
        }
      }

      if (this.autoSelectFeatureOn) {
        this.runAutoSelection(rowDataMap);
      }

      const t1 = performance.now();
      const totalTime = t1 - t0;
      logRenderingMetrics && log.info(`onRowData took ${totalTime}ms`, ' | ', format(new Date(), 'hh:mm:ss:SSS'));

      if (totalTime > 300) {
        logRenderingRelated && log.info(JSON.stringify(rowDataMap));
        logRenderingRelated && log.info('=====================================');
      }
    } else {
      const t0 = performance.now();
      this.params.setRowData(rowDataMap);
      const t1 = performance.now();
      logRenderingMetrics &&
        log.info(`onRowData for group took ${t1 - t0}ms`, ' | ', format(new Date(), 'hh:mm:ss:SSS'));
      if (this.autoSelectFeatureOn) {
        this.runAutoSelection(rowDataMap);
      }
    }
  };

  ViewportDatasource.prototype.onDataUpdated = function(event) {
    const { changes } = event;

    changes.forEach(change => {
      const rowNode = this.params.getRow(change.rowIndex);
      if (!rowNode || !rowNode.data) return;
      rowNode.setDataValue(change.columnId, change.newValue);
    });
  };

  ViewportDatasource.prototype.onRowCountChanged = function(event) {
    const { rowCount } = event;
    this.params.setRowCount(rowCount, true);
  };

  ViewportDatasource.prototype.onReset = function() {
    this.params.setRowCount(-1);
  };

  ViewportDatasource.prototype.onSelectRow = function(event) {
    const { rowIndex } = event;
    const node = this.params.getRow(rowIndex);
    if (node) {
      node.setSelected(true, REMOVE_OTHER_SELECTIONS);
    }
  };

  ViewportDatasource.prototype.onSelectAllCheckboxChanged = function(event) {
    const {
      checkboxEventValue: { selectAllCheckboxStatus, checkboxList }
    } = event;
    this.selectAllStatus = selectAllCheckboxStatus;
    this.customCheckboxList = checkboxList;
  };

  ViewportDatasource.prototype.runAutoSelection = function(rowDataMap) {
    Object.keys(rowDataMap).forEach(rowIndex => {
      const node = this.params.getRow(rowIndex);
      if (node) {
        if (isCheckboxStateCheck(this.selectAllStatus) && !node.selected) {
          node.setSelected(true, !REMOVE_OTHER_SELECTIONS);
        } else if (isCheckboxStateUncheck(this.selectAllStatus) && node.selected) {
          node.setSelected(false);
        } else if (
          isCheckboxStateDash(this.selectAllStatus) &&
          node.data &&
          !this.customCheckboxList.includes(node.data.key_id)
        ) {
          node.setSelected(true, !REMOVE_OTHER_SELECTIONS);
        } else if (
          isCheckboxStatePartial(this.selectAllStatus) &&
          node.data &&
          this.customCheckboxList.includes(node.data.sowkey)
        ) {
          node.setSelected(true, !REMOVE_OTHER_SELECTIONS);
        }
      }
    });
  };

  ViewportDatasource.prototype.handleRFQEvent = function(rfqEventType, data) {
    const rfqEventPayload = {
      type: rfqEventType,
      data
    };

    this.sendRFQEvent(rfqEventPayload);
  };

  return new ViewportDatasource(proxyService, autoSelectFeatureOn, viewportOptions, handleRFQEvent);
}
