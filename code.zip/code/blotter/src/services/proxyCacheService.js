import { filter, concatMap } from 'rxjs/operators';
import { of } from 'rxjs';
import { WS_COMMANDS } from '~helpers/jasperMessage';
import { INITIAL_RFQ_REQUEST_END_RANGE } from '~helpers/globals';
import { rfqNotificationService } from '~services/rfqNotificationService';

export const initialRFQRequestRange = { firstRow: 0, lastRow: Number(INITIAL_RFQ_REQUEST_END_RANGE) };

const getRequestRange = rfqTotal => {
  const firstRow = initialRFQRequestRange.firstRow;
  const lastRow = rfqTotal > initialRFQRequestRange.lastRow ? initialRFQRequestRange.lastRow : rfqTotal;

  return {
    firstRow,
    lastRow
  };
};

export function createProxyCacheService(subscriptionInstance$, requestDataHandler) {
  const {
    dataSource$,
    RFQPopupManuallyEnabledThisSession,
    rfqNotificationCache$,
    rfqNotificationRequestedRangeSubject,
    handleNotifyNewRFQ
  } = rfqNotificationService;

  function ProxyCacheService(_subscriptionInstance$, _requestDataHandler) {
    this.subscriptionId = null;
    this.startCaching = false;
    this.requestedViewportRange = null;

    // Observables
    this.subscriptionInstance$ = _subscriptionInstance$;

    // Handlers
    this.requestData = _requestDataHandler;

    /*
     * Subscription instance observable provide the current subscription instance Id
     * The subscription instance Id will be used for filtering data that the proxy cache service instance might use
     */
    this.subsIntanceSubscription = this.subscriptionInstance$.subscribe(value => (this.subscriptionId = value));

    /*
     * Requested renge observable provide access to the latest requested viewport range
     * the latest requested viewport range will be used for skip rfq messages
     */

    this.requestedRangeSubscription = rfqNotificationRequestedRangeSubject.subscribe(newRequestRange => {
      this.requestedViewportRange = { ...newRequestRange };
    });

    /*
     * source observable will handle the flow of formatted messages that comes from the websocket
     */
    this.sourceSubscription = dataSource$
      .pipe(
        filter(value => this.isValidRFQ(value)),
        concatMap(value => of(value))
      )
      .subscribe(value => {
        const { command } = value;
        if (
          !this.startCaching &&
          command === WS_COMMANDS.ACK &&
          (value.rfqTotal > 0 || RFQPopupManuallyEnabledThisSession)
        ) {
          this.startCaching = !this.startCaching;
          const { rfqTotal } = value;
          const { firstRow, lastRow } = getRequestRange(rfqTotal);

          handleNotifyNewRFQ({});
          rfqNotificationRequestedRangeSubject.next({ firstRow, lastRow });
        } else if (command === WS_COMMANDS.NEW_MESSAGE) {
          handleNotifyNewRFQ(value);
        }

        rfqNotificationCache$.next(value);
      });
  }

  ProxyCacheService.prototype.isValidRFQ = function(value) {
    return this.isValidSubscriptionId(value) && (this.isAckOrClearCommand(value) || this.validViewportRange(value));
  };

  ProxyCacheService.prototype.disconnect = function() {
    // unsubscribe from observables
    this.subsIntanceSubscription.unsubscribe && this.subsIntanceSubscription.unsubscribe();
    this.sourceSubscription.unsubscribe && this.sourceSubscription.unsubscribe();
    this.requestedRangeSubscription.unsubscribe && this.requestedRangeSubscription.unsubscribe();
  };

  ProxyCacheService.prototype.isValidSubscriptionId = function({ source }) {
    return source === this.subscriptionId;
  };

  ProxyCacheService.prototype.isAckOrClearCommand = function({ command }) {
    return command === WS_COMMANDS.ACK || command === WS_COMMANDS.CLEAR;
  };

  ProxyCacheService.prototype.validViewportRange = function({ vpFirstRow, vpLastRow }) {
    if (!this.requestedViewportRange) return false;

    return vpFirstRow === this.requestedViewportRange.firstRow && vpLastRow === this.requestedViewportRange.lastRow;
  };

  return new ProxyCacheService(subscriptionInstance$, requestDataHandler);
}
