import {
  isJsBehaviorDirectional,
  isJsBehaviorTagStatus,
  isJsBehaviorTagSource,
  isJsBehaviorTagAction,
  showLegIndicator,
  isClientBuy,
  isClientSell,
  isStatusEqual,
  cellHasValue,
  isSourceEqual,
  isActionEqual,
  isStyleNameEqual,
  isAlignEqual,
  TAG_STATUS,
  TAG_ACTION,
  SOURCES,
  STYLENAMES,
  ALIGN
} from '~helpers/columnStyles';
import {
  CALENDAR_COLUMN_FILTER,
  MATURITY_COLUMN_FILTER,
  DYNAMIC_SET_FILTER,
  INTEGER_FILTER,
  FLOAT_STRING,
  DATETIME,
  DATE_FORMAT_STRING
} from '../constants/filters';

import {
  FILTER_MODEL_TEXT,
  FILTER_MODEL_DATE,
  FILTER_MODEL_NUMBER,
  FILTER_MODEL_DYNAMIC_SET,
  FILTER_MODEL_SET
} from '~helpers/filterModelTypes';

import {
  CalendarFilter,
  MaturityFilter,
  CustomAgGridSetFilter,
  CustomAgGridDynamicSetFilter,
  CustomAgGridTextFilter,
  CustomAgGridNumFilter
} from '~components';
import { formatValue } from '~helpers/rfqFormatters';
import { requestXiosWindowFromGrid } from '~helpers/popups';
import { customRenderingColumns } from '~helpers/globals';
import sortIcon from '~assets/icon/util/triangle-active.svg';
import menuIcon from '~assets/icon/util/menu.svg';
import filterIcon from '~assets/icon/util/filter.svg';
import { getAvailableColumns } from '~helpers/availableColumns';
import { customColumnRenderer, CustomAgGridHeaderTextFilter, CustomAgGridHeaderLabelFilter } from '~components';
import { isLegField, isLegRow, isMainRFQLeg, isL1RFQLeg, isL2RFQLeg } from '~helpers/jasperMessage';

export const getFilters = ({ columnDefinition }) => {
  let filterOptions = null;
  if (columnDefinition.codeinstruction && columnDefinition.codeinstruction.columnFilter === DYNAMIC_SET_FILTER) {
    filterOptions = [];
  } else if (columnDefinition.filteroptions) {
    filterOptions = columnDefinition.filteroptions;
  }

  return {
    filter: false,
    filterFramework: getCustomFilter(columnDefinition),
    menuTabs: ['filterMenuTab'],
    filterParams: {
      values: filterOptions,
      sortable: columnDefinition.sortable,
      columnDefinition
    }
  };
};

const getCustomFilter = columnDefinition => {
  if (columnDefinition.codeinstruction && columnDefinition.codeinstruction.columnFilter === DYNAMIC_SET_FILTER) {
    return CustomAgGridDynamicSetFilter;
  }

  if (columnDefinition.codeinstruction && columnDefinition.codeinstruction.advanceFilter) {
    switch (columnDefinition.codeinstruction.advanceFilter) {
      case CALENDAR_COLUMN_FILTER:
        return CalendarFilter;
      case MATURITY_COLUMN_FILTER:
        return MaturityFilter;
      default:
        return false;
    }
  }

  if (columnDefinition.filteroptions !== null) {
    return CustomAgGridSetFilter;
  }

  if (columnDefinition.columntype === INTEGER_FILTER || columnDefinition.columntype === FLOAT_STRING) {
    return CustomAgGridNumFilter;
  }

  if (
    columnDefinition.columntype === DATETIME &&
    columnDefinition.formatinstruction &&
    columnDefinition.formatinstruction.dateFormat === DATE_FORMAT_STRING
  ) {
    return CalendarFilter;
  }

  return CustomAgGridTextFilter;
};

export const getFilterType = columnDefinition => {
  if (!columnDefinition) return FILTER_MODEL_TEXT;

  const { codeinstruction, filteroptions, columntype, formatinstruction } = columnDefinition;

  if (codeinstruction && codeinstruction.columnFilter === DYNAMIC_SET_FILTER) return FILTER_MODEL_DYNAMIC_SET;

  if (filteroptions !== null) return FILTER_MODEL_SET;

  if (codeinstruction && codeinstruction.advanceFilter) {
    switch (codeinstruction.advanceFilter) {
      case CALENDAR_COLUMN_FILTER:
        return FILTER_MODEL_DATE;
      case MATURITY_COLUMN_FILTER:
        return FILTER_MODEL_DATE;
      default:
        return FILTER_MODEL_TEXT;
    }
  }

  if (columntype === INTEGER_FILTER || columntype === FLOAT_STRING) return FILTER_MODEL_NUMBER;

  if (columntype === DATETIME && formatinstruction && formatinstruction.dateFormat === DATE_FORMAT_STRING)
    return FILTER_MODEL_DATE;

  return FILTER_MODEL_TEXT;
};

const getCellClassRules = codeinstruction => {
  if (!codeinstruction) return {};

  const classRules = {};

  classRules['hide-cell-text'] = ({ colDef: { field }, data }) => isLegRow(data) && !isLegField(data, field);
  classRules['leg-indicator'] = params => showLegIndicator(params);
  classRules['leg-indicator-m'] = params => showLegIndicator(params) && isMainRFQLeg(params.data);
  classRules['leg-indicator-l1'] = params => showLegIndicator(params) && isL1RFQLeg(params.data);
  classRules['leg-indicator-l2'] = params => showLegIndicator(params) && isL2RFQLeg(params.data);

  const { styleName, jsBehavior, alignment } = codeinstruction;

  if (styleName) {
    classRules['col-link'] = params => isStyleNameEqual(params, styleName, STYLENAMES.LINK);
    classRules['col-classic'] = params => isStyleNameEqual(params, styleName, STYLENAMES.CLASSIC);
    classRules['col-tag-axe'] = params => isStyleNameEqual(params, styleName, STYLENAMES.TAG_AXE);
    classRules['col-capitalize'] = params => isStyleNameEqual(params, styleName, STYLENAMES.CAPITALIZE);
    classRules['col-time'] = params => isStyleNameEqual(params, styleName, STYLENAMES.TIME);
    classRules['col-font-green'] = params => isStyleNameEqual(params, styleName, STYLENAMES.FONT_GREEN);
    classRules['col-font-red'] = params => isStyleNameEqual(params, styleName, STYLENAMES.FONT_RED);
  }

  if (alignment) {
    classRules['col-align-right'] = params => isAlignEqual(params, alignment, ALIGN.RIGHT);
    classRules['col-align-center'] = params => isAlignEqual(params, alignment, ALIGN.CENTER);
  }

  if (jsBehavior) {
    if (isJsBehaviorDirectional(jsBehavior)) {
      classRules['col-directional-buy-sell'] = params => isClientBuy(params);
      classRules['col-directional-sell-buy'] = params => isClientSell(params);
    }
    if (isJsBehaviorTagStatus(jsBehavior)) {
      classRules['col-tag-status'] = params => cellHasValue(params) && !isLegRow(params.data);
      Object.values(TAG_STATUS).forEach(status => {
        const classname = `col-tag-status-${status.class}`;
        classRules[classname] = params => isStatusEqual(params, status.value);
      });
    }
    if (isJsBehaviorTagAction(jsBehavior)) {
      classRules['col-tag-action'] = params => cellHasValue(params) && !isLegRow(params.data);
      Object.values(TAG_ACTION).forEach(action => {
        const classname = `col-tag-action-${action.class}`;
        classRules[classname] = params => isActionEqual(params, action.value);
      });
    }
    if (isJsBehaviorTagSource(jsBehavior)) {
      classRules['col-tag-source'] = params => cellHasValue(params);
      Object.values(SOURCES).forEach(source => {
        const classname = `col-tag-source--${source}`;
        classRules[classname] = params => isSourceEqual(params, source);
        classRules[`${classname}-active`] = params => isSourceEqual(params, source, true);
      });
    }
  }

  return classRules;
};
export const getMinWidth = codeinstruction => {
  if (!codeinstruction || !codeinstruction.hasOwnProperty('minWidth')) return null;

  return codeinstruction.minWidth;
};

const getCustomHeaderComponents = () => ({
  CustomAgGridHeaderTextFilter: CustomAgGridHeaderTextFilter,
  CustomAgGridHeaderLabelFilter: CustomAgGridHeaderLabelFilter
});

const getCustomHeaderComponent = codeinstruction => {
  if (!codeinstruction || !codeinstruction.headerFilter) return null;

  const { headerFilter } = codeinstruction;
  const customHeaderComponents = getCustomHeaderComponents();

  return customHeaderComponents[headerFilter];
};

export const isColumnResizable = codeinstruction => {
  if (!codeinstruction || !codeinstruction.hasOwnProperty('minWidth')) return false;

  return true;
};

export const getCustomCellRenderer = (sourcecolumnname, customRenderingColumnsObj) => {
  return customRenderingColumnsObj[sourcecolumnname] ? customColumnRenderer : null;
};

export const getCustomCellRendererParams = (sourcecolumnname, customRenderingColumnsObj, currentUser, signedInUser) => {
  if (!customRenderingColumnsObj[sourcecolumnname]) return null;

  return { columnCallback: requestXiosWindowFromGrid, currentUser, signedInUser };
};

// This helper method is used for both FlowGrid and RFQGrid
// any custom ag component that we configured here must be included in the frameworkComponents property for both grid components
const formattedColumnDefinition = (viewColumn, columnDefinition, currentUser, signedInUser) => {
  const { size, sort } = viewColumn || {};
  const {
    codeinstruction,
    columntype,
    displayname,
    displaywidth,
    filterable,
    formatinstruction,
    sortable,
    sourcecolumnname
  } = columnDefinition;

  // RFQ notification doesn't support filters
  const filters = getFilters({ viewColumn, columnDefinition });
  const customCellClassRules = getCellClassRules(codeinstruction);
  const customResizable = isColumnResizable(codeinstruction);
  const customMinWidth = getMinWidth(codeinstruction);
  const customCellRenderer = getCustomCellRenderer(sourcecolumnname, customRenderingColumns);
  const customCellRendererParams = getCustomCellRendererParams(
    sourcecolumnname,
    customRenderingColumns,
    currentUser,
    signedInUser
  );
  const customHeaderComponent = getCustomHeaderComponent(codeinstruction);
  return {
    headerName: displayname,
    field: sourcecolumnname,
    colId: sourcecolumnname,
    columnType: columntype,
    suppressMovable: false,
    suppressMenu: !filterable,
    sortable: sort || sortable,
    filter: filterable,
    lockPinned: false,
    resizable: customResizable,
    minWidth: customMinWidth,
    icons: {
      sortAscending: `<img class="sort-icon-asc" src=${sortIcon} />`,
      sortDescending: `<img class="sort-icon-des" src=${sortIcon} />`,
      filter: `<img class="filter-icon" src=${filterIcon} />`,
      menu: `<img class="menu-icon" src=${menuIcon} />`
    },
    width: size || displaywidth,
    hide: false, // !required // This field need to be updated in the service
    valueFormatter: params =>
      formatValue({ params, field: sourcecolumnname, columntype, formatinstruction, codeinstruction }),
    cellClassRules: customCellClassRules,
    cellRenderer: customCellRenderer,
    cellRendererParams: customCellRendererParams,
    tooltipComponent: customRenderingColumns['tooltipColumns'][sourcecolumnname] ? 'customTooltip' : null,
    tooltipValueGetter: function(params) {
      return customRenderingColumns['tooltipColumns'][sourcecolumnname] ? { value: params.value } : '';
    },
    headerComponentFramework: customHeaderComponent,
    ...filters
  };
};

export const getColumnsDefinition = ({ view, columnsDictionary, currentUser, isTechOrAdmin, signedInUser }) => {
  if (view && view.Columns && columnsDictionary && columnsDictionary.sourceColumnNames) {
    const { Columns: ViewColumns } = view;
    const { sourceColumnNames } = columnsDictionary;

    const availableSourceColumns = getAvailableColumns(sourceColumnNames, isTechOrAdmin);

    const columnsDefinition = ViewColumns.map(viewColumn => {
      const columnDefinition = availableSourceColumns.find(
        ({ sourcecolumnname }) => sourcecolumnname === viewColumn.ColName
      );
      return columnDefinition
        ? formattedColumnDefinition(viewColumn, columnDefinition, currentUser, signedInUser)
        : null;
    });
    return columnsDefinition.filter(columnDefinition => columnDefinition);
  }
  return null;
};

export const getRFQColumnsDefinition = (columnsDictionary, currentUser) => {
  if (columnsDictionary && columnsDictionary.sourceColumnNames) {
    const { sourceColumnNames } = columnsDictionary;
    const Columns = sourceColumnNames.filter(({ available }) => available);

    return Columns.map(columnDefinition => {
      columnDefinition.displaywidth = 100; // TODO: remove this when services updates this value
      return formattedColumnDefinition(null, columnDefinition, currentUser);
    });
  }
  return null;
};

export const getFiltersByType = (columnsDictionary, columnFilterType) => {
  if (columnFilterType && columnsDictionary && columnsDictionary.sourceColumnNames) {
    const { sourceColumnNames } = columnsDictionary;
    const filters = sourceColumnNames.filter(
      sourceColumn =>
        sourceColumn.codeinstruction &&
        sourceColumn.codeinstruction.columnFilter &&
        sourceColumn.codeinstruction.columnFilter === columnFilterType
    );
    return filters.length ? filters : null;
  }

  return null;
};

export const firstColumnOfGrid = {
  headerName: '',
  field: 'key_id',
  colId: 'key_id',
  suppressMovable: true,
  suppressMenu: true,
  sortable: false,
  filter: false,
  lockPosition: true,
  lockPinned: true,
  pinned: 'left',
  valueFormatter: function() {
    return '';
  },
  resizable: false,
  width: 40,
  hide: false,
  checkboxSelection: true
};

export const firstColumnOfGridState = {
  aggFunc: null,
  available: true,
  colId: 'key_id',
  displayname: ' ',
  hide: false,
  lockPinned: true,
  lockPosition: true,
  pinned: 'left',
  pivotIndex: 0,
  required: true,
  rowGroupIndex: null,
  width: 40
};

export const checkboxColumnDefinition = {
  headerName: '',
  field: 'key_id',
  colId: 'key_id',
  suppressMovable: true,
  suppressMenu: true,
  sortable: false,
  filter: false,
  lockPosition: true,
  lockPinned: true,
  pinned: 'left',
  valueFormatter: function() {
    return '';
  },
  resizable: false,
  width: 40,
  hide: false,
  checkboxSelection: true
};

export const checkboxColumnState = {
  aggFunc: null,
  available: true,
  colId: 'key_id',
  displayname: ' ',
  hide: false,
  lockPinned: true,
  lockPosition: true,
  pinned: 'left',
  pivotIndex: 0,
  required: true,
  rowGroupIndex: null,
  width: 40
};

export const filterRepetedColumn = (sourceColumns, excludedColumns) => {
  const excludedColumnsKey = excludedColumns.map(item => item.field);
  const sourceColumnsKey = sourceColumns.map(item => item.field);
  const nonRepeatedSourceKeys = sourceColumnsKey.filter(sourcekey => !excludedColumnsKey.includes(sourcekey));
  return sourceColumns.filter(sourceColumn => nonRepeatedSourceKeys.includes(sourceColumn.field));
};
