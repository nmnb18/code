import { arrayFromIterator } from 'flow-navigator-shared/dist/array';
const formatUID = (...str) => (str || []).join('-').toLowerCase();

class KVPStoreSingleton {
  static instance;

  constructor() {
    this.store = new Map();
  }

  static getInstance() {
    if (!KVPStoreSingleton.instance) {
      KVPStoreSingleton.instance = new KVPStoreSingleton();
    }

    return KVPStoreSingleton.instance;
  }

  get = key => {
    return this.store.get(key);
  };

  set = (key, value) => {
    this.store.set(key, value);
  };

  delete = key => {
    this.store.delete(key);
  };

  findUID = partialKey =>
    this.entries()
      .map(([key]) => key)
      .find(key => key.includes(partialKey));

  clear = () => {
    this.store.clear();
  };

  entries = () => arrayFromIterator(this.store.entries());
}

const kvpStore = KVPStoreSingleton.getInstance();

export { kvpStore, formatUID };
