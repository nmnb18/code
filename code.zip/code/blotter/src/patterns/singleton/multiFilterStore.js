const BLANKS_VALUE = '';
const BLANKS_LABEL = '(Blanks)';

const safeOptionValue = option => option || BLANKS_VALUE;
const safeOptionLabel = option => option || BLANKS_LABEL;

class MultiFilterStoreSingleton {
  static instance;

  constructor() {
    this.multiFilterSet = {};
    this.multiFilterMap = {};
  }

  static getInstance() {
    if (!MultiFilterStoreSingleton.instance) {
      MultiFilterStoreSingleton.instance = new MultiFilterStoreSingleton();
    }

    return MultiFilterStoreSingleton.instance;
  }

  initSet = key => {
    this.multiFilterSet[key] = new Set();
  };

  getSetOptions = key => {
    return this.multiFilterSet[key];
  };

  addSetOption = (key, option) => {
    const mfSetOptions = this.getSetOptions(key);

    if (mfSetOptions) {
      mfSetOptions.add(safeOptionValue(option));
      return;
    }

    this.initSet(key);
    this.addSetOption(key, option);
  };

  initMap = key => {
    this.multiFilterMap[key] = {};
  };

  getMap = key => {
    return this.multiFilterMap[key];
  };

  setMap = (key, value) => {
    this.multiFilterMap[key] = value;
  };
}

const multiFilterStore = MultiFilterStoreSingleton.getInstance();

export { multiFilterStore, BLANKS_VALUE, BLANKS_LABEL, safeOptionValue, safeOptionLabel };
