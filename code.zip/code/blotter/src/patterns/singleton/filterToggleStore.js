import { arrayFromIterator } from 'flow-navigator-shared/dist/array';
import { Subject } from 'rxjs';

const formatUID = (...str) => (str || []).join('-').toLowerCase();

class FilterToggleStore {
  static instance;

  constructor() {
    this.store = new Map();
    this.stateChangeHandler$ = new Subject();
  }

  static getInstance() {
    if (!FilterToggleStore.instance) {
      FilterToggleStore.instance = new FilterToggleStore();
    }

    return FilterToggleStore.instance;
  }

  get = key => {
    return this.store.get(key);
  };

  set = (key, value) => {
    this.store.set(key, value);
  };

  delete = key => {
    this.store.delete(key);
  };

  findUID = partialKey =>
    this.entries()
      .map(([key]) => key)
      .find(key => key.includes(partialKey));

  clear = () => {
    this.store.clear();
  };

  entries = () => arrayFromIterator(this.store.entries());

  handleStateChange = stateChange => {
    this.stateChangeHandler$.next(stateChange);
  };

  get stateChanges$() {
    return this.stateChangeHandler$.asObservable();
  }
}

const filterToggleStore = FilterToggleStore.getInstance();

export { filterToggleStore, formatUID };
