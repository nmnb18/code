import { executeBBGSendKeysCommand, executeBBGCommandConsole } from '~services/bloombergService';

const bloombergCommandConfiguration = {
  BBGSendKeys: executeBBGSendKeysCommand,
  BloombergCommandConsole: executeBBGCommandConsole
};

export function BloombergCommandFactory() {
  this.create = bbgSender => {
    return bloombergCommandConfiguration[bbgSender];
  };
}
