import {
  FILTER_MODEL_SET,
  FILTER_MODEL_DYNAMIC_SET,
  FILTER_MODEL_TEXT,
  FILTER_MODEL_NUMBER
} from '~constants/filterModelTypes';
import { parseSetValue } from '~helpers/filterOptionsParser';
import { isString } from '~helpers/dataTypes';

const SetFilter = function({ field, headerName, filter }) {
  this.field = field;
  this.headerName = headerName;
  this.filter = filter;
  this.filterType = FILTER_MODEL_SET;
  this.type = '';
};

const DynamicSetFilter = function({ field, headerName, arrayFilter, textFilter }) {
  this.field = field;
  this.headerName = headerName;
  this.arrayFilter = arrayFilter;
  this.textFilter = textFilter;
  this.filterType = FILTER_MODEL_DYNAMIC_SET;
  this.type = '';
};

const NumFilter = function({ field, headerName, filter, type = '' }) {
  this.field = field;
  this.headerName = headerName;
  this.filter = filter;
  this.filterType = FILTER_MODEL_NUMBER;
  this.type = type;
};

const TextFilter = function({ field, headerName, filter }) {
  this.field = field;
  this.headerName = headerName;
  this.filter = filter;
  this.filterType = FILTER_MODEL_TEXT;
  this.type = '';
};

const filterTypes = {
  SetFilter: 'SetFilter',
  DynamicSetFilter: 'DynamicSetFilter',
  NumFilter: 'NumFilter',
  TextFilter: 'TextFilter'
};

const Filters = {
  SetFilter,
  DynamicSetFilter,
  NumFilter,
  TextFilter
};

const agGridFilterTypes = {
  CustomAgGridSetFilter: SetFilter,
  dynamicSetFilter: DynamicSetFilter,
  CustomAgGridTextFilter: TextFilter,
  CustomAgGridNumFilter: NumFilter
};

const isAgDynamicSetFilter = filterType => filterType === DynamicSetFilter;

const isAgSetFilter = filterType => filterType === SetFilter;

function CustomFilterFactory() {
  this.createFilter = function(type, attributes) {
    const FilterType = Filters[type];
    return new FilterType(attributes);
  };

  this.createCustomFilter = (colDef, value) => {
    const {
      field,
      headerName,
      filterParams: { values = [], columnDefinition }
    } = colDef;

    const { columnFilter } = columnDefinition.codeinstruction;
    const FilterType = agGridFilterTypes[columnFilter];

    if (!isAgDynamicSetFilter(FilterType)) {
      const filter = isAgSetFilter(FilterType) && isString(value) ? parseSetValue(value, values) : value;

      return new FilterType({
        field,
        headerName,
        filter
      });
    }

    let arrayFilter = [];
    let textFilter = '';

    if (isString(value)) {
      textFilter = value;
    } else if (Array.isArray(value)) {
      arrayFilter.push(value);
    }

    return new FilterType({
      field,
      headerName,
      arrayFilter,
      textFilter
    });
  };
}

export { CustomFilterFactory, filterTypes, isAgDynamicSetFilter, isAgSetFilter };
