export const FILTER_MODEL_DYNAMIC_SET = 'dynamic_set';
export const FILTER_MODEL_SET = 'set';
export const FILTER_MODEL_TEXT = 'text';
export const FILTER_MODEL_NUMBER = 'number';
export const FILTER_MODEL_DATE = 'date';
