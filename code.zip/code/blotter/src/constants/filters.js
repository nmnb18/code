export const CALENDAR_COLUMN_FILTER = 'calendarColumnFilter';
export const MATURITY_COLUMN_FILTER = 'maturityColumnFilter';

export const TEXT_FILTER = 'CustomAgGridTextFilter';
export const NUM_FILTER = 'CustomAgGridNumFilter';
export const SET_FILTER = 'CustomAgGridSetFilter';
export const CALENDAR_FILTER = 'CalendarFilter';
export const MATURITY_FILTER = 'MaturityFilter';
export const DYNAMIC_SET_FILTER = 'dynamicSetFilter';

export const AG_SET_FILTER = 'agSetColumnFilter';
export const AG_TEXT_FILTER = 'agTextColumnFilter';
export const AG_NUMBER_FILTER = 'agNumberColumnFilter';
export const AG_DATE_FILTER = 'agDateColumnFilter';
export const INTEGER_FILTER = 'INTEGER';
export const TEXT_STRING = 'STRING';
export const FLOAT_STRING = 'FLOAT';
export const DATETIME = 'DATETIME';
export const FILTER_RANGE_EQUALS = 'equals';
export const FILTER_RANGE_LESS_X = 'lessthan';
export const FILTER_RANGE_LESS_EQUAL_X = 'lessthanorequal';
export const FILTER_RANGE_GREAT_X = 'greaterthan';
export const FILTER_RANGE_GREAT_EQUAL_X = 'greaterthanorequal';
export const DATE_FORMAT_STRING = 'MMM-dd-yyyy';
export const REACT_COMPONENT_FILTER_STRING = 'reactComponent';
export const MAX_FILTER_SIZE = Number(process.env.REACT_APP_JASPER_WS_MAX_FILTER_SIZE);
export const FILTER_TYPES = {
  EQUALS: 'equals',
  LESS_THAN: 'lessThan',
  LESS_THAN_OR_EQUAL: 'lessThanOrEqual',
  GREATER_THAN: 'greaterThan',
  GREATER_THAN_OR_EQUAL: 'greaterThanOrEqual'
};
export const AXED_FILTER = ['BUY', 'SELL', 'DOUBLE SIDED'];
export const AXED_FILTER_DISABLE_OPTIONS = ['Select All', 'NONE'];

export const FILTER_TYPES_ARRAY = [
  {
    value: FILTER_TYPES.EQUALS,
    stringValue: 'Equals',
    symbol: '='
  },
  {
    value: FILTER_TYPES.LESS_THAN,
    stringValue: 'Less than',
    symbol: '<'
  },
  {
    value: FILTER_TYPES.LESS_THAN_OR_EQUAL,
    stringValue: 'Less than or equals',
    symbol: '<='
  },
  {
    value: FILTER_TYPES.GREATER_THAN,
    stringValue: 'Greater than',
    symbol: '>'
  },
  {
    value: FILTER_TYPES.GREATER_THAN_OR_EQUAL,
    stringValue: 'Greater than or equals',
    symbol: '>='
  }
];
