const fin = window.fin;
const VERSION = '@VERSION-2.3.0@';
const defaultVersion = '0.1.0';

// TODO: Refactor following code, we should use values from environment files instead of hardcode
const blotterContainerUrls = [
  'http://localhost:3100/#/',
  'http://jaspertest.jefferies.com:8400/#/',
  'http://jasperauthd.jefferies.com:8300/#/',
  'http://jasperldn.jefferies.com:8300/#/',
  'http://jasperauthd.jefferies.com:8310/#/',
  'http://jaspertest.jefferies.com:8300/#/',
  'http://localhost:3100',
  'http://jaspertest.jefferies.com:8400',
  'http://jasperauthd.jefferies.com:8300',
  'http://jasperldn.jefferies.com:8300',
  'http://jasperauthd.jefferies.com:8310',
  'http://jaspertest.jefferies.com:8300'
];

const convertVersionToNumber = version => {
  if (!version) return 0;
  const dotRegex = /\./g;
  const formattedVersion = version.replace(dotRegex, '');
  return +formattedVersion;
};

async function clearCache() {
  const app = await fin.Application.getCurrent();
  const info = await app.getInfo();

  const manifestVersion =
    (info &&
      info.manifest &&
      info.manifest.startup_app &&
      info.manifest.startup_app.metadata &&
      info.manifest.startup_app.metadata.version) ||
    defaultVersion;
  console.log(`Running Jasper on ${manifestVersion} version`);
  const newVersionNumber = convertVersionToNumber(manifestVersion);

  const previousVersion = window.localStorage.getItem('version') || defaultVersion;
  const previousVersionNumber = convertVersionToNumber(previousVersion);

  const currentAppOrigin = window.location.origin;
  const isBlotterContainer = blotterContainerUrls.includes(currentAppOrigin);

  if (isBlotterContainer && previousVersionNumber !== newVersionNumber) {
    console.log(`Cleaning up the cache. Updating from version ${previousVersion} to version ${manifestVersion}`);
    fin.desktop.System.clearCache(
      {
        cache: true,
        cookies: false,
        localStorage: false,
        appcache: true
      },
      () => {
        console.log(`Storing new version ${manifestVersion} in localStorage`);
        window.localStorage.setItem('version', manifestVersion);
      }
    );
  }
}

clearCache();
