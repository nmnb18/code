## Requirements

Install a Node Version Manager to allow easy switching of Node versions.
Recommended: [nvm-windows](https://github.com/coreybutler/nvm-windows) or [Volta](https://volta.sh/)

Using a Node Version Manager install the same version of Node we run in Bamboo (currently Node v8.11.3) and switch to it.

Confirm you are using correct version by running both `node -v` and the command of your Version Manager to show current used version (eg `nvm list` for nvm-windows).

Whenever you run any commands that will adjust package dependencies (eg `npm install` `npm install PACKAGE-NAME`, etc) you must be using the same version of Node we run in Bamboo.

Install [OpenFin CLI](https://developers.openfin.co/docs/getting-started#section-install-and-test-openfin-cli-tools). The instructions recommend using Node 12 or above, but you should use the same Node version as we run on Bamboo.

## Application Links

[DEV](https://install.openfin.co/download?fileName=Flow-Navigator-DEV&config=http://jasperauthd.jefferies.com:2100/api/jaspwebstaticlauncherblottercontainer/app.json&unzipped=true)

[UAT- 2D and AWS](https://install.openfin.co/download?fileName=Flow-Navigator-UAT&config=http://jaspertest.jefferies.com:2100/api/jasper-web-static-launcher-blotter-container/app.json&unzipped=true)

[PROD-UK server UK-AWS-AMPS](https://install.openfin.co/download?fileName=Flow-Navigator-UK&config=http://jasperldn.jefferies.com:2100/api/jasper-web-static-launcher-blotter-container/app.json&unzipped=true)

[PROD-US server US-AWS-AMPS](https://install.openfin.co/download?fileName=Flow-Navigator-US&config=http://jasperus1p.jefferies.com:2100/api/jasper-web-static-launcher-blotter-container/app.json&unzipped=true)

## Development steps

#### For local DEV environment

1. Clone both repositories: `Blotter container` and `Flow blotter app`.
2. Go to `Blotter container` project directoy, open a terminal and execute command `npm install`. Wait until dependencies installation is done, then execute command `npm run dev` to start `Blotter container` project.
3. Go to `Flow blotter app` project directoy, open a terminal and execute command `npm install`. Wait until dependencies installation is done, then execute command `npm run dev` to start `Flow blotter app` project.
4. Once both projects are up and running, go to `Blotter container` project directoy, open a new terminal and execute command `npm run openfin`.

#### For local UAT environment

1. Clone both repositories: `Blotter container` and `Flow blotter app`.
2. Go to `Blotter container` project directoy, open a terminal and execute command `npm install`. Wait until dependencies installation is done, then execute command `npm run uat` to start `Blotter container` project.
3. Go to `Flow blotter app` project directoy, open a terminal and execute command `npm install`. Wait until dependencies installation is done, then execute command `npm run uat` to start `Flow blotter app` project.
4. Once both projects are up and running, go to `Blotter container` project directoy, open a new terminal and execute command `npm run openfin:uat`.

#### For local PROD UK environment

1. Clone both repositories: `Blotter container` and `Flow blotter app`.
2. Go to `Blotter container` project directoy, open a terminal and execute command `npm install`. Wait until dependencies installation is done, then execute command `npm run produk` to start `Blotter container` project.
3. Go to `Flow blotter app` project directoy, open a terminal and execute command `npm install`. Wait until dependencies installation is done, then execute command `npm run produk` to start `Flow blotter app` project.
4. Once both projects are up and running, go to `Blotter container` project directoy, open a new terminal and execute command `npm run openfin:produk`.

#### For local PROD US environment

1. Clone both repositories: `Blotter container` and `Flow blotter app`.
2. Go to `Blotter container` project directoy, open a terminal and execute command `npm install`. Wait until dependencies installation is done, then execute command `npm run produs` to start `Blotter container` project.
3. Go to `Flow blotter app` project directoy, open a terminal and execute command `npm install`. Wait until dependencies installation is done, then execute command `npm run produs` to start `Flow blotter app` project.
4. Once both projects are up and running, go to `Blotter container` project directoy, open a new terminal and execute command `npm run openfin:produs`.

## Release steps

#### For DEV environment

1. Raise a `Pull Request` from `feature` branch to `develop` branch.
2. Once `PR` get merged to `develop` branch, `Bamboo` will execute a plan for `development` environment.
3. Publish latest development artifact.

#### For UAT environment

1. Raise a `Pull Request` from `develop` branch to `uat` branch.
2. Once `PR` get merged to `uat` branch, `Bamboo` will execute a plan for `uat` environment.
3. Publish latest uat artifact.

#### For PROD UK/US environment

1. Raise a `Pull Request` from `uat` branch to `master` branch.
2. Once `PR` get merged to `master` branch, we can manually run `Bamboo` plan for `PROD UK` or `PROD US` environment only one at the time.
3. For Build phase:
   1. Click on `Run` option (from top menu).
   2. Click on `Run customized` option.
   3. Click on `Override a variable` and update the value for `version` variable.
   4. Click on `Run` button.
4. For Publish phase:
   1. Click on `Actions` option (from top menu).
   2. Click on `Configure plan` option.
   3. Click on `Publish artifact` (from left menu).
   4. Based on target environment for release to `PROD` we need to enable/disable task for `PROD UK` or `PROD US`.
5. Publish latest production artifact.
