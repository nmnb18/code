import { zonedTimeToUtc, utcToZonedTime, format } from 'date-fns-tz';

export const TIME_FORMAT = 'HH:mm:ss zzz';
export const DISPLAY_DATE_FORMAT = 'MMM-dd-yyyy';
export const COPY_TIME_FORMAT = 'HHmmss';

// Convert time to local timezone
export const dateTimezoneToLocalTimezone = (sourcedate, sourcetimezone, formatStr = TIME_FORMAT) => {
  if (!sourcedate || !sourcetimezone) return null;

  const timeUTCFormatted = zonedTimeToUtc(sourcedate, sourcetimezone);
  const localTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const finalTimeForUser = format(timeUTCFormatted, formatStr, { timeZone: localTimezone }).toUpperCase();

  return finalTimeForUser;
};

// Convert time to UTC
export const dateTimezoneToUTC = (sourcedate, sourcetimezone, formatStr = TIME_FORMAT) => {
  if (!sourcedate || !sourcetimezone) return null;

  const timeUTCFormatted = zonedTimeToUtc(sourcedate, sourcetimezone);
  const destinationTime = utcToZonedTime(timeUTCFormatted, 'Etc/UTC');
  const finalTimeForUser = format(destinationTime, formatStr, { timeZone: 'Etc/UTC' }).toUpperCase();

  return finalTimeForUser;
};

// Convert time to a different timezone
export const dateTimezoneToAnotherTimezone = (
  sourcedate,
  sourcetimezone,
  destinationtimezone,
  formatStr = TIME_FORMAT
) => {
  if (!sourcedate || !sourcetimezone || !destinationtimezone) return null;

  const timeUTCFormatted = zonedTimeToUtc(sourcedate, sourcetimezone);
  const destinationTime = utcToZonedTime(timeUTCFormatted, destinationtimezone);
  const finalTimeForUser = format(destinationTime, formatStr, { timeZone: destinationtimezone }).toUpperCase();

  return finalTimeForUser;
};
