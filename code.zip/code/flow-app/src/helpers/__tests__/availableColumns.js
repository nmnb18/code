import { getAvailableColumns } from '~helpers/availableColumns';

const sourceColumns = [
  { colId: 'key_id', field: 'key_id', headerName: 'Key Id', available: true },
  { colId: 'rfqaxed', field: 'rfqaxed', headerName: 'Axe', available: true },
  { colId: 'clientbuysell', field: 'clientbuysell', headerName: 'Client B/S', available: true },
  { colId: 'l1_clientbuysell', field: 'l1_clientbuysell', headerName: 'Client B/S', available: false },
  { colId: 'l2_clientbuysell', field: 'l2_clientbuysell', headerName: 'Client B/S', available: false }
];

describe('availableColumns', () => {
  test('get available columns for tech or admin user', () => {
    const result = getAvailableColumns(sourceColumns, true);
    expect(result).toEqual(sourceColumns);
  });

  test('get available columns for non tech or admin user', () => {
    const result = getAvailableColumns(sourceColumns, false);
    expect(result).toEqual([
      { colId: 'key_id', field: 'key_id', headerName: 'Key Id', available: true },
      { colId: 'rfqaxed', field: 'rfqaxed', headerName: 'Axe', available: true },
      { colId: 'clientbuysell', field: 'clientbuysell', headerName: 'Client B/S', available: true }
    ]);
  });
});
