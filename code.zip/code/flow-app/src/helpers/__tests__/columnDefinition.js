import { removeColumn, removeRepeatedColumn } from '~helpers/columnDefinition';

const sourceColumns = [
  { colId: 'key_id', field: 'key_id', headerName: 'Key Id' },
  { colId: 'rfqaxed', field: 'rfqaxed', headerName: 'Axe' }
];
const repeatedColumns = [{ colId: 'key_id', field: 'key_id', headerName: 'Key Id' }];
const nonRepeatedColumns = [{ colId: 'countdown', field: 'countdown', headerName: 'Axe' }];

describe('columnDefinition', () => {
  test('remove column', () => {
    const result = removeColumn(sourceColumns, 'key_id');
    expect(result).toEqual([{ colId: 'rfqaxed', field: 'rfqaxed', headerName: 'Axe' }]);
  });

  test('skip remove column', () => {
    const result = removeColumn(sourceColumns, 'invalid');
    expect(result).toEqual(sourceColumns);
  });

  test('remove repeated column', () => {
    const result = removeRepeatedColumn(sourceColumns, repeatedColumns);
    expect(result).toEqual([{ colId: 'rfqaxed', field: 'rfqaxed', headerName: 'Axe' }]);
  });

  test('skip remove non repeated column', () => {
    const result = removeRepeatedColumn(sourceColumns, nonRepeatedColumns);
    expect(result).toEqual(sourceColumns);
  });
});
