import { formatComma, decimalValueForExcel, formatCopyToClipboardData } from '~helpers/rfqFormatters';
import { COLUMNS_TYPE } from '~helpers/columnStyles';
import * as columnDictionary from '../../mocks/columnDictionary.json';

describe('rfqFormatters', () => {
  describe('formatComma', () => {
    // Integer columntype cases
    test('Value: 0, columnType: Integer', () => {
      const result = formatComma('0', COLUMNS_TYPE.INTEGER);
      expect(result).toBe('0');
    });

    test('Value: 123, columnType: Integer', () => {
      const result = formatComma('123', COLUMNS_TYPE.INTEGER);
      expect(result).toBe('123');
    });

    test('Value: 1234, columnType: Integer', () => {
      const result = formatComma('1234', COLUMNS_TYPE.INTEGER);
      expect(result).toBe('1,234');
    });

    test('Value: 0.12, columnType: Integer', () => {
      const result = formatComma('0.12', COLUMNS_TYPE.INTEGER);
      expect(result).toBe('0');
    });

    test('Value: 1234.565, columnType: Integer', () => {
      const result = formatComma('1234.565', COLUMNS_TYPE.INTEGER);
      expect(result).toBe('1,234');
    });

    test('Value: 12345, columnType: Integer', () => {
      const result = formatComma('12345', COLUMNS_TYPE.INTEGER);
      expect(result).toBe('12,345');
    });

    test('Value: 5.0E10, columnType: Integer', () => {
      const result = formatComma('5.0E10', COLUMNS_TYPE.INTEGER);
      expect(result).toBe('50,000,000,000');
    });

    // Float columntype cases
    test('Value: 0, columnType: Float', () => {
      const result = formatComma('0', COLUMNS_TYPE.FLOAT);
      expect(result).toBe('0');
    });

    test('Value: 5678, columnType: Float', () => {
      const result = formatComma('5678', COLUMNS_TYPE.FLOAT);
      expect(result).toBe('5,678');
    });

    test('Value: 1234.56789, columnType: Float', () => {
      const result = formatComma('1234.56789', COLUMNS_TYPE.FLOAT);
      expect(result).toBe('1,234.56789');
    });

    test('Value: 6.200, columnType: Float', () => {
      const result = formatComma('6.200', COLUMNS_TYPE.FLOAT);
      expect(result).toBe('6.200');
    });

    test('Value: 1234.567, columnType: Float', () => {
      const result = formatComma('1234.567', COLUMNS_TYPE.FLOAT);
      expect(result).toBe('1,234.567');
    });

    test('Value: 0.12, columnType: Float', () => {
      const result = formatComma('0.12', COLUMNS_TYPE.FLOAT);
      expect(result).toBe('0.12');
    });
  });

  describe('decimalValueForExcel', () => {
    test('should return empty string', () => {
      const result = decimalValueForExcel();
      expect(result).toBe('');
    });

    test('should return a float number', () => {
      const result = decimalValueForExcel('100.1');
      expect(result).toBe(100.1);
    });

    test('should return a integer number', () => {
      const result = decimalValueForExcel('100.0');
      expect(result).toBe(100);
    });
  });

  describe('formatCopyToClipboardData', () => {
    const headers = [
      { headerName: 'Description', field: 'description', width: 18 },
      { headerName: 'CUSIP/ISIN', field: 'code', width: 12 },
      { headerName: 'Ask Px-Bid Px', field: 'rfqbbgask', width: 20 },
      { headerName: 'Size', field: 'size', width: 6 },
      { headerName: 'Price', field: 'rfqdealvalue', width: 18 },
      { headerName: 'Currency', field: 'currencystr', width: 8 }
    ];
    const headerFields = ['description', 'code', 'rfqbbgask', 'size', 'rfqdealvalue', 'currencystr'];
    const data = [
      {
        description: 'Test-Desc',
        code: 'Test-code',
        rfqbbgask: '102.302',
        rfqbbgbid: '102.890',
        size: 2000,
        rfqdealvalue: 123,
        currencystr: 'USA'
      }
    ];
    test('should return formatted copy template data', () => {
      const result = formatCopyToClipboardData(data, headers, headerFields, columnDictionary.columnDictionary);
      expect(result[0][2]).toBe('102.302-102.890     ');
    });

    test('should return formatted data even if key not present in data', () => {
      const tempData = [...data];
      delete tempData[0].rfqbbgask;
      const result = formatCopyToClipboardData(data, headers, headerFields, columnDictionary.columnDictionary);
      expect(result[0][2]).toBe('                    ');
    });

    test('should return formatted data even if value is blank or null', () => {
      const tempData = [...data];
      tempData[0].size = '';
      const result = formatCopyToClipboardData(data, headers, headerFields, columnDictionary.columnDictionary);
      expect(result[0][2]).toBe('                    ');
    });
  });
});
