import { newTextFilter, addFilter, getColumnFilterValue, hasFilter } from '~helpers/filters';

const codeFilter = { field: 'code', headerName: 'CUSIP/ISIN', filter: 'us11', filterType: 'text', type: '=' };
const currencystrFilter = {
  field: 'currencystr',
  headerName: 'Currency',
  filter: ['USD'],
  filterType: 'set',
  type: ''
};
const rfqcreatedateFilter = {
  field: 'rfqcreatedate',
  headerName: 'Date',
  dateFrom: '06/02/2020',
  dateTo: '06/02/2020',
  filterType: 'date',
  type: '',
  customRange: 'Today'
};
const clientnameFilter = {
  field: 'clientname',
  headerName: 'Client Name',
  filter: 'blackrock',
  filterType: 'text',
  type: '='
};

describe('filters', () => {
  test('user get new text filter object', () => {
    const result = newTextFilter('clientname', 'Client Name', 'blackrock');
    expect(result).toEqual(clientnameFilter);
  });

  test('user add new text filter object', () => {
    const filters = {
      code: codeFilter,
      currencystr: currencystrFilter,
      rfqcreatedate: rfqcreatedateFilter
    };
    const newFilter = clientnameFilter;
    const result = addFilter(newFilter, filters);
    expect(result).toEqual({
      code: codeFilter,
      currencystr: currencystrFilter,
      rfqcreatedate: rfqcreatedateFilter,
      clientname: clientnameFilter
    });
  });

  test('user get the existing filter value', () => {
    const column = { colId: 'clientname' };
    const filters = {
      code: codeFilter,
      currencystr: currencystrFilter,
      rfqcreatedate: rfqcreatedateFilter,
      clientname: clientnameFilter
    };

    const result = getColumnFilterValue(column, filters);
    expect(result).toEqual(clientnameFilter.filter);
  });

  test("user get empty string if filter doesnt's exists", () => {
    const column = { colId: 'clientname' };
    const filters = {
      code: codeFilter,
      currencystr: currencystrFilter,
      rfqcreatedate: rfqcreatedateFilter
    };

    const result = getColumnFilterValue(column, filters);
    expect(result).toEqual('');
  });

  test('filter has a valid value', () => {
    const filterObj = {
      field: 'clientname',
      headerName: 'Client Name',
      filter: ['blackrock inc', ''],
      filterType: 'text',
      type: ''
    };
    const result = hasFilter(filterObj);
    expect(result).toBeTruthy();
  });

  test("filter doesn't have a valid value", () => {
    const filterObj = {
      field: 'clientname',
      headerName: 'Client Name',
      filter: ['', ''],
      filterType: 'text',
      type: ''
    };
    const result = hasFilter(filterObj);
    expect(result).toBeFalsy();
  });
});
