import { getSort, SORT_ASC, SORT_DESC, SORT_NONE } from '~helpers/sort';

const column = {
  isSortAscending: () => {},
  isSortDescending: () => {}
};

describe('sort', () => {
  test('get sort should return ascending order', () => {
    const isSortAscending = jest.spyOn(column, 'isSortAscending');
    const isSortDescending = jest.spyOn(column, 'isSortDescending');
    isSortAscending.mockImplementation(() => true);
    isSortDescending.mockImplementation(() => false);

    const result = getSort(column);

    expect(isSortAscending).toHaveBeenCalledTimes(1);
    expect(isSortDescending).toHaveBeenCalledTimes(0);
    expect(result).toBe(SORT_ASC);

    isSortAscending.mockRestore();
    isSortDescending.mockRestore();
  });

  test('get sort should return descending order', () => {
    const isSortAscending = jest.spyOn(column, 'isSortAscending');
    const isSortDescending = jest.spyOn(column, 'isSortDescending');
    isSortAscending.mockImplementation(() => false);
    isSortDescending.mockImplementation(() => true);

    const result = getSort(column);

    expect(isSortAscending).toHaveBeenCalledTimes(1);
    expect(isSortDescending).toHaveBeenCalledTimes(1);
    expect(result).toBe(SORT_DESC);

    isSortAscending.mockRestore();
    isSortDescending.mockRestore();
  });

  test('get sort should return empty order', () => {
    const isSortAscending = jest.spyOn(column, 'isSortAscending');
    const isSortDescending = jest.spyOn(column, 'isSortDescending');
    isSortAscending.mockImplementation(() => false);
    isSortDescending.mockImplementation(() => false);

    const result = getSort(column);

    expect(isSortAscending).toHaveBeenCalledTimes(1);
    expect(isSortDescending).toHaveBeenCalledTimes(1);
    expect(result).toBe(SORT_NONE);
    isSortAscending.mockRestore();
    isSortDescending.mockRestore();
  });
});
