import { getFlowAppFromSettings, skipFlowAppFromSettings, setTradingDeskCoverageChoicesInUserSettings } from '../userSettings';

const userSetttings = {
  User: '',
  Applications: [{ AppName: 'Flow', Settings: {} }],
  AlertSettings: {}
};

const userEntitlement = {
  entitlementExtensionRules: [
    {
      appTopic: 'TradingDeskCoverageChoices',
      uiInstruction: { Visible: '1' },
      backendInstruction: { MyDesk: 'US High Yield' }
    }
  ]
};
describe('userSetttings', () => {
  test('get flow app from settings', () => {
    const result = getFlowAppFromSettings(userSetttings);
    expect(result).toEqual(userSetttings.Applications[0]);
  });

  test('get other apps from settings', () => {
    const result = skipFlowAppFromSettings(userSetttings);
    expect(result.length).toEqual(0);
  });

  test('set entilement in settings', () => {
    const result = setTradingDeskCoverageChoicesInUserSettings(true, true, userSetttings, userEntitlement);
    expect(result.Applications[0].Settings.TradingDeskCoverageChoices.coverage).toEqual(true);
    expect(result.Applications[0].Settings.TradingDeskCoverageChoices.mydesk).toEqual('US High Yield');
  });
});
