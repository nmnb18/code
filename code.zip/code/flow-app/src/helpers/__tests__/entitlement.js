import {
  isTechnologyUser,
  isTechOrAdminUser,
  isUserEntitledForTradingDeskCoverage,
  getMyDeskFromEntitlement
} from '~helpers/entitlement';

const userEntitlement = {
  entitlementExtensionRules: [
    {
      appTopic: 'TradingDeskCoverageChoices',
      uiInstruction: { Visible: '1' },
      backendInstruction: { MyDesk: 'US High Yield' }
    }
  ]
};
describe('entitlement', () => {
  test('user belongs to tech', () => {
    const result = isTechnologyUser('FI Technology');
    expect(result).toBe(true);
  });

  test('user does not belong to tech', () => {
    const result = isTechnologyUser('US Emerging Markets');
    expect(result).toBe(false);
  });

  test('user is tech or admin user', () => {
    const result = isTechOrAdminUser(false, 'FI Technology');
    expect(result).toBe(true);

    const result2 = isTechOrAdminUser(true, 'US Emerging Markets');
    expect(result2).toBe(true);

    const result3 = isTechOrAdminUser(true, 'FI Technology');
    expect(result3).toBe(true);
  });

  test('user is not tech or admin user', () => {
    const result = isTechOrAdminUser(false, 'US Emerging Markets');
    expect(result).toBe(false);
  });

  test('user is entitled to see coverage and mydesk option', () => {
    const result = isUserEntitledForTradingDeskCoverage(userEntitlement);
    expect(result).toBe(true);
  });

  test('user is not entitled to see coverage and mydesk option', () => {
    const result = isUserEntitledForTradingDeskCoverage({});
    expect(result).toBe(false);
  });

  test('user is not entitled to see coverage and mydesk option', () => {
    const entitlement = {
      ...userEntitlement,
      entitlementExtensionRules: [
        {
          appTopic: 'TradingDeskCoverageChoices',
          uiInstruction: { Visible: '0' },
          backendInstruction: { MyDesk: 'US High Yield' }
        }
      ]
    };
    const result = isUserEntitledForTradingDeskCoverage(entitlement);
    expect(result).toBe(false);
  });

  test('user is not entitled to see coverage and mydesk option', () => {
    const entitlement = { ...userEntitlement, entitlementExtensionRules: [{ appTopic: 'Test' }] };
    const result = isUserEntitledForTradingDeskCoverage(entitlement);
    expect(result).toBe(false);
  });

  test('get mydesk from entitlement', () => {
    const result = getMyDeskFromEntitlement(userEntitlement);
    expect(result).toBe('US High Yield');
  });

  describe('get empty my desk value', () => {
    test('due to invalid entitlementExtensionRules configuration in user entitlement', () => {
      const userEntitlementCopy = { ...userEntitlement };
      userEntitlementCopy.entitlementExtensionRules = undefined;
      const result = getMyDeskFromEntitlement(userEntitlementCopy);
      expect(result).toBe('');
    });

    test('due to invalid appTopic value in user entitlement', () => {
      const userEntitlementCopy = { ...userEntitlement };
      userEntitlementCopy.entitlementExtensionRules[0].appTopic = 'Random topic';
      const result = getMyDeskFromEntitlement(userEntitlementCopy);
      expect(result).toBe('');
    });

    test('due to invalid backendInstruction configuration in user entitlement', () => {
      const userEntitlementCopy = { ...userEntitlement };
      userEntitlementCopy.entitlementExtensionRules[0].backendInstruction = {};
      const result = getMyDeskFromEntitlement(userEntitlementCopy);
      expect(result).toBe('');
    });

    test('due to invalid MyDesk value in user entitlement', () => {
      const userEntitlementCopy = { ...userEntitlement };
      userEntitlementCopy.entitlementExtensionRules[0].backendInstruction.MyDesk = '';
      const result = getMyDeskFromEntitlement(userEntitlementCopy);
      expect(result).toBe('');
    });
  });
});
