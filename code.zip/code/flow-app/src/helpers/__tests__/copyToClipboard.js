import { createHtmlTable } from '../copyToClipboard';

describe('copyToClipboard', () => {
  describe('create html table', () => {
    test('create html with header and data', () => {
      const headers = ['Client Name', 'Axe'];
      const data = [['Test Client Name-1', 'Axe-1'], ['Test-Client-Name-2', 'Axe-2']];
      const result = createHtmlTable(headers, data);
      expect(result).toBe(
        '<table><tr><th>Client Name</th><th>Axe</th></tr><tbody><tr><td>Test Client Name-1</td><td>Axe-1</td></tr><tr><td>Test-Client-Name-2</td><td>Axe-2</td></tr></tbody></table>'
      );
    });

    test('check if no header is passed', () => {
      const headers = [];
      const data = [['Test Client Name-1', 'Axe-1'], ['Test-Client-Name-2', 'Axe-2']];
      const result = createHtmlTable(headers, data);
      expect(result).toBe('');
    });

    test('check if no data is passed', () => {
      const headers = ['Client Name', 'Axe'];
      const data = [];
      const result = createHtmlTable(headers, data);
      expect(result).toBe('');
    });
  });
});
