import { getLiveAxeContent, getHistAxeContent, getPriorityAxeContent } from '~helpers/columnRenderer';

describe('columnRenderer', () => {
  describe('Live axe content', () => {
    test('Live axe has an invalid value', () => {
      const result = getLiveAxeContent();
      expect(result).toBe('');
    });

    test('Live axe has NONE value', () => {
      const result = getLiveAxeContent('NONE');
      expect(result).toBe('');
    });

    test('Live axe has BUY value', () => {
      const result = getLiveAxeContent('BUY');
      expect(result).toBe('<span class="rfq-axed-content rfq-axed-content-buy">AXE</span>');
    });

    test('Live axe has SELL value', () => {
      const result = getLiveAxeContent('SELL');
      expect(result).toBe('<span class="rfq-axed-content rfq-axed-content-sell">AXE</span>');
    });

    test('Live axe has DOUBLE SIDED value', () => {
      const result = getLiveAxeContent('DOUBLE SIDED');
      expect(result).toBe('<span class="rfq-axed-content rfq-axed-content-doublesided">AXE</span>');
    });
  });

  describe('Historical axe content', () => {
    test('Historical axe has an invalid value', () => {
      const result = getHistAxeContent();
      expect(result).toBe('');
    });

    test('Historical axe has NONE value', () => {
      const result = getHistAxeContent('NONE');
      expect(result).toBe('');
    });

    test('Historical axe has BUY value', () => {
      const result = getHistAxeContent('BUY');
      expect(result).toBe('<span class="rfq-axed-content rfq-axed-content-buy">AXE</span>');
    });

    test('Historical axe has SELL value', () => {
      const result = getHistAxeContent('SELL');
      expect(result).toBe('<span class="rfq-axed-content rfq-axed-content-sell">AXE</span>');
    });

    test('Historical axe has DOUBLE SIDED value', () => {
      const result = getHistAxeContent('DOUBLE SIDED');
      expect(result).toBe('<span class="rfq-axed-content rfq-axed-content-doublesided">AXE</span>');
    });
  });

  describe('Priority axe content', () => {
    test('Priority axe has an invalid value', () => {
      const result = getPriorityAxeContent();
      expect(result).toBe('');
    });

    test('Priority axe has NO as value', () => {
      const result = getPriorityAxeContent('NO');
      expect(result).toBe('');
    });

    test('Priority axe has an invalid value', () => {
      const result = getPriorityAxeContent('NA');
      expect(result).toBe('');
    });

    test('Priority axe has NO_AXE value', () => {
      const result = getPriorityAxeContent('NO_AXE');
      expect(result).toBe('<span class="rfq-priority-axe-content-noaxed">!</span>');
    });

    test('Priority axe has YES value', () => {
      const result = getPriorityAxeContent('YES');
      expect(result).toBe('<span class="rfq-priority-axe-content">!</span>');
    });
  });
});
