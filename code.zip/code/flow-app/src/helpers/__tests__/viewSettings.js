import {
  shouldLoadRatings,
  getSortPriority,
  getColumnState,
  getColumnFilters,
  getEnhancedColumnDefs
} from '~helpers/viewSettings';
import * as columnDictionaryService from '~services/columnDictionaryService';
import * as columnDefinition from '~helpers/columnDefinition';

const columnsDictionary = {
  sourceColumnNames: [
    {
      sourcecolumnname: 'key_id',
      displayname: 'Key Id',
      required: false,
      sortable: true,
      filterable: true,
      columntype: 'STRING',
      formatinstruction: null,
      displaywidth: 100,
      businessunitrestriction: null,
      filteroptions: null,
      columndescription: 'Key Id Column',
      codeinstruction: {
        alwaysRequest: 'true',
        styleName: 'col-classic'
      },
      available: false
    },
    {
      sourcecolumnname: 'rfqaxed',
      displayname: 'Axe',
      required: true,
      sortable: true,
      filterable: true,
      columntype: 'INTEGER',
      formatinstruction: null,
      displaywidth: 100,
      businessunitrestriction: null,
      filteroptions: ['Axe'],
      columndescription: 'Indicates if the bond is axed',
      codeinstruction: {
        legEnabled: 'true',
        styleName: 'col-tag-axe',
        alwaysRequest: 'true',
        pinInstruction: 'left'
      },
      available: true
    },
    {
      sourcecolumnname: 'l1_rfqaxed',
      displayname: 'Axe',
      required: true,
      sortable: true,
      filterable: true,
      columntype: 'INTEGER',
      formatinstruction: null,
      displaywidth: 100,
      businessunitrestriction: null,
      filteroptions: ['Axe'],
      columndescription: 'Indicates if the bond is axed',
      codeinstruction: {
        styleName: 'col-tag-axe',
        alwaysRequest: 'true',
        pinInstruction: 'left'
      },
      available: false
    },
    {
      sourcecolumnname: 'l2_rfqaxed',
      displayname: 'Axe',
      required: true,
      sortable: true,
      filterable: true,
      columntype: 'INTEGER',
      formatinstruction: null,
      displaywidth: 100,
      businessunitrestriction: null,
      filteroptions: ['Axe'],
      columndescription: 'Indicates if the bond is axed',
      codeinstruction: {
        styleName: 'col-tag-axe',
        alwaysRequest: 'true',
        pinInstruction: 'left'
      },
      available: false
    },
    {
      sourcecolumnname: 'coupon',
      displayname: 'Coupon',
      required: false,
      sortable: true,
      filterable: true,
      columntype: 'FLOAT',
      formatinstruction: {
        decFormat: 3,
        numComma: 'True'
      },
      displaywidth: 100,
      businessunitrestriction: null,
      filteroptions: null,
      columndescription: 'Bond descriptor',
      codeinstruction: {
        styleName: 'col-classic',
        alignment: 'col-align-right',
        alwaysRequest: 'true',
        copyTemplateFormat: {
          padRight: 3,
          decFormat: 3,
          showHeader: 'True'
        }
      },
      available: true
    }
  ]
};

const columnDefs = [
  { colId: 'key_id', field: 'key_id', headerName: 'Key Id', available: true, width: 50 },
  { colId: 'rfqaxed', field: 'rfqaxed', headerName: 'Axe', available: true, width: 50 }
];

const moodyColumnDef = { field: 'ratingmoody', headerName: 'Moody', available: true, width: 50 };
const spColumnDef = { field: 'rating_s_and_p', headerName: 'S&P', available: true, width: 50 };

const sortPriority = [
  {
    colId: 'rfqnlegs',
    sort: 'desc'
  }
];

const columnState = [
  {
    colId: 'coupon',
    hide: true,
    aggFunc: null,
    width: 75,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  }
];

const columnFilters = [
  {
    field: 'clientname',
    headerName: 'Client Name',
    filter: ['market', ''],
    filterType: 'text',
    type: ''
  }
];

beforeEach(() => {
  jest.resetAllMocks();
});

describe('viewSettings', () => {
  describe('should load ratings', () => {
    test('if source columns includes Moody column', () => {
      const result = shouldLoadRatings([...columnDefs, moodyColumnDef]);
      expect(result).toBe(true);
    });

    test('if source columns includes S&P column', () => {
      const result = shouldLoadRatings([...columnDefs, spColumnDef]);
      expect(result).toBe(true);
    });

    test('if source columns includes Moody and S&P columns', () => {
      const result = shouldLoadRatings([moodyColumnDef, ...columnDefs, spColumnDef]);
      expect(result).toBe(true);
    });
  });

  describe('should not load ratings', () => {
    test('if source columns is null', () => {
      const result = shouldLoadRatings(null);
      expect(result).toBe(false);
    });

    test('if source columns does not include Moody or S&P columns', () => {
      const result = shouldLoadRatings(columnDefs);
      expect(result).toBe(false);
    });
  });

  describe('get sort priorities', () => {
    test("should return viewSettings's SortPriority property", () => {
      const result = getSortPriority({ SortPriority: sortPriority });
      expect(result).toEqual(sortPriority);
    });

    test('should return empty array if sort priority property is missing', () => {
      const result = getSortPriority({});
      expect(result).toEqual([]);
    });

    test('should return empty array if sort priority is empty', () => {
      const result = getSortPriority({ SortPriority: [] });
      expect(result).toEqual([]);
    });
  });

  describe('get column state', () => {
    test("should return viewSettings's ColumnState property", () => {
      const result = getColumnState({ ColumnState: columnState }, null, false);
      expect(result).toEqual(columnState);
    });

    test('should return default ColumnState using columnDefs', () => {
      const result = getColumnState({ ColumnState: [] }, columnDefs, false);
      const defaultColumnState = columnDictionaryService.getDefaultColumnState(columnDefs);
      expect(result).toEqual(defaultColumnState);
    });

    test("should return viewSettings's ColumnState property having checkboxColumnState configuration as first column", () => {
      const result = getColumnState({ ColumnState: columnState }, null, true);
      expect(result[0]).toEqual({
        aggFunc: null,
        available: true,
        colId: 'key_id',
        displayname: ' ',
        hide: false,
        lockPinned: true,
        lockPosition: true,
        pinned: 'left',
        pivotIndex: 0,
        required: true,
        rowGroupIndex: null,
        width: 40
      });
    });
  });

  describe('get column filters', () => {
    test("should return viewSettings's ColumnFilters property", () => {
      const result = getColumnFilters({ ColumnFilters: columnFilters });
      expect(result).toEqual([
        {
          field: 'clientname',
          headerName: 'Client Name',
          filter: ['market', ''],
          filterType: 'text',
          type: ''
        }
      ]);
    });

    test('should return empty array if column filters property is missing', () => {
      const result = getColumnFilters({});
      expect(result).toEqual([]);
    });

    test('should return empty array if column filters  is empty', () => {
      const result = getColumnFilters({ ColumnFilters: [] });
      expect(result).toEqual([]);
    });
  });

  describe('get enhanced column definitions', () => {
    test('should return column definitions with LEG and always request fields', () => {
      const getLegColumnDefinitions = jest.spyOn(columnDictionaryService, 'getLegColumnDefinitions');
      const getAlwaysRequestColumnDefinitions = jest.spyOn(
        columnDictionaryService,
        'getAlwaysRequestColumnDefinitions'
      );
      const removeRepeatedColumn = jest.spyOn(columnDefinition, 'removeRepeatedColumn');
      const removeColumn = jest.spyOn(columnDefinition, 'removeColumn');

      const result = getEnhancedColumnDefs(columnDefs, columnsDictionary, false);

      const l1_rfqaxed = result.find(columnDef => columnDef.field === 'l1_rfqaxed');
      const l2_rfqaxed = result.find(columnDef => columnDef.field === 'l2_rfqaxed');
      const coupon = result.find(columnDef => columnDef.field === 'coupon');

      expect(l1_rfqaxed).toBeDefined();
      expect(l2_rfqaxed).toBeDefined();
      expect(coupon).toBeDefined();

      expect(getLegColumnDefinitions).toHaveBeenCalledTimes(1);
      expect(getLegColumnDefinitions).toHaveBeenCalledWith(columnDefs, columnsDictionary);

      expect(getAlwaysRequestColumnDefinitions).toHaveBeenCalledTimes(1);
      expect(getAlwaysRequestColumnDefinitions).toHaveBeenCalledWith(columnsDictionary);

      expect(removeRepeatedColumn).toHaveBeenCalledTimes(1);
      expect(removeColumn).toHaveBeenCalledTimes(0);

      getLegColumnDefinitions.mockRestore();
      getAlwaysRequestColumnDefinitions.mockRestore();
      removeRepeatedColumn.mockRestore();
      removeColumn.mockRestore();
    });

    test('should return column definitions with LEG and always request fields having checkboxColumnDefinition configuration as first column', () => {
      const getLegColumnDefinitions = jest.spyOn(columnDictionaryService, 'getLegColumnDefinitions');
      const getAlwaysRequestColumnDefinitions = jest.spyOn(
        columnDictionaryService,
        'getAlwaysRequestColumnDefinitions'
      );
      const removeRepeatedColumn = jest.spyOn(columnDefinition, 'removeRepeatedColumn');
      const removeColumn = jest.spyOn(columnDefinition, 'removeColumn');

      const result = getEnhancedColumnDefs(columnDefs, columnsDictionary, true);

      const l1_rfqaxed = result.find(columnDef => columnDef.field === 'l1_rfqaxed');
      const l2_rfqaxed = result.find(columnDef => columnDef.field === 'l2_rfqaxed');
      const coupon = result.find(columnDef => columnDef.field === 'coupon');

      expect(l1_rfqaxed).toBeDefined();
      expect(l2_rfqaxed).toBeDefined();
      expect(coupon).toBeDefined();

      expect(getLegColumnDefinitions).toHaveBeenCalledTimes(1);
      expect(getLegColumnDefinitions).toHaveBeenCalledWith(columnDefs, columnsDictionary);

      expect(getAlwaysRequestColumnDefinitions).toHaveBeenCalledTimes(1);
      expect(getAlwaysRequestColumnDefinitions).toHaveBeenCalledWith(columnsDictionary);

      expect(removeRepeatedColumn).toHaveBeenCalledTimes(1);
      expect(removeColumn).toHaveBeenCalledTimes(1);

      getLegColumnDefinitions.mockRestore();
      getAlwaysRequestColumnDefinitions.mockRestore();
      removeRepeatedColumn.mockRestore();
      removeColumn.mockRestore();
    });
  });
});
