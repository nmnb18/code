import { isAxeMatch } from './columnRenderer';

const agGridValueFormatterMaster = (field, params) => {
  switch (field) {
    case 'AXE':
      return agGridVFReturnString(params, 'AXE');
    case 'Status':
      return agGridVFReturnTagString(params);
    case 'Priority':
      return agGridVFReturnEmptyString();
    case 'Verb':
      return agGridVFReturnVerbString(params);
    case 'Description':
      return agGridVFReturnDescription(params);
    default:
      return agGridVFReturnSelfString(params);
  }
};

const agGridCellClassMaster = (field, params) => {
  switch (field) {
    case 'AXE':
      return agGridCCReturnAxeTag(params);
    case 'Status':
      return agGridCCReturnTagClass(params);
    case 'Time':
      return agGridCCReturnTimeTag();
    case 'Date':
      return agGridCCReturnDateTag();
    case 'Priority':
      return agGridCCReturnPriority(params);
    case 'Client':
      return agGridCCReturnRowLink();
    case 'Level':
      return agGridCCReturnMultiLeg(params);
    case 'Verb':
      return agGridCCReturnVerbClass(params);
    case 'Description':
      return agGridCCReturnRowLink();
    case 'Price':
      return agGridCCReturnVerbBasedOnRow(params);
    default:
      return agGridCCReturnDefaultTag();
  }
};

/*------------------------
*   VALUE FORMATTER 
-------------------------*/

const agGridVFReturnEmptyString = () => {
  return '';
};

const agGridVFReturnSelfString = params => {
  return params.value || '-';
};

const agGridVFReturnString = (params, valueString) => {
  return params.value === true ? valueString : '';
};

const agGridVFReturnTagString = params => {
  switch (params.value) {
    case 1:
      return 'Unvalidated';
    case 2:
      return 'Traded Away';
    case 3:
      return 'Quote Requested';
    case 4:
      return 'Done';
    case 5:
      return 'Dealer Timeout';
    case 6:
      return 'Dealer Rejected';
    case 7:
      return 'Cust Timeout';
    default:
      return 'Unvalidated';
  }
};

const agGridVFReturnVerbString = params => {
  return params.value === 1 ? 'BUY' : 'SELL';
};

const randomNumber = Math.floor(Math.random() * Math.floor(10)).toFixed(2);

const agGridVFReturnDescription = params => {
  return params.value + ' ' + randomNumber + '12/10/2018';
};

/*------------------------
*   CELL CLASS
-------------------------*/

const agGridCCReturnVerbBasedOnRow = params => {
  // Here we are checking the data from another Column in the same Row
  return params.data.Verb === 1 ? 'verb-buy' : 'verb-sell';
};

const agGridCCReturnVerbClass = params => {
  return params.value === 1 ? 'verb-buy' : 'verb-sell';
};

const agGridCCReturnMultiLeg = params => (params.value ? 'jp-blotter-multileg' : '');

const agGridCCReturnRowLink = () => {
  return 'jp-blotter-row-link';
};

const agGridCCReturnTagClass = params => {
  switch (params.value) {
    case 1:
      return 'jp-status-tag-unvalidated';
    case 2:
      return 'jp-status-tag-ta';
    case 3:
      return 'jp-status-tag-qr';
    case 4:
      return 'jp-status-tag-done';
    case 5:
      return 'jp-status-tag-dt';
    case 6:
      return 'jp-status-tag-dr';
    case 7:
      return 'jp-status-tag-ct';
    default:
      return 'jp-status-tag-unvalidated';
  }
};

const agGridCCReturnPriority = params => {
  switch (params.value) {
    case 0:
      return 'jp-priority-0';
    case 1:
      return 'jp-priority-1';
    case 2:
      return 'jp-priority-2';
    case 3:
      return 'jp-priority-3';
    default:
      return 'jp-priority-0';
  }
};

const agGridCCReturnAxeTag = params => {
  return params.value === true ? 'jp-status-tag-axe' : 'jp-status-tag';
};

const agGridCCReturnTimeTag = () => {
  return 'jp-row-blotter-time';
};

const agGridCCReturnDateTag = () => {
  return 'jp-row-blotter-date';
};

const agGridCCReturnDefaultTag = () => {
  return 'jp-row-blotter-default';
};

const agGridCCReturnChatTag = () => {
  return 'jp-status-tag-chat';
};

const shouldCheckStatus = (params, status) => {
  const { statusstr, recordtype } = params?.data;
  return statusstr && statusstr.toLowerCase() === status && recordtype === 'RFQ';
};

export const ROW_CLASS_RULES = {
  'row-bg-done': params => {
    if (!params?.data) return false;
    return shouldCheckStatus(params, 'done');
  },
  'row-bg-dealerrejected': params => {
    if (!params?.data) return false;
    return shouldCheckStatus(params, 'dealerrejected');
  },
  'row-bg-dealertimeout': params => {
    if (!params?.data) return false;
    return shouldCheckStatus(params, 'dealertimeout');
  },
  'row-bg-customertimeout': params => {
    if (!params?.data) return false;
    return shouldCheckStatus(params, 'customertimeout');
  },
  'row-bg-custrejected': params => {
    if (!params?.data) return false;
    return shouldCheckStatus(params, 'custrejected');
  },
  'row-axematch': params => {
    if (!params?.data) return false;
    return isAxeMatch(params?.data?.axematch);
  }
};

export {
  agGridCellClassMaster,
  agGridValueFormatterMaster,
  agGridVFReturnEmptyString,
  agGridVFReturnString,
  agGridCCReturnAxeTag,
  agGridCCReturnTimeTag,
  agGridCCReturnDateTag,
  agGridVFReturnTagString,
  agGridCCReturnTagClass,
  agGridCCReturnPriority,
  agGridCCReturnMultiLeg,
  agGridCCReturnRowLink,
  agGridCCReturnChatTag,
  randomNumber,
  agGridVFReturnVerbString,
  agGridCCReturnVerbClass,
  agGridVFReturnDescription,
  agGridCCReturnVerbBasedOnRow
};
