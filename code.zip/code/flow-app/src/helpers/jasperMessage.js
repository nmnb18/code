import { strToNumber } from '~helpers/types';

export const WS_FIELDS = {
  SOWKEY: 'sowkey',
  COMMAND: 'command',
  ROWINDEX: 'rowIndex',
  SOURCE: 'source',
  LEGNO: 'legno',
  KEY_ID: 'key_id',
  KEY_ID_RFQ_GROUP: 'key_id_rfq_group',
  RECORD_TYPE: 'recordtype',
  MY_MARKET_ID_FORMATTED: 'mymarketidformatted'
};

export const WS_MESSAGE_TYPE = {
  RFQ_MESSAGE: 'RFQMessage',
  RFQ_TOTALS: 'RFQTotals'
};

export const WS_COMMANDS = {
  GROUP_BEGIN: 'GROUPBEGIN',
  NEW_MESSAGE_SOW: 'NEW_MESSAGE_SOW',
  GROUP_END: 'GROUPEND',
  NEW_MESSAGE: 'NEW_MESSAGE',
  UPDATE_MESSAGE: 'UPDATE_MESSAGE',
  DELETE_MESSAGE: 'DELETE_MESSAGE',
  ACK: 'ACK',
  SOW: 'SOW',
  CONNECT: 'CONNECT',
  DISCONNECT: 'DISCONNECT',
  CLEAR: 'CLEAR',
  ENTITLEMENT_ERROR: 'ENTITLEMENT_ERROR'
};

export const EXPORT_COMMANDS = {
  FETCH_DONE: 'FETCH_DONE'
};

export const FETCH_TRIGGERS = {
  EXPORT_TO_EXCEL_AS_DOWNLOAD: 'EXPORT_TO_EXCEL_AS_DOWNLOAD',
  EXPORT_TO_EXCEL_AND_OPEN: 'EXPORT_TO_EXCEL_AND_OPEN',
  COPY_TO_CLIPBOARD: 'COPY_TO_CLIPBOARD'
};

export const LEGNO = {
  MAIN: 0,
  L1: 1,
  L2: 2
};

export const RFQNLEGS = {
  MAIN: '1',
  L1: '2',
  L2: '3'
};

export const isMainRFQLeg = ({ legno }) => parseInt(legno) === LEGNO.MAIN;
export const isL1RFQLeg = ({ legno }) => parseInt(legno) === LEGNO.L1;
export const isL2RFQLeg = ({ legno }) => parseInt(legno) === LEGNO.L2;

export const LEG_FIELD_REGEX = /^(l1|l2)_/;

export const isLegIndicator = field => field === WS_FIELDS.LEGNO;

/**
 * @param {object} elements
 * @returns {boolean}
 */
export const isLegRow = elements => {
  if (!elements) return false;
  const { legno } = elements;
  const legnoValue = strToNumber(legno);
  return !!legnoValue;
};

export const hasLegs = elements => {
  if (!elements) return false;
  const { rfqnlegs } = elements;
  const numberOfLegs = strToNumber(rfqnlegs);
  return numberOfLegs > 1;
};

const getMainField = legField => {
  const legFieldRegex = new RegExp(LEG_FIELD_REGEX, 'i');
  return legField.replace(legFieldRegex, '');
};

export const isLegFieldValid = field => {
  const legFieldRegex = new RegExp(LEG_FIELD_REGEX, 'i');
  return legFieldRegex.test(field);
};

export const isLegFieldInValid = field => {
  const legFieldRegex = new RegExp(LEG_FIELD_REGEX, 'i');
  return !legFieldRegex.test(field);
};

const isLegFieldOrderValid = (legField, legOrder) => {
  const underscoreIndex = legField.indexOf('_');
  const legFieldOrder = legField.substr(underscoreIndex - 1, 1);

  const legFieldOrderValue = strToNumber(legFieldOrder);
  const legOrderValue = strToNumber(legOrder);

  return legFieldOrderValue === legOrderValue;
};

export const isLegField = (elements, field) => {
  const legFields = Object.keys(elements)
    .filter(isLegFieldValid)
    .map(getMainField)
    .reduce((acc, cur) => {
      if (!acc.find(key => key === cur)) {
        acc.push(cur);
      }
      return acc;
    }, []);

  return legFields.find(legField => legField === field);
};

export const getLegFields = elements =>
  Object.keys(elements)
    .filter(isLegFieldValid)
    .map(getMainField)
    .reduce((acc, cur) => {
      if (!acc.find(key => key === cur)) {
        acc.push(cur);
      }
      return acc;
    }, []);

export const isLegKey = (legFields, field) => {
  const legKey = legFields.find(legField => legField === field);
  return !!legKey;
};

const miscCommands = [WS_COMMANDS.DISCONNECT, WS_COMMANDS.CONNECT, WS_COMMANDS.CLEAR, WS_COMMANDS.ENTITLEMENT_ERROR];

const mapRFQRecord = ({
  source,
  clientSubscriptionId,
  sowkey,
  command,
  elements,
  rowIndex,
  vpFirstRow,
  vpLastRow,
  isResorting
}) => {
  const rowIndexValue = strToNumber(rowIndex);

  if (isLegRow(elements)) {
    // "legno" field is index base (0,1,2) and indicates that the rfq bond index (M, L1, L2)
    // "rfqnlengs" field indicates the number of rfq rows (length) for this rfq bond (1,2,3)
    const { legno } = elements;
    const elementsWithLegFields = { ...elements };

    const legFields = Object.keys(elements).filter(isLegFieldValid);

    // Copy LEG field (L1|L2) value on the MAIN field
    // example: copy value from l1_clientbuysell|l2_clientbuysell fields into the clientbuysell field
    legFields.forEach(legField => {
      if (isLegFieldOrderValid(legField, legno)) {
        const mainField = getMainField(legField);
        if (legField === 'l1_code' || legField === 'l2_code') {
          elementsWithLegFields['code_main_value'] = elementsWithLegFields['code'];
        }
        elementsWithLegFields[mainField] = elements[legField];
        // TODO: check if delete leg field is required
        // delete elementsWithLegFields[field];
      }
    });

    return {
      source,
      clientSubscriptionId,
      sowkey,
      command,
      rowIndex: rowIndexValue,
      vpFirstRow,
      vpLastRow,
      isResorting,
      ...elementsWithLegFields
    };
  }

  return {
    source,
    clientSubscriptionId,
    sowkey,
    command,
    vpFirstRow,
    vpLastRow,
    isResorting,
    rowIndex: rowIndexValue,
    ...elements
  };
};

const mapRFQCommand = ({ source, clientSubscriptionId, command, vpFirstRow, vpLastRow }) => ({
  source,
  clientSubscriptionId,
  command,
  vpFirstRow,
  vpLastRow
});

const mapRFQMessage = ({
  source,
  clientSubscriptionId,
  command,
  elements,
  rowIndex,
  sowkey,
  type,
  vpFirstRow,
  vpLastRow,
  isResorting
}) => {
  if (!elements && !miscCommands.includes(command)) return null;

  switch (command) {
    case WS_COMMANDS.GROUP_BEGIN:
    case WS_COMMANDS.GROUP_END:
    case WS_COMMANDS.ENTITLEMENT_ERROR:
      return mapRFQCommand({ source, clientSubscriptionId, command, type, vpFirstRow, vpLastRow });
    case WS_COMMANDS.NEW_MESSAGE_SOW:
    case WS_COMMANDS.NEW_MESSAGE:
    case WS_COMMANDS.UPDATE_MESSAGE:
    case WS_COMMANDS.DELETE_MESSAGE:
    case WS_COMMANDS.DISCONNECT:
    case WS_COMMANDS.CONNECT:
    case WS_COMMANDS.CLEAR:
    case WS_COMMANDS.SOW:
      return mapRFQRecord({
        source,
        clientSubscriptionId,
        command,
        elements,
        rowIndex,
        sowkey,
        type,
        vpFirstRow,
        vpLastRow,
        isResorting
      });

    default:
      return {};
  }
};

const mapRFQTotals = ({ source, clientSubscriptionId, command, elements, type, vpFirstRow, vpLastRow }) => {
  const { RFQTotal } = elements;
  return {
    source,
    clientSubscriptionId,
    command,
    rfqTotal: RFQTotal,
    type,
    vpFirstRow,
    vpLastRow
  };
};

export const mapMessage = message => {
  const {
    source,
    data: { clientSubscriptionId, command, elements, rowIndex, sowkey, type, vpFirstRow, vpLastRow, isResorting }
  } = message;
  let response;

  if (type === WS_MESSAGE_TYPE.RFQ_MESSAGE) {
    response = mapRFQMessage({
      source,
      clientSubscriptionId,
      command,
      elements,
      rowIndex,
      sowkey,
      type,
      vpFirstRow,
      vpLastRow,
      isResorting
    });
  } else if (type === WS_MESSAGE_TYPE.RFQ_TOTALS) {
    response = mapRFQTotals({ source, clientSubscriptionId, command, elements, type, vpFirstRow, vpLastRow });
  }

  return response;
};

export function getType(message) {
  const { data } = message;
  if (!data) return '';
  const { type } = data;
  return type;
}
