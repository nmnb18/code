import { recordTypes } from '~helpers/globals';

const AXESIDE_NONE = 'NONE';
const RFQ_AXE_MATCH = '1';
const HIST_AXESIDE_NONE = 'NONE';
const PRIORITY_AXE = {
  YES: '<span class="rfq-priority-axe-content">!</span>',
  NO_AXE: '<span class="rfq-priority-axe-content-noaxed">!</span>'
};

const MARKET_ID_PIL = 'PIL';
const MARKET_ID_VOICE = 'Voice';

export const isRFQRecord = recordtype => recordtype === recordTypes.RFQ;

export const isInquiryRecord = recordtype => recordtype === recordTypes.INQUIRY;

export const isMarketIdVoice = mymarketidformatted => mymarketidformatted === MARKET_ID_VOICE;

export const isMarketIdPIL = mymarketidformatted => mymarketidformatted === MARKET_ID_PIL;

export const showEditInquiry = data => {
  const { id, recordtype, mymarketidformatted } = data;
  return isInquiryRecord(recordtype) && isMarketIdVoice(mymarketidformatted) && id !== null;
};

export const showMiniTicket = data => {
  const { recordtype } = data;
  return isRFQRecord(recordtype) || isPILRecord(data);
};

export const isPILRecord = ({ recordtype, mymarketidformatted }) =>
  isInquiryRecord(recordtype) && isMarketIdPIL(mymarketidformatted);

export const isAxeMatch = axematch => axematch === RFQ_AXE_MATCH;

export const showLiveAxeFlag = axeside => axeside && axeside !== AXESIDE_NONE;

export const showHistAxeFlag = histaxeside => histaxeside && histaxeside !== HIST_AXESIDE_NONE;

export const getAxeClass = (axeside, axematch) => {
  if (!axeside) return '';

  const axeType = axeside.toLowerCase().replace(/\s/g, '');
  return `rfq-axed-content-${axeType} ${isAxeMatch(axematch) ? 'rfq-axed-content-axematched' : ''}`;
};

export const getLiveAxeContent = (axeside, axematch) => {
  if (!showLiveAxeFlag(axeside)) return '';

  const axeClass = getAxeClass(axeside, axematch);
  return getAxeContent(axeClass);
};

export const isPriorityAxeInvalid = priorityaxe =>
  !priorityaxe || priorityaxe === 'NO' || priorityaxe === 'NA' || priorityaxe === '';

export const getPriorityAxeContent = priorityaxe => {
  if (isPriorityAxeInvalid(priorityaxe)) {
    return '';
  }
  return PRIORITY_AXE[priorityaxe];
};

export const getHistAxeContent = (axeside, axematch) => {
  if (!showHistAxeFlag(axeside)) return '';

  const axeClass = getAxeClass(axeside, axematch);
  return getAxeContent(axeClass);
};

export const getAxeContent = axeClass => `<span class="rfq-axed-content ${axeClass}">AXE</span>`;
