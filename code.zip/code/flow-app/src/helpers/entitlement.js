const FI_TECHNOLOGY = 'FI Technology';
const TRADING_CHOICES = 'TradingDeskCoverageChoices';
const ROLE_TRADER = 'Trader';

export const uiEntitlementOptions = {
  VISIBLE: 'Visible',
  ME_ONLY_VISIBLE: 'MeOnlyVisible',
  RFQ_POPUP_VISIBLE: 'RFQPopUpVisible',
  INQUIRY_VISIBLE: 'InquiryVisible',
  PORTFOLIO_VISIBLE: 'PortfolioVisible',
  SEARCH_BAR_VISIBLE: 'SearchBarVisible',
  XIOS_POPUP_VISIBLE: 'XiosPopUpVisible'
};

export const isTechnologyUser = level3 => FI_TECHNOLOGY === level3;

export const isTechOrAdminUser = (isAdmin, level3) => isAdmin || isTechnologyUser(level3);

const invalidEntitlementExtensionRules = userEntitlement =>
  !userEntitlement ||
  !userEntitlement.entitlementExtensionRules ||
  userEntitlement.entitlementExtensionRules.length === 0;

const getTradingDeskCoverageFromEntitlement = userEntitlement => {
  return userEntitlement.entitlementExtensionRules.find(entitlement => entitlement.appTopic === TRADING_CHOICES);
};

const isTradingDeskCoverageVisible = tradingDeskCoverage => !!tradingDeskCoverage?.uiInstruction?.Visible;

const getMyDesk = tradingDeskCoverage =>
  (tradingDeskCoverage.backendInstruction && tradingDeskCoverage.backendInstruction.MyDesk) || '';

export const isUserEntitledForTradingDeskCoverage = userEntitlement => {
  if (invalidEntitlementExtensionRules(userEntitlement)) return false;

  const tradingDeskCoverage = getTradingDeskCoverageFromEntitlement(userEntitlement);
  if (!tradingDeskCoverage) return false;

  return isTradingDeskCoverageVisible(tradingDeskCoverage);
};

export const getMyDeskFromEntitlement = userEntitlement => {
  if (invalidEntitlementExtensionRules(userEntitlement)) return '';

  const tradingDeskCoverage = getTradingDeskCoverageFromEntitlement(userEntitlement);
  if (!tradingDeskCoverage) return '';

  return getMyDesk(tradingDeskCoverage);
};

const isMydeskAvailable = tradingDeskCoverage => tradingDeskCoverage?.backendInstruction?.MyDesk;

const checkUserEntitlement = userEntitlement =>
  !userEntitlement ||
  !userEntitlement.entitlementExtensionRules ||
  userEntitlement.entitlementExtensionRules.length === 0;

export const showEntitlementOption = (entitlement, property) => {
  const userEntitledOptions = getUserEntitledTradingOptions(entitlement);
  return userEntitledOptions ? userEntitledOptions[property] : true;
};

export const getUserEntitledTradingOptions = userEntitlement => {
  if (checkUserEntitlement(userEntitlement)) return null;

  const tradingDeskCoverage = getTradingDeskCoverageFromEntitlement(userEntitlement);
  if (!tradingDeskCoverage) return null;

  return { ...tradingDeskCoverage.uiInstruction, isMydeskOptionAvailable: isMydeskAvailable(tradingDeskCoverage) };
};

export const userIsTrader = userEntitlement => {
  if (!userEntitlement) return false;
  return userEntitlement.primaryRole === ROLE_TRADER;
};
