import {
  dateTimezoneToLocalTimezone,
  dateTimezoneToUTC,
  dateTimezoneToAnotherTimezone,
  DATE_FORMAT
} from '~helpers/dateTimeUtil';

describe('DATE-FNS TIMES', () => {
  const sourcedate = '2019-11-16 23:30';
  const sourcetimezone = 'Asia/Kolkata';
  const destinationTimezones = [
    { tz: 'America/New_York', expectedTime: '13:00:00 EST' },
    { tz: 'America/Santiago', expectedTime: '15:00:00 GMT-3' },
    { tz: 'America/Argentina/Buenos_Aires', expectedTime: '15:00:00 GMT-3' },
    { tz: 'America/Mexico_City', expectedTime: '12:00:00 CST' },
    { tz: 'America/Bogota', expectedTime: '13:00:00 GMT-5' },
    { tz: 'America/Lima', expectedTime: '13:00:00 GMT-5' },
    { tz: 'America/Montevideo', expectedTime: '15:00:00 GMT-3' }
  ];

  test('Convert timezone to local timezone', () => {
    const expectedTime = dateTimezoneToLocalTimezone(sourcedate, sourcetimezone);
    expect(dateTimezoneToLocalTimezone(sourcedate, sourcetimezone)).toBe(expectedTime);
  });

  test('Convert timezone to UTC', () => {
    expect(dateTimezoneToUTC(sourcedate, sourcetimezone)).toBe('18:00:00 UTC');
  });

  test.each(destinationTimezones)('Convert timezone to %p timezone', ({ tz, expectedTime }) => {
    expect(dateTimezoneToAnotherTimezone(sourcedate, sourcetimezone, tz)).toBe(expectedTime);
  });
});

describe('DATE-FNS DATES', () => {
  const sourcedate = '2019-11-19 08:30';
  const sourcetimezone = 'Asia/Kolkata';
  const destinationTimezones = [
    { tz: 'America/New_York', expectedDate: 'NOV-18-2019' },
    { tz: 'America/Santiago', expectedDate: 'NOV-19-2019' },
    { tz: 'America/Argentina/Buenos_Aires', expectedDate: 'NOV-19-2019' },
    { tz: 'America/Mexico_City', expectedDate: 'NOV-18-2019' },
    { tz: 'America/Bogota', expectedDate: 'NOV-18-2019' },
    { tz: 'America/Lima', expectedDate: 'NOV-18-2019' },
    { tz: 'America/Montevideo', expectedDate: 'NOV-19-2019' }
  ];

  test('Convert date to local timezone', () => {
    const expectedDate = dateTimezoneToLocalTimezone(sourcedate, sourcetimezone);
    expect(dateTimezoneToLocalTimezone(sourcedate, sourcetimezone)).toBe(expectedDate);
  });

  test('Convert date to UTC', () => {
    expect(dateTimezoneToUTC(sourcedate, sourcetimezone, DATE_FORMAT)).toBe('NOV-19-2019');
  });

  test.each(destinationTimezones)('Convert date to %p timezone', ({ tz, expectedDate }) => {
    expect(dateTimezoneToAnotherTimezone(sourcedate, sourcetimezone, tz, DATE_FORMAT)).toBe(expectedDate);
  });
});
