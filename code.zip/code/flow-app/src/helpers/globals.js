export const FLOW_APP_NAME = 'Flow';
export const RFQ_APP_NAME = 'FlowRFQNotification';

export const postMessageActions = {
  closingBlotterApp: 'closingBlotterApp',
  switchingBlotterApp: 'SWITCHING_BLOTTER_APP',
  changesFound: 'CHANGES_FOUND',
  addInquiry: 'CONTAINER_ADD_INQUIRY',
  manageInquiry: 'CONTAINER_MANAGE_INQUIRY',
  addPortfolio: 'CONTAINER_ADD_PORTFOLIO',
  managePortfolio: 'CONTAINER_MANAGE_PORTFOLIO',
  assignUser: 'ASSIGN_USER',
  assignEntitlement: 'ASSIGN_ENTITLEMENT',
  assignUserSettings: 'ASSIGN_USERSETTINGS',
  assignImpersonated: 'ASSIGN_IMPERSONATED',
  assignRFQNotificationPopupState: 'ASSIGN_RFQ_NOTIFICATION_POPUP_STATE',
  childContentReady: 'CHILD_CONTENT_READY',
  rfqPopupReady: 'RFQ_POPUP_READY',
  rfqPopupInitialMessages: 'RFQ_POPUP_INITIAL_MESSAGES',
  rfqPopupSendMessage: 'RFQ_POPUP_SEND_MESSAGE',
  webSocketConnectionOff: 'WS_CONNECTION_OFF',
  webSocketConnectionOn: 'WS_CONNECTION_ON',
  wsConnectionChange: 'WS_CONNECTION_CHANGE',
  updatedUserSettings: 'UPDATED_USER_SETTINGS',
  currentUserSettings: 'CURRENT_USER_SETTINGS',
  requestForUserSettings: 'REQUEST_FOR_USER_SETTINGS',
  reload: 'RELOAD'
};
export const copyTemplateRedMessages = {
  ENTER_NEW_NAME: 'Please enter a name before saving a template.',
  NAME_EXISTS: 'Name already exists. Please enter a new name.',
  MINIMIUM_OF_ONE_COLUMN: 'Please add at least one column before saving a template',
  BLANK: ''
};
export const FLOW_BLOTTER_URL = process.env.REACT_APP_FLOW_BLOTTER_APP_URL;
export const CLOSING_BLOTTER_APP = 'closingBlotterApp';
export const CONTAINER_ADD_INQUIRY = 'CONTAINER_ADD_INQUIRY';
export const CONTAINER_ADD_INQUIRY_TITLE = 'Add Inquiry';
export const CONTAINER_ADD_INQUIRY_URL = process.env.REACT_APP_AXEJAM_URL + 'inquiry';
export const CONTAINER_MANAGE_INQUIRY = 'CONTAINER_MANAGE_INQUIRY';
export const CONTAINER_MANAGE_INQUIRY_TITLE = 'Manage Inquiry';
export const CONTAINER_MANAGE_INQUIRY_URL = process.env.REACT_APP_AXEJAM_URL + 'manageinquiries';
export const CONTAINER_ADD_PORTFOLIO = 'CONTAINER_ADD_PORTFOLIO';
export const CONTAINER_ADD_PORTFOLIO_TITLE = 'Add Portfolio';
export const CONTAINER_ADD_PORTFOLIO_URL = process.env.REACT_APP_AXEJAM_URL + 'addportfolio';
export const CONTAINER_MANAGE_PORTFOLIO = 'CONTAINER_MANAGE_PORTFOLIO';
export const CONTAINER_MANAGE_PORTFOLIO_TITLE = 'Manage Portfolio';
export const CONTAINER_MANAGE_PORTFOLIO_URL = process.env.REACT_APP_AXEJAM_URL + 'editportfolio';
export const CONTAINER_BOND_DASHBOARD = 'CONTAINER_BOND_DASHBOARD';
export const CONTAINER_BOND_DASHBOARD_TITLE = 'Bond Details';
export const CONTAINER_BOND_DASHBOARD_URL = process.env.REACT_APP_AXEJAM_URL + 'analyze';
export const CONTAINER_CUSTOMER_DASHBOARD = 'CONTAINER_CUSTOMER_DASHBOARD';
export const CONTAINER_CUSTOMER_DASHBOARD_TITLE = 'Customer Details';
export const CONTAINER_TICKER = 'CONTAINER_TICKER';
export const CONTAINER_TICKER_TITLE = 'Ticker Details';
export const CONTAINER_EDIT_INQUIRY = 'CONTAINER_EDIT_INQUIRY';
export const CONTAINER_EDIT_INQUIRY_TITLE = 'Edit Inquiry';
export const CONTAINER_EDIT_INQUIRY_URL = process.env.REACT_APP_AXEJAM_URL + 'inquiry';
export const RFQ_POPUP_INTERVAL = 2000;
export const EXPORT_COPY_LIMIT = process.env.REACT_APP_FLOW_BLOTTER_COPY_LIMIT;
export const EXPORT_EXCEL_LIMIT = process.env.REACT_APP_FLOW_BLOTTER_EXPORT_LIMIT;
export const AG_GRID_AUTOSAVE_INTERVAL = process.env.REACT_APP_AG_GRID_AUTOSAVE_INTERVAL;
export const AG_GRID_FILTER_CHANGED_INTERVAL = process.env.REACT_APP_AG_GRID_FILTER_CHANGED_INTERVAL;
export const BREADCRUMB_FILTERS_MERGE_BREAKPOINT = process.env.REACT_APP_AG_GRID_BREADCRUMB_FILTERS_MERGE_BREAKPOINT;
export const INITIAL_RFQ_REQUEST_END_RANGE = 15;
export const BLOOMBERG_TERMINAL_WINDOW = '1-BLOOMBERG';
export const SORT_DIRECTION = {
  asc: 'Ascending',
  desc: 'Descending'
};
export const BBG_SENDER = process.env.REACT_APP_BBGSENDER;
export const BBG_COMMAND_CONSOLE = 'BloombergCommandConsole';
export const BBG_SEND_KEYS = 'BBGSendKeys';

export const FIRSTROW_ALWAYS_CHECKBOX =
  process.env.REACT_APP_AG_GRID_FIRSTROW_ALWAYS_CHECKBOX === 'true' ? true : false;

export const customRenderingColumns = {
  code: true,
  clientname: true,
  ticker: true,
  axeside: true,
  description: true,
  tooltipColumns: {
    clientname: true
  },
  priorityaxe: true,
  histaxeside: true
};

export const columnsHavingBloombergIBChat = ['clientname', 'custusername'];
export const columnsHavingBloombergDataCommands = ['code', 'description'];
export const columnsHavingBondDetailsOption = ['code', 'description', 'ticker'];
export const columnsHavingClientDetailsOption = ['clientname'];

export const tradingDeskCoverageChoicesLabels = {
  coverage: 'Coverage',
  mydesk: 'My Desk'
};

export const recordTypes = {
  ALL: 'All',
  RFQ: 'RFQ',
  INQUIRY: 'Inquiry',
  TRADE: 'Trade'
};

export const LIVE_ONLY = 'LIVE ONLY';
export const ME_ONLY = 'ME ONLY';
export const AXE_ONLY = 'AXE ONLY';
export const AXE_DIRECTION_MATCH = 'AXE DIRECTION MATCH';

export const STANDARD_COPY_TEMPLATE_NAME = 'Standard';
export const STANDARD_FLOWBLOTTER_NAME = 'Standard';
export const FORCE_DEFAULT_THEME_CLASS = 'forceDefaultTheme';
