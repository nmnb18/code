import {
  CalendarFilter,
  MaturityFilter,
  CustomAgGridSetFilter,
  CustomAgGridDynamicSetFilter,
  CustomAgGridTextFilter,
  CustomAgGridNumFilter
} from '~components';
import {
  TODAY_STRING,
  YESTERDAY_STRING,
  FYTD_STRING,
  getDifferenceInDatesByDays,
  today,
  getFiscalDate
} from '~helpers/dateHelper';
import {
  FILTER_MODEL_TEXT,
  FILTER_MODEL_DATE,
  FILTER_MODEL_NUMBER,
  FILTER_MODEL_DYNAMIC_SET,
  FILTER_MODEL_SET
} from '~helpers/filterModelTypes';
import { getAgGridFilter, getFilterList } from '~helpers/agGridFilterRecreation';
import { BASE_32 } from './rfqFormatters';

export const AG_SET_FILTER = 'agSetColumnFilter';
export const AG_TEXT_FILTER = 'agTextColumnFilter';
export const AG_NUMBER_FILTER = 'agNumberColumnFilter';
export const AG_DATE_FILTER = 'agDateColumnFilter';
export const INTEGER_FILTER = 'INTEGER';
export const TEXT_STRING = 'STRING';
export const FLOAT_STRING = 'FLOAT';
export const DATETIME = 'DATETIME';
export const FILTER_RANGE_EQUALS = 'equals';
export const FILTER_RANGE_LESS_X = 'lessthan';
export const FILTER_RANGE_LESS_EQUAL_X = 'lessthanorequal';
export const FILTER_RANGE_GREAT_X = 'greaterthan';
export const FILTER_RANGE_GREAT_EQUAL_X = 'greaterthanorequal';
export const DATE_FORMAT_STRING = 'MMM-dd-yyyy';
export const REACT_COMPONENT_FILTER_STRING = 'reactComponent';
export const MAX_FILTER_SIZE = Number(process.env.REACT_APP_JASPER_WS_MAX_FILTER_SIZE);
export const FILTER_TYPES = {
  EQUALS: 'equals',
  LESS_THAN: 'lessThan',
  LESS_THAN_OR_EQUAL: 'lessThanOrEqual',
  GREATER_THAN: 'greaterThan',
  GREATER_THAN_OR_EQUAL: 'greaterThanOrEqual'
};
export const AXED_FILTER = ['BUY', 'SELL', 'DOUBLE SIDED'];
export const AXED_FILTER_DISABLE_OPTIONS = ['Select All', 'NONE'];
export const FILTER_TYPES_ARRAY = [
  {
    value: FILTER_TYPES.EQUALS,
    stringValue: 'Equals',
    symbol: '='
  },
  {
    value: FILTER_TYPES.LESS_THAN,
    stringValue: 'Less than',
    symbol: '<'
  },
  {
    value: FILTER_TYPES.LESS_THAN_OR_EQUAL,
    stringValue: 'Less than or equals',
    symbol: '<='
  },
  {
    value: FILTER_TYPES.GREATER_THAN,
    stringValue: 'Greater than',
    symbol: '>'
  },
  {
    value: FILTER_TYPES.GREATER_THAN_OR_EQUAL,
    stringValue: 'Greater than or equals',
    symbol: '>='
  }
];

export const getFilters = ({ columnDefinition }) => {
  let filterOptions = null;
  if (columnDefinition.codeinstruction && columnDefinition.codeinstruction.columnFilter === DYNAMIC_SET_FILTER) {
    filterOptions = [];
  } else if (columnDefinition.filteroptions) {
    filterOptions = columnDefinition.filteroptions;
  }

  return {
    filter: false,
    filterFramework: getCustomFilter(columnDefinition),
    menuTabs: ['filterMenuTab'],
    filterParams: {
      values: filterOptions,
      sortable: columnDefinition.sortable,
      columnDefinition
    }
  };
};

const CALENDAR_COLUMN_FILTER = 'calendarColumnFilter';
const MATURITY_COLUMN_FILTER = 'maturityColumnFilter';

export const TEXT_FILTER = 'CustomAgGridTextFilter';
export const NUM_FILTER = 'CustomAgGridNumFilter';
export const SET_FILTER = 'CustomAgGridSetFilter';
export const CALENDAR_FILTER = 'CalendarFilter';
export const MATURITY_FILTER = 'MaturityFilter';
export const DYNAMIC_SET_FILTER = 'dynamicSetFilter';

export const getFilterType = columnDefinition => {
  if (!columnDefinition) return FILTER_MODEL_TEXT;

  const { codeinstruction, filteroptions, columntype, formatinstruction } = columnDefinition;

  if (codeinstruction && codeinstruction.columnFilter === DYNAMIC_SET_FILTER) return FILTER_MODEL_DYNAMIC_SET;

  if (filteroptions !== null) return FILTER_MODEL_SET;

  if (codeinstruction && codeinstruction.advanceFilter) {
    switch (codeinstruction.advanceFilter) {
      case CALENDAR_COLUMN_FILTER:
        return FILTER_MODEL_DATE;
      case MATURITY_COLUMN_FILTER:
        return FILTER_MODEL_DATE;
      default:
        return FILTER_MODEL_TEXT;
    }
  }

  if (columntype === INTEGER_FILTER || columntype === FLOAT_STRING) return FILTER_MODEL_NUMBER;

  if (columntype === DATETIME && formatinstruction && formatinstruction.dateFormat === DATE_FORMAT_STRING)
    return FILTER_MODEL_DATE;

  return FILTER_MODEL_TEXT;
};

const getCustomFilter = columnDefinition => {
  if (columnDefinition.codeinstruction && columnDefinition.codeinstruction.columnFilter === DYNAMIC_SET_FILTER) {
    return CustomAgGridDynamicSetFilter;
  }

  if (columnDefinition.codeinstruction && columnDefinition.codeinstruction.advanceFilter) {
    switch (columnDefinition.codeinstruction.advanceFilter) {
      case CALENDAR_COLUMN_FILTER:
        return CalendarFilter;
      case MATURITY_COLUMN_FILTER:
        return MaturityFilter;
      default:
        return false;
    }
  }

  if (columnDefinition.filteroptions !== null) {
    return CustomAgGridSetFilter;
  }

  if (columnDefinition.columntype === INTEGER_FILTER || columnDefinition.columntype === FLOAT_STRING) {
    return CustomAgGridNumFilter;
  }

  if (
    columnDefinition.columntype === DATETIME &&
    columnDefinition.formatinstruction &&
    columnDefinition.formatinstruction.dateFormat === DATE_FORMAT_STRING
  ) {
    return CalendarFilter;
  }

  return CustomAgGridTextFilter;
};

export const parseSetFilterOptions = filterValues => filterValues.map(filterValue => `"${filterValue}"`).join(',');

export const defaultFilterParam = col => {
  return {
    field: col.field,
    headerName: col.headerName,
    filter: [],
    filterType: FILTER_MODEL_TEXT,
    type: null
  };
};

export const isEmpty = str => {
  return !str || 0 === str.length;
};

export const formatFilterType = filterType => {
  switch (filterType) {
    case FILTER_RANGE_EQUALS:
      return '';
    case FILTER_RANGE_LESS_X:
      return '<';
    case FILTER_RANGE_LESS_EQUAL_X:
      return '<=';
    case FILTER_RANGE_GREAT_X:
      return '>';
    case FILTER_RANGE_GREAT_EQUAL_X:
      return '>=';
    default:
      return '';
  }
};

export const reverseFormatFilterType = filterType => {
  switch (filterType) {
    case '':
      return 'equals';
    case '<':
      return 'lessThan';
    case '<=':
      return 'lessThanOrEqual';
    case '>':
      return 'greaterThan';
    case '>=':
      return 'greaterThanOrEqual';
    default:
      return 'equals';
  }
};

//Special interaction with Date Advance Filter: When the user Selects Today, yesterday, 7, 30 or more.
export const processCustomRange = columnFilters =>
  columnFilters.map(currentFilter => {
    if (isValidDateFilter(currentFilter)) {
      let dateToAlterFrom = new Date();
      let dateToAlterTo = new Date();

      let daysToSubstract = 0;
      if (currentFilter.customRange !== TODAY_STRING) {
        if (currentFilter.customRange === YESTERDAY_STRING) {
          daysToSubstract = 1;

          const day = dateToAlterTo.getDay();
          if (day === 1) {
            //Today is Monday
            daysToSubstract = 3;
          }
          if (day === 0) {
            //Today is Sunday
            daysToSubstract = 2;
          }
        } else if (currentFilter.customRange === FYTD_STRING) {
          daysToSubstract = getDifferenceInDatesByDays(getFiscalDate(today.getFullYear()), today);
        } else {
          daysToSubstract = parseInt(currentFilter.customRange);
        }
      }
      dateToAlterFrom.setDate(dateToAlterFrom.getDate() - daysToSubstract);

      //Restore Date Format
      if (currentFilter.filter && currentFilter.filter.length > 1) {
        currentFilter.filter[0] = restoreDateFormat(dateToAlterFrom);
        if (currentFilter.customRange === YESTERDAY_STRING) {
          currentFilter.filter[1] = restoreDateFormat(dateToAlterFrom);
        } else {
          currentFilter.filter[1] = restoreDateFormat(dateToAlterTo);
        }
      }
    }

    return currentFilter;
  });

export const restoreDateFormat = alteredDate => {
  //Restore Date Format
  const dd = String(alteredDate.getDate()).padStart(2, '0');
  const mm = String(alteredDate.getMonth() + 1).padStart(2, '0'); //January is 0!
  const yyyy = alteredDate.getFullYear();

  return mm + '/' + dd + '/' + yyyy;
};

const VALID_DATE_FILTER_LENGTH = 2;

const isValidDateFilter = currentFilter =>
  currentFilter.filterType === FILTER_MODEL_DATE &&
  currentFilter.customRange &&
  currentFilter.filter.length === VALID_DATE_FILTER_LENGTH;

export function hasFilter(filterObj) {
  return filterObj && filterObj.filter && filterObj.filter.length > 0 && filterObj.filter[0] !== '';
}

export function addFilter(newFilter, filters) {
  const newFilters = {
    ...filters,
    [newFilter.field]: newFilter
  };

  return newFilters;
}

export function applyAgGridFilterFormat(filters, columnDefs) {
  const filterList = getFilterList(columnDefs, filters);

  const agGridFilterModel = getAgGridFilter(filterList);

  return agGridFilterModel;
}

export const getColumnFilterValue = (column, filters) => {
  const columnFilter = filters[column.colId];
  return columnFilter ? columnFilter.filter : '';
};

export const hasFilterChanged = (model, filter) => {
  if (model.filterType === FILTER_MODEL_DYNAMIC_SET) {
    return model.textFilter !== filter;
  }

  return model.filter !== filter;
};

export const getNumModelValue = (model, { formatinstruction }) => {
  if (model) {
    const { filter } = model;
    const { decFormat } = formatinstruction;
    if (decFormat === BASE_32) return filter;

    if (`${filter || ''}`.trim() !== '') return Number(filter);

    return null;
  }

  return null;
};

export const hasDenominator = colDef =>
  !!colDef?.filterParams?.columnDefinition?.codeinstruction?.denominatorInstruction;
