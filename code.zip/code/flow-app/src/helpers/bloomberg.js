import { FLOW_APP_NAME, BBG_SENDER } from '~helpers/globals';
import { usageService, ACTION_BBG_NAVIGATE, usageTriggers } from '~services/usageService';
import { BloombergCommandFactory } from '~patterns/factory-method/bloombergCommand';

export const executeCommandWithUsage = (bloombergOptions, usageOptions) => {
  const { command, args } = bloombergOptions;
  const { commandLabel, currentFinUser } = usageOptions;

  const payload = usageService.getPayload(currentFinUser, ACTION_BBG_NAVIGATE, FLOW_APP_NAME, {
    Selection: commandLabel,
    Command: command,
    Data: args,
    From: usageTriggers.flowBlotter
  });
  usageService.sendUsage(payload);

  const bloombergCommandFactory = new BloombergCommandFactory();
  const executeBBGCommand = bloombergCommandFactory.create(BBG_SENDER);
  executeBBGCommand(bloombergOptions);
};
