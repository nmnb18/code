// If user's level3 is 'FI Technology' or user is an Admin
// then he should be able to see all columns
// otherwise, only the columns that have "available" flag set to "true"
export const getAvailableColumns = (columns, isTechOrAdmin) =>
  isTechOrAdmin ? columns : columns.filter(col => col.available);
