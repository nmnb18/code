import { multiLegIndicator, COLUMNS } from './columnStyles';
import { formatLegnoLetter } from '~helpers/rfqFormatters';

let params = {
  value: '1 leg',
  data: {
    rfqnlegs: 1,
    legno: 0
  },
  colDef: {
    field: COLUMNS.CLIENT_NAME
  }
};

const legs = [0, 1, 2];

describe('multiLegIndicator', () => {
  test('passing just one leg for Client Name column', () => {
    expect(multiLegIndicator(params)).toBe('');
  });

  test('passing just one leg for another column', () => {
    params = {
      ...params,
      colDef: {
        field: COLUMNS.STATUS_STR
      }
    };

    expect(multiLegIndicator(params)).toBe('');
  });

  test.each(legs)('passing multileg, being the Leg %p', leg => {
    params = {
      ...params,
      data: {
        rfqnlegs: 3,
        legno: leg
      },
      colDef: {
        field: COLUMNS.CLIENT_NAME
      }
    };

    const {
      data: { legno }
    } = params;

    expect(multiLegIndicator(params)).toBe(`<span class='leg-indicator'>${formatLegnoLetter(legno)}</span>`);
  });
});
