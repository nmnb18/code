export const mapToExcelColumnDef = columnDef => {
  const {
    field,
    headerName,
    width,
    hide,
    columntype: columnType,
    formatinstruction: formatInstruction,
    codeinstruction
  } = columnDef;

  return {
    field,
    headerName,
    columnType,
    formatInstruction,
    codeinstruction,
    width,
    hide
  };
};
