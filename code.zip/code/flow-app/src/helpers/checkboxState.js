import { SELECTALL_CHECKBOX_STATE } from '~helpers/exportHelper';

export const selectAllCheckboxNextState = (checkboxValue, selectAllCheckboxStatus, totalRows, checkboxList) => {
  const { newSelectAllCheckboxStatus } = checkboxValue;
  let totalSelectedRows = 0;
  let displayCopyExcel = false;
  // If the user clicks on the "select all" checkbox
  if (newSelectAllCheckboxStatus) {
    if (newSelectAllCheckboxStatus === SELECTALL_CHECKBOX_STATE.CHECK) {
      totalSelectedRows = totalRows;
      displayCopyExcel = true;
    } else if (newSelectAllCheckboxStatus === SELECTALL_CHECKBOX_STATE.UNCHECK) {
      totalSelectedRows = 0;
      displayCopyExcel = false;
    }
    const newCheckboxList = [];
    return {
      selectAllCheckboxStatus: newSelectAllCheckboxStatus,
      selectedRows: totalSelectedRows,
      valueDisplayCopyExcel: displayCopyExcel,
      checkboxList: newCheckboxList
    };
  } else {
    // If the user clicks on single checkbox
    const { selectedRow, isRowChecked } = checkboxValue;
    // 1st state: empty selection and the user just clicked on one single row
    if (selectAllCheckboxStatus === SELECTALL_CHECKBOX_STATE.UNCHECK) {
      if (isRowChecked) {
        // Validate that the clicked row is checked
        const { sowkey } = selectedRow;
        let newCheckboxList = [...checkboxList];
        totalSelectedRows = newCheckboxList.unshift(sowkey);
        displayCopyExcel = totalSelectedRows > 0;
        if (totalRows === totalSelectedRows) {
          newCheckboxList = [];
        }

        return {
          selectAllCheckboxStatus:
            totalRows === totalSelectedRows ? SELECTALL_CHECKBOX_STATE.CHECK : SELECTALL_CHECKBOX_STATE.PARTIAL,
          selectedRows: totalSelectedRows,
          valueDisplayCopyExcel: displayCopyExcel,
          checkboxList: newCheckboxList
        };
      }
    } else if (selectAllCheckboxStatus === SELECTALL_CHECKBOX_STATE.CHECK) {
      // 2nd state: all rows are already selected and the user just clicked on one single row
      if (!isRowChecked) {
        // Validate that the clicked row is unchecked
        const { key_id } = selectedRow;
        let newCheckboxList = [...checkboxList];
        totalSelectedRows = newCheckboxList.unshift(key_id);
        displayCopyExcel = totalRows - totalSelectedRows > 0;
        if (totalRows === totalSelectedRows) {
          newCheckboxList = [];
        }

        return totalRows !== totalSelectedRows
          ? {
              selectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.DASH,
              selectedRows: totalRows - totalSelectedRows,
              valueDisplayCopyExcel: displayCopyExcel,
              checkboxList: newCheckboxList
            }
          : {
              selectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.UNCHECK,
              selectedRows: 0,
              valueDisplayCopyExcel: false,
              checkboxList: newCheckboxList
            };
      }
    } else if (selectAllCheckboxStatus === SELECTALL_CHECKBOX_STATE.DASH) {
      // 3rd state: the user keep unchecking rows while the "select all" checkbox has the DASH status
      if (!isRowChecked) {
        const { key_id } = selectedRow;
        let newCheckboxList = [...checkboxList];
        totalSelectedRows = newCheckboxList.unshift(key_id);
        displayCopyExcel = totalRows - totalSelectedRows > 0;
        if (totalRows === totalSelectedRows) {
          newCheckboxList = [];
        }

        return totalRows !== totalSelectedRows
          ? {
              selectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.DASH,
              selectedRows: totalRows - totalSelectedRows,
              valueDisplayCopyExcel: displayCopyExcel,
              checkboxList: newCheckboxList
            }
          : {
              selectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.UNCHECK,
              selectedRows: 0,
              valueDisplayCopyExcel: false,
              checkboxList: newCheckboxList
            };
      } else {
        const { key_id } = selectedRow;
        let newCheckboxList = [...checkboxList].filter(_key_id => _key_id !== key_id);
        totalSelectedRows = newCheckboxList.length;
        displayCopyExcel = totalRows - totalSelectedRows > 0;
        if (totalSelectedRows === 0) {
          newCheckboxList = [];
        }

        return totalSelectedRows === 0
          ? {
              selectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.CHECK,
              selectedRows: totalRows,
              valueDisplayCopyExcel: displayCopyExcel,
              checkboxList: newCheckboxList
            }
          : {
              selectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.DASH,
              selectedRows: totalRows - totalSelectedRows,
              valueDisplayCopyExcel: displayCopyExcel,
              checkboxList: newCheckboxList
            };
      }
    } else if (selectAllCheckboxStatus === SELECTALL_CHECKBOX_STATE.PARTIAL) {
      // 4rd state: the user keep checking rows while the "select all" checkbox has the PARTIAL status
      if (isRowChecked) {
        const { sowkey } = selectedRow;
        let newCheckboxList = [...checkboxList];
        totalSelectedRows = newCheckboxList.unshift(sowkey);
        displayCopyExcel = totalSelectedRows > 0;
        if (totalRows === totalSelectedRows) {
          newCheckboxList = [];
        }

        return totalRows === totalSelectedRows
          ? {
              selectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.CHECK,
              selectedRows: totalSelectedRows,
              valueDisplayCopyExcel: displayCopyExcel,
              checkboxList: newCheckboxList
            }
          : {
              selectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.PARTIAL,
              selectedRows: totalSelectedRows,
              valueDisplayCopyExcel: displayCopyExcel,
              checkboxList: newCheckboxList
            };
      } else {
        const { sowkey } = selectedRow;
        let newCheckboxList = [...checkboxList].filter(_sowkey => _sowkey !== sowkey);
        totalSelectedRows = newCheckboxList.length;
        displayCopyExcel = totalSelectedRows > 0;
        if (!displayCopyExcel) {
          newCheckboxList = [];
        }

        return displayCopyExcel
          ? {
              selectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.PARTIAL,
              selectedRows: totalSelectedRows,
              valueDisplayCopyExcel: displayCopyExcel,
              checkboxList: newCheckboxList
            }
          : {
              selectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.UNCHECK,
              selectedRows: 0,
              valueDisplayCopyExcel: false,
              checkboxList: newCheckboxList
            };
      }
    }
  }
};
