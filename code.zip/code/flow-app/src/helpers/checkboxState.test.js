import { selectAllCheckboxNextState } from '~helpers/checkboxState';

describe.only('checkboxState', () => {
  describe('Grid has 1 single row', () => {
    const totalRows = 1;

    describe('All rows are selected', () => {
      const currentSelectAllCheckboxStatus = 'CHECK';
      const checkboxList = [];

      test('the user uncheck the select all checkbox', () => {
        const checkboxValue = { newSelectAllCheckboxStatus: 'UNCHECK' };

        const nextCheckboxState = selectAllCheckboxNextState(
          checkboxValue,
          currentSelectAllCheckboxStatus,
          totalRows,
          checkboxList
        );

        expect(nextCheckboxState.selectAllCheckboxStatus).toBe('UNCHECK');
        expect(nextCheckboxState.selectedRows).toBe(0);
        expect(nextCheckboxState.valueDisplayCopyExcel).toBeFalsy();
        expect(nextCheckboxState.checkboxList).toHaveLength(0);
      });

      test('the user uncheck any checkbox', () => {
        const checkboxValue = { selectedRow: { sowkey: 'sowkey-1', key_id: 'key_id-1' }, isRowChecked: false };

        const nextCheckboxState = selectAllCheckboxNextState(
          checkboxValue,
          currentSelectAllCheckboxStatus,
          totalRows,
          checkboxList
        );

        expect(nextCheckboxState.selectAllCheckboxStatus).toBe('UNCHECK');
        expect(nextCheckboxState.selectedRows).toBe(0);
        expect(nextCheckboxState.valueDisplayCopyExcel).toBeFalsy();
        expect(nextCheckboxState.checkboxList).toHaveLength(0);
      });
    });

    describe('No row selected', () => {
      const currentSelectAllCheckboxStatus = 'UNCHECK';
      const checkboxList = [];

      test('the user check the select all checkbox', () => {
        const checkboxValue = { newSelectAllCheckboxStatus: 'CHECK' };

        const nextCheckboxState = selectAllCheckboxNextState(
          checkboxValue,
          currentSelectAllCheckboxStatus,
          totalRows,
          checkboxList
        );

        expect(nextCheckboxState.selectAllCheckboxStatus).toBe('CHECK');
        expect(nextCheckboxState.selectedRows).toBe(totalRows);
        expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
        expect(nextCheckboxState.checkboxList).toHaveLength(0);
      });

      test('the user check any checkbox', () => {
        const checkboxValue = { selectedRow: { sowkey: 'sowkey-1', key_id: 'key_id-1' }, isRowChecked: true };

        const nextCheckboxState = selectAllCheckboxNextState(
          checkboxValue,
          currentSelectAllCheckboxStatus,
          totalRows,
          checkboxList
        );

        expect(nextCheckboxState.selectAllCheckboxStatus).toBe('CHECK');
        expect(nextCheckboxState.selectedRows).toBe(totalRows);
        expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
        expect(nextCheckboxState.checkboxList).toHaveLength(0);
      });
    });
  });

  describe('Grid has more than 1 row (5 rows)', () => {
    const totalRows = 5;

    describe('All rows are selected', () => {
      const currentSelectAllCheckboxStatus = 'CHECK';
      const checkboxList = [];

      test('the user uncheck the select all checkbox', () => {
        const checkboxValue = { newSelectAllCheckboxStatus: 'UNCHECK' };

        const nextCheckboxState = selectAllCheckboxNextState(
          checkboxValue,
          currentSelectAllCheckboxStatus,
          totalRows,
          checkboxList
        );

        expect(nextCheckboxState.selectAllCheckboxStatus).toBe('UNCHECK');
        expect(nextCheckboxState.selectedRows).toBe(0);
        expect(nextCheckboxState.valueDisplayCopyExcel).toBeFalsy();
        expect(nextCheckboxState.checkboxList).toHaveLength(0);
      });

      test('the user uncheck any checkbox', () => {
        const checkboxValue = { selectedRow: { sowkey: 'sowkey-1', key_id: 'key_id-1' }, isRowChecked: false };

        const nextCheckboxState = selectAllCheckboxNextState(
          checkboxValue,
          currentSelectAllCheckboxStatus,
          totalRows,
          checkboxList
        );

        expect(nextCheckboxState.selectAllCheckboxStatus).toBe('DASH');
        expect(nextCheckboxState.selectedRows).toBe(4);
        expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
        expect(nextCheckboxState.checkboxList).toHaveLength(1);
        expect(nextCheckboxState.checkboxList[0]).toBe('key_id-1');
      });
    });

    describe('User is checking checkbox', () => {
      describe('1 single row is already selected (1/5 rows selected)', () => {
        const currentSelectAllCheckboxStatus = 'PARTIAL';
        const checkboxList = ['sowkey-1'];

        test('the user check the select all checkbox', () => {
          const checkboxValue = { newSelectAllCheckboxStatus: 'CHECK' };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('CHECK');
          expect(nextCheckboxState.selectedRows).toBe(totalRows);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });

        test('the user check other checkbox', () => {
          const checkboxValue = { selectedRow: { sowkey: 'sowkey-2', key_id: 'key_id-2' }, isRowChecked: true };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('PARTIAL');
          expect(nextCheckboxState.selectedRows).toBe(2);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(2);
          expect(nextCheckboxState.checkboxList[0]).toBe('sowkey-2');
          expect(nextCheckboxState.checkboxList[1]).toBe('sowkey-1');
        });

        test('the user uncheck the only checked checkbox', () => {
          const checkboxValue = { selectedRow: { sowkey: 'sowkey-1', key_id: 'key_id-1' }, isRowChecked: false };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('UNCHECK');
          expect(nextCheckboxState.selectedRows).toBe(0);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeFalsy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });

        test('the user uncheck the select all checkbox', () => {
          const checkboxValue = { newSelectAllCheckboxStatus: 'UNCHECK' };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('UNCHECK');
          expect(nextCheckboxState.selectedRows).toBe(0);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeFalsy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });
      });

      describe('More than 1 row is already selected (2/5 rows selected)', () => {
        const currentSelectAllCheckboxStatus = 'PARTIAL';
        const checkboxList = ['sowkey-2', 'sowkey-1'];

        test('the user check the select all checkbox', () => {
          const checkboxValue = { newSelectAllCheckboxStatus: 'CHECK' };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('CHECK');
          expect(nextCheckboxState.selectedRows).toBe(totalRows);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });

        test('the user check other checkbox', () => {
          const checkboxValue = { selectedRow: { sowkey: 'sowkey-3', key_id: 'key_id-3' }, isRowChecked: true };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('PARTIAL');
          expect(nextCheckboxState.selectedRows).toBe(3);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(3);
          expect(nextCheckboxState.checkboxList[0]).toBe('sowkey-3');
          expect(nextCheckboxState.checkboxList[1]).toBe('sowkey-2');
          expect(nextCheckboxState.checkboxList[2]).toBe('sowkey-1');
        });

        test('the user uncheck the second checked checkbox', () => {
          const checkboxValue = { selectedRow: { sowkey: 'sowkey-2', key_id: 'key_id-2' }, isRowChecked: false };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('PARTIAL');
          expect(nextCheckboxState.selectedRows).toBe(1);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(1);
          expect(nextCheckboxState.checkboxList[0]).toBe('sowkey-1');
        });

        test('the user uncheck the select all checkbox', () => {
          const checkboxValue = { newSelectAllCheckboxStatus: 'UNCHECK' };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('UNCHECK');
          expect(nextCheckboxState.selectedRows).toBe(0);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeFalsy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });
      });

      describe('Almost all rows are already selected (4/5 rows selected)', () => {
        const currentSelectAllCheckboxStatus = 'PARTIAL';
        const checkboxList = ['sowkey-4', 'sowkey-3', 'sowkey-2', 'sowkey-1'];

        test('the user check the select all checkbox', () => {
          const checkboxValue = { newSelectAllCheckboxStatus: 'CHECK' };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('CHECK');
          expect(nextCheckboxState.selectedRows).toBe(totalRows);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });

        test('the user check other checkbox', () => {
          const checkboxValue = { selectedRow: { sowkey: 'sowkey-5', key_id: 'key_id-5' }, isRowChecked: true };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('CHECK');
          expect(nextCheckboxState.selectedRows).toBe(5);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });

        test('the user uncheck the last checked checkbox (4 row)', () => {
          const checkboxValue = { selectedRow: { sowkey: 'sowkey-4', key_id: 'key_id-4' }, isRowChecked: false };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('PARTIAL');
          expect(nextCheckboxState.selectedRows).toBe(3);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(3);
          expect(nextCheckboxState.checkboxList[0]).toBe('sowkey-3');
          expect(nextCheckboxState.checkboxList[1]).toBe('sowkey-2');
          expect(nextCheckboxState.checkboxList[2]).toBe('sowkey-1');
        });

        test('the user uncheck the select all checkbox', () => {
          const checkboxValue = { newSelectAllCheckboxStatus: 'UNCHECK' };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('UNCHECK');
          expect(nextCheckboxState.selectedRows).toBe(0);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeFalsy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });
      });
    });

    describe('User is unchecking checkbox', () => {
      describe('1 single row is already unselected (4/5 rows selected)', () => {
        const currentSelectAllCheckboxStatus = 'DASH';
        const checkboxList = ['key_id-1'];

        test('the user check the select all checkbox', () => {
          const checkboxValue = { newSelectAllCheckboxStatus: 'CHECK' };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('CHECK');
          expect(nextCheckboxState.selectedRows).toBe(totalRows);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });

        test('the user uncheck other checkbox', () => {
          const checkboxValue = { selectedRow: { sowkey: 'sowkey-2', key_id: 'key_id-2' }, isRowChecked: false };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('DASH');
          expect(nextCheckboxState.selectedRows).toBe(3);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(2);
          expect(nextCheckboxState.checkboxList[0]).toBe('key_id-2');
          expect(nextCheckboxState.checkboxList[1]).toBe('key_id-1');
        });

        test('the user check the only unchecked checkbox', () => {
          const checkboxValue = { selectedRow: { sowkey: 'sowkey-1', key_id: 'key_id-1' }, isRowChecked: true };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('CHECK');
          expect(nextCheckboxState.selectedRows).toBe(5);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });

        test('the user uncheck the select all checkbox', () => {
          const checkboxValue = { newSelectAllCheckboxStatus: 'UNCHECK' };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('UNCHECK');
          expect(nextCheckboxState.selectedRows).toBe(0);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeFalsy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });
      });

      describe('More than 1 row is already unselected (3/5 rows selected)', () => {
        const currentSelectAllCheckboxStatus = 'DASH';
        const checkboxList = ['key_id-2', 'key_id-1'];

        test('the user check the select all checkbox', () => {
          const checkboxValue = { newSelectAllCheckboxStatus: 'CHECK' };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('CHECK');
          expect(nextCheckboxState.selectedRows).toBe(totalRows);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });

        test('the user uncheck the third checked checkbox', () => {
          const checkboxValue = { selectedRow: { sowkey: 'sowkey-3', key_id: 'key_id-3' }, isRowChecked: false };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('DASH');
          expect(nextCheckboxState.selectedRows).toBe(2);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(3);
          expect(nextCheckboxState.checkboxList[0]).toBe('key_id-3');
          expect(nextCheckboxState.checkboxList[1]).toBe('key_id-2');
          expect(nextCheckboxState.checkboxList[2]).toBe('key_id-1');
        });

        test('the user check the second unchecked checkbox', () => {
          const checkboxValue = { selectedRow: { sowkey: 'sowkey-2', key_id: 'key_id-2' }, isRowChecked: true };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('DASH');
          expect(nextCheckboxState.selectedRows).toBe(4);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(1);
          expect(nextCheckboxState.checkboxList[0]).toBe('key_id-1');
        });

        test('the user uncheck the select all checkbox', () => {
          const checkboxValue = { newSelectAllCheckboxStatus: 'UNCHECK' };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('UNCHECK');
          expect(nextCheckboxState.selectedRows).toBe(0);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeFalsy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });
      });

      describe('Almost all rows are already unselected (1/5 rows selected)', () => {
        const currentSelectAllCheckboxStatus = 'DASH';
        const checkboxList = ['key_id-4', 'key_id-3', 'key_id-2', 'key_id-1'];

        test('the user check the select all checkbox', () => {
          const checkboxValue = { newSelectAllCheckboxStatus: 'CHECK' };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('CHECK');
          expect(nextCheckboxState.selectedRows).toBe(totalRows);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });

        test('the user uncheck the last checked checkbox (5 row)', () => {
          const checkboxValue = { selectedRow: { sowkey: 'sowkey-5', key_id: 'key_id-5' }, isRowChecked: false };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('UNCHECK');
          expect(nextCheckboxState.selectedRows).toBe(0);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeFalsy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });

        test('the user check the fourth checkbox', () => {
          const checkboxValue = { selectedRow: { sowkey: 'sowkey-4', key_id: 'key_id-4' }, isRowChecked: true };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('DASH');
          expect(nextCheckboxState.selectedRows).toBe(2);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
          expect(nextCheckboxState.checkboxList).toHaveLength(3);
          expect(nextCheckboxState.checkboxList[0]).toBe('key_id-3');
          expect(nextCheckboxState.checkboxList[1]).toBe('key_id-2');
          expect(nextCheckboxState.checkboxList[2]).toBe('key_id-1');
        });

        test('the user uncheck the select all checkbox', () => {
          const checkboxValue = { newSelectAllCheckboxStatus: 'UNCHECK' };

          const nextCheckboxState = selectAllCheckboxNextState(
            checkboxValue,
            currentSelectAllCheckboxStatus,
            totalRows,
            checkboxList
          );

          expect(nextCheckboxState.selectAllCheckboxStatus).toBe('UNCHECK');
          expect(nextCheckboxState.selectedRows).toBe(0);
          expect(nextCheckboxState.valueDisplayCopyExcel).toBeFalsy();
          expect(nextCheckboxState.checkboxList).toHaveLength(0);
        });
      });
    });

    describe('No row selected', () => {
      const currentSelectAllCheckboxStatus = 'UNCHECK';
      const checkboxList = [];

      test('the user check the select all checkbox', () => {
        const checkboxValue = { newSelectAllCheckboxStatus: 'CHECK' };

        const nextCheckboxState = selectAllCheckboxNextState(
          checkboxValue,
          currentSelectAllCheckboxStatus,
          totalRows,
          checkboxList
        );

        expect(nextCheckboxState.selectAllCheckboxStatus).toBe('CHECK');
        expect(nextCheckboxState.selectedRows).toBe(totalRows);
        expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
        expect(nextCheckboxState.checkboxList).toHaveLength(0);
      });

      test('the user check any checkbox', () => {
        const checkboxValue = { selectedRow: { sowkey: 'sowkey-1', key_id: 'key_id-1' }, isRowChecked: true };

        const nextCheckboxState = selectAllCheckboxNextState(
          checkboxValue,
          currentSelectAllCheckboxStatus,
          totalRows,
          checkboxList
        );

        expect(nextCheckboxState.selectAllCheckboxStatus).toBe('PARTIAL');
        expect(nextCheckboxState.selectedRows).toBe(1);
        expect(nextCheckboxState.valueDisplayCopyExcel).toBeTruthy();
        expect(nextCheckboxState.checkboxList).toHaveLength(1);
        expect(nextCheckboxState.checkboxList[0]).toBe('sowkey-1');
      });
    });
  });
});
