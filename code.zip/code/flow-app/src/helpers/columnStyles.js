import { isLegRow, hasLegs } from '~helpers/jasperMessage';

const JS_BEHAVIORS = {
  DIRECTIONAL: 'col-directional',
  TAG_STATUS: 'col-tag-status',
  TAG_SOURCE: 'col-tag-source',
  TAG_TIER: 'col-tag-tier', // This style is related to the priority column which is out of scope for phase 1
  TAG_ACTION: 'col-tag-action'
};

export const COLUMNS = {
  BUY_SELL: 'buysell',
  CLIENT_BUY_SELL: 'clientbuysell',
  STATUS_STR: 'statusstr',
  ACTION_STR: 'actionstr',
  SOURCE: 'recordtype',
  CLIENT_NAME: 'clientname',
  RFQ_CREATE_DATE: 'rfqcreatedate',
  RFQ_CREATE_TIME: 'rfqcreatetime',
  TIMEUPDEX: 'timeupdex',
  AXESIDE: 'axeside',
  MOODY: 'ratingmoody',
  SP: 'rating_s_and_p',
  CUSIP_ISIN: 'code',
  DESCRIPTION: 'description',
  PRIORITY_AXE: 'priorityaxe',
  HIST_AXESIDE: 'histaxeside',
  TICKER: 'ticker'
};

export const COLUMNS_TYPE = {
  FLOAT: 'FLOAT',
  INTEGER: 'INTEGER'
};

const BUY = 'BUY';
const SELL = 'SELL';

const hasEmptyValue = params => !params.value;

const isStatusStrEqual = (params, status) =>
  params.data && params.data[COLUMNS.STATUS_STR] && params.data[COLUMNS.STATUS_STR].toLowerCase() === status;

const isActionStrEqual = (params, action) =>
  params.data && params.data[COLUMNS.ACTION_STR] && params.data[COLUMNS.ACTION_STR].toLowerCase() === action;

const isClientBuySellEqual = (params, value) =>
  params.data && params.data[COLUMNS.CLIENT_BUY_SELL] && params.data[COLUMNS.CLIENT_BUY_SELL] === value;

const isSourceTypeEqual = (params, source) =>
  params.data && params.data[COLUMNS.SOURCE] && params.data[COLUMNS.SOURCE].toLowerCase() === source;

const isActiveStatus = params => {
  const hasStatus = !!(params.data && params.data[COLUMNS.STATUS_STR]);
  const status = params.data && params.data[COLUMNS.STATUS_STR];

  return (
    hasStatus &&
    (status === TAG_STATUS.UNVALIDATED.value ||
      status === TAG_STATUS.QUOTE_REQUESTED.value ||
      status === TAG_STATUS.QUOTE_ON_THE_WIRE.value)
  );
};

export const isJsBehaviorDirectional = jsBehavior => jsBehavior === JS_BEHAVIORS.DIRECTIONAL;

export const isJsBehaviorTagStatus = jsBehavior => jsBehavior === JS_BEHAVIORS.TAG_STATUS;

export const isJsBehaviorTagSource = jsBehavior => jsBehavior === JS_BEHAVIORS.TAG_SOURCE;

export const isJsBehaviorTagAction = jsBehavior => jsBehavior === JS_BEHAVIORS.TAG_ACTION;

export const isClientBuy = params => !hasEmptyValue(params) && isClientBuySellEqual(params, BUY);

export const isClientSell = params => !hasEmptyValue(params) && isClientBuySellEqual(params, SELL);

export const showLegIndicator = ({ colDef: { field }, data }) => hasLegs(data) && isClientNameColum(field);

export const isStatusEqual = (params, status) =>
  !hasEmptyValue(params) && !isLegRow(params.data) && isStatusStrEqual(params, status);

export const isActionEqual = (params, action) =>
  !hasEmptyValue(params) && !isLegRow(params.data) && isActionStrEqual(params, action);

/**
 * @param {object} params
 * @returns {boolean}
 */
export const cellHasValue = params => !hasEmptyValue(params);

export const isSourceEqual = (params, source, evaluateActive = false) => {
  const isActive = isSourceTypeEqual(params, SOURCES.RFQ) && isActiveStatus(params);

  if (evaluateActive) {
    return !hasEmptyValue(params) && isSourceTypeEqual(params, source) && isActive;
  }

  return !hasEmptyValue(params) && isSourceTypeEqual(params, source) && !isActive;
};

export const isStyleNameEqual = (params, styleName, expectedStyleName) =>
  !hasEmptyValue(params) && styleName === expectedStyleName;

export const isAlignEqual = (params, align, expectedAlign) => !hasEmptyValue(params) && align === expectedAlign;

export const TAG_STATUS = {
  ORDER_SENT: { value: 'ordersent', class: 'ordersent' },
  PASSED: { value: 'passed', class: 'passed' },
  QUOTE_ON_THE_WIRE: { value: 'quoteonthewire', class: 'quoteonthewire' },
  QUOTE_REFRESH_REQUESTED: { value: 'quoterefreshrequested', class: 'quoterefreshrequested' },
  ERROR: { value: 'error', class: 'error' },
  DEALER_REJECTED_PENDING: { value: 'dealerrejectedpending', class: 'dealerrejectedpending' },
  UNVALIDATED: { value: 'unvalidated', class: 'unvalidated' },
  CUST_REJECTED: { value: 'custrejected', class: 'custrejected' },
  QUOTE_REQUESTED: { value: 'quoterequested', class: 'quoterequested' },
  DONE: { value: 'done', class: 'done' },
  DEALER_TIMEOUT: { value: 'dealertimeout', class: 'dealertimeout' },
  DEALER_REJECTED: { value: 'dealerrejected', class: 'dealerrejected' },
  CUSTOMER_TIMEOUT: { value: 'customertimeout', class: 'customertimeout' },
  DEALER_QUOTE_PENDING: { value: 'dealerquotepending', class: 'dealerquotepending' },
  QUOTE_SUBJECT: { value: 'quotesubject', class: 'quotesubject' },
  CUST_ACCEPTED_REJECTED: { value: 'custacceptedrejected', class: 'custacceptedrejected' },
  CUST_ACCEPTED_SUBJECT: { value: 'custacceptedsubject', class: 'custacceptedsubject' },
  PENDING: { value: 'pending', class: 'pending' },
  SENT_TO_TRADER: { value: 'sent to trader', class: 'senttotrader' },
  LIVE: { value: 'live', class: 'live' },
  EXPIRED: { value: 'expired', class: 'expired' },
  FILLED: { value: 'filled', class: 'filled' },
  TRADER_REJECTED: { value: 'trader rejected', class: 'traderrejected' },
  ACCEPTPENDING: { value: 'acceptpending', class: 'acceptpending' },
  CANCELLED: { value: 'cancelled', class: 'cancelled' },
  LIVE_TRADER_AXED: { value: 'live - trader axed', class: 'livetraderaxed' },
  LIVE_TRADER_NOT_AXED: { value: 'live - trader not axed', class: 'livetradernotaxed' },
  NOT_ROUTED: { value: 'not routed', class: 'notrouted' }
};

export const TAG_ACTION = {
  COVER_TIED: { value: 'covertied', class: 'covertied' },
  COVERED: { value: 'covered', class: 'covered' },
  CUST_ACCEPTED_QUOTE: { value: 'custacceptedquote', class: 'custacceptedquote' },
  CUST_ACCEPTED_QUOTEFIRM: { value: 'custacceptedquotefirm', class: 'custacceptedquotefirm' },
  CUST_ACCEPTED_TIED: { value: 'custacceptedtied', class: 'custacceptedtied' },
  CUST_REJECTED_QUOTE: { value: 'custrejectedquote', class: 'custrejectedquote' },
  CUST_REQUESTED_QUOTE: { value: 'custrequestedquote', class: 'custrequestedquote' },
  CUST_SENT_LIST: { value: 'custsentlist', class: 'custsentlist' },
  CUST_SENT_ORDER: { value: 'custsentorder', class: 'custsentorder' },
  DEALER_ACCEPT_ORDER: { value: 'dealeracceptorder', class: 'dealeracceptorder' },
  DEALER_ACCEPT_TIED: { value: 'dealeraccepttied', class: 'dealeraccepttied' },
  DEALER_PASS: { value: 'dealerpass', class: 'dealerpass' },
  DEALER_QUOTE: { value: 'dealerquote', class: 'dealerquote' },
  DEALER_REJECT: { value: 'dealerreject', class: 'dealerreject' },
  ERROR: { value: 'error', class: 'error' },
  EXPIRED: { value: 'expired', class: 'expired' },
  ON_THE_WIRE_ELAPSED: { value: 'onthewireelapsed', class: 'onthewireelapsed' },
  PHASE_EXPIRED: { value: 'phaseexpired', class: 'phaseexpired' },
  ROUTE: { value: 'route', class: 'route' },
  SPOTTED: { value: 'spotted', class: 'spotted' },
  TIED_TRADED_AWAY: { value: 'tiedtradedaway', class: 'tiedtradedaway' },
  TRADED_AWAY: { value: 'tradedaway', class: 'tradedaway' }
};

export const SOURCES = {
  CHAT: 'chat',
  VOICE: 'voice',
  INQUIRY: 'inquiry',
  RFQ: 'rfq',
  TRADE: 'trade'
};

export const STYLENAMES = {
  LINK: 'col-link',
  CLASSIC: 'col-classic',
  TAG_AXE: 'col-tag-axe',
  CAPITALIZE: 'col-capitalize',
  TIME: 'col-time',
  FONT_GREEN: 'col-font-green',
  FONT_RED: 'col-font-red'
};

export const ALIGN = {
  RIGHT: 'col-align-right',
  CENTER: 'col-align-center'
};

export const isClientNameColum = field => field === COLUMNS.CLIENT_NAME;

export const isCusipIsinColum = field => field === COLUMNS.CUSIP_ISIN;

export const isDescriptionColum = field => field === COLUMNS.DESCRIPTION;

export const isAxeSideColum = field => field === COLUMNS.AXESIDE;

export const isPriorityAxeColum = field => field === COLUMNS.PRIORITY_AXE;

export const isHistAxeSideColum = field => field === COLUMNS.HIST_AXESIDE;

export const isTickerColumn = field => field === COLUMNS.TICKER;
