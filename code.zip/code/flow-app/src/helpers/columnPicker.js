import { getAvailableColumns } from '~helpers/availableColumns';

export const filterColumnListForChooser = (columnsDictionary, columnState, isTech) => {
  if (columnsDictionary) {
    const filteredColumnDictionary = columnsDictionary.filter(
      element =>
        element.sourcecolumnname.indexOf('l1') < 0 &&
        element.sourcecolumnname.indexOf('l2') < 0 &&
        element.sourcecolumnname !== '-' &&
        !columnState.find(({ colId }) => colId === element.sourcecolumnname) &&
        element.sourcecolumnname !== 'key_id'
    );

    return getAvailableColumns(filteredColumnDictionary, isTech);
  }

  return null;
};

export const filterColumnListForActive = colState => {
  if (colState) {
    return colState.filter(
      element =>
        element.colId.indexOf('l1') < 0 &&
        element.colId.indexOf('l2') < 0 &&
        element.colId !== '-' &&
        element.hide !== true &&
        element.colId !== 'key_id' &&
        !!element.displayname
    );
  }
  return null;
};

const getDisplayColumnName = (columnsDictionary, colId) => {
  return (
    columnsDictionary &&
    columnsDictionary.sourceColumnNames &&
    columnsDictionary.sourceColumnNames.find(({ sourcecolumnname }) => sourcecolumnname === colId)
  );
};

export const upgradeColumnState = (columnsDictionary, columnState) => {
  return (
    columnState &&
    columnState.map(element => {const {
      displayname = false,
      available = false,
      required = false,
      codeinstruction = {}
    } = getDisplayColumnName(columnsDictionary, element.colId) || {};
      return {
        ...element,
        displayname,
        available,
        required,
        referenceKey: codeinstruction.referenceKey
      };
    })
  );
};

export const addRowOnActiveColumns = selectedColumn => {
  const defaultColumnWidth = 125;

  return {
    aggFunc: null,
    colId: selectedColumn.sourcecolumnname,
    displayname: selectedColumn.displayname,
    available: selectedColumn.available,
    required: selectedColumn.required,
    hide: false,
    pinned: null,
    pivotIndex: null,
    rowGroupIndex: null,
    width: selectedColumn.displaywidth || defaultColumnWidth,
    referenceKey: selectedColumn.codeinstruction.referenceKey
  };
};

export const formatColumnName = (columnName, numberToFormat) => {
  const maxNumberLength = numberToFormat ? numberToFormat : 20;
  return columnName.length > maxNumberLength ? `${columnName.substring(0, maxNumberLength)}...` : columnName;
};
