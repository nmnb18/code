export const EXPORT_BATCH_SIZE = 75;

export const SELECTALL_CHECKBOX_STATE = {
  UNCHECK: 'UNCHECK',
  CHECK: 'CHECK',
  DASH: 'DASH',
  PARTIAL: 'PARTIAL'
};

export const isCheckboxStateUncheck = state => state === SELECTALL_CHECKBOX_STATE.UNCHECK;
export const isCheckboxStateCheck = state => state === SELECTALL_CHECKBOX_STATE.CHECK;
export const isCheckboxStateDash = state => state === SELECTALL_CHECKBOX_STATE.DASH;
export const isCheckboxStatePartial = state => state === SELECTALL_CHECKBOX_STATE.PARTIAL;

export const toggleSelectAllCheckboxStatus = currentStatus => {
  switch (currentStatus) {
    case SELECTALL_CHECKBOX_STATE.UNCHECK:
    case SELECTALL_CHECKBOX_STATE.PARTIAL:
      return SELECTALL_CHECKBOX_STATE.CHECK;
    case SELECTALL_CHECKBOX_STATE.CHECK:
    case SELECTALL_CHECKBOX_STATE.DASH:
      return SELECTALL_CHECKBOX_STATE.UNCHECK;
    default:
      return SELECTALL_CHECKBOX_STATE.UNCHECK;
  }
};
