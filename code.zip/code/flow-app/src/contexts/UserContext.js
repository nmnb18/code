import React, { useState, useEffect, createContext } from 'react';
import { fin } from '~helpers/globals';

export const UserContext = createContext();

const UserContextProvider = props => {
  const [currentUser, setUser] = useState(null);
  const [currentComputer, setComputer] = useState(null);
  const [impersonatedUser, setImpersonatedUser] = useState(null);

  useEffect(() => {
    fin && fin.desktop.System.getEnvironmentVariable('USERNAME', currentUser => setUser(currentUser.toLowerCase()));
    fin && fin.desktop.System.getEnvironmentVariable('COMPUTERNAME', computerName => setComputer(computerName));
  }, []);

  const value = {
    currentUser,
    setUser,
    currentComputer,
    impersonatedUser,
    setImpersonatedUser
  };

  if (currentUser && currentComputer) {
    return <UserContext.Provider value={value}>{props.children}</UserContext.Provider>;
  }
  return null;
};

export default UserContextProvider;
