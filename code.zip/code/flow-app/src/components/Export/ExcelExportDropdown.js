import React, { useRef, Fragment } from 'react';
import styles from './ExcelExportDropdown.module.scss';
import { useClickOutside } from '~hooks';
import { FETCH_TRIGGERS } from '~helpers/jasperMessage';
import { EXPORT_EXCEL_LIMIT } from '~helpers/globals';
import { ReactComponent as ChevrondownIcon } from '~assets/icon/nav/chevrondown.svg';
import { ReactComponent as ExcelIcon } from '~assets/icon/logo/excel.svg';
import IconButton from '../../ui-library/Buttons/IconButton';

const ExcelExportDropdown = props => {
  const myRef = useRef();
  const [isOpen, setIsOpen] = useClickOutside(myRef);
  const handleIsOpen = () => setIsOpen(!isOpen);
  const { isFetchingData, handleExportToExcel, showTooltipExcel } = props;
  const styleClass = `${styles['dropdown__options']} ${
    showTooltipExcel ? styles['header-action-buttons--disabled'] : null
  }`;

  return (
    <Fragment>
      <div
        className={`${styles['header-action-button__main']} ${
          showTooltipExcel ? styles['header-action-buttons--disabled'] : null
        }`}
      >
        <IconButton
          disabled={isFetchingData || showTooltipExcel}
          handleClick={() => handleExportToExcel(FETCH_TRIGGERS.EXPORT_TO_EXCEL_AND_OPEN)}
          title="Export to Excel"
          size="large"
          disabledExtremeStyle
        >
          <ExcelIcon />
        </IconButton>
        <span className={styles['header-action-buttons--disabled__text']}>
          Number of rows exceeds limit ({EXPORT_EXCEL_LIMIT} rows).<br></br>Please refine selection
        </span>
      </div>
      <div ref={myRef} className={styles['dropdown dropdown--container']}>
        <IconButton handleClick={handleIsOpen} size="tiny">
          <ChevrondownIcon />
        </IconButton>
        {isOpen && (
          <div className={styleClass}>
            <button onClick={() => handleExportToExcel(FETCH_TRIGGERS.EXPORT_TO_EXCEL_AS_DOWNLOAD)}>Save As</button>
            <span className={styles['header-action-buttons--disabled__text']}>
              Number of rows exceeds limit ({EXPORT_EXCEL_LIMIT} rows).<br></br>Please refine selection
            </span>
          </div>
        )}
      </div>
    </Fragment>
  );
};

export default ExcelExportDropdown;
