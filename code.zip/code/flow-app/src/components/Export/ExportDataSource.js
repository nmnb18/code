import { Component } from 'react';
import { Subject } from 'rxjs';
import { FETCH_TRIGGERS } from '~helpers/jasperMessage';
import { fetchLimit } from '~services/apiConfig';
import { getColumnDefinition } from '~services/columnDictionaryService';
import { mapToExcelColumnDef } from '~helpers/exportToExcel';

class ExportDataSource extends Component {
  exportDataCacheService;

  subscriptionIdSubject$ = new Subject();
  dataFlowSubject$ = new Subject();

  columnDefs;
  columnsDictionary;
  trigger;

  componentDidMount() {
    const { subscriptionInstanceId, fetchDataSubject$, onExportDataSourceReady } = this.props;

    this.setSubscriptionInstance(subscriptionInstanceId);

    this.fetchDataSubscription = fetchDataSubject$.subscribe(
      ({ selectAllCheckboxStatus, selectedRowsValue, columnsDictionary, columnDefs, trigger }) => {
        this.columnsDictionary = columnsDictionary;
        this.trigger = trigger;

        let limit = null;

        if (trigger === FETCH_TRIGGERS.COPY_TO_CLIPBOARD) {
          this.columnDefs = columnDefs.map(({ field, headerName }) => ({ field, headerName, width: 75, hide: false }));
          limit = fetchLimit.COPY;
        } else {
          this.columnDefs = columnDefs.map(({ field, headerName, width, hide }) => {
            const columnDef = getColumnDefinition(columnsDictionary, field);
            if (!columnDef) return null;

            const excelColumnDef = mapToExcelColumnDef({ field, headerName, width, hide, ...columnDef });
            return excelColumnDef;
          });
          limit = fetchLimit.EXPORT;
        }

        const filterRange = { firstRow: 0, lastRow: limit - 1 };
        this.handleRequestData({
          ...filterRange,
          newCriteria: true,
          columnDefs: this.columnDefs,
          selectAllCheckboxStatus,
          selectedRowsValue,
          trigger
        });
      }
    );

    onExportDataSourceReady();
  }

  componentDidUpdate(prevProps) {
    const { subscriptionInstanceId: subscriptionInstanceIdPrev } = prevProps;
    const { subscriptionInstanceId } = this.props;

    if (subscriptionInstanceId !== subscriptionInstanceIdPrev) {
      this.setSubscriptionInstance(subscriptionInstanceId);
    }
  }

  componentWillUnmount() {
    this.fetchDataSubscription.unsubscribe();
  }

  setSubscriptionInstance = subscriptionInstanceId => this.subscriptionIdSubject$.next(subscriptionInstanceId);

  handleRequestData = ({
    firstRow,
    lastRow,
    columnDefs,
    newCriteria = false,
    selectAllCheckboxStatus,
    selectedRowsValue,
    trigger
  } = {}) => {
    const { requestData, subscriptionInstanceId, gridId } = this.props;

    requestData &&
      requestData({
        subscriptionInstanceId,
        columnDefs,
        firstRow,
        lastRow,
        newCriteria,
        gridId,
        selectAllCheckboxStatus,
        selectedRowsValue,
        trigger
      });
  };

  render() {
    return null;
  }
}

export default ExportDataSource;
