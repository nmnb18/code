import React, { memo } from 'react';
import styles from './FlowGridFooter.module.scss';

const FlowGridFooter = ({ selectedRows, totalRows }) => (
  <div className={styles['footer-text']}>
    <div className={styles['footer-text-items']}>
      <div>{totalRows} Items</div>
      <div>{selectedRows} Selected</div>
    </div>
  </div>
);

export default memo(FlowGridFooter);
