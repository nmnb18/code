import React, { useEffect, useRef } from 'react';
import { useClickOutside } from '~hooks';

const ClickOutsideWrapper = ({ children, open, closeCallback }) => {
  const myRef = useRef();
  const [isOpen, setIsOpen] = useClickOutside(myRef);

  useEffect(() => {
    setIsOpen(open);
  }, [open, setIsOpen]);

  useEffect(() => {
    if (!isOpen) {
      closeCallback && closeCallback();
    }
  }, [isOpen, closeCallback]);

  return <div ref={myRef}>{isOpen && children}</div>;
};

export default ClickOutsideWrapper;
