// @External Dependencies
import React, { memo } from 'react';
import PropTypes from 'prop-types';
import styles from './NoAccess.module.scss';

// @Component
const NoAccess = ({ title, description, contact, subject }) => {
  return (
    <div className={styles['no-access']}>
      <div className={styles['no-access__container']}>
        <span className={styles['no-access__icon']}>!</span>

        <div className={styles['no-access__message']}>
          <h3 className={styles['no-access__message__title']}>{title}</h3>
          <p className={styles['no-access__message__description']}>
            {`${description} `}
            <a href={`mailto:${contact}${subject}`}>{contact}</a>
          </p>
        </div>
      </div>
    </div>
  );
};

// @Proptypes
NoAccess.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  contact: PropTypes.string.isRequired
};

NoAccess.defaultProps = {
  title: 'Your are not entitled to the page that you are trying to access',
  description:
    'If you would like to request access or you feel you have received this message in error, please contact',
  contact: 'FI_Entitlements@jefferies.com',
  subject: '?subject=Entitlements Inquiry'
};

// @Export Component
export default memo(NoAccess);
