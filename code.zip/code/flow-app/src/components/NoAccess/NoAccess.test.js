import React from 'react';
import { render, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import NoAccess from './NoAccess';

// Unmount everything from the dom after each test
afterEach(cleanup);

describe('<NoAccess />', () => {
  test('renders NoAccess', () => {
    // Renders component
    const props = {
      title: 'No Access title',
      description: 'No Access description',
      contact: 'No Access contact'
    };
    render(<NoAccess {...props} />);
    const component = document.querySelector('.no-access');
    const icon = component.querySelector('.no-access__icon');
    const title = component.querySelector('.no-access__message__title');
    const description = component.querySelector('.no-access__message__description');
    const contact = component.querySelector('.no-access__message a');

    expect(component).toBeInTheDocument();
    expect(icon).toBeInTheDocument();
    expect(title).toBeInTheDocument();
    expect(description).toBeInTheDocument();
    expect(title).toHaveTextContent(props.title);
    expect(description).toHaveTextContent(props.description);
    expect(contact).toHaveTextContent(props.contact);
  });
});
