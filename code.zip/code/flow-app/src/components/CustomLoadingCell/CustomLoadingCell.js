import React, { Component } from 'react';
import styles from './CustomLoadingCell.module.scss';

export default class CustomLoadingCell extends Component {
  render() {
    return (
      <div className={styles['loader-block']}>
        <div className={styles['loader']}></div>
        <div className={styles['loadingText']}>Loading...</div>
      </div>
    );
  }
}
