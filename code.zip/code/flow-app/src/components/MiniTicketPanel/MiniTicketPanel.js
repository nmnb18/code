import React, { useEffect, useCallback, useReducer, useMemo } from 'react';
import styles from './MiniTicketPanel.module.scss';
import { RFQCardDetail } from '~components';
import * as bloombergService from '~services/bloombergService';
import { LEGNO, WS_COMMANDS } from '~helpers/jasperMessage';
import { defaultFlowBlotterMiniTicketPanelId } from '~helpers/jasperWebSocket';
import { formatDateOrTime, FORMATS } from '~helpers/rfqFormatters';
import { getRFQRowDetail } from '~helpers/rfq';
import { logger } from '~helpers/logger';
import { CustomFilterFactory, filterTypes } from '~patterns/factory-method/customFilter';
import { filter } from 'rxjs/operators';
import { flowBlotterAppId } from '~services/apiConfig';
import { recordTypes } from '~helpers/globals';
import { WS_FIELDS } from '~helpers/jasperMessage';
import { COLUMNS, TAG_STATUS } from '~helpers/columnStyles';
import { SORT_ASC } from '~helpers/sort';
import { defaultToggles } from '~helpers/toggles';
import { arrayFromIterator } from 'flow-navigator-shared/dist/array';
import { flowBlotterService } from '~services/flowBlotterService';
import { isPILRecord } from '~helpers/columnRenderer';
import { IconButton } from '~ui-library';
import { ReactComponent as CloseIcon } from '~assets/icon/nav/close.svg';

const statusObject = {};
Object.values(TAG_STATUS).forEach(item => {
  statusObject[item.value] = item.class;
});

/**
 * Apply class to mini-ticket status.
 * @param {string} statusstr The statusstr value
 * @returns {string} Returns a string to use as className.
 */
const getStatusClassname = statusstr => {
  const cleanedClass = statusstr.toLowerCase();
  let classname = 'mini-ticket-panel__status';
  if (statusObject[cleanedClass]) {
    classname = classname + `--${statusObject[cleanedClass]}`;
  }
  return classname;
};

const formatMainRFQRow = mainRFQRow => {
  if (!mainRFQRow) return null;

  const { clientname, countdown, rfqnlegs, code, bbgcustchatid, sowkey, statusstr } = mainRFQRow;
  const formattedCountdown = formatDateOrTime(countdown, FORMATS.countdown);

  return {
    clientname,
    countdown: formattedCountdown,
    rfqnlegs,
    code,
    bbgcustchatid,
    sowkey,
    statusstr
  };
};

const initialState = {
  mainRow: null,
  selectedRows: []
};

const SET_MINITICKET_DETAILS = 'SET_MINITICKET_DETAILS';

function reducer(state, action) {
  switch (action.type) {
    case SET_MINITICKET_DETAILS:
      return {
        ...state,
        mainRow: action.payload.mainRow,
        selectedRows: action.payload.selectedRows
      };
    default:
      return state;
  }
}

const miniTicketRequiredColumnsDefs = [
  'statusstr',
  'l1_rfqdealspread',
  'l2_rfqdealspread',
  'rfqdealspread',
  'rfqcoverprice',
  'l1_rfqcoverprice',
  'l2_rfqcoverprice',
  'rfqcoverspread',
  'l1_rfqcoverspread',
  'l2_rfqcoverspread',
  'l1_rfqdayssettl',
  'l2_rfqdayssettl'
].map(field => ({ field }));

const MiniTicketPanel = ({
  columnsDictionary,
  columnDefs,
  selectedRFQsSubject$,
  toggleMiniTicketPanel,
  handleBloombergCommand,
  showMiniTicketPanel,
  handleRequestData,
  closeConnection,
  subscriptionInstanceId,
  rfqRecordsMap
}) => {
  const [{ mainRow, selectedRows }, dispatch] = useReducer(reducer, initialState);

  const setMiniTicketDetails = useCallback(
    (_mainRow, _selectedRows) =>
      dispatch({
        type: SET_MINITICKET_DETAILS,
        payload: {
          mainRow: _mainRow,
          selectedRows: _selectedRows
        }
      }),
    [dispatch]
  );

  const updateMiniTicketDetails = useCallback(() => {
    const rfqRecordsArr = arrayFromIterator(rfqRecordsMap.values());
    setMiniTicketDetails(formatMainRFQRow(rfqRecordsArr[0]), rfqRecordsArr);
  }, [rfqRecordsMap, setMiniTicketDetails]);

  const wsMessageHandlers = useMemo(() => {
    const { GROUP_BEGIN, GROUP_END, NEW_MESSAGE_SOW, UPDATE_MESSAGE, NEW_MESSAGE } = WS_COMMANDS;
    return {
      [GROUP_BEGIN]: () => {
        rfqRecordsMap.clear();
      },
      [NEW_MESSAGE_SOW]: message => {
        rfqRecordsMap.set(message.rowIndex, message);
      },
      [GROUP_END]: () => {
        updateMiniTicketDetails();
      },
      [NEW_MESSAGE]: message => {
        rfqRecordsMap.set(message.rowIndex, message);
        updateMiniTicketDetails();
      },
      [UPDATE_MESSAGE]: message => {
        const { rowIndex } = message;
        const oldRecord = rfqRecordsMap.get(rowIndex);
        rfqRecordsMap.set(rowIndex, { ...oldRecord, ...message });
        updateMiniTicketDetails();
      }
    };
  }, [rfqRecordsMap, updateMiniTicketDetails]);

  useEffect(() => {
    const dataSourceSubscription = flowBlotterService.datasource
      .pipe(filter(message => message.source === subscriptionInstanceId))
      .subscribe(message => {
        if (!message) return;
        const { command } = message;
        wsMessageHandlers[command] && wsMessageHandlers[command](message);
      });

    return () => {
      dataSourceSubscription.unsubscribe();
    };
  }, [subscriptionInstanceId, wsMessageHandlers]);

  useEffect(() => {
    const rfqSubscription = selectedRFQsSubject$.subscribe(data => {
      if (!data) return;

      const { key_id_rfq_group, recordtype, mymarketidformatted } = data;
      if (!key_id_rfq_group) return;

      if (!showMiniTicketPanel) {
        toggleMiniTicketPanel();
      } else {
        closeConnection(subscriptionInstanceId);
      }
      const filterFactory = new CustomFilterFactory();

      const keyIdRfqGroupFilter = filterFactory.createFilter(filterTypes.TextFilter, {
        field: WS_FIELDS.KEY_ID_RFQ_GROUP,
        headerName: WS_FIELDS.KEY_ID_RFQ_GROUP,
        filter: [key_id_rfq_group, '']
      });

      const recordTypeFilterValue = isPILRecord({ recordtype, mymarketidformatted })
        ? recordTypes.INQUIRY
        : recordTypes.RFQ;
      const recordTypeFilter = filterFactory.createFilter(filterTypes.SetFilter, {
        field: COLUMNS.SOURCE,
        headerName: WS_FIELDS.SOURCE,
        filter: [recordTypeFilterValue]
      });

      const customFilterList = [keyIdRfqGroupFilter, recordTypeFilter];
      const customSortList = [{ colId: WS_FIELDS.LEGNO, sort: SORT_ASC }];

      handleRequestData({
        subscriptionInstanceId,
        columnDefs: [...columnDefs, ...miniTicketRequiredColumnsDefs],
        firstRow: 0,
        lastRow: 2,
        newCriteria: true,
        gridId: defaultFlowBlotterMiniTicketPanelId,
        appName: flowBlotterAppId,
        customFilterList,
        customSortList,
        customToggles: defaultToggles
      });
    });
    return () => {
      rfqSubscription.unsubscribe();
    };
  }, [
    selectedRFQsSubject$,
    handleRequestData,
    showMiniTicketPanel,
    columnDefs,
    closeConnection,
    subscriptionInstanceId,
    toggleMiniTicketPanel
  ]);

  const handleClose = () => {
    logger.log('user clicked close (x) from within mini ticket panel');
    closeConnection(subscriptionInstanceId);
    toggleMiniTicketPanel();
  };

  const getRFQData = () => {
    const { rfqnlegs, bbgcustchatid, code } = mainRow;
    const leg1 = getRFQRowDetail(selectedRows, LEGNO.L1);
    const leg2 = getRFQRowDetail(selectedRows, LEGNO.L2);

    return {
      l1_code: leg1?.code,
      l2_code: leg2?.code,
      rfqnlegs,
      bbgcustchatid: bbgcustchatid,
      code_main_value: code,
      code: code
    };
  };

  const ibChatOnClickHandler = event => {
    event.preventDefault();
    handleBloombergCommand(
      getRFQData(),
      bloombergService.IBCHAT_COMMAND.label,
      bloombergService.IBCHAT_COMMAND.command
    );
  };

  const bloombergOnClickHandler = (command, event) => {
    event.preventDefault();
    handleBloombergCommand(getRFQData(), command);
  };

  const renderBloombergButtons = () => (
    <div className={styles['mini-ticket-panel__bloomberg']}>
      {mainRow && <button onClick={ibChatOnClickHandler}>{bloombergService.IBCHAT_COMMAND.label}</button>}
      {mainRow &&
        Object.values(bloombergService.DATA_COMMANDS)
          .filter(({ legs }) => legs === mainRow?.rfqnlegs?.toString())
          .map(({ command }) => (
            <button key={command} onClick={bloombergOnClickHandler.bind(null, command)}>
              {command}
            </button>
          ))}
    </div>
  );

  const renderClientName = () => (
    <div>
      <span className={`${styles['mini-ticket-panel__client__exp']} ibmmono`}>{mainRow?.countdown || '--:--'}</span>
      <span className={styles['mini-ticket-panel__client__name']}>{mainRow?.clientname || '----'}</span>
      {mainRow?.statusstr && <span className={styles[getStatusClassname(mainRow.statusstr)]}>{mainRow.statusstr}</span>}
    </div>
  );

  return (
    <div
      className={`${styles['mini-ticket-panel']} ${!showMiniTicketPanel ? styles['mini-ticket-panel__hidden'] : ''}`}
    >
      <header className={styles['mini-ticket-panel__topbar']}>
        <h3>
          <span>RFQ Mini Tickets</span>
        </h3>
        <div className={styles['mini-ticket-panel__actions']}>
          <IconButton handleClick={handleClose} title="Close">
            <CloseIcon />
          </IconButton>
        </div>
      </header>
      <section className={styles['mini-ticket-panel__client']}>
        <header>
          <div className={styles['mini-ticket-panel__client-button']}>
            {renderClientName()}
            {renderBloombergButtons()}
          </div>
        </header>
        <div className={styles['mini-ticket-panel__cards']}>
          {selectedRows.map((row, index) => (
            <RFQCardDetail key={index} columnsDictionary={columnsDictionary} {...row} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default MiniTicketPanel;
