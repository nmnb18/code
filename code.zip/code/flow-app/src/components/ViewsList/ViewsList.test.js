import React from 'react';
import { render, cleanup, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import ViewsList from './ViewsList.js';
import { viewsMock } from '~mocks/viewsMock.json';

// Unmount everything from the dom after each test
afterEach(cleanup);

describe('<ViewsList />', () => {
  test('renders ViewsList', () => {
    // Renders component
    const { getByTestId } = render(<ViewsList />);
    const component = getByTestId('ViewsList');
    const chevronDownIcon = getByTestId('ChevrondownIcon');

    // Asserts
    expect(component).toBeInTheDocument();
    expect(chevronDownIcon).toBeInTheDocument();
  });

  test('click dropdown button to show views list', () => {
    const { getByTestId } = render(<ViewsList />);
    const component = getByTestId('ViewsList');
    const chevronDownIcon = getByTestId('ChevrondownIcon');

    fireEvent.click(chevronDownIcon);
    // Asserts
    expect(component).toBeInTheDocument();
    expect(chevronDownIcon).toBeInTheDocument();
    expect(getByTestId('ViewsSelector')).toBeInTheDocument();
  });
});
