import React from 'react';
import './style.scss';
import { ReactComponent as CheckDashIc } from '~assets/icon/util/dash.svg';

const CheckDashIcon = () => <CheckDashIc className={'icon-checkdash active'} />;

export default CheckDashIcon;
