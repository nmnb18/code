import React from 'react';
import styles from './TriangleIcon.module.scss';
import { ReactComponent as Triangle } from '~assets/icon/util/triangle-active.svg';

const TriangleIcon = ({ small, inverted = false }) => (
  <Triangle
    className={`${styles['triangle-icon']} 
        ${small ? styles['triangle-icon--small'] : ''} 
        ${inverted ? styles['triangle-icon--inverted'] : ''}`}
  />
);

export default TriangleIcon;
