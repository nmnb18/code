import React from 'react';
import './style.scss';
import { ReactComponent as CopyIc } from '../../../../assets/icon/util/clipboard.svg';

const CopyIcon = ({ active = false, disabled = false }) => {
  const iconClass = disabled ? 'icon-copy disabled' : active ? 'icon-copy active' : 'icon-excel';

  return <CopyIc className={iconClass} />;
};

export default CopyIcon;
