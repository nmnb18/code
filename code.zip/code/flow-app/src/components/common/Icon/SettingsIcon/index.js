import React from 'react';
import './styles.scss';
import { ReactComponent as Settings } from '~assets/icon/util/settings.svg';

const SettingsIcon = ({ onClick }) => (
  <Settings data-testid="SettingsIcon" onClick={onClick} className="settings-icon" />
);

export default SettingsIcon;
