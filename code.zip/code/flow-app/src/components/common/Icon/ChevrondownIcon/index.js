import React from 'react';
import './style.scss';
import { ReactComponent as ChevrondownIc } from '~assets/icon/nav/chevrondown.svg';

const ChevrondownIcon = ({ active = false, onClick = () => {} }) => (
  <ChevrondownIc
    data-testid="ChevrondownIcon"
    onClick={onClick}
    className={active ? 'icon-chevrondown active-chevrondown' : 'icon-chevrondown'}
  />
);

export default ChevrondownIcon;
