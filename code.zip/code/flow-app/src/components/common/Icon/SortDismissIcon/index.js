import React from 'react';
import './style.scss';
import { ReactComponent as SortDismissIc } from '~assets/icon/util/dismissSort.svg';

const SortDismissIcon = ({ active }) => (
  <SortDismissIc className={active ? 'icon-sort-dismiss active' : 'icon-sort-dismiss'} />
);

export default SortDismissIcon;
