import React from 'react';
import './style.scss';
import { ReactComponent as AddIc } from '~assets/icon/util/add.svg';

const AddIcon = ({ active }) => <AddIc className={active ? 'icon-add active' : 'icon-add-dismiss'} />;

export default AddIcon;
