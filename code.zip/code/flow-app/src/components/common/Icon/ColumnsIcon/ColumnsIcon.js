import React from 'react';
import styles from './ColumnsIcon.module.scss';
import { ReactComponent as ColumnsIc } from '~assets/icon/util/columns.svg';

const ColumnsIcon = ({ active }) => <ColumnsIc className={active ? styles['column'].active : styles['column']} />;
export default ColumnsIcon;
