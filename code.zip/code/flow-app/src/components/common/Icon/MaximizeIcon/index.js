import React from 'react';
import './style.scss';
import { ReactComponent as MaximizeIc } from '~assets/icon/nav/maximize.svg';

const MaximizeIcon = ({ active }) => <MaximizeIc className={active ? 'icon-maximize active' : 'icon-maximize'} />;

export default MaximizeIcon;
