import React from 'react';
import './style.scss';
import { ReactComponent as PriorityIc } from '~assets/icon/rating/priority-blotter.svg';

const PriorityIcon = ({ active }) => <PriorityIc className={active ? 'icon-priority active' : 'icon-priority'} />;

export default PriorityIcon;
