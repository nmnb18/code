import React from 'react';
import './style.scss';
import { ReactComponent as CloseIc } from '~assets/icon/nav/close.svg';

const CloseIcon = ({ active = false }) => <CloseIc className={active ? 'icon-close active' : 'icon-close'} />;

export default CloseIcon;
