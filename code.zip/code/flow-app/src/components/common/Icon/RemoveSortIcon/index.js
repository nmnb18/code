import React from 'react';
import './style.scss';
import { ReactComponent as SortDismissIc } from '~assets/icon/util/dismissSort.svg';

const RemoveSortIcon = () => <SortDismissIc className={'icon-remove-sort'} />;

export default RemoveSortIcon;
