import React from 'react';
import './style.scss';
import { ReactComponent as MinimizeIc } from '~assets/icon/nav/minimize.svg';

const MinimizeIcon = ({ active }) => <MinimizeIc className={active ? 'icon-minimize active' : 'icon-minimize'} />;

export default MinimizeIcon;
