import React from 'react';
import './style.scss';
import { ReactComponent as CheckActiveIc } from '~assets/icon/util/check-active.svg';

const CheckActiveIcon = () => <CheckActiveIc className={'icon-checkactive'} />;

export default CheckActiveIcon;
