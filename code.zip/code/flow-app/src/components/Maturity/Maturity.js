import React, { useState } from 'react';
import { format, addYears, formatDistanceStrict, compareAsc, isValid } from 'date-fns';
import {
  DATE_FORMAT,
  today,
  START_STRING,
  TWELVEMONTH_STRING,
  PLACEHOLDER_DATESTART,
  PLACEHOLDER_DATEEND,
  YEAR_STRING_LC,
  ONE_STRING,
  MIN_STRING_LC,
  MAX_STRING_LC,
  END_STRING
} from '~helpers/dateHelper';
import styles from './Maturity.module.scss';

const Maturity = ({ onFilterChange, sortingMenu }) => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [minYears, setMinYears] = useState('');
  const [maxYears, setMaxYears] = useState('');

  const handleDates = ({ date, type }) => {
    const alphabetRegExp = /[a-z]/gi;
    if (alphabetRegExp.test(date)) return false;

    if (!date) {
      type === START_STRING ? setStartDate('') : setEndDate('');
    }

    type === START_STRING ? setStartDate(date) : setEndDate(date);

    if (date.length === 10) {
      if (isValid(new Date(date))) {
        const dateDigits = date.replace(/[^0-9]/g, '');
        const [, month, day, year] = dateDigits.match(/(\d{2})-?(\d{2})-?(\d{4})/);
        const formattedDate = new Date(year, month - 1, day);

        const comparedDistance = formatDistanceStrict(formattedDate, today);
        const comparedDates = compareAsc(new Date(date), today);

        if (comparedDistance.includes(YEAR_STRING_LC) || comparedDistance === TWELVEMONTH_STRING) {
          const [years] =
            comparedDistance === TWELVEMONTH_STRING ? [ONE_STRING, YEAR_STRING_LC] : comparedDistance.split(' ');

          const result = years * comparedDates;
          type === START_STRING ? setMinYears(result) : setMaxYears(result);
        }
      } else {
        type === START_STRING ? setStartDate('') : setEndDate('');
      }
    } else {
      type === START_STRING ? setMinYears('') : setMaxYears('');
    }
  };

  const handleYears = ({ years, type }) => {
    if (!years) {
      if (type === MIN_STRING_LC) {
        setStartDate('');
        setMinYears('');
      } else {
        setEndDate('');
        setMaxYears('');
      }
    }

    if (years) {
      const yearsAdded = addYears(today, years);
      const formattedDate = format(yearsAdded, DATE_FORMAT);

      if (type === MIN_STRING_LC) {
        setMinYears(years);
        setStartDate(formattedDate);
      } else {
        setMaxYears(years);
        setEndDate(formattedDate);
      }
    }
  };

  // Function called when you click "Clear" button
  const handleClear = () => {
    setStartDate('');
    setEndDate('');
    setMinYears('');
    setMaxYears('');
    onFilterChange();
  };

  // Function called when you click "Apply" button
  const handleApply = () => {
    if (startDate !== '' && endDate !== '') {
      onFilterChange(startDate, endDate);
    }
  };

  return (
    <div className={styles.maturity}>
      {sortingMenu}
      <table>
        <tbody>
          <tr>
            <td></td>
            <td>Min</td>
            <td>Max</td>
          </tr>
          <tr>
            <td>Date</td>
            <td>
              <input
                maxLength="10"
                placeholder={PLACEHOLDER_DATESTART}
                onChange={e => handleDates({ date: e.target.value, type: START_STRING })}
                value={startDate}
              />
            </td>
            <td>
              <input
                maxLength="10"
                placeholder={PLACEHOLDER_DATEEND}
                onChange={e => handleDates({ date: e.target.value, type: END_STRING })}
                value={endDate}
              />
            </td>
          </tr>
          <tr>
            <td>Years</td>
            <td>
              <input
                placeholder="1"
                onChange={e => handleYears({ years: e.target.value, type: MIN_STRING_LC })}
                value={minYears}
                type="number"
              />
            </td>
            <td>
              <input
                placeholder="5"
                onChange={e => handleYears({ years: e.target.value, type: MAX_STRING_LC })}
                value={maxYears}
                type="number"
              />
            </td>
          </tr>
        </tbody>
      </table>
      <footer className={styles['maturity__footer']}>
        <button onClick={handleClear}>Clear</button>
        <button onClick={handleApply}>Apply</button>
      </footer>
    </div>
  );
};

export default Maturity;
