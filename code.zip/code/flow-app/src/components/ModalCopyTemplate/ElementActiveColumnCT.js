import React, { Component } from 'react';
import { Draggable } from 'react-beautiful-dnd';
import { formatColumnName } from '~helpers/columnPicker';
import { CloseIcon } from '~common';
import styles from './ModalCopyTemplate.module.scss';

export default class ElementActiveColumn extends Component {
  render() {
    const { column, index, handleClickRemoveButton } = this.props;

    return (
      <Draggable draggableId={`key_col_copytemp_active_drag_${index}`} index={index}>
        {provided => (
          <div
            className={styles['copytemplate-modal__row-active']}
            {...provided.draggableProps}
            {...provided.dragHandleProps}
            ref={provided.innerRef}
          >
            <div title={column.displayname}>{formatColumnName(column.displayname)}</div>
            <div onClick={() => handleClickRemoveButton(column)}>
              <CloseIcon />
            </div>
          </div>
        )}
      </Draggable>
    );
  }
}
