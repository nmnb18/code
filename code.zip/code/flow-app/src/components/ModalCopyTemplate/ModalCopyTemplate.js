import React, { Component } from 'react';
import styles from './ModalCopyTemplate.module.scss';
import { filterColumnListForChooser, addRowOnActiveColumns, formatColumnName } from '~helpers/columnPicker';
import { DragDropContext, Droppable } from 'react-beautiful-dnd';
import ElementActiveColumnCT from './ElementActiveColumnCT';
import { FLOW_APP_NAME, copyTemplateRedMessages } from '~helpers/globals';
import * as settingsService from '~services/settingsService';
import { KEYS } from '~helpers/keyCodes';
import OverModal from './OverModal';
import { IconButton } from '~ui-library';
import { ReactComponent as AddIcon } from '~assets/icon/util/add.svg';
import { ReactComponent as CloseIcon } from '~assets/icon/nav/close.svg';
import { ReactComponent as ChevrondownIcon } from '~assets/icon/nav/chevrondown.svg';
import { copyActions } from '~helpers/actionCreator';

class ModalCopyTemplate extends Component {
  constructor(props) {
    super(props);
    this.selfRef = React.createRef();
    this.selectRef = React.createRef();
  }

  state = {
    inputDefaultIsChecked: false,
    newTemplateMode: false,
    errorNameExists: false,
    finalCopyTempActiveColumns: [],
    finalCopyTempAvaliableColumns: [],
    defaultCopyTemplateName: '',
    typedCopyTemplateName: '',
    copyTemplateList: [],
    currentCopyTemplate: null,
    saveButtonEnabled: true,
    showOverModalDelete: false,
    showOverModalClose: false,
    thereIsAnyChange: false,
    redMessageText: '',
    flowApp: {},
    isSavingTemplate: false,
    isDeletingTemplate: false
  };

  componentDidMount() {
    this.initializeData();
    this.selfRef.current.focus();
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.evalRedMessage(prevState)) {
      this.conditionalRedMessage();
    }
  }

  handleChangeDropDownList = event => {
    this.props.setSelectedInDDLCopyTemplateName(event.target.value);

    const { userSettings, columnsDictionary, isTech } = this.props;

    const copyTemplateList = settingsService.getCopyTemplatesList(userSettings, FLOW_APP_NAME);
    const selectedCopyTemplate =
      event.target.value &&
      copyTemplateList &&
      copyTemplateList.find(copyTemplate => copyTemplate.CopyTemplateName === event.target.value);
    copyTemplateList && this.setCopyTemplateList(copyTemplateList);
    selectedCopyTemplate && this.setCopyTemplate(selectedCopyTemplate);

    const defaultCopyTempName = settingsService.getDefaultCopyTemplateName(userSettings, FLOW_APP_NAME);

    const columnListForChooser = filterColumnListForChooser(
      columnsDictionary.sourceColumnNames,
      selectedCopyTemplate.Columns,
      isTech
    );

    this.setState({
      finalCopyTempActiveColumns: selectedCopyTemplate.Columns,
      finalCopyTempAvaliableColumns: columnListForChooser,
      defaultCopyTemplateName: defaultCopyTempName,
      thereIsAnyChange: false,
      inputDefaultIsChecked: defaultCopyTempName === event.target.value
    });
  };

  handleClickNewTemplate = () => {
    this.setState({
      newTemplateMode: true,
      inputDefaultIsChecked: false
    });
  };

  handleChangeTxtCopyTemplateName = event => {
    this.setState(
      { typedCopyTemplateName: event.target.value, thereIsAnyChange: event.target.value.length > 0 },
      () => {
        this.checkCopyTemplateNameAvailability(this.state.typedCopyTemplateName);
      }
    );
  };

  checkCopyTemplateNameAvailability = ctname => {
    const { copyTemplateList } = this.state;
    const selectedCopyTemplate =
      copyTemplateList && copyTemplateList.filter(copyTemplate => copyTemplate.CopyTemplateName === ctname);
    this.setState({
      errorNameExists: selectedCopyTemplate.length > 0
    });
  };

  onDragEnd = result => {
    const { finalCopyTempActiveColumns } = this.state;
    const { destination, source } = result;

    if (!destination) return;
    if (destination.droppableId === source.droppableId && destination.index === source.index) return;

    const newFinalActiveColumns = Array.from(finalCopyTempActiveColumns);
    const columnBackup = finalCopyTempActiveColumns[source.index];
    newFinalActiveColumns.splice(source.index, 1);
    newFinalActiveColumns.splice(destination.index, 0, columnBackup);

    this.setState({
      finalCopyTempActiveColumns: newFinalActiveColumns,
      thereIsAnyChange: true
    });
  };

  handleClickAddButton = selectedColumn => {
    const { finalCopyTempAvaliableColumns, finalCopyTempActiveColumns } = this.state;

    const newFinalActiveColumns = [...finalCopyTempActiveColumns];
    newFinalActiveColumns.push(addRowOnActiveColumns(selectedColumn));

    this.setState({
      finalCopyTempActiveColumns: newFinalActiveColumns,
      finalCopyTempAvaliableColumns: finalCopyTempAvaliableColumns.filter(column => column !== selectedColumn),
      thereIsAnyChange: true
    });
  };

  handleClickRemoveButton = selectedColumn => {
    const { finalCopyTempAvaliableColumns, finalCopyTempActiveColumns } = this.state;
    const { columnsDictionary } = this.props;

    const activeColumnToAdd = columnsDictionary.sourceColumnNames.filter(
      column => column.sourcecolumnname === selectedColumn.colId
    );

    const newFinalAvaliableColumns = [...finalCopyTempAvaliableColumns];
    newFinalAvaliableColumns.push(activeColumnToAdd[0]);

    this.setState({
      finalCopyTempActiveColumns: finalCopyTempActiveColumns.filter(column => column !== selectedColumn),
      finalCopyTempAvaliableColumns: newFinalAvaliableColumns,
      thereIsAnyChange: true
    });
  };

  handleClickOpenOverModalDeleteCopyTemp = () => {
    const { showOverModalDelete } = this.state;
    this.setState({
      showOverModalDelete: !showOverModalDelete
    });
    this.selfRef.current.focus();
  };

  handleClickOpenOverModalCloseCopyTemp = () => {
    const { showOverModalClose } = this.state;
    this.setState({
      showOverModalClose: !showOverModalClose
    });
    this.selfRef.current.focus();
  };

  handleClickCancelButton = () => {
    const { newTemplateMode } = this.state;
    if (newTemplateMode) {
      this.setState({
        newTemplateMode: false
      });
      //TODO: RESTORE DEFAULT CHECK
    } else {
      this.props.handleClickOpenModalCopyTemplate(false);
    }
  };

  handleSave = () => {
    this.setState({ isSavingTemplate: true }, () => {
      const { finalCopyTempActiveColumns, inputDefaultIsChecked } = this.state;
      const { selectedInDDLCopyTemplateName } = this.props;
      const activeColumns = this.cleanFinalActiveColumnForSaving(finalCopyTempActiveColumns);

      copyActions.update({ activeColumns, inputDefaultIsChecked, selectedInDDLCopyTemplateName });
    });
  };

  handleSaveNew = () => {
    this.setState({ isSavingTemplate: true }, () => {
      const { inputDefaultIsChecked, finalCopyTempActiveColumns, typedCopyTemplateName } = this.state;
      const activeColumns = this.cleanFinalActiveColumnForSaving(finalCopyTempActiveColumns);
      copyActions.create({ inputDefaultIsChecked, typedCopyTemplateName, activeColumns });
    });
  };

  handleClickDeleteTemplate = () => {
    this.setState({ isDeletingTemplate: true }, () => {
      const { inputDefaultIsChecked } = this.state;
      const { selectedInDDLCopyTemplateName } = this.props;
      copyActions.delete({ inputDefaultIsChecked, selectedInDDLCopyTemplateName });
    });
  };

  handleClickCloseButtonCopyTemplate = () => {
    const { thereIsAnyChange } = this.state;
    const { handleClickOpenModalCopyTemplate } = this.props;

    if (thereIsAnyChange) {
      this.handleClickOpenOverModalCloseCopyTemp();
    } else {
      handleClickOpenModalCopyTemplate(false);
    }
  };

  handleClickDiscardChangesCopyTemplate = () => {
    this.props.handleClickOpenModalCopyTemplate('reload');
  };

  setCopyTemplateList = copyTemplateList => this.setState({ copyTemplateList: copyTemplateList });

  setCopyTemplate = copyTemplate => this.setState({ currentCopyTemplate: copyTemplate });

  initializeData = () => {
    const { userSettings, columnsDictionary, isTech, selectedInDDLCopyTemplateName } = this.props;
    const flowApp = userSettings.Applications.find(app => app.AppName === FLOW_APP_NAME);

    if (userSettings) {
      const copyTemplateList = settingsService.getCopyTemplatesList(userSettings, FLOW_APP_NAME);
      const selectedCopyTemplate =
        selectedInDDLCopyTemplateName &&
        copyTemplateList &&
        copyTemplateList.find(copyTemplate => copyTemplate.CopyTemplateName === selectedInDDLCopyTemplateName);
      copyTemplateList && this.setCopyTemplateList(copyTemplateList);
      selectedCopyTemplate && this.setCopyTemplate(selectedCopyTemplate);

      const defaultCopyTempName = settingsService.getDefaultCopyTemplateName(userSettings, FLOW_APP_NAME);

      const columnListForChooser = filterColumnListForChooser(
        columnsDictionary.sourceColumnNames,
        selectedCopyTemplate.Columns,
        isTech
      );

      this.setState({
        finalCopyTempActiveColumns: selectedCopyTemplate.Columns,
        finalCopyTempAvaliableColumns: columnListForChooser,
        defaultCopyTemplateName: defaultCopyTempName,
        inputDefaultIsChecked: defaultCopyTempName === selectedInDDLCopyTemplateName,
        flowApp
      });
    }
  };

  cleanFinalActiveColumnForSaving = activeColumns =>
    activeColumns.map(col => {
      return {
        colId: col.colId,
        displayname: col.displayname
      };
    });

  evalRedMessage = prevState => {
    const {
      newTemplateMode,
      typedCopyTemplateName,
      errorNameExists,
      finalCopyTempActiveColumns,
      finalCopyTempAvaliableColumns
    } = this.state;

    if (
      prevState.typedCopyTemplateName.length !== typedCopyTemplateName.length ||
      prevState.errorNameExists !== errorNameExists ||
      prevState.newTemplateMode !== newTemplateMode ||
      prevState.finalCopyTempActiveColumns.length !== finalCopyTempActiveColumns.length ||
      prevState.finalCopyTempAvaliableColumns.length !== finalCopyTempAvaliableColumns.length
    ) {
      return true;
    }
    return false;
  };

  conditionalRedMessage = () => {
    const {
      newTemplateMode,
      typedCopyTemplateName,
      errorNameExists,
      finalCopyTempActiveColumns,
      saveButtonEnabled
    } = this.state;

    if (newTemplateMode && typedCopyTemplateName.length === 0 && !errorNameExists) {
      if (saveButtonEnabled) {
        this.setState({ saveButtonEnabled: false });
      }
      this.setState({
        redMessageText: copyTemplateRedMessages.ENTER_NEW_NAME
      });
      return;
    }

    if (errorNameExists) {
      if (saveButtonEnabled) {
        this.setState({ saveButtonEnabled: false });
      }
      this.setState({
        redMessageText: copyTemplateRedMessages.NAME_EXISTS
      });
      return;
    }

    if (finalCopyTempActiveColumns.length === 0) {
      if (saveButtonEnabled) {
        this.setState({
          saveButtonEnabled: false
        });
      }
      this.setState({
        redMessageText: copyTemplateRedMessages.MINIMIUM_OF_ONE_COLUMN
      });
      return;
    }

    if (!saveButtonEnabled) {
      this.setState({ saveButtonEnabled: true });
    }
    this.setState({
      redMessageText: copyTemplateRedMessages.BLANK
    });
    return;
  };

  handleKeyPress = event => {
    const { keyCode } = event;
    const { ENTER, ESC, UP, DOWN } = KEYS;

    event.stopPropagation();
    if (keyCode === ENTER) {
      event.preventDefault();
      this.state.newTemplateMode ? this.handleSaveNew() : this.handleSave();
    } else if (keyCode === ESC) {
      event.preventDefault();
      this.handleClickCloseButtonCopyTemplate();
    } else if (keyCode === UP || keyCode === DOWN) {
      this.selectRef.current.focus();
    }
  };

  renderTemplateSelector = () => {
    const { selectedInDDLCopyTemplateName } = this.props;
    const { copyTemplateList } = this.state;

    return (
      <>
        <div className={styles['copytemplate-modal__dropdown__wrapper']}>
          <select
            className={styles['copytemplate-modal__dropdown']}
            onChange={this.handleChangeDropDownList}
            value={selectedInDDLCopyTemplateName}
            tabIndex="1"
            ref={this.selectRef}
          >
            {copyTemplateList.length > 0 &&
              copyTemplateList.map((copyTemplate, index) => (
                <option
                  key={`key_copytempalte_option_${copyTemplate.CopyTemplateName}_${index}`}
                  className={styles['copytemplate-modal__option']}
                  value={copyTemplate.CopyTemplateName}
                >
                  {formatColumnName(copyTemplate.CopyTemplateName, 9)}
                </option>
              ))}
          </select>
          <ChevrondownIcon />
        </div>
        <div className={styles['copytemplate-modal__add-icon']}>
          <IconButton handleClick={this.handleClickNewTemplate} title="Add Column">
            <AddIcon />
          </IconButton>
        </div>
      </>
    );
  };

  renderNewTemplateNameInput = () => {
    const { typedCopyTemplateName } = this.state;

    return (
      <input
        type="text"
        placeholder="Enter Name..."
        autoFocus={true}
        className={styles['copytemplate-modal__textbox']}
        id="txtModalCopyTemplate_CopyTemplateName"
        autoComplete="false"
        onChange={e => this.handleChangeTxtCopyTemplateName(e)}
        value={typedCopyTemplateName}
      />
    );
  };

  renderSetDefaultCheckbox = () => {
    const { inputDefaultIsChecked } = this.state;

    return (
      <label className={styles['copy-template-checkbox-container']}>
        Set Default
        <input
          type="checkbox"
          onChange={() => this.setState({ inputDefaultIsChecked: !inputDefaultIsChecked })}
          checked={inputDefaultIsChecked}
        />
        <span className={styles['copy-template-checkbox-checkmark']} />
      </label>
    );
  };

  renderBodyHeader = () => {
    const { redMessageText, newTemplateMode } = this.state;
    //TODO: refactor this layout
    return (
      <div className={styles['copytemplate-modal__body-header']}>
        <div className={styles['copytemplate-modal__body-header__cols']}>
          <div className={styles['copytemplate-modal__body-header__cols__col']}>
            <div className={styles['copytemplate-modal__body-header__rows']}>
              <span className={styles['copytemplate-modal__title']}>Template Name</span>
            </div>
            <div className={styles['copytemplate-modal__body-header__rows']}>
              {newTemplateMode ? this.renderNewTemplateNameInput() : this.renderTemplateSelector()}
            </div>
            <div className={styles['copytemplate-modal__body-header__rows']}>{this.renderSetDefaultCheckbox()}</div>
          </div>
          <div className={styles['copytemplate-modal__body-header__cols__col']}>
            <div className={styles['copytemplate-modal__body-header__rows']} />
            <div className={styles['copytemplate-modal__body-header__rows']}>
              <span className={styles['copytemplate-modal__red-text']}>{redMessageText}</span>
            </div>
            <div className={styles['copytemplate-modal__body-header__rows']} />
          </div>
        </div>
      </div>
    );
  };

  renderFooter = () => {
    const { newTemplateMode, copyTemplateList, isDeletingTemplate, isSavingTemplate, saveButtonEnabled } = this.state;

    return (
      <div className={styles['copytemplate-modal__footer']}>
        <div className={styles['copytemplate-modal__cols__buttons']}>
          {!newTemplateMode && (
            <button
              className={styles['copytemplate-modal__button-delete']}
              onClick={this.handleClickOpenOverModalDeleteCopyTemp}
              disabled={copyTemplateList.length === 1 || isDeletingTemplate}
            >
              Delete
            </button>
          )}
        </div>
        <div className={styles['copytemplate-modal__cols__buttons']}>
          <button className={styles['copytemplate-modal__button-cancel']} onClick={this.handleClickCancelButton}>
            Cancel
          </button>
          <button
            className={styles['copytemplate-modal__button-save']}
            disabled={!saveButtonEnabled || isSavingTemplate}
            onClick={newTemplateMode ? this.handleSaveNew : this.handleSave}
          >
            {isSavingTemplate ? 'Saving...' : 'Save'}
          </button>
        </div>
      </div>
    );
  };

  renderAvailableColumns = () => {
    const { finalCopyTempAvaliableColumns } = this.state;

    return (
      <div className={styles['copytemplate-modal__cols']}>
        <div className={styles['copytemplate-modal__cols__space']}>
          {finalCopyTempAvaliableColumns &&
            finalCopyTempAvaliableColumns.map((column, index) => (
              <div
                key={`key_copytemplate_aval_${column}_${index}`}
                className={styles['copytemplate-modal__row-avaliable']}
              >
                <div title={column.displayname}>{formatColumnName(column.displayname)}</div>

                <IconButton
                  handleClick={() => this.handleClickAddButton(column)}
                  title="Close"
                  colorScheme="transparent"
                >
                  <AddIcon />
                </IconButton>
              </div>
            ))}
        </div>
      </div>
    );
  };

  renderActiveColumns = () => {
    const { finalCopyTempActiveColumns } = this.state;

    return (
      <DragDropContext onDragEnd={this.onDragEnd}>
        <div className={styles['copytemplate-modal__cols']}>
          <Droppable droppableId="copytemplate">
            {provided => (
              <div
                ref={provided.innerRef}
                className={styles['copytemplate-modal__cols__space']}
                {...provided.droppableProps}
              >
                {finalCopyTempActiveColumns &&
                  finalCopyTempActiveColumns.map((column, index) => (
                    <ElementActiveColumnCT
                      key={`key_col_copytemp_active_${index}`}
                      column={column}
                      index={index}
                      handleClickRemoveButton={this.handleClickRemoveButton}
                    />
                  ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </div>
      </DragDropContext>
    );
  };

  renderBodyColumns = () => (
    <>
      <div className={styles['copytemplate-modal__body-body']}>
        <div className={styles['copytemplate-modal__cols']}>Available Columns</div>
        <div className={styles['copytemplate-modal__cols']}>Active Columns</div>
      </div>
      <div className={styles['copytemplate-modal__body-body']}>
        {this.renderAvailableColumns()}
        {this.renderActiveColumns()}
      </div>
    </>
  );

  renderBody = () => (
    <div className={styles['copytemplate-modal__body']}>
      {this.renderBodyHeader()}
      {this.renderBodyColumns()}
    </div>
  );

  getOverModalProps = type =>
    ({
      close: {
        primaryButtonConfig: {
          onClickHandler: this.props.handleClickOpenModalCopyTemplate.bind(null, false),
          text: 'Discard Changes',
          classModifier: 'delete'
        },
        secondaryButtonConfig: {
          onClickHandler: this.handleClickOpenOverModalCloseCopyTemp,
          text: 'Cancel',
          classModifier: 'cancel'
        },
        children: (
          <>
            Changes were made. <br /> Save before closing?
          </>
        )
      },
      delete: {
        primaryButtonConfig: {
          onClickHandler: this.handleClickDeleteTemplate,
          disabled: this.state.isDeletingTemplate,
          text: 'Delete',
          disabledText: 'Deleting...',
          classModifier: 'delete'
        },
        secondaryButtonConfig: {
          onClickHandler: this.handleClickOpenOverModalDeleteCopyTemp.bind(null, false),
          text: 'Cancel',
          classModifier: 'cancel'
        },
        children: (
          <>
            You are about to delete a template.
            <br /> Please confirm action.
          </>
        )
      }
    }[type]);

  renderOverModal = () => {
    const { showOverModalClose, showOverModalDelete } = this.state;
    const type = showOverModalClose ? 'close' : showOverModalDelete ? 'delete' : '';

    return type ? <OverModal {...this.getOverModalProps(type)} /> : null;
  };

  renderHeader = () => {
    const { newTemplateMode } = this.state;

    return (
      <header className={styles['copytemplate-modal__header']}>
        <span>Template Settings {newTemplateMode ? '- New' : ''}</span>
        <div className={styles['copytemplate-modal__actions']}>
          <IconButton handleClick={this.handleClickCloseButtonCopyTemplate} title="Close" size="custom">
            <CloseIcon />
          </IconButton>
        </div>
      </header>
    );
  };

  render() {
    return (
      <div onKeyDown={this.handleKeyPress} tabIndex="1" ref={this.selfRef}>
        <div data-testid="ModalCopyTemplate" className={styles['copytemplate-modal__display']}>
          <div className={styles['copytemplate-modal']}>
            {this.renderHeader()}
            {this.renderBody()}
            {this.renderFooter()}
          </div>
        </div>
        {this.renderOverModal()}
      </div>
    );
  }
}

export default ModalCopyTemplate;
