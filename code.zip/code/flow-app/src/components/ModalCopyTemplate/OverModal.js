import React, { useEffect, useRef } from 'react';
import styles from './ModalCopyTemplate.module.scss';
import { KEYS } from '~helpers/keyCodes';

//TODO: convert this component into an independent one (ConfirmationDialog); the fullscreen background should be optional and controlled by prop
const OverModal = ({ children, primaryButtonConfig, secondaryButtonConfig }) => {
  const selfRef = useRef(null);
  useEffect(() => {
    selfRef.current.focus();
  }, []);

  const renderButton = ({ onClickHandler, classModifier, disabled = false, text, disabledText }) => (
    <div className={styles['copytemplate-modal__cols__buttons']}>
      <button className={styles['copytemplate-modal__button-' + classModifier]} onClick={onClickHandler}>
        {disabled ? disabledText : text}
      </button>
    </div>
  );

  const handleKeyPress = event => {
    event.preventDefault();
    event.stopPropagation();
    if (event.keyCode === KEYS.ENTER) {
      primaryButtonConfig.onClickHandler();
    } else if (event.keyCode === KEYS.ESC) {
      secondaryButtonConfig.onClickHandler();
    }
  };

  return (
    <>
      <div className={styles['copytemplate-overmodal']} onKeyDown={handleKeyPress} tabIndex="1" ref={selfRef}>
        <div className={styles['copytemplate-overmodal__body']}>{children}</div>
        <div className={styles['copytemplate-modal__footer']}>
          {renderButton(secondaryButtonConfig)}
          {renderButton(primaryButtonConfig)}
        </div>
      </div>
      <div className="modal-full-blackout" onClick={secondaryButtonConfig.onClickHandler} />
    </>
  );
};

export default OverModal;
