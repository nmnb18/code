import React, { Component } from 'react';
import { DragDropContext, Droppable } from 'react-beautiful-dnd';
import { FLOW_APP_NAME } from '~helpers/globals';
import * as settingsService from '~services/settingsService';
import {
  filterColumnListForChooser,
  filterColumnListForActive,
  upgradeColumnState,
  addRowOnActiveColumns,
  formatColumnName
} from '~helpers/columnPicker';
import styles from './ModalColumnPicker.module.scss';
import ModalSaveView from '../ModalSaveView/ModalSaveView';
import ElementActiveColumn from './ElementActiveColumn';
import {
  ACTION_VIEW_ADD_COLUMN,
  ACTION_VIEW_REMOVE_COLUMN,
  ACTION_VIEW_PIN_COLUMN,
  ACTION_VIEW_UNPIN_COLUMN
} from '~services/usageService';
import { KEYS } from '~helpers/keyCodes';
import { IconButton } from '~ui-library';
import { ReactComponent as AddIcon } from '~assets/icon/util/add.svg';
import { ReactComponent as CloseIcon } from '~assets/icon/nav/close.svg';
import { viewsActions } from '~helpers/actionCreator';

const COLUMN_PICKER_PINNED = 'columnpicker_pinned';
const COLUMN_PICKER_AVALIABLE = 'columnpicker_avaliable';
const PINNED_LEFT_STRING = 'left';

class ModalColumnPicker extends Component {
  constructor(props) {
    super(props);
    this.selfRef = React.createRef();
  }
  state = {
    showModalConfirmation: false,
    finalAvaliableColumns: [],
    finalActiveColumns: [],
    finalPinnedColumns: [],
    finalColumnOrder: null,
    flowApp: {},
    usageNotes: [],
    isApplyingColumnChange: false
  };

  componentDidMount() {
    const { userSettings, columnsDictionary, columnState, isTech } = this.props;
    const flowApp = userSettings.Applications.find(app => app.AppName === FLOW_APP_NAME);

    const upgradedColumnStateList = filterColumnListForActive(upgradeColumnState(columnsDictionary, columnState));
    const columnListForChooser = filterColumnListForChooser(
      columnsDictionary.sourceColumnNames,
      upgradedColumnStateList,
      isTech
    );

    this.setState({
      finalAvaliableColumns: columnListForChooser,
      finalActiveColumns: upgradedColumnStateList.filter(column => column.pinned === null),
      finalPinnedColumns: upgradedColumnStateList.filter(column => column.pinned === PINNED_LEFT_STRING),
      flowApp: flowApp
    });

    this.selfRef.current.focus();
  }

  componentDidUpdate(prevProps) {
    const { showModalSaveViewOverModal } = this.props;

    if (prevProps.showModalSaveViewOverModal && !showModalSaveViewOverModal) {
      this.selfRef.current.focus();
    }
  }

  createResultView = () => {
    const { currentView, filterList } = this.props;
    const { finalActiveColumns, finalPinnedColumns } = this.state;
    const combinedActivePinnedColumns = [...finalPinnedColumns, ...finalActiveColumns];
    const finalColumnOrder = combinedActivePinnedColumns.map(({ colId, width, referenceKey }) => ({
      colId,
      actualWidth: width,
      referenceKey
    }));

    this.setState({
      finalColumnOrder: finalColumnOrder
    });
    const resultView = settingsService.getNewView(
      currentView,
      finalColumnOrder,
      filterList,
      combinedActivePinnedColumns
    );

    return resultView;
  };

  handleSave = () => {
    const { flowApp, usageNotes, isApplyingColumnChange } = this.state;
    const { currentView, handleClickOpenModalSaveViewOverModal } = this.props;

    const viewIndex = flowApp.Views.findIndex(view => view.ViewName === currentView);
    const resultView = this.createResultView();

    if (flowApp.Views[viewIndex] && flowApp.Views[viewIndex].ReadOnly === 'true') {
      handleClickOpenModalSaveViewOverModal(false);
    } else {
      this.setState({ isApplyingColumnChange: !isApplyingColumnChange });

      viewsActions.editColumns({
        currentView,
        resultView,
        usageNotes
      });
    }
  };

  onDragEnd = result => {
    const { destination, source } = result;

    if (!destination) return;

    if (destination.droppableId === source.droppableId && destination.index === source.index) return;

    //Source: Pinned | Destination: Pinned
    if (source.droppableId === COLUMN_PICKER_PINNED && destination.droppableId === COLUMN_PICKER_PINNED) {
      this.processDragDropSameOriginDestination(source, destination);
    }

    //Source: Pinned | Destination: Avaliable
    if (source.droppableId === COLUMN_PICKER_PINNED && destination.droppableId === COLUMN_PICKER_AVALIABLE) {
      this.processDragDropDifferentOriginDestination(source, destination);
    }

    //Source: Avaliable | Destination: Pinned
    if (source.droppableId === COLUMN_PICKER_AVALIABLE && destination.droppableId === COLUMN_PICKER_PINNED) {
      this.processDragDropDifferentOriginDestination(source, destination);
    }

    //Source: Avaliable | Destination: Avaliable
    if (source.droppableId === COLUMN_PICKER_AVALIABLE && destination.droppableId === COLUMN_PICKER_AVALIABLE) {
      this.processDragDropSameOriginDestination(source, destination);
    }
  };

  processDragDropSameOriginDestination = (source, destination) => {
    const { finalActiveColumns, finalPinnedColumns } = this.state;

    const currentColumnToWorkOn =
      source.droppableId === COLUMN_PICKER_AVALIABLE ? finalActiveColumns : finalPinnedColumns;

    const newFinalColumns = Array.from(currentColumnToWorkOn);
    const newColumnBackup = currentColumnToWorkOn[source.index];
    newFinalColumns.splice(source.index, 1);
    newFinalColumns.splice(destination.index, 0, newColumnBackup);

    if (source.droppableId === COLUMN_PICKER_AVALIABLE) {
      this.setState({
        finalActiveColumns: newFinalColumns
      });
    } else {
      this.setState({
        finalPinnedColumns: newFinalColumns
      });
    }
  };

  processDragDropDifferentOriginDestination = (source, destination) => {
    const { finalActiveColumns, finalPinnedColumns, usageNotes } = this.state;

    const newFinalActiveColumns = Array.from(finalActiveColumns);
    const newFinalPinnedColumns = Array.from(finalPinnedColumns);
    let usage = {};

    if (source.droppableId === COLUMN_PICKER_AVALIABLE) {
      const columnBeingMoved = finalActiveColumns[source.index];
      usage[columnBeingMoved.displayname] = ACTION_VIEW_PIN_COLUMN;

      columnBeingMoved.pinned = PINNED_LEFT_STRING;
      newFinalActiveColumns.splice(source.index, 1);
      newFinalPinnedColumns.splice(destination.index, 0, columnBeingMoved);
    } else {
      const columnBeingMoved = finalPinnedColumns[source.index];
      usage[columnBeingMoved.displayname] = ACTION_VIEW_UNPIN_COLUMN;

      columnBeingMoved.pinned = null;
      newFinalPinnedColumns.splice(source.index, 1);
      newFinalActiveColumns.splice(destination.index, 0, columnBeingMoved);
    }

    this.setState({
      finalActiveColumns: newFinalActiveColumns,
      finalPinnedColumns: newFinalPinnedColumns,
      usageNotes: [...usageNotes, usage]
    });
  };

  handleClickAddButton = selectedColumn => {
    const { finalAvaliableColumns, finalActiveColumns, usageNotes } = this.state;
    const usage = { Name: selectedColumn.displayname, Action: ACTION_VIEW_ADD_COLUMN };

    this.setState({
      finalAvaliableColumns: finalAvaliableColumns.filter(column => column !== selectedColumn),
      finalActiveColumns: [...finalActiveColumns, addRowOnActiveColumns(selectedColumn)],
      usageNotes: [...usageNotes, usage]
    });
  };

  handleClickRemoveButton = selectedColumn => {
    const { columnsDictionary } = this.props;
    const { finalAvaliableColumns, finalActiveColumns, finalPinnedColumns, usageNotes } = this.state;
    const usage = { Name: selectedColumn.displayname, Action: ACTION_VIEW_REMOVE_COLUMN };

    const activeColumnToAdd = columnsDictionary.sourceColumnNames.filter(
      column => column.sourcecolumnname === selectedColumn.colId
    );

    this.setState({
      finalActiveColumns: finalActiveColumns.filter(column => column !== selectedColumn),
      finalPinnedColumns: finalPinnedColumns.filter(column => column !== selectedColumn),
      finalAvaliableColumns: [...finalAvaliableColumns, activeColumnToAdd[0]],
      usageNotes: [...usageNotes, usage]
    });
  };

  closePopup = () => this.props.handleClickOpenModalColumnPicker(false);

  handleKeyPress = event => {
    event.stopPropagation();
    if (event.keyCode === KEYS.ENTER) {
      event.preventDefault();
      this.handleSave();
    } else if (event.keyCode === KEYS.ESC) {
      event.preventDefault();
      this.closePopup();
    }
  };

  render() {
    const {
      showModalSaveViewOverModal,
      handleClickOpenModalColumnPicker,
      handleClickOpenModalSaveView,
      handleClickOpenModalSaveViewOverModal,
      currentView,
      userSettings,
      currentFinUser,
      filterList,
      handleCloseIconClick,
      disableColumnChooserButtons
    } = this.props;

    const {
      finalAvaliableColumns,
      finalActiveColumns,
      finalPinnedColumns,
      finalColumnOrder,
      isApplyingColumnChange
    } = this.state;

    const combinedActivePinnedColumns = [...finalPinnedColumns, ...finalActiveColumns];

    return (
      <div onKeyDown={this.handleKeyPress} tabIndex="1" ref={this.selfRef}>
        {showModalSaveViewOverModal && (
          <ModalSaveView
            isEditing={false}
            fromColumnPicker={true}
            editingView={null}
            currentView={currentView}
            handleClickOpenModalSaveView={handleClickOpenModalSaveView}
            handleClickOpenModalSaveViewOverModal={handleClickOpenModalSaveViewOverModal}
            handleOnCloseApplication={null}
            userSettings={userSettings}
            currentFinUser={currentFinUser}
            columnOrderFromGrid={finalColumnOrder}
            columnOrderFromView={finalColumnOrder}
            forceClosing={false}
            setFilterList={null}
            filterList={filterList}
            columnState={combinedActivePinnedColumns}
            closeIconClick={handleCloseIconClick}
            showModalSaveViewOverModal={showModalSaveViewOverModal}
          />
        )}
        <div data-testid="ModalColumnPicker" className={styles['columnpicker-modal__display']}>
          <div className={styles['columnpicker-modal']}>
            <header className={styles['columnpicker-modal__header']}>
              <span>Flow - Column Chooser</span>
              <div className={styles['columnpicker-modal__actions']}>
                <IconButton handleClick={() => handleClickOpenModalColumnPicker(false)} title="Close" size="custom">
                  <CloseIcon />
                </IconButton>
              </div>
            </header>

            <div className={styles['columnpicker-modal__body']}>
              <div className={styles['columnpicker-modal__body-header']}>
                {/*TODO: Pending style refactor */}
                Current View:&nbsp;&nbsp;&nbsp;{currentView}
                <br></br>
                Blotter Type:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Flow
              </div>
              <div className={styles['columnpicker-modal__body-body']}>
                <div className={styles['columnpicker-modal__cols']}>Available Columns</div>
                <div className={styles['columnpicker-modal__cols']}>Pinned Columns</div>
              </div>
              <div className={styles['columnpicker-modal__body-body']}>
                <div className={styles['columnpicker-modal__cols']}>
                  <div className={styles['columnpicker-modal__cols__space']}>
                    {finalAvaliableColumns &&
                      finalAvaliableColumns.map((column, index) => {
                        return (
                          <div
                            key={`key_col_picker_aval_${column}_${index}`}
                            className={styles['columnpicker-modal__row-avaliable']}
                          >
                            <div title={column.displayname}>{formatColumnName(column.displayname)}</div>
                            <div>
                              <IconButton
                                handleClick={() => this.handleClickAddButton(column)}
                                title="Add Column"
                                colorScheme="transparent"
                              >
                                <AddIcon />
                              </IconButton>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
                <DragDropContext onDragEnd={this.onDragEnd}>
                  <div className={styles['columnpicker-modal__cols']}>
                    <div>
                      <Droppable droppableId={COLUMN_PICKER_PINNED}>
                        {provided => (
                          <div
                            ref={provided.innerRef}
                            className={styles['columnpicker-modal__cols__space__avalcolumns__pinned']}
                            {...provided.droppableProps}
                          >
                            {finalPinnedColumns &&
                              finalPinnedColumns.map((column, index) => {
                                return (
                                  <ElementActiveColumn
                                    key={`key_col_picker_pinned_${index}`}
                                    column={column}
                                    index={index}
                                    type={'pinned'}
                                    handleClickRemoveButton={selectedColumn =>
                                      this.handleClickRemoveButton(selectedColumn)
                                    }
                                  />
                                );
                              })}
                            {provided.placeholder}
                          </div>
                        )}
                      </Droppable>
                      <div className={styles['columnpicker-modal__cols__space__avalcolumns__title']}>
                        Active Columns
                      </div>
                      <Droppable droppableId={COLUMN_PICKER_AVALIABLE}>
                        {provided => (
                          <div
                            ref={provided.innerRef}
                            className={styles['columnpicker-modal__cols__space__avalcolumns']}
                            {...provided.droppableProps}
                          >
                            {finalActiveColumns &&
                              finalActiveColumns.map((column, index) => {
                                return (
                                  <ElementActiveColumn
                                    key={`key_col_picker_active_${index}`}
                                    column={column}
                                    index={index}
                                    type={'aval'}
                                    handleClickRemoveButton={selectedColumn =>
                                      this.handleClickRemoveButton(selectedColumn)
                                    }
                                  />
                                );
                              })}
                            {provided.placeholder}
                          </div>
                        )}
                      </Droppable>
                    </div>
                  </div>
                </DragDropContext>
              </div>
            </div>
            <div className={styles['columnpicker-modal__footer']}>
              <div className={styles['columnpicker-modal__cols']}></div>

              <div className={styles['columnpicker-modal__cols__buttons']}>
                <button
                  disabled={isApplyingColumnChange || disableColumnChooserButtons}
                  className={styles['columnpicker-modal__button-cancel']}
                  onClick={() => handleClickOpenModalColumnPicker(false)}
                >
                  Cancel
                </button>
                {/* TODO: Use more meaningful name for variables*/}
                <button
                  disabled={isApplyingColumnChange || disableColumnChooserButtons}
                  className={styles['columnpicker-modal__button-save']}
                  onClick={this.handleSave}
                >
                  {isApplyingColumnChange ? 'Applying...' : 'Apply'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ModalColumnPicker;
