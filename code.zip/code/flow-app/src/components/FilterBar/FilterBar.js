import React, { Component } from 'react';
import styles from './FilterBar.module.scss';
import { BREADCRUMB_FILTERS_MERGE_BREAKPOINT } from '~helpers/globals';
import { hasItems } from 'flow-navigator-shared/dist/array';
import { BLANKS_VALUE, BLANKS_LABEL } from '~patterns/singleton/multiFilter';
import { togglesWithBreadcrumb, getBreadcrumbTextForToggle } from '~helpers/toggles';
import { FILTER_MODEL_DYNAMIC_SET } from '~helpers/filterModelTypes';
import { IconButton, Tooltip } from '~ui-library';
import { filterToggleStore } from '~patterns/singleton/filterToggleStore';
import { ReactComponent as ColumnsIcon } from '~assets/icon/util/columns.svg';
import { ReactComponent as FilterDismissIcon } from '~assets/icon/util/filter-dismiss.svg';
import { ReactComponent as SortDismissIcon } from '~assets/icon/util/dismissSort.svg';

const MULTIPLE = 'Multiple';
const COMMA_SEPARATOR = ', ';
const DASH_SEPARATOR = ' - ';
const MAX_TOOLTIP_LENGTH = 500;

const showToolTip = filters => filters.length >= Number(BREADCRUMB_FILTERS_MERGE_BREAKPOINT);

const joinFilters = (filters, filterType, separator) => {
  const joinedFilters = filters
    .filter(value => filterType === 'set' || (value && value !== ''))
    .map(value => (filterType === 'set' && value === BLANKS_VALUE ? BLANKS_LABEL : value))
    .join(separator);
  return joinedFilters.length > MAX_TOOLTIP_LENGTH
    ? `${joinedFilters.slice(0, MAX_TOOLTIP_LENGTH - 3)}...`
    : joinedFilters;
};

const applyToggleOptionFormat = (filters, toggleOptions) => {
  const filtersCopy = [...filters];
  const [first, second] = filtersCopy;
  const { denominator } = toggleOptions;

  return [first !== null ? first / denominator : null, second !== null ? second / denominator : null];
};

const getHeaderName = (headerName, filterToggleState) => {
  if (!filterToggleState) return headerName;

  const { showToggle, toggle, toggleOptions } = filterToggleState;

  if (showToggle && toggle) return toggleOptions.breadCrumbText;

  return headerName;
};

class FilterBar extends Component {
  renderToggles = () => {
    const { toggles, onToggleChange } = this.props;

    return togglesWithBreadcrumb
      .filter(toggleKey => toggles[toggleKey])
      .map(toggleKey => (
        <div key={toggleKey} className={styles.breadcrumb}>
          {getBreadcrumbTextForToggle(toggleKey)}
          <button className={styles['close-mark']} onClick={() => onToggleChange(toggleKey)}>
            X
          </button>
        </div>
      ));
  };

  renderFilter = (filterObj, index) => {
    const { field, filter, filterType, headerName, type, originalFilter, arrayFilter, textFilter } = filterObj;

    const filterToggleState = filterToggleStore.get(field);
    let showToggle, toggle, toggleOptions;

    if (filterToggleState) {
      showToggle = filterToggleState.showToggle;
      toggle = filterToggleState.toggle;
      toggleOptions = filterToggleState.toggleOptions;
    }

    if (hasItems(filter) || hasItems(originalFilter) || hasItems(arrayFilter) || textFilter) {
      const formattedHeaderName = getHeaderName(headerName, filterToggleState);
      let filters;

      if (filterType === FILTER_MODEL_DYNAMIC_SET) {
        const dynamicSetFilters = [];

        if (hasItems(arrayFilter)) dynamicSetFilters.push(...arrayFilter);
        if (textFilter) dynamicSetFilters.push(textFilter);

        filters = [...dynamicSetFilters];
      } else {
        if (!showToggle || !toggle) {
          filters = originalFilter || filter;
        } else {
          filters = applyToggleOptionFormat(originalFilter || filter, toggleOptions);
        }
      }

      return (
        <div className={styles.breadcrumb} key={`filterBreadcrumb_${index}`}>
          {formattedHeaderName}: {type}
          {showToolTip(filters) ? (
            <div className={styles['breadcrumb__tooltip']}>
              <Tooltip label={joinFilters(filters, filterType, COMMA_SEPARATOR)} className={styles.filterTooltip}>
                <span>
                  {MULTIPLE} ({filters.length})
                </span>
              </Tooltip>
            </div>
          ) : (
            joinFilters(filters, filterType, DASH_SEPARATOR)
          )}
          <button className={styles['close-mark']} onClick={() => this.props.handleClickResetFilter(field)}>
            X
          </button>
        </div>
      );
    }

    return '';
  };

  renderBreadcrumb = () => {
    const { filterList } = this.props;
    return (
      <div className={styles['breadcrumb-zone']}>
        {hasItems(filterList) && filterList.map((filter, index) => this.renderFilter(filter, index))}
        {this.renderToggles()}
      </div>
    );
  };

  renderResetIcons = () => {
    const { filterList, sortList, handleClickResetFilter, handleClickResetSort } = this.props;

    return (
      <div className={hasItems(filterList) ? styles['icon-zone'] : styles['icon-zone__nofilter']}>
        <IconButton
          handleClick={handleClickResetSort}
          size="custom"
          padding="2px"
          disabled={!hasItems(sortList)}
          title="Reset Sorting"
        >
          <SortDismissIcon />
        </IconButton>

        <IconButton
          handleClick={() => handleClickResetFilter(null)}
          size="custom"
          padding="2px"
          title="Remove all filters"
        >
          <FilterDismissIcon />
        </IconButton>
      </div>
    );
  };

  renderColumnChooserIcon = () => {
    const { handleClickOpenModalColumnPicker } = this.props;

    return (
      <IconButton handleClick={handleClickOpenModalColumnPicker} size="custom" padding="2px" title="Column Chooser">
        <ColumnsIcon />
      </IconButton>
    );
  };

  render() {
    return (
      <div data-testid="FilterBar" className={styles['filter-bar']}>
        <div className={styles['filter-bar-main']}>
          {this.renderResetIcons()}
          {this.renderBreadcrumb()}
        </div>
        <div className={`${styles['filter-bar-main']} ${styles['column-selector-zone']}`}>
          {this.renderColumnChooserIcon()}
        </div>
      </div>
    );
  }
}

export default FilterBar;
