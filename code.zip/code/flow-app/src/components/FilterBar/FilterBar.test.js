import React from 'react';
import { render, cleanup, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import FilterBar from './FilterBar';

// Unmount everything from the dom after each test
afterEach(cleanup);

const filterBarProps = {
  filterList: [],
  sortList: [],
  setFilterList: [],
  handleClickResetFilter: jest.fn(),
  handleClickResetSort: jest.fn(),
  handleClickOpenModalColumnPicker: jest.fn()
};

describe('<FilterBar />', () => {
  test('renders FilterBar', () => {
    const { getByTestId } = render(<FilterBar {...filterBarProps} />);
    const component = getByTestId('FilterBar');

    expect(component).toBeInTheDocument();
  });
});
