import React from 'react';
import { render, cleanup, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import SearchBar from './SearchBar';
import { clientsMock, tickersMock, cusipsMock } from '~mocks/searchBar.json';

// Unmount everything from the dom after each test
afterEach(cleanup);

describe('<SearchBar />', () => {
  test('renders default SearchBar', () => {
    const { getByTestId } = render(<SearchBar />);
    const searchBar = getByTestId('SearchBar');

    expect(searchBar).toBeInTheDocument();
    expect(searchBar).toHaveTextContent('');
  });

  test('type something on SearchBar', () => {
    const { getByTestId } = render(<SearchBar />);
    const searchBar = getByTestId('SearchBar');

    const typedValue = 'Madison';
    fireEvent.change(searchBar, { target: { value: typedValue } });
    expect(searchBar).toHaveValue(typedValue);
  });

  test('filter data on SearchBar', () => {
    const onChange = jest.fn();
    const props = {
      dataToFilter: [...clientsMock, ...tickersMock, ...cusipsMock],
      onChange
    };
    const { getByTestId } = render(<SearchBar {...props} />);
    const searchBar = getByTestId('SearchBar');

    const typedValue = 'frank';
    const expectedResult = [clientsMock[4]];
    fireEvent.change(searchBar, { target: { value: typedValue } });
    expect(searchBar).toHaveValue(typedValue);
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(expectedResult);
  });
});
