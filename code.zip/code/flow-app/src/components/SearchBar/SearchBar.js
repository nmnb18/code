import React, { memo, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import styles from './SearchBar.module.scss';

const SearchBar = ({
  dataToFilter,
  onChange,
  onBlur,
  onFocus,
  placeholder,
  autofocus,
  active,
  rounded = true,
  small = false
}) => {
  let inputEl = useRef(null);

  useEffect(() => {
    if (active || autofocus) inputEl.current.focus();
  }, [active, autofocus]);

  const handleChange = event => {
    const userInput = event.target.value;
    if (dataToFilter) {
      const regex = new RegExp(userInput, 'i');
      const filteredData = dataToFilter.filter(item =>
        item.name ? item.name.match(regex) : item.ViewName.match(regex)
      );
      onChange && onChange(filteredData);
    }
  };

  const handleSubmit = e => e.preventDefault();

  return (
    <form className={`${styles.container} ${small ? styles.small : ''}`} onSubmit={handleSubmit}>
      <input
        data-testid="SearchBar"
        ref={inputEl}
        onChange={handleChange}
        onBlur={onBlur}
        onFocus={onFocus}
        className={`${styles.input} ${rounded ? styles.rounded : ''}`}
        type="text"
        placeholder={placeholder}
      />
    </form>
  );
};

// @Proptypes
SearchBar.propTypes = {
  dataToFilter: PropTypes.array,
  onChange: PropTypes.func,
  onBlur: PropTypes.func,
  onFocus: PropTypes.func,
  placeholder: PropTypes.string
};

SearchBar.defaultProps = {
  placeholder: 'SearchBar'
};

// @Export Component
export default memo(SearchBar);
