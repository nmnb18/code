import React from 'react';
import styles from './HeaderToggle.module.scss';
import { FORCE_DEFAULT_THEME_CLASS } from '~helpers/globals';

const HeaderToggle = ({ onToggleChange, isToggleOn, text, toggleClass = undefined, forceDefaultTheme = false }) => (
  <div
    className={`${toggleClass ? styles[toggleClass] : styles['toggle']} ${
      forceDefaultTheme ? styles[FORCE_DEFAULT_THEME_CLASS] : ''
    }`}
    onClick={onToggleChange}
    onKeyPress={onToggleChange}
    role="button"
    tabIndex={0}
  >
    <div className={styles['toggle__title']}>{text}</div>
    <div className={styles[`toggle__container--${isToggleOn ? '' : 'in'}active`]}>
      <div className={styles[`toggle__thumb--${isToggleOn ? '' : 'in'}active`]}></div>
    </div>
  </div>
);

export default HeaderToggle;
