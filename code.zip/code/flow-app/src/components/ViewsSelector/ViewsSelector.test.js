import React from 'react';
import { render, cleanup, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import ViewsSelector from './ViewsSelector.js';
import { viewsMock } from '~mocks/viewsMock.json';

// Unmount everything from the dom after each test
afterEach(cleanup);

const props = {
  viewsList: viewsMock,
  onSelectView: jest.fn(),
  readOnlyView: 'Standard'
};

describe('<ViewsSelector />', () => {
  test('renders ViewsSelector', () => {
    // Renders component
    const { container, getByTestId } = render(<ViewsSelector {...props} />);
    const component = getByTestId('ViewsSelector');
    const searchBar = getByTestId('SearchBar');
    const viewsList = container.querySelectorAll('.views-selector__scroll button');

    // Asserts
    expect(component).toBeInTheDocument();
    expect(searchBar).toBeInTheDocument();
    expect(viewsList.length).toBe(viewsMock.length);
  });

  test('filter views list by typing on the searchbar', () => {
    const { container, getByTestId } = render(<ViewsSelector {...props} />);
    const searchBar = getByTestId('SearchBar');

    const typedValue = 'Sell';
    fireEvent.change(searchBar, { target: { value: typedValue } });
    const viewsList = container.querySelectorAll('.views-selector-view-item');

    const regex = new RegExp(typedValue, 'i');
    const filteredViews = viewsMock.find(({ ViewName }) => ViewName.match(regex));
    expect(viewsList.length).toBe([filteredViews].length);

    const viewName = container.querySelector('.views-selector-view-item');
    fireEvent.click(viewName);
    expect(props.onSelectView).toHaveBeenCalledWith(filteredViews, false);
  });
});
