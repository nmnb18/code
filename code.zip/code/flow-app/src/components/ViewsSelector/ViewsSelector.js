// @Dependencies
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import styles from './ViewsSelector.module.scss';

// @Dependencies
import { SearchBar, ViewsSelectorItem } from '~components';

// @Component
const ViewsSelector = ({ inputActive, current, viewsList, onSelectView, setCurrentViewName }) => {
  const [list, setList] = useState([]);
  useEffect(() => {
    setList(viewsList);
  }, [viewsList]);

  const handleSelectedView = (view, editing = false) => {
    onSelectView && onSelectView(view, editing);
    !editing && setCurrentViewName && setCurrentViewName(view.ViewName);
  };

  const handleChange = data => setList(data);
  const isActiveView = view => {
    return current ? view.ViewName === current.ViewName : false;
  };

  return (
    <div data-testid="ViewsSelector" className={styles['views-selector']}>
      <SearchBar
        active={inputActive}
        dataToFilter={viewsList}
        onChange={handleChange}
        placeholder="Search Views..."
        rounded={false}
        small
      />
      <ul className={styles['views-selector__scroll']}>
        {list &&
          list.map((view, index) => (
            <ViewsSelectorItem
              active={isActiveView(view)}
              key={view.ViewName}
              tabIndex={index}
              view={view}
              handleSelectedView={handleSelectedView}
            />
          ))}
      </ul>
    </div>
  );
};

// @Proptypes
ViewsSelector.propTypes = {
  onSelectView: PropTypes.func,
  viewsList: PropTypes.array
};

// @Export component
export default ViewsSelector;
