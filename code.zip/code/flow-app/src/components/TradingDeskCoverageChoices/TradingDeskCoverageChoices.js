import React from 'react';
import styles from './TradingDeskCoverageChoices.module.scss';
import { tradingDeskCoverageChoicesLabels } from '~helpers/globals';

const TradingDeskCoverageChoices = ({ isCoverageSelected, isMyDeskSelected, onClickMyDesk, onClickCoverage }) => (
  <div className={styles['filter-wrapper']}>
    <div
      role="button"
      onClick={onClickCoverage}
      className={`${styles['filter-wrapper__label']} ${isCoverageSelected ? styles['filter-wrapper__active'] : ''}`}
    >
      {tradingDeskCoverageChoicesLabels.coverage}
    </div>
    <div
      role="button"
      onClick={onClickMyDesk}
      className={`${styles['filter-wrapper__label']} ${isMyDeskSelected ? styles['filter-wrapper__active'] : ''}`}
    >
      {tradingDeskCoverageChoicesLabels.mydesk}
    </div>
  </div>
);

export default TradingDeskCoverageChoices;
