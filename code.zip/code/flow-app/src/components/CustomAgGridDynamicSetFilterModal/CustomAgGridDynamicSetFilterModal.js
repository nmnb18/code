import React, { useState, useMemo, useCallback } from 'react';
import styles from './CustomAgGridDynamicSetFilterModal.module.scss';
import { KEYS } from '~helpers/keyCodes';
import { isEmpty } from 'flow-navigator-shared/dist/array';
import { isNotEmpty } from '~helpers/string';
import { ClearFilterIcon } from '~common';

const CustomAgGridDynamicSetFilterModal = ({
  selectAll,
  searchText,
  availableOptions,
  arrayFilter,
  textFilterOptions,
  onSearchTextChange,
  onToggle,
  onToggleAll,
  onApply,
  onCancel,
  onReset,
  sortingMenu,
  loading
}) => {
  const [addCurrentSelection, setAddCurrentSelection] = useState(false);

  const checkedCount = useMemo(() => {
    if (!addCurrentSelection) return availableOptions.filter(o => o.checked).length;

    const checkedOptions = availableOptions.filter(o => o.checked).map(o => o.value);

    const uncheckedOptions = availableOptions.filter(o => !o.checked).map(o => o.value);
    const remainingArrayFilter = arrayFilter.filter(o => !uncheckedOptions.includes(o));

    const filters = Array.from(new Set([...remainingArrayFilter, ...textFilterOptions, ...checkedOptions]));

    return filters.length;
  }, [availableOptions, addCurrentSelection, arrayFilter, textFilterOptions]);

  const handleSearchTextChange = useCallback(
    ({ target: { value } }) => {
      const uncheckCurrentSelection = !value && addCurrentSelection;

      if (uncheckCurrentSelection) setAddCurrentSelection(false);

      onSearchTextChange(value);
    },
    [addCurrentSelection, setAddCurrentSelection, onSearchTextChange]
  );

  const handleClear = useCallback(() => {
    onReset();
    if (addCurrentSelection) setAddCurrentSelection(false);
  }, [onReset, addCurrentSelection, setAddCurrentSelection]);

  const handleCancel = useCallback(() => {
    onCancel();
    if (addCurrentSelection) setAddCurrentSelection(false);
  }, [onCancel, addCurrentSelection, setAddCurrentSelection]);

  const handleApply = useCallback(() => {
    onApply(addCurrentSelection);
    if (addCurrentSelection) setAddCurrentSelection(false);
  }, [onApply, addCurrentSelection, setAddCurrentSelection]);

  const handleKeyDown = useCallback(
    event => {
      if (event.keyCode === KEYS.ENTER) {
        event.preventDefault();
        if (checkedCount > 0) handleApply();
      }
    },
    [checkedCount, handleApply]
  );

  const renderClearFilter = useCallback(
    () => (
      <div className={styles['set-advanced-options__clear-filter']}>
        <button onClick={handleClear}>
          <ClearFilterIcon />
          <p>Clear Filter</p>
        </button>
      </div>
    ),
    [handleClear]
  );

  const renderSearchBox = useCallback(
    () => (
      <div className={styles['set-advanced-options__wrapper-textbox']}>
        <input
          className={styles['set-advanced-options__textbox']}
          type="text"
          placeholder="Search..."
          value={searchText}
          onChange={handleSearchTextChange}
          onKeyDown={handleKeyDown}
        />
      </div>
    ),
    [searchText, handleSearchTextChange, handleKeyDown]
  );

  const renderSelectAll = useCallback(
    () => (
      <div className={styles['set-advanced-options__wrapper-selectall']}>
        <label className={styles['set-advanced-options-checkbox-container']}>
          Select All
          <input type="checkbox" onChange={onToggleAll} checked={selectAll} />
          <span className={styles['set-advanced-options-checkbox-checkmark']}></span>
        </label>
      </div>
    ),
    [onToggleAll, selectAll]
  );

  const renderCurrentSelection = useCallback(
    () =>
      isNotEmpty(searchText) ? (
        <div className={styles['set-advanced-options__wrapper-selectall']}>
          <label className={styles['set-advanced-options-checkbox-container']}>
            Add current selection to filter
            <input
              type="checkbox"
              onChange={event => setAddCurrentSelection(event.target.checked)}
              checked={addCurrentSelection}
            />
            <span className={styles['set-advanced-options-checkbox-checkmark']} />
          </label>
        </div>
      ) : null,
    [searchText, setAddCurrentSelection, addCurrentSelection]
  );

  const renderSelectableOptions = useCallback(() => {
    if (loading) return <div className={styles['set-advanced-options__wrapper-body-loading']}>loading...</div>;
    if (isEmpty(availableOptions)) return <div className={styles['set-advanced-options__wrapper-body']} />;

    return (
      <div className={styles['set-advanced-options__wrapper-body']}>
        {availableOptions.map((option, index) => (
          <div key={`filterchooser_${option.value}_${index}`} className={styles['set-advanced-options__filter-option']}>
            <label className={styles['set-advanced-options-checkbox-container']}>
              {option.label}
              <input type="checkbox" onChange={() => onToggle(option)} checked={option.checked} />
              <span className={styles['set-advanced-options-checkbox-checkmark']}></span>
            </label>
          </div>
        ))}
      </div>
    );
  }, [availableOptions, onToggle, loading]);

  const renderActions = useCallback(
    () => (
      <footer className={styles['set-advanced-options__footer']}>
        <button onClick={handleCancel}>Cancel</button>
        <button disabled={checkedCount === 0} onClick={handleApply}>
          Apply Filter {checkedCount > 0 ? `(${checkedCount})` : ''}
        </button>
      </footer>
    ),
    [handleCancel, handleApply, checkedCount]
  );

  return (
    <div className={styles['set-advanced-options']}>
      {sortingMenu}
      {renderClearFilter()}
      {renderSearchBox()}
      {renderSelectAll()}
      {renderCurrentSelection()}
      {renderSelectableOptions()}
      {renderActions()}
      <div className={styles['set-advanced-options__footer__fix']}></div>
    </div>
  );
};

export default CustomAgGridDynamicSetFilterModal;
