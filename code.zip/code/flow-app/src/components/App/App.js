import React, { Fragment, Component } from 'react';
import './App.scss';
import {
  FlowGrid,
  FlowGridHeader,
  FlowGridFooter,
  NoAccess,
  ExportDataSource,
  CustomLoadingCell,
  HeaderToggle,
  FilterBar,
  ViewsList,
  TradingDeskCoverageChoices,
  MiniTicketPanel
} from '~components';
import {
  FLOW_APP_NAME,
  FIRSTROW_ALWAYS_CHECKBOX,
  tradingDeskCoverageChoicesLabels,
  recordTypes,
  BLOOMBERG_TERMINAL_WINDOW,
  STANDARD_FLOWBLOTTER_NAME
} from '~helpers/globals';
import { logger } from '~helpers/logger';
import { COLUMNS } from '~helpers/columnStyles';
import {
  FILTER_MODEL_SET,
  FILTER_MODEL_DYNAMIC_SET,
  FILTER_MODEL_TEXT,
  FILTER_MODEL_NUMBER,
  FILTER_MODEL_DATE
} from '~helpers/filterModelTypes';
import * as settingsService from '~services/settingsService';
import * as columnDictionaryService from '~services/columnDictionaryService';
import * as integrationService from '~services/integrationService';
import { defaultMainGridId, exportDataSourceId, defaultMultiFilterFlowId } from '~helpers/jasperWebSocket';
import ModalSaveView from '../ModalSaveView/ModalSaveView.js';
import { forkJoin, Subject, ReplaySubject, of } from 'rxjs';
import { filter, switchMap, delay } from 'rxjs/operators';
import ModalColumnPicker from '../ModalColumnPicker/ModalColumnPicker';
import { flowBlotterActions, exportDataSourceActions } from '~services/openfinConfig';
import { getFinApplication } from '~helpers/openfin';
import ModalCopyTemplate from '../ModalCopyTemplate/ModalCopyTemplate';
import { FETCH_TRIGGERS, WS_COMMANDS, RFQNLEGS } from '~helpers/jasperMessage';
import { updateRatingFilters } from '~helpers/filterListHelper';
import { SELECTALL_CHECKBOX_STATE } from '~helpers/exportHelper';
import { selectAllCheckboxNextState } from '~helpers/checkboxState';
import { flowBlotterService, fbEvents } from '~services/flowBlotterService';
import { exportDataSourceService } from '~services/exportDataSourceService';
import {
  usageService,
  ACTION_APPLY_FILTER,
  ACTION_CLEAR_FILTER,
  ACTION_RESET_FILTER,
  ACTION_CLEAR_SORTING
} from '~services/usageService';
import {
  showEntitlementOption,
  uiEntitlementOptions,
  isTechOrAdminUser,
  isUserEntitledForTradingDeskCoverage,
  userIsTrader
} from '~helpers/entitlement';
import {
  isTradingDeskCoverageAvailableInUserSettings,
  getFlowAppFromSettings,
  defaultFlowUserSharedSettings,
  defaultFlowFilterSharedSettings
} from '~helpers/userSettings';
import {
  getSelectedViewName,
  getColumnFilters,
  getDynamicSetFilterColumns,
  getSortPriority,
  getEnhancedColumnDefs,
  shouldLoadRatings,
  getColumnState
} from '~helpers/viewSettings';
import { isEmpty, hasItems } from 'flow-navigator-shared/dist/array';
import {
  TOGGLE_ME_ONLY,
  getTogglesToReset,
  getToggleLabel,
  filterTogglesConfiguration,
  filterToggleConfigurationMapping
} from '~helpers/toggles';
import { getSubscriptionsInstances } from '~helpers/subscriptions';
import { DYNAMIC_SET_FILTER, getFilterType } from '~helpers/filters';
import { kvpStore } from '~patterns/singleton/kvpStore';
import { filterToggleStore } from '~patterns/singleton/filterToggleStore';
import { executeCommandWithUsage } from '~helpers/bloomberg';
import * as bloombergService from '~services/bloombergService';
import TextButton from '~ui-library/Buttons/TextButton';
import { viewsActions, sharedSettingsActions, tradingDeskCoverageChoicesActions } from '~helpers/actionCreator';
import { useSetTheme } from '~hooks';

let currentApplication;
const requestInterval = 50;

const mapToUsageFilterList = filterList =>
  filterList.map(({ filterType, filter, headerName, type, arrayFilter, textFilter }) => {
    const getValue = {
      [FILTER_MODEL_SET]: () => filter,
      [FILTER_MODEL_DYNAMIC_SET]: () => {
        const dynamicFilterValue = [];
        if (hasItems(arrayFilter)) dynamicFilterValue.push(...arrayFilter.filter(Boolean));
        if (textFilter) dynamicFilterValue.push(textFilter);
        return dynamicFilterValue;
      },
      [FILTER_MODEL_TEXT]: () => filter.filter(Boolean).toString(),
      [FILTER_MODEL_NUMBER]: () => type + filter.filter(Boolean).toString(),
      [FILTER_MODEL_DATE]: () => filter.filter(Boolean).join(' - ')
    }[filterType];

    return { [`${headerName}`]: getValue && getValue() };
  });

const ThemeSetter = ({ theme }) => {
  useSetTheme(theme);
  return <></>;
};

class App extends Component {
  constructor(props) {
    super(props);
    this.FlowGridRef = React.createRef();
    this.jasperWebSocket = new Subject();
  }

  // Subjects for Export Data Use case
  exportDataCacheSubject = new ReplaySubject();
  fetchDataSubject = new Subject();
  fetchDataSubject$ = this.fetchDataSubject.asObservable();

  fetchingStatusSubject = new Subject();
  fetchingStatusSubject$ = this.fetchingStatusSubject.asObservable();

  // Subject for handle the select all checkbox and row checkbox
  checkboxSubject = new Subject();
  checkboxSubject$ = this.checkboxSubject.asObservable();

  // Subject for handle the context menu copy template option
  contextMenuSubject = new Subject();
  contextMenuSubject$ = this.contextMenuSubject.asObservable();

  checkboxList = [];

  checkboxChangesSubject = new Subject();
  checkboxChangesSubject$ = this.checkboxChangesSubject.asObservable();

  processedRecordSubject = new Subject();
  processedRecordSubject$ = this.processedRecordSubject.asObservable();

  requestHandler$ = new Subject();

  selectedRFQsSubject$ = new Subject();

  rfqRecordsMap = new Map();

  state = {
    columnOptions: {
      rowHeight: 24,
      suppressDragLeaveHidesColumns: true,
      suppressPropertyNamesCheck: true
    },
    impersonatingUser: false,
    currentFinUser: null,
    signedInUser: null,
    isSettingCurrentFinUserProfile: true,
    currentFinComputer: null,
    columnDefs: [],
    columnsDictionary: null,
    valueDisplayCopyExcel: false,
    totalRows: 0,
    selectedRows: 0,
    userSettings: {},
    toggles: defaultFlowUserSharedSettings,
    filterToggles: defaultFlowFilterSharedSettings,
    showModalSaveView: false,
    showModalColumnPicker: false,
    showModalSaveViewOverModal: false,
    showModalCopyTemplate: false,
    columnOrderFromGrid: [],
    columnOrderFromView: [],
    isSaveButtonVisible: false,
    forceClosing: false,
    isEditing: false,
    editingView: '',
    currentViewName: '',
    filterList: [],
    filterListFromView: [],
    sortList: [],
    sortListFromView: [],
    columnState: [],
    flowSubscriptionInstanceId: null,
    exportDataSourceInstanceId: null,
    multiFilterSourceInstanceId: null,
    flowBlotterMiniTicketPanelInstanceId: null,
    userEntitlement: null,
    impersonatedUser: null,
    isTech: null,
    selectedInDDLCopyTemplateName: null,
    loading: true,
    webSocketDisconnected: null,
    selectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.UNCHECK,
    ratingFilters: {},
    switchingBlotterApp: false,
    selectedViewIsReadOnly: false,
    isCoverageSelected: true,
    isMyDeskSelected: false,
    isTradingDeskCoverageChoicesVisible: false,
    resetAllFiltersButtonClicked: false,
    disableColumnChooserButtons: false,
    multiFilterList: [],
    showMiniTicketPanel: false,
    isUserTrader: false
  };

  async componentDidMount() {
    flowBlotterService.sendMessage({ type: flowBlotterActions.mounted });

    flowBlotterService.initSubscriptions();
    exportDataSourceService.initSubscriptions();

    currentApplication = await getFinApplication();
    currentApplication.addListener('closed', this.handleOnCloseApplication);

    // TODO: Add IAB topics here
    this.entitlementErrorSubscription = flowBlotterService.entitlementErrors$.subscribe(this.blockAccess);
    this.stateChangesSubscription = flowBlotterService.stateChanges$.subscribe(this.handleStateChanges);
    this.eventEmittedSubscription = flowBlotterService.eventEmitted$.subscribe(this.handleEventEmitted);
    this.filterToggleChangeSubscription = filterToggleStore.stateChanges$.subscribe(this.handleOnFilterToggleChange);

    this.multiFilterRequestHandlerSubscription = flowBlotterService.multiFilterRequest$.subscribe(
      ({ field, event }) => {
        flowBlotterService.setMultiFilterField(field);
        flowBlotterService.setMultiFilterEvent(event);

        const requestCommand = this.requestMultiFilter(field);

        flowBlotterService.sendMessage({
          type: flowBlotterActions.flowBlotterRequestMultiFilter,
          payload: { requestCommand }
        });
      }
    );

    const multiFilterCommands = [
      WS_COMMANDS.GROUP_BEGIN,
      WS_COMMANDS.NEW_MESSAGE,
      WS_COMMANDS.GROUP_END,
      WS_COMMANDS.NEW_MESSAGE_SOW,
      WS_COMMANDS.DELETE_MESSAGE
    ];
    this.multiFilterSubscription = flowBlotterService.multiFiltersSource$
      .pipe(filter(filterMessage => multiFilterCommands.includes(filterMessage.command)))
      .subscribe(this.handleMultiFilterChanges);

    this.checkboxSubscriber = this.checkboxSubject$.subscribe(checkboxValue => {
      const { selectAllCheckboxStatus, totalRows } = this.state;
      this.handleOnCheckboxChange(checkboxValue, selectAllCheckboxStatus, totalRows);
    });

    this.contextMenuSubscriber = this.contextMenuSubject$.subscribe(data => {
      this.handleContextMenuEvent(data);
    });

    this.requestHandlerSubscription = this.requestHandler$
      .pipe(switchMap(requestCommand => of(requestCommand).pipe(delay(requestInterval))))
      .subscribe(requestCommand => {
        flowBlotterService.sendMessage({
          type: flowBlotterActions.flowBlotterRequestData,
          payload: { requestCommand }
        });
      });
  }

  componentDidUpdate(_, prevState) {
    const {
      currentFinUser,
      userSettings,
      userEntitlement,
      columnsDictionary,
      filterList,
      filterFromView,
      selectedInDDLCopyTemplateName
    } = this.state;

    if (currentFinUser && prevState.currentFinUser !== currentFinUser) {
      forkJoin({
        userSettings: settingsService.getUserSettings(currentFinUser),
        appColumns: columnDictionaryService.getApplicationColumns(FLOW_APP_NAME)
      }).subscribe(({ userSettings, appColumns }) => {
        this.setState(
          {
            userSettings,
            columnsDictionary: appColumns,
            selectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.UNCHECK,
            selectedRows: 0,
            valueDisplayCopyExcel: false
          },
          () => flowBlotterService.sendMessage({ type: flowBlotterActions.requestUserEntitlement })
        );
      });
    }

    if (userSettings && columnsDictionary && userEntitlement && prevState.userEntitlement !== userEntitlement) {
      this.setState({ loading: false });

      //Column Definition initializer
      //First Param: Selected View (in case we are choosing a view from the Dropdown Menu)
      //Second Param: Editing View (in case we are changing the name of the View)
      this.setUserColumnDefinition(null, false, false);
    }

    if (this.evalIfSaveButtonShouldAppear(prevState.columnOrderFromGrid)) {
      this.setState({ isSaveButtonVisible: true });
    }

    if (userSettings && userEntitlement && prevState.userSettings !== userSettings) {
      this.configureTradingAndDeskOptions();
    }

    if (userEntitlement && prevState.userEntitlement !== userEntitlement) {
      this.setTradingDeskCoverageChoicesVisibleState();
    }

    if (
      filterList.length > 0 &&
      filterFromView.length > 0 &&
      JSON.stringify(filterFromView) !== JSON.stringify(filterList) &&
      JSON.stringify(prevState.filterList) !== JSON.stringify(filterList)
    ) {
      this.setState({ isSaveButtonVisible: true });
    }

    if (
      userSettings &&
      userEntitlement &&
      prevState.userSettings !== userSettings &&
      selectedInDDLCopyTemplateName === null
    ) {
      const defaultCopyTempName = settingsService.getDefaultCopyTemplateName(userSettings, FLOW_APP_NAME);
      this.setSelectedInDDLCopyTemplateName(defaultCopyTempName);
    }
  }

  componentWillUnmount() {
    currentApplication.removeListener('closed', this.handleOnCloseApplication);

    flowBlotterService.removeSubscriptions();
    exportDataSourceService.removeSubscriptions();

    this.entitlementErrorSubscription && this.entitlementErrorSubscription.unsubscribe();
    this.checkboxSubscriber && this.checkboxSubscriber.unsubscribe();
    this.contextMenuSubscriber && this.contextMenuSubscriber.unsubscribe();
    this.stateChangesSubscription && this.stateChangesSubscription.unsubscribe();
    this.multiFilterSubscription && this.multiFilterSubscription.unsubscribe();
    this.requestHandlerSubscription && this.requestHandlerSubscription.unsubscribe();
    this.multiFilterRequestHandlerSubscription && this.multiFilterRequestHandlerSubscription.unsubscribe();
    this.filterToggleChangeSubscription && this.filterToggleChangeSubscription.unsubscribe();
  }

  handleMultiFilterChanges = filterMessage => {
    const { elements } = filterMessage;
    if (!elements) return;

    const keys = Object.keys(elements);
    if (!keys.length) return;

    const filterFieldId = keys[0];
    const filterInstance = this.FlowGridRef.current.gridApi.getFilterInstance(filterFieldId);
    if (!filterInstance) return;

    const { command } = filterMessage;
    const filterValue = elements[filterFieldId];

    const componentInstance = filterInstance.getFrameworkComponentInstance();
    if (!componentInstance) return;

    componentInstance.filters$.next({
      option: filterValue,
      command
    });
  };

  handleStateChanges = stateChanges => {
    this.setState(stateChanges);
  };

  handleEventEmitted = eventEmitted => {
    const { type, payload } = eventEmitted;

    switch (type) {
      case flowBlotterActions.updatedUserSettings: {
        const { userSettings } = payload;
        this.setState({ userSettings });
        return;
      }
      case flowBlotterActions.reloadBlotterApp: {
        this.handleReloadFlowBlotter();
        return;
      }
      case flowBlotterActions.closingBlotterApp: {
        this.closeApplicationRequest();
        return;
      }
      case flowBlotterActions.switchingBlotterApp: {
        this.switchApplicationRequest();
        return;
      }
      case flowBlotterActions.assignBlotterUser: {
        const { user } = payload;
        const { currentFinUser } = this.state;

        if (currentFinUser !== user) {
          const {
            impersonating,
            impersonatedUser,
            signedInUser,
            computer,
            ampsConnected,
            webSocketDisconnected,
            toggles,
            filterToggles
          } = payload;

          const {
            flowSubscriptionInstanceId,
            exportDataSourceInstanceId,
            multiFilterSourceInstanceId,
            flowBlotterMiniTicketPanelInstanceId
          } = getSubscriptionsInstances({
            signedInUser,
            flowNavigatorUser: user,
            computerId: computer
          });

          this.setState({
            currentFinUser: user,
            signedInUser,
            currentFinComputer: computer,
            impersonatingUser: impersonating,
            impersonatedUser,
            isSettingCurrentFinUserProfile: true,
            flowSubscriptionInstanceId,
            exportDataSourceInstanceId,
            multiFilterSourceInstanceId,
            flowBlotterMiniTicketPanelInstanceId,
            noAccess: false,
            ampsConnected,
            webSocketDisconnected,
            toggles,
            filterToggles
          });
        }
        return;
      }
      case flowBlotterActions.setUserEntitlement: {
        const { userEntitlement } = payload;
        this.setState({ userEntitlement });
        return;
      }
      default:
        return;
    }
  };

  configureTradingAndDeskOptions = () => {
    const { userSettings, isTradingDeskCoverageChoicesVisible } = this.state;
    const tradingDeskCoverageAvailableInUserSettings = isTradingDeskCoverageAvailableInUserSettings(userSettings);

    if (isTradingDeskCoverageChoicesVisible) {
      if (tradingDeskCoverageAvailableInUserSettings) {
        // User entitled for trading desk and coverage and settings also exist
        const flowApp = getFlowAppFromSettings(userSettings);
        const { coverage, mydesk } = flowApp.Settings.TradingDeskCoverageChoices;
        this.setState({ isCoverageSelected: coverage, isMyDeskSelected: mydesk ? true : false });
      } else {
        // User entitled but settings not updated
        const { isCoverageSelected, isMyDeskSelected, userEntitlement } = this.state;
        tradingDeskCoverageChoicesActions.update({
          isCoverageSelected,
          isMyDeskSelected,
          userEntitlement
        });
      }
    } else {
      if (tradingDeskCoverageAvailableInUserSettings) {
        // remove trading and desk from user settings as user might moved to other desk
        tradingDeskCoverageChoicesActions.delete();
      }
    }
  };

  blockAccess = () => this.setState({ noAccess: true });

  handleOnCloseApplication = () => flowBlotterService.sendMessage({ type: flowBlotterActions.flowBlotterClose });

  handleOnSwitchBlotter = () => {
    flowBlotterService.sendSwitchBlotterResponse({ unsavedChanges: false });
  };

  resetModalState = () => {
    const { showModalSaveViewOverModal } = this.state;

    showModalSaveViewOverModal
      ? this.handleClickOpenModalSaveViewOverModal(false)
      : this.handleClickOpenModalSaveView(false);

    this.setState({ forceClosing: false, switchingBlotterApp: false });
  };

  handleRequestData = ({
    subscriptionInstanceId,
    columnDefs,
    firstRow,
    lastRow,
    newCriteria,
    gridId,
    appName,
    customFilterList,
    customSortList,
    customToggles
  }) => {
    if (!this.state.ampsConnected) return;

    const {
      currentFinUser,
      filterList,
      sortList,
      toggles,
      impersonatingUser,
      isCoverageSelected,
      isMyDeskSelected
    } = this.state;

    const fields = columnDefs.map(({ field }) => ({ field }));

    const requestCommand = {
      subscriptionInstanceId,
      firstRow,
      lastRow,
      columnDefs: fields,
      newCriteria,
      impersonatingUser: impersonatingUser ? currentFinUser : null,
      gridId,
      appName,
      filterList: customFilterList ? customFilterList : filterList,
      sortList: customSortList || sortList,
      toggles: customToggles ? customToggles : toggles,
      isCoverageSelected,
      isMyDeskSelected
    };

    this.requestHandler$.next(requestCommand);
  };

  handleMultiFilterRequest = ({ subscriptionInstanceId, gridId, appName, multiFilterFields, excludeFilter }) => {
    if (!this.state.ampsConnected) return;

    const { filterList, toggles, isCoverageSelected, isMyDeskSelected, impersonatingUser, currentFinUser } = this.state;
    const multiFilterList = filterList.filter(f => f.field !== excludeFilter);

    const requestCommand = {
      isMultiFilter: true,
      subscriptionInstanceId,
      gridId,
      appName,
      multiFilterFields,
      filterList: multiFilterList,
      toggles,
      isCoverageSelected,
      isMyDeskSelected,
      impersonatingUser: impersonatingUser ? currentFinUser : null
    };

    return requestCommand;
  };

  handleExportRequestData = ({
    subscriptionInstanceId,
    columnDefs,
    firstRow,
    lastRow,
    newCriteria,
    gridId,
    selectAllCheckboxStatus,
    selectedRowsValue,
    trigger
  }) => {
    if (!this.state.ampsConnected) return;

    const {
      currentFinUser,
      filterList,
      sortList,
      toggles,
      impersonatingUser,
      isCoverageSelected,
      isMyDeskSelected,
      columnsDictionary,
      selectedInDDLCopyTemplateName,
      userSettings
    } = this.state;
    const filterToggleEntries = filterToggleStore.entries();
    const requestCommand = {
      subscriptionInstanceId,
      firstRow,
      lastRow,
      columnDefs,
      filterList,
      sortList,
      toggles,
      newCriteria,
      impersonatingUser: impersonatingUser ? currentFinUser : null,
      gridId,
      selectAllCheckboxStatus,
      selectedRowsValue,
      isCoverageSelected,
      isMyDeskSelected,
      columnsDictionary,
      trigger,
      selectedInDDLCopyTemplateName,
      userSettings,
      filterToggleEntries
    };

    exportDataSourceService.sendMessage({
      type: exportDataSourceActions.exportDataSourceRequestData,
      payload: { requestCommand }
    });
  };

  handleCloseConnection = subscriptionInstanceId => {
    const { showMiniTicketPanel, flowBlotterMiniTicketPanelInstanceId } = this.state;

    if (subscriptionInstanceId === flowBlotterMiniTicketPanelInstanceId && !showMiniTicketPanel) return;

    flowBlotterService.sendMessage({
      type: flowBlotterActions.flowBlotterRequestUnsubscribe,
      payload: { subscriptionInstanceId }
    });
  };

  handleUnsubscribeRange = ({ subscriptionInstanceId }) =>
    flowBlotterService.sendMessage({
      type: flowBlotterActions.flowBlotterRequestUnsubscribeRange,
      payload: { subscriptionInstanceId }
    });

  setUserColumnDefinition = (selectedView, editing, switchingView) => {
    const {
      userSettings,
      columnsDictionary,
      currentFinUser,
      signedInUser,
      userEntitlement,
      impersonatedUser,
      impersonatingUser,
      currentViewName,
      filterToggles
    } = this.state;

    if (!userSettings || !columnsDictionary) return;
    if (!editing && selectedView?.ViewName === currentViewName) return;

    kvpStore.clear();
    filterToggleStore.clear();

    if (editing) {
      this.setState({
        isEditing: true,
        editingView: selectedView.ViewName,
        showModalSaveView: true
      });
      return;
    }

    flowBlotterService.clearMultiFilter();
    if (switchingView) flowBlotterService.setMultiFilterEvent(fbEvents.SWITCH_VIEW);

    const selectedViewName = getSelectedViewName(userSettings, selectedView);
    let viewSettings = settingsService.getViewSettings(userSettings, FLOW_APP_NAME, selectedViewName);
    if (!viewSettings) {
      viewSettings = settingsService.getViewSettings(userSettings, FLOW_APP_NAME, STANDARD_FLOWBLOTTER_NAME);
      this.handleSelectedView(viewSettings);
    }
    const { level3 } = impersonatingUser ? impersonatedUser : userEntitlement;
    const { isAdmin } = userEntitlement;
    const isTechOrAdmin = isTechOrAdminUser(isAdmin, level3);
    const isUserTrader = userIsTrader(userEntitlement);

    const columnDefs = integrationService.getColumnsDefinition({
      view: viewSettings,
      columnsDictionary,
      currentUser: currentFinUser,
      isTechOrAdmin,
      signedInUser
    });
    if (!columnDefs) return;

    const enhancedColumnDefs = getEnhancedColumnDefs(columnDefs, columnsDictionary, FIRSTROW_ALWAYS_CHECKBOX);

    if (shouldLoadRatings(enhancedColumnDefs)) this.loadRatings();

    const columnStateFromViewSettings = getColumnState(viewSettings, columnDefs, FIRSTROW_ALWAYS_CHECKBOX);

    const columnFilterList = getColumnFilters(viewSettings);

    const sortingFromViewSettings = getSortPriority(viewSettings);

    const dynamicSetFilters = integrationService.getFiltersByType(columnsDictionary, DYNAMIC_SET_FILTER);
    const updatedState = {};

    if (dynamicSetFilters) {
      const dynamicSetFilterColumnsFromViewSettings = getDynamicSetFilterColumns(viewSettings, dynamicSetFilters);
      if (dynamicSetFilterColumnsFromViewSettings) {
        updatedState.multiFilterList = dynamicSetFilterColumnsFromViewSettings.map(({ ColName }) => ColName);
      } else if (hasItems(this.state.multiFilterList)) {
        updatedState.multiFilterList = [];
      }
    }

    this.setFilterTogglesInStore({
      viewColumnDefs: enhancedColumnDefs,
      columnsDictionary: columnsDictionary.sourceColumnNames,
      filterToggles
    });

    this.setState(
      {
        columnDefs: enhancedColumnDefs,
        filterList: columnFilterList,
        filterFromView: columnFilterList,
        sortList: sortingFromViewSettings,
        sortListFromView: sortingFromViewSettings,
        columnState: columnStateFromViewSettings,
        currentViewName: viewSettings.ViewName,
        selectedViewIsReadOnly: viewSettings.ReadOnly,
        isTech: isTechOrAdmin,
        isSaveButtonVisible: false,
        isSettingCurrentFinUserProfile: false,
        ...updatedState,
        isUserTrader
      },
      () => {
        if (!this.FlowGridRef.current) return;

        this.FlowGridRef.current.setFilterModel();

        if (impersonatingUser || impersonatedUser || selectedView) {
          const gridOptions = { skipSetFilterModel: true };
          this.FlowGridRef.current.handleFilterModelAndSortingRecovery(gridOptions);
        }
      }
    );
  };

  loadRatings = () => {
    settingsService
      .getRatings()
      .pipe(filter(ratings => ratings))
      .subscribe(ratings => {
        const moodyRatings = ratings.filter(rating => rating.ratingsource === COLUMNS.MOODY);
        const spRatings = ratings.filter(rating => rating.ratingsource === COLUMNS.SP);
        this.setState({ ratingFilters: { moody: moodyRatings, sp: spRatings } });
      });
  };

  evalIfSaveButtonShouldAppear = prevStateColumnOrderFromGrid => {
    const { impersonatingUser, selectedViewIsReadOnly, columnOrderFromGrid } = this.state;
    if (
      (impersonatingUser !== false || selectedViewIsReadOnly) &&
      prevStateColumnOrderFromGrid !== columnOrderFromGrid
    ) {
      return true;
    }
    return false;
  };

  handleTotalRowChanged = totalRows => this.setState({ totalRows });

  handleOnToggleChange = toggleKey => {
    const { toggles } = this.state;
    const updatedToggleState = { [toggleKey]: !toggles[toggleKey] };

    flowBlotterService.clearMultiFilter();

    sharedSettingsActions.updateToggles({ updatedToggles: updatedToggleState });

    this.setState({
      selectedRows: 0,
      resetAllFiltersButtonClicked: false,
      toggles: { ...toggles, ...updatedToggleState }
    });
  };

  handleOnFilterToggleChange = stateChange => {
    const { field, toggle } = stateChange;

    const filterToggleState = filterToggleStore.get(field);
    if (filterToggleState) {
      filterToggleStore.set(field, { ...filterToggleState, toggle });
    }

    const filterToggleKey = filterToggleConfigurationMapping[field];

    const { filterToggles } = this.state;
    const updatedFilterToggleState = { [filterToggleKey]: toggle };

    flowBlotterService.clearMultiFilter();

    sharedSettingsActions.updateFilterToggles({ updatedFilterToggles: updatedFilterToggleState });

    this.setState({
      selectedRows: 0,
      resetAllFiltersButtonClicked: false,
      filterToggles: { ...filterToggles, ...updatedFilterToggleState }
    });
  };

  handleOnClickCoverage = () => {
    const { isCoverageSelected, isMyDeskSelected, userEntitlement } = this.state;
    const updatedValue = !isCoverageSelected;
    // In order to toggle Coverage OFF, My Desk cannot be OFF (meaning that My Desk must be ON)
    if (updatedValue || (!updatedValue && isMyDeskSelected)) {
      tradingDeskCoverageChoicesActions.update({
        userEntitlement,
        isCoverageSelected: updatedValue,
        isMyDeskSelected,
        usageNotes: {
          Selection: tradingDeskCoverageChoicesLabels.coverage,
          Action: updatedValue ? 'On' : 'Off'
        }
      });
      this.setState({
        isCoverageSelected: updatedValue,
        selectedRows: 0
      });
    }
  };

  handleOnClickMyDesk = () => {
    const { isMyDeskSelected, isCoverageSelected, userEntitlement } = this.state;
    const updatedValue = !isMyDeskSelected;

    // In order to toggle My Desk OFF, Coverage cannot be OFF (meaning that Coverage must be ON)
    if (updatedValue || (!updatedValue && isCoverageSelected)) {
      tradingDeskCoverageChoicesActions.update({
        userEntitlement,
        isCoverageSelected,
        isMyDeskSelected: updatedValue,
        usageNotes: {
          Selection: tradingDeskCoverageChoicesLabels.mydesk,
          Action: updatedValue ? 'On' : 'Off'
        }
      });
      this.setState({
        isMyDeskSelected: updatedValue,
        selectedRows: 0
      });
    }
  };

  setTradingDeskCoverageChoicesVisibleState = () => {
    const { userEntitlement, isTradingDeskCoverageChoicesVisible } = this.state;
    const userEntitlementTradingDeskCoverageChoicesVisible = isUserEntitledForTradingDeskCoverage(userEntitlement);

    if (userEntitlementTradingDeskCoverageChoicesVisible !== isTradingDeskCoverageChoicesVisible) {
      this.setState({ isTradingDeskCoverageChoicesVisible: userEntitlementTradingDeskCoverageChoicesVisible });
    }
  };

  getNewRecordTypeFilterList = (currentRecordtypeFilterList, selectedRecordtypeFilter) => {
    if (!currentRecordtypeFilterList || !selectedRecordtypeFilter || selectedRecordtypeFilter === recordTypes.ALL)
      return [];

    const active = currentRecordtypeFilterList.includes(selectedRecordtypeFilter);

    if (active) return currentRecordtypeFilterList.filter(element => element !== selectedRecordtypeFilter);

    const updateRecordTypeFilterList = [...currentRecordtypeFilterList, selectedRecordtypeFilter];
    const maxQTF = 3;
    const totalQTF = updateRecordTypeFilterList.length;

    return totalQTF === maxQTF ? [] : updateRecordTypeFilterList;
  };

  getRecordTypeFilterList = () => {
    const result = this.state.filterList.find(element => element.field === COLUMNS.SOURCE);
    return result?.filter || [];
  };

  setRecordTypeFilterList = (recordTypeFilterList = []) => {
    const filterInstance = this.FlowGridRef.current.gridApi.getFilterInstance(COLUMNS.SOURCE);
    if (filterInstance) {
      filterInstance.setModel(recordTypeFilterList);
    } else {
      const newFilterList = this.state.filterList.filter(element => element.field !== COLUMNS.SOURCE);

      if (recordTypeFilterList.length) {
        newFilterList.push({
          field: COLUMNS.SOURCE,
          headerName: 'Source',
          filter: recordTypeFilterList,
          filterType: 'set',
          type: ''
        });
      }

      this.setFilterList(newFilterList);
    }
  };

  setFilterTogglesInStore = ({ viewColumnDefs, columnsDictionary, filterToggles }) => {
    Object.keys(filterToggles).forEach(key => {
      if (Object.prototype.hasOwnProperty.call(filterTogglesConfiguration, key)) {
        const filterToggleConfiguration = filterTogglesConfiguration[key];
        const { field, label, breadCrumbText, instructionField } = filterToggleConfiguration;

        const viewColumnDef = viewColumnDefs.find(viewColDef => viewColDef.field === field);
        const columnDictionary = columnsDictionary.find(colDictionary => colDictionary.sourcecolumnname === field);

        if (columnDictionary) {
          let columnDefinition;

          if (viewColumnDef)
            columnDefinition =
              viewColumnDef && viewColumnDef.filterParams && viewColumnDef.filterParams.columnDefinition;

          const { codeinstruction, columntype } = columnDictionary;
          const instructions = codeinstruction[instructionField];

          filterToggleStore.set(field, {
            showToggle: true,
            toggle: filterToggles[key],
            toggleOptions: {
              field,
              label,
              breadCrumbText,
              denominator: instructions.denominator,
              decFormat: instructions.decFormat,
              exportColumnHeader: instructions.exportColumnHeader,
              columntype,
              filterType: getFilterType(columnDefinition)
            }
          });
        }
      }
    });
  };

  handleRecordTypeChange = selectedRecordtypeFilter => {
    const currentRecordtypeFilterList = this.getRecordTypeFilterList();
    const newRecordTypeFilterList = this.getNewRecordTypeFilterList(
      currentRecordtypeFilterList,
      selectedRecordtypeFilter
    );

    this.setRecordTypeFilterList(newRecordTypeFilterList);
  };

  displayCopyAndExcelBasedOnSelection = ({ rowCount }) => {
    if (Number(rowCount) > 0) {
      this.setState({ valueDisplayCopyExcel: true, selectedRows: Number(rowCount) });
    } else {
      this.setState({ valueDisplayCopyExcel: false, selectedRows: 0 });
    }
  };

  handleClickOpenModalSaveView = reload => {
    // reload happens when saving, editing or removing a view.
    if (reload) {
      this.handleReloadFlowBlotter();
    } else {
      this.setState({
        showModalSaveView: !this.state.showModalSaveView,
        isEditing: false
      });
    }
  };

  handleClickOpenModalSaveViewOverModal = reload => {
    // reload happens when saving, editing or removing a view.
    if (reload) {
      this.handleReloadFlowBlotter();
    } else {
      const { showModalSaveViewOverModal, disableColumnChooserButtons } = this.state;
      this.setState({
        showModalSaveViewOverModal: !showModalSaveViewOverModal,
        isEditing: false,
        disableColumnChooserButtons: !disableColumnChooserButtons
      });
    }
  };

  handleClickOpenModalColumnPicker = reload => {
    // reload happens when saving, editing or removing a view.
    if (reload) {
      this.handleReloadFlowBlotter();
    } else {
      this.setState({
        showModalColumnPicker: !this.state.showModalColumnPicker
      });
    }
  };

  handleCloseIconClick = () => {
    this.setState({ disableColumnChooserButtons: !this.state.disableColumnChooserButtons });
  };

  handleClickOpenModalCopyTemplate = reload => {
    // reload happens when saving, editing or removing a view.
    const { showModalCopyTemplate } = this.state;
    if (reload) {
      this.handleReloadFlowBlotter();
    } else {
      this.setState({
        showModalCopyTemplate: !showModalCopyTemplate
      });
    }
  };

  setColumnOrder = columnOrder => this.setState({ columnOrderFromGrid: columnOrder });

  setColumnOrderFromView = colFromView => this.setState({ columnOrderFromView: colFromView });

  setColumnState = columns => this.setState({ columnState: columns });

  setSelectedInDDLCopyTemplateName = ctName => this.setState({ selectedInDDLCopyTemplateName: ctName });

  closeApplicationRequest = () => {
    if (this.state.isSaveButtonVisible) {
      this.setState({ forceClosing: true });
      this.handleClickOpenModalSaveView();
    } else {
      this.handleOnCloseApplication();
    }
  };

  switchApplicationRequest = () => {
    const { isSaveButtonVisible, flowSubscriptionInstanceId, flowBlotterMiniTicketPanelInstanceId } = this.state;

    if (isSaveButtonVisible) {
      this.setState({ switchingBlotterApp: true });
      this.handleClickOpenModalSaveView();
    } else {
      // if there is no change that need to be saved
      // we will leave flow blotter, so we need to close the ws connection
      this.handleCloseConnection(flowSubscriptionInstanceId);
      this.handleCloseConnection(flowBlotterMiniTicketPanelInstanceId);
    }

    flowBlotterService.sendSwitchBlotterResponse({ unsavedChanges: isSaveButtonVisible });
  };

  handleSelectedView = (selectedView, editing) => {
    viewsActions.switch({ viewName: selectedView.ViewName });
    this.setUserColumnDefinition(selectedView, editing, true);
  };

  setCurrentViewName = viewName => this.setState({ currentViewName: viewName });

  handleUsageFilterChange = (filterList, action) => {
    const usageFilterList = mapToUsageFilterList(filterList);
    if (isEmpty(usageFilterList)) return;

    const { currentFinUser } = this.state;
    const payload = usageService.getPayload(currentFinUser, action, FLOW_APP_NAME, {
      ...usageFilterList
    });
    usageService.sendUsage(payload);
  };

  removeFilter = fieldId => {
    const newFilterList = this.state.filterList.filter(({ field }) => field !== fieldId);
    this.setFilterList(newFilterList);
  };

  isColumnlessFilter = fieldId => !this.state.columnState.find(({ colId }) => colId === fieldId);

  getColumnlessFilters = () => this.state.filterList.filter(({ field }) => this.isColumnlessFilter(field));

  setColumnsFilters = columnFilters => {
    const { filterList } = this.state;
    const columnlessFilters = this.getColumnlessFilters();
    const deletedFilters = filterList.filter(filter => !columnFilters.find(({ field }) => filter.field === field));
    deletedFilters.forEach(filter => {
      const filterUID = kvpStore.findUID(filter.field);
      if (filterUID) kvpStore.delete(filterUID);
    });
    this.setFilterList([...columnFilters, ...columnlessFilters]);
  };

  setFilterList = newFilterList => {
    const { filterList, filterFromView, ratingFilters, resetAllFiltersButtonClicked, toggles } = this.state;
    const updatedState = {};
    const updatedFilterList = resetAllFiltersButtonClicked ? [] : updateRatingFilters(newFilterList, ratingFilters);

    if (JSON.stringify(filterFromView) !== JSON.stringify(updatedFilterList)) {
      updatedState.isSaveButtonVisible = true;

      if (filterList.length <= updatedFilterList.length) {
        this.handleUsageFilterChange(updatedFilterList, ACTION_APPLY_FILTER);
      } else if (!resetAllFiltersButtonClicked) {
        const fields = new Set(updatedFilterList.map(({ field }) => field));
        const deletedFilterList = filterList.filter(({ field }) => !fields.has(field));
        this.handleUsageFilterChange(deletedFilterList, ACTION_CLEAR_FILTER);
      }
    } else {
      updatedState.isSaveButtonVisible = false;
    }

    if (resetAllFiltersButtonClicked) {
      const togglesToReset = getTogglesToReset(toggles);
      sharedSettingsActions.updateToggles({ updatedToggles: togglesToReset });
      updatedState.toggles = { ...toggles, ...togglesToReset };
      kvpStore.clear();
    }

    updatedFilterList &&
      this.setState({
        resetAllFiltersButtonClicked: false,
        filterList: updatedFilterList,
        selectedRows: 0,
        ...updatedState
      });
  };

  setSortList = oSortList => this.setState({ sortList: oSortList, selectedRows: 0 });

  handleClickResetFilter = fieldId => {
    const { currentFinUser, filterList } = this.state;
    const field = fieldId;
    const resetAllFiltersButtonClicked = !field;

    if (resetAllFiltersButtonClicked) {
      const payload = usageService.getPayload(currentFinUser, ACTION_RESET_FILTER, FLOW_APP_NAME, {});
      usageService.sendUsage(payload);
    } else {
      const deletedFilterList = filterList.filter(colFilter => colFilter.field === field);
      this.handleUsageFilterChange(deletedFilterList, ACTION_CLEAR_FILTER);
    }

    this.setState(
      { resetAllFiltersButtonClicked },
      function() {
        this.FlowGridRef.current.handleResetFilter(field);
      }.bind(this)
    );
  };

  handleClickResetSort = () => {
    this.setState({ sortList: [] }, () => {
      const gridOptions = { skipSetFilterModel: true };
      const { currentFinUser } = this.state;
      if (currentFinUser) {
        const payload = usageService.getPayload(currentFinUser, ACTION_CLEAR_SORTING, FLOW_APP_NAME, {});
        usageService.sendUsage(payload);
      }
      this.FlowGridRef.current.handleFilterModelAndSortingRecovery(gridOptions);
    });
  };

  handleExportToExcel = fetchTrigger => {
    const { columnsDictionary, columnDefs, selectAllCheckboxStatus } = this.state;
    const selectedRowsValue = [...this.checkboxList];

    this.fetchDataSubject.next({
      selectAllCheckboxStatus,
      selectedRowsValue,
      columnsDictionary,
      columnDefs,
      trigger: fetchTrigger
    });
  };

  handleExportToClipboard = () => {
    const { columnsDictionary, columnDefs, selectAllCheckboxStatus } = this.state;
    const selectedRowsValue = [...this.checkboxList];

    this.fetchDataSubject.next({
      selectAllCheckboxStatus,
      selectedRowsValue,
      columnsDictionary,
      columnDefs,
      trigger: FETCH_TRIGGERS.COPY_TO_CLIPBOARD
    });
  };

  handleStartFetchingData = () => this.fetchingStatusSubject.next(true);

  handleEndFetchingData = () => this.fetchingStatusSubject.next(false);

  handleOnCheckboxChange = (checkboxValue, selectAllCheckboxStatus, totalRows) => {
    const nextState = selectAllCheckboxNextState(checkboxValue, selectAllCheckboxStatus, totalRows, this.checkboxList);
    if (!nextState) return;

    this.checkboxList = [...nextState.checkboxList];

    this.checkboxChangesSubject.next({
      selectAllCheckboxStatus: nextState.selectAllCheckboxStatus,
      checkboxList: nextState.checkboxList
    });

    this.setState({
      selectAllCheckboxStatus: nextState.selectAllCheckboxStatus,
      selectedRows: nextState.selectedRows,
      valueDisplayCopyExcel: nextState.valueDisplayCopyExcel
    });
  };

  // Event to handle copy-template/export/save-as option from context menu
  handleContextMenuEvent = ({ sowkey, trigger }) => {
    const { columnsDictionary, columnDefs } = this.state;
    const selectedRowsValue = [sowkey]; // selected row sowkey

    this.fetchDataSubject.next({
      selectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.PARTIAL,
      selectedRowsValue,
      columnsDictionary,
      columnDefs,
      trigger
    });
  };

  handleOnFlowGridReady = () => {
    flowBlotterService.sendMessage({ type: flowBlotterActions.flowBlotterGridReadyForReceiveData });
  };

  requestMultiFilter = column => {
    const { multiFilterSourceInstanceId } = this.state;

    const multiFilterFields = [{ column, doQuery: true }];

    return this.handleMultiFilterRequest({
      subscriptionInstanceId: multiFilterSourceInstanceId,
      gridId: defaultMultiFilterFlowId,
      appName: FLOW_APP_NAME,
      multiFilterFields,
      excludeFilter: column
    });
  };

  handleReloadFlowBlotter = () => {
    const { flowSubscriptionInstanceId, flowBlotterMiniTicketPanelInstanceId } = this.state;
    this.handleCloseConnection(flowSubscriptionInstanceId);
    this.handleCloseConnection(flowBlotterMiniTicketPanelInstanceId);
    window.location.reload();
  };

  handleOnExportDataSourceReady = () =>
    exportDataSourceService.sendMessage({ type: exportDataSourceActions.exportDataSourceReadyForReceiveData });

  toggleMiniTicketPanel = () => this.setState({ showMiniTicketPanel: !this.state.showMiniTicketPanel });

  renderToggleSection = () => {
    const { toggles, userEntitlement } = this.state;
    return Object.entries(toggles)
      .filter(
        ([toggleKey]) =>
          toggleKey !== TOGGLE_ME_ONLY || showEntitlementOption(userEntitlement, uiEntitlementOptions.ME_ONLY_VISIBLE)
      )
      .map(([toggleKey, value]) => (
        <HeaderToggle
          key={toggleKey}
          onToggleChange={() => this.handleOnToggleChange(toggleKey)}
          isToggleOn={value}
          text={getToggleLabel(toggleKey)}
        />
      ));
  };

  handleBloombergCommand = (rfq, commandLabel, command = commandLabel) => {
    let { code, rfqnlegs, code_main_value, l1_code, l2_code, bbgcustchatid } = rfq;
    let cusipIsinArg;
    const { userSettings, currentFinUser } = this.state;
    const settings = settingsService.getSettings(userSettings, FLOW_APP_NAME);
    const bloombergTerminalWindow = settings.BloombergTerminalWindow || BLOOMBERG_TERMINAL_WINDOW;
    // in case if rfqnlegs > 1, if we click on main row check if code_main_value is defined for that or not else we need to assign code value to that
    code_main_value = code_main_value ? code_main_value : code;

    if (command === bloombergService.IBCHAT_COMMAND.command) {
      cusipIsinArg = !bbgcustchatid ? ' ' : isNaN(bbgcustchatid) ? bbgcustchatid : `>${bbgcustchatid}`;
    } else if (rfqnlegs === RFQNLEGS.MAIN) {
      cusipIsinArg = code;
    } else if (rfqnlegs === RFQNLEGS.L1) {
      cusipIsinArg = [code_main_value, l1_code];
    } else if (rfqnlegs === RFQNLEGS.L2) {
      cusipIsinArg = [code_main_value, l1_code, l2_code];
    }

    const listener = result => logger.log('Bloomberg integration listener. The exit code', result.exitCode);
    const onSuccess = processIdentity => logger.log(`Bloomberg ${command} command success`, processIdentity);
    const onError = err => logger.log(`Bloomberg ${command} command fail`, err);

    const bloombergOptions = { command, args: cusipIsinArg, listener, onSuccess, onError, bloombergTerminalWindow };

    const usageOptions = { commandLabel, currentFinUser };

    executeCommandWithUsage(bloombergOptions, usageOptions);
  };

  render() {
    const {
      valueDisplayCopyExcel,
      selectedRows,
      totalRows,
      columnDefs,
      toggles,
      filterToggles,
      isSaveButtonVisible,
      columnOrderFromGrid,
      showModalSaveView,
      showModalSaveViewOverModal,
      showModalColumnPicker,
      showModalCopyTemplate,
      filterList,
      sortList,
      userSettings,
      currentFinUser,
      signedInUser,
      isSettingCurrentFinUserProfile,
      impersonatingUser,
      columnOrderFromView,
      forceClosing,
      columnState,
      columnOptions,
      isEditing,
      editingView,
      currentViewName,
      columnsDictionary,
      flowSubscriptionInstanceId,
      exportDataSourceInstanceId,
      flowBlotterMiniTicketPanelInstanceId,
      isTech,
      selectedInDDLCopyTemplateName,
      userEntitlement,
      loading,
      webSocketDisconnected,
      selectAllCheckboxStatus,
      switchingBlotterApp,
      noAccess,
      isCoverageSelected,
      isMyDeskSelected,
      isTradingDeskCoverageChoicesVisible,
      disableColumnChooserButtons,
      showMiniTicketPanel,
      isUserTrader,
      theme
    } = this.state;

    if (loading) return null;
    if (!loading && !userEntitlement) return <NoAccess />;

    return (
      <div className={`flowBlotter ${isUserTrader ? 'theme-userType-trader' : ''}`}>
        <ThemeSetter theme={theme}></ThemeSetter>
        {noAccess && <NoAccess />}
        {showModalSaveView && (
          <ModalSaveView
            isEditing={isEditing}
            editingView={editingView}
            fromColumnPicker={false}
            currentView={currentViewName}
            handleClickOpenModalSaveView={this.handleClickOpenModalSaveView}
            handleClickOpenModalSaveViewOverModal={this.handleClickOpenModalSaveViewOverModal}
            handleOnCloseApplication={this.handleOnCloseApplication}
            handleOnSwitchBlotter={this.handleOnSwitchBlotter}
            userSettings={userSettings}
            currentFinUser={currentFinUser}
            columnOrderFromGrid={columnOrderFromGrid}
            columnOrderFromView={columnOrderFromView}
            forceClosing={forceClosing}
            setFilterList={this.setFilterList}
            filterList={filterList}
            columnState={columnState}
            showModalSaveViewOverModal={showModalSaveViewOverModal}
            switchingBlotterApp={switchingBlotterApp}
            sortList={sortList}
          />
        )}
        {showModalColumnPicker && (
          <ModalColumnPicker
            columnState={columnState}
            handleCloseIconClick={this.handleCloseIconClick}
            handleClickOpenModalColumnPicker={this.handleClickOpenModalColumnPicker}
            columnsDictionary={columnsDictionary}
            columnOrderFromGrid={columnOrderFromGrid}
            columnOrderFromView={columnOrderFromView}
            currentFinUser={currentFinUser}
            isTech={isTech}
            currentView={currentViewName}
            userSettings={userSettings}
            handleClickOpenModalSaveViewOverModal={this.handleClickOpenModalSaveViewOverModal}
            showModalSaveViewOverModal={showModalSaveViewOverModal}
            filterList={filterList}
            disableColumnChooserButtons={disableColumnChooserButtons}
          />
        )}
        {showModalCopyTemplate && (
          <ModalCopyTemplate
            handleClickOpenModalCopyTemplate={this.handleClickOpenModalCopyTemplate}
            columnsDictionary={columnsDictionary}
            currentFinUser={currentFinUser}
            isTech={isTech}
            userSettings={userSettings}
            setSelectedInDDLCopyTemplateName={this.setSelectedInDDLCopyTemplateName}
            selectedInDDLCopyTemplateName={selectedInDDLCopyTemplateName}
          />
        )}
        <div
          className={showModalSaveView || showModalSaveViewOverModal ? 'modal-full-blackout' : ''}
          role="button"
          tabIndex={0}
          onClick={this.resetModalState}
          onKeyPress={this.resetModalState}
        ></div>
        <div
          className={showModalColumnPicker || showModalCopyTemplate ? 'modal-full-blackout-less' : ''}
          role="button"
          tabIndex={0}
          onClick={() =>
            showModalColumnPicker
              ? this.handleClickOpenModalColumnPicker(false)
              : showModalCopyTemplate
              ? this.handleClickOpenModalCopyTemplate(false)
              : null
          }
          onKeyPress={() =>
            showModalColumnPicker
              ? this.handleClickOpenModalColumnPicker(false)
              : showModalCopyTemplate
              ? this.handleClickOpenModalCopyTemplate(false)
              : null
          }
        ></div>
        {userSettings && userSettings.Applications && (
          <FlowGridHeader
            displayCopyExcel={valueDisplayCopyExcel}
            onClickHandler={this.handleRecordTypeChange}
            handleClickOpenModalColumnPicker={() => this.handleClickOpenModalColumnPicker(false)}
            handleClickOpenModalCopyTemplate={() => this.handleClickOpenModalCopyTemplate(false)}
            filterList={filterList}
            showModalCopyTemplate={showModalCopyTemplate}
            userSettings={userSettings}
            setSelectedInDDLCopyTemplateName={this.setSelectedInDDLCopyTemplateName}
            selectedInDDLCopyTemplateName={selectedInDDLCopyTemplateName}
            currentFinUser={currentFinUser}
            exportToExcel={this.handleExportToExcel}
            exportToClipboard={this.handleExportToClipboard}
            fetchingStatusSubject$={this.fetchingStatusSubject$}
            selectedRows={selectedRows}
            processedRecordSubject$={this.processedRecordSubject$}
            TradingDeskCoverageChoicesSection={
              isTradingDeskCoverageChoicesVisible && (
                <TradingDeskCoverageChoices
                  isCoverageSelected={isCoverageSelected}
                  isMyDeskSelected={isMyDeskSelected}
                  onClickCoverage={this.handleOnClickCoverage}
                  onClickMyDesk={this.handleOnClickMyDesk}
                />
              )
            }
            TogglesSection={this.renderToggleSection()}
            FilterBarSection={
              <FilterBar
                filterList={filterList}
                sortList={sortList}
                setFilterList={this.setFilterList}
                handleClickResetFilter={this.handleClickResetFilter}
                handleClickResetSort={this.handleClickResetSort}
                handleClickOpenModalColumnPicker={() => this.handleClickOpenModalColumnPicker(false)}
                toggles={toggles}
                onToggleChange={this.handleOnToggleChange}
              />
            }
            ViewsSection={
              <ViewsList
                setCurrentViewName={this.setCurrentViewName}
                currentViewName={currentViewName}
                userSettings={userSettings}
                onSelectView={this.handleSelectedView}
              />
            }
            SaveButtonSection={
              isSaveButtonVisible && (
                <TextButton handleClick={() => this.handleClickOpenModalSaveView(false)}>SAVE</TextButton>
              )
            }
          />
        )}

        {currentFinUser ? (
          <Fragment>
            {exportDataSourceInstanceId && columnsDictionary && (
              <ExportDataSource
                gridId={exportDataSourceId}
                subscriptionInstanceId={exportDataSourceInstanceId}
                requestData={this.handleExportRequestData}
                exportDataCacheSubject={this.exportDataCacheSubject}
                fetchDataSubject$={this.fetchDataSubject$}
                startFetchingData={this.handleStartFetchingData}
                endFetchingData={this.handleEndFetchingData}
                userSettings={userSettings}
                selectedInDDLCopyTemplateName={selectedInDDLCopyTemplateName}
                onExportDataSourceReady={this.handleOnExportDataSourceReady}
                processedRecordSubject={this.processedRecordSubject}
              />
            )}

            {flowSubscriptionInstanceId && columnDefs?.length ? (
              <FlowGrid
                ref={this.FlowGridRef}
                gridId={defaultMainGridId}
                subscriptionInstanceId={flowSubscriptionInstanceId}
                isSettingCurrentFinUserProfile={isSettingCurrentFinUserProfile}
                datasource$={flowBlotterService.datasource}
                requestData={this.handleRequestData}
                closeConnection={this.handleCloseConnection}
                toggles={toggles}
                filterToggles={filterToggles}
                filterList={filterList}
                setColumnsFilters={this.setColumnsFilters}
                removeFilter={this.removeFilter}
                columnDefs={columnDefs}
                gridOptions={columnOptions}
                onRowSelection={this.displayCopyAndExcelBasedOnSelection}
                onTotalRowChanged={this.handleTotalRowChanged}
                setColumnOrder={this.setColumnOrder}
                setColumnOrderFromView={this.setColumnOrderFromView}
                columnOrderFromView={columnOrderFromView}
                setColumnState={this.setColumnState}
                columnState={columnState}
                sortList={sortList}
                setSortList={this.setSortList}
                currentFinUser={currentFinUser}
                signedInUser={signedInUser}
                impersonatingUser={impersonatingUser}
                currentViewName={currentViewName}
                userSettings={userSettings}
                webSocketDisconnected={webSocketDisconnected}
                appName={FLOW_APP_NAME}
                selectAllCheckboxStatus={selectAllCheckboxStatus}
                checkboxSubject={this.checkboxSubject}
                checkboxEvent$={this.checkboxChangesSubject$}
                contextMenuSubject={this.contextMenuSubject}
                blockAccess={this.blockAccess}
                onFlowGridReady={this.handleOnFlowGridReady}
                isCoverageSelected={isCoverageSelected}
                isMyDeskSelected={isMyDeskSelected}
                entitlement={userEntitlement}
                onUnsubscribeRange={this.handleUnsubscribeRange}
                showMiniTicketPanel={showMiniTicketPanel}
                selectedRFQsSubject$={this.selectedRFQsSubject$}
                handleBloombergCommand={this.handleBloombergCommand}
                columnsDictionary={columnsDictionary}
                theme={theme}
              />
            ) : (
              <CustomLoadingCell />
            )}
            {flowBlotterMiniTicketPanelInstanceId && columnsDictionary && columnDefs?.length && (
              <MiniTicketPanel
                columnsDictionary={columnsDictionary}
                columnDefs={columnDefs}
                selectedRFQsSubject$={this.selectedRFQsSubject$}
                toggleMiniTicketPanel={this.toggleMiniTicketPanel}
                handleBloombergCommand={this.handleBloombergCommand}
                showMiniTicketPanel={showMiniTicketPanel}
                handleRequestData={this.handleRequestData}
                closeConnection={this.handleCloseConnection}
                subscriptionInstanceId={flowBlotterMiniTicketPanelInstanceId}
                rfqRecordsMap={this.rfqRecordsMap}
              />
            )}
          </Fragment>
        ) : (
          <p>Waiting for Flow Blotter User</p>
        )}

        <FlowGridFooter selectedRows={selectedRows} totalRows={totalRows} />
      </div>
    );
  }
}

export default App;
