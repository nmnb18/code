import React, { Component } from 'react';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-enterprise';
import isEqual from 'lodash/isEqual';
import './FlowGrid.scss';
import {
  FLOW_APP_NAME,
  FIRSTROW_ALWAYS_CHECKBOX,
  AG_GRID_AUTOSAVE_INTERVAL,
  AG_GRID_FILTER_CHANGED_INTERVAL,
  columnsHavingBloombergIBChat,
  columnsHavingBloombergDataCommands,
  columnsHavingClientDetailsOption,
  columnsHavingBondDetailsOption,
  SORT_DIRECTION
} from '~helpers/globals';
import { createProxyService } from '~services/proxyService';
import { createViewportDatasource } from '~services/viewportDataSource';
import { REACT_COMPONENT_FILTER_STRING, DYNAMIC_SET_FILTER, DATETIME } from '~helpers/filters';
import {
  CalendarFilter,
  MaturityFilter,
  CustomAgGridSetFilter,
  CustomAgGridDynamicSetFilter,
  CustomAgGridTextFilter,
  CustomAgGridNumFilter,
  CustomTooltip,
  CustomAgGridHeaderTextFilter,
  CustomAgGridHeaderLabelFilter
} from '~components';
import { getAgGridFilter, getFilterList } from '~helpers/agGridFilterRecreation';
import { SELECTALL_CHECKBOX_STATE, toggleSelectAllCheckboxStatus } from '~helpers/exportHelper';
import { CheckActiveIcon, CheckDashIcon } from '~common';
import { FETCH_TRIGGERS, WS_COMMANDS, RFQNLEGS, WS_FIELDS } from '~helpers/jasperMessage';
import * as bloombergService from '~services/bloombergService';
import { defaultFilterRange } from '~helpers/proxyService';
import { usageService, ACTION_SORTING, ACTION_RIGHT_CLICK, BLOTTER_CLICK_ACTION_LABELS } from '~services/usageService';
import { showEditInquiry, showMiniTicket } from '~helpers/columnRenderer';
import { requestXiosWindowFromGrid } from '~helpers/popups';
import { isEmpty } from 'flow-navigator-shared/dist/array';
import { uiEntitlementOptions, showEntitlementOption } from '~helpers/entitlement';
import { formatDateOrTime } from '~helpers/rfqFormatters';
import { flowBlotterService } from '~services/flowBlotterService';
import { viewsActions } from '~helpers/actionCreator';
import { ROW_CLASS_RULES } from '~helpers/agGrid';
import { ErrorModal, TextButton } from '~ui-library';

const AUTOSAVE_EVENTS = {
  SORT_CHANGED: 'onSortChanged',
  DRAG_STOP: 'handleDragStopped'
};

class FlowGrid extends Component {
  proxyService;

  filterSource$ = new Subject();

  subscriptionIdSubject = new Subject();
  subscriptionIdSubject$ = this.subscriptionIdSubject.asObservable();

  autoSaveSubject = new Subject();
  autoSaveSubject$ = this.autoSaveSubject.asObservable();

  filterChange$ = new Subject();

  rfqEventHandlers = {
    [WS_COMMANDS.ENTITLEMENT_ERROR]: () => this.blockGridAccess()
  };

  state = {
    getRowNodeId: data => data.sowkey,
    headerComponentFramework: {
      CustomAgGridHeaderTextFilter: CustomAgGridHeaderTextFilter,
      CustomAgGridHeaderLabelFilter: CustomAgGridHeaderLabelFilter
    },
    components: {
      rowIdRenderer: params => '' + params.rowIndex
    },
    frameworkComponents: {
      CalendarFilter: CalendarFilter,
      MaturityFilter: MaturityFilter,
      CustomAgGridSetFilter: CustomAgGridSetFilter,
      CustomAgGridDynamicSetFilter: CustomAgGridDynamicSetFilter,
      CustomAgGridTextFilter: CustomAgGridTextFilter,
      CustomAgGridNumFilter: CustomAgGridNumFilter,
      customTooltip: CustomTooltip
    },
    flowApp: {},
    flowGridHeaderHeight: 0,
    sortingOrder: ['desc', 'asc', null],
    activeSortColumn: '',
    selectedRowCodes: new Map(),
    rowClassRules: ROW_CLASS_RULES,
    showFilterTooBigMessage: false
  };

  skipInitialSortingAssignment = true;

  componentDidMount() {
    const { userSettings } = this.props;
    const flowApp = userSettings.Applications.find(app => app.AppName === FLOW_APP_NAME);

    this.setState({ flowApp: flowApp });

    this.autoSaveSubscription = this.autoSaveSubject$
      .pipe(debounceTime(Number(AG_GRID_AUTOSAVE_INTERVAL)))
      .subscribe(() => this.handleColumnSizeAndOrderAndSortAutoSave());

    this.filterChangeSubscription = this.filterChange$
      .pipe(debounceTime(Number(AG_GRID_FILTER_CHANGED_INTERVAL)))
      .subscribe(event => this.handleFilterChange(event));
  }

  shouldComponentUpdate(nextProps, nextState) {
    if (
      this.props.gridId !== nextProps.gridId ||
      this.props.subscriptionInstanceId !== nextProps.subscriptionInstanceId ||
      this.props.isSettingCurrentFinUserProfile !== nextProps.isSettingCurrentFinUserProfile ||
      !isEqual(this.props.toggles, nextProps.toggles) ||
      !isEqual(this.props.filterToggles, nextProps.filterToggles) ||
      !isEqual(this.props.filterList, nextProps.filterList) ||
      !isEqual(this.props.columnDefs, nextProps.columnDefs) ||
      !isEqual(this.props.columnOrderFromView, nextProps.columnOrderFromView) ||
      !isEqual(this.props.columnState, nextProps.columnState) ||
      !isEqual(this.props.sortList, nextProps.sortList) ||
      this.props.currentFinUser !== nextProps.currentFinUser ||
      !isEqual(this.props.impersonatingUser, nextProps.impersonatingUser) ||
      this.props.currentViewName !== nextProps.currentViewName ||
      !isEqual(this.props.userSettings, nextProps.userSettings) ||
      this.props.webSocketDisconnected !== nextProps.webSocketDisconnected ||
      this.props.appName !== nextProps.appName ||
      this.props.selectAllCheckboxStatus !== nextProps.selectAllCheckboxStatus ||
      !isEqual(this.state.flowApp, nextState.flowApp) ||
      this.state.flowGridHeaderHeight !== nextState.flowGridHeaderHeight ||
      this.props.isCoverageSelected !== nextProps.isCoverageSelected ||
      this.props.isMyDeskSelected !== nextProps.isMyDeskSelected ||
      this.props.showMiniTicketPanel !== nextProps.showMiniTicketPanel ||
      this.state.showFilterTooBigMessage !== nextProps.showFilterTooBigMessage
    ) {
      return true;
    }

    return false;
  }

  componentDidUpdate(prevProps, prevState) {
    const {
      columnDefs: columnDefsPrev,
      filterList: filterListPrev,
      subscriptionInstanceId: subscriptionInstanceIdPrev,
      currentViewName: currentViewNamePrev,
      sortList: sortListprev,
      webSocketDisconnected: webSocketDisconnectedPrev,
      isCoverageSelected: isCoverageSelectedPrev,
      isMyDeskSelected: isMyDeskSelectedPrev,
      toggles: togglesPrev,
      filterToggles: filterTogglesPrev
    } = prevProps;

    const {
      filterList,
      columnDefs,
      subscriptionInstanceId,
      currentViewName,
      sortList,
      webSocketDisconnected,
      checkboxSubject,
      isSettingCurrentFinUserProfile,
      isCoverageSelected,
      isMyDeskSelected,
      toggles,
      filterToggles
    } = this.props;

    if (subscriptionInstanceId !== subscriptionInstanceIdPrev) {
      this.setSubscriptionInstance(subscriptionInstanceId);
    }

    if (
      !isSettingCurrentFinUserProfile &&
      (!isEqual(toggles, togglesPrev) ||
        !isEqual(filterToggles, filterTogglesPrev) ||
        !isEqual(columnDefs, columnDefsPrev) ||
        !isEqual(filterList, filterListPrev) ||
        currentViewName !== currentViewNamePrev ||
        !isEqual(sortList, sortListprev) ||
        subscriptionInstanceId !== subscriptionInstanceIdPrev ||
        isCoverageSelected !== isCoverageSelectedPrev ||
        isMyDeskSelected !== isMyDeskSelectedPrev ||
        (webSocketDisconnected !== webSocketDisconnectedPrev && !webSocketDisconnected))
    ) {
      this.filterSource$.next({ newCriteria: true });
      checkboxSubject && checkboxSubject.next({ newSelectAllCheckboxStatus: SELECTALL_CHECKBOX_STATE.UNCHECK });
    }

    if (!isEqual(columnDefs, columnDefsPrev)) {
      this.gridApi.setColumnDefs([]);
      this.gridApi.setColumnDefs(columnDefs);
    }

    const flowGridHeaderHeight = document.querySelector('.FlowGridHeader').offsetHeight;
    if (prevState.flowGridHeaderHeight !== flowGridHeaderHeight) {
      this.setState({ flowGridHeaderHeight });
    }
  }

  componentWillUnmount() {
    const { closeConnection, subscriptionInstanceId } = this.props;
    closeConnection(subscriptionInstanceId);
    this.filterSource$.unsubscribe();
    this.proxyService.disconnect();
    this.autoSaveSubscription.unsubscribe();
    this.filterChangeSubscription.unsubscribe();
  }

  setSubscriptionInstance = subscriptionInstanceId => this.subscriptionIdSubject.next(subscriptionInstanceId);

  emitAutoSaveEvent = event => this.autoSaveSubject.next(event);

  onSortChanged = event => {
    if (this.skipInitialSortingAssignment) {
      this.skipInitialSortingAssignment = false;
      return;
    }

    if (event) {
      const { setSortList, currentFinUser, impersonatingUser } = this.props;
      const sortModel = this.gridApi.getSortModel();

      if (currentFinUser && sortModel[0]) {
        const column = this.gridColumnApi.getColumn(sortModel[0].colId);
        this.setState({ activeSortColumn: column.colDef.headerName });
        const payload = usageService.getPayload(currentFinUser, ACTION_SORTING, FLOW_APP_NAME, {
          Name: column.colDef.headerName,
          Direction: SORT_DIRECTION[sortModel[0].sort]
        });
        usageService.sendUsage(payload);
      } else if (currentFinUser) {
        const { activeSortColumn } = this.state;
        if (activeSortColumn) {
          const payload = usageService.getPayload(currentFinUser, ACTION_SORTING, FLOW_APP_NAME, {
            Name: activeSortColumn,
            Direction: ''
          });
          usageService.sendUsage(payload);
        }
      }

      setSortList && setSortList(sortModel);

      !impersonatingUser && this.emitAutoSaveEvent(AUTOSAVE_EVENTS.SORT_CHANGED);
    }
  };

  handleColumnSizeAndOrderAndSortAutoSave = () => {
    const { currentViewName, columnState } = this.props;
    const sortModel = this.gridApi.getSortModel();
    viewsActions.editColumnStateAndSort({
      currentViewName,
      sortModel,
      columnState
    });
  };

  addRowCode = (sowkey, code, rfqnlegs) => {
    Boolean(sowkey) &&
      Boolean(code) &&
      this.setState(({ selectedRowCodes }) => ({
        selectedRowCodes: new Map(selectedRowCodes).set(sowkey, { code, rfqnlegs })
      }));
  };

  removeRowCode = sowkey => {
    Boolean(sowkey) &&
      this.setState(({ selectedRowCodes }) => {
        const newSelectedRowCodes = new Map(selectedRowCodes);
        newSelectedRowCodes.delete(sowkey);
        return {
          selectedRowCodes: newSelectedRowCodes
        };
      });
  };

  clearRowCodes = () => {
    this.setState({ selectedRowCodes: new Map() });
  };

  onRowSelected = event => {
    const { checkboxSubject } = this.props;
    const {
      data,
      node: { selected }
    } = event;
    selected ? this.addRowCode(data.sowkey, data.code, data.rfqnlegs) : this.removeRowCode(data.sowkey);

    checkboxSubject && checkboxSubject.next({ selectedRow: data, isRowChecked: selected });
  };

  onFilterChanged = event => {
    if (event) this.filterChange$.next(event);
  };

  handleFilterChange = params => {
    const { columnDefs, setColumnsFilters } = this.props;
    const agGridFilterModel = this.gridApi.getFilterModel();
    const filterList = getFilterList(columnDefs, agGridFilterModel);

    let skipDoQueryForMultiSelectFilterList = null;
    const { columnMetadata } = params;

    if (columnMetadata) {
      const { filterType, field, isEmpty, skipFetch } = columnMetadata;

      if (filterType === DYNAMIC_SET_FILTER) {
        skipDoQueryForMultiSelectFilterList = isEmpty ? [] : [field];
      } else if (filterType !== DYNAMIC_SET_FILTER) {
        skipDoQueryForMultiSelectFilterList = [];
      }

      if (typeof skipFetch === 'boolean' && !skipFetch) flowBlotterService.setMultiFilterField(field);
    }

    setColumnsFilters && setColumnsFilters(filterList, skipDoQueryForMultiSelectFilterList);

    //The next line removes the div generated by the filter PopUp upon filtering:
    [...document.getElementsByClassName('ag-tab-body')].map(n => n && n.remove());
    this.clearRowCodes();
  };

  toggleShowFilterTooBigMessage = value => {
    this.setState({ showFilterTooBigMessage: value });
  };

  handleOnGridReady = params => {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

    // Create proxy service
    const {
      datasource$,
      subscriptionInstanceId,
      setColumnOrderFromView,
      columnState,
      filterList,
      sortList,
      checkboxEvent$,
      columnsDictionary
    } = this.props;
    const { webSocketDisconnected } = this.state;

    const proxyOptions = {
      notifyOnViewportReady: true,
      deleteLegFieldsFromRfqRecord: true,
      notifyOnEntitlementError: true
    };

    this.proxyService = createProxyService(
      this.subscriptionIdSubject$,
      datasource$,
      this.filterSource$,
      this.handleRequestData,
      this.handleRowCountChanged,
      proxyOptions,
      checkboxEvent$,
      null, // updateConnectionStatus,
      this.handleRFQEvent,
      this.handleOnViewportReady,
      this.handleUnsubscribeRange
    );

    this.proxyService.setReferenceKeys(columnsDictionary.sourceColumnNames);

    this.setSubscriptionInstance(subscriptionInstanceId);

    const autoSelectFeatureOn = true;

    // Create viewport datasource
    const viewportDatasource = createViewportDatasource(this.proxyService, autoSelectFeatureOn);
    this.gridApi.setViewportDatasource(viewportDatasource);

    if (!webSocketDisconnected) {
      // Request initial data to the websocket (default params { firstRow: -1, lastRow: -1 })
      this.handleRequestData({ ...defaultFilterRange, newCriteria: true });
    }

    const colIds = this.gridColumnApi.getAllDisplayedColumns();
    setColumnOrderFromView && setColumnOrderFromView(colIds);

    this.gridColumnApi.setColumnState(columnState && columnState.length > 0 ? columnState : null);

    const agGridFilterModel = getAgGridFilter(filterList);
    this.gridApi.setFilterModel(agGridFilterModel);

    this.gridApi.setSortModel(sortList && sortList.length > 0 ? sortList : null);
  };

  handleRequestData = ({ firstRow, lastRow, newCriteria = false } = {}) => {
    const { subscriptionInstanceId, columnDefs, requestData, gridId, appName } = this.props;

    requestData && requestData({ subscriptionInstanceId, columnDefs, firstRow, lastRow, newCriteria, gridId, appName });
  };

  handleUnsubscribeRange = () => {
    const { subscriptionInstanceId, onUnsubscribeRange } = this.props;

    onUnsubscribeRange && onUnsubscribeRange({ subscriptionInstanceId });
  };

  handleRowCountChanged = totalRows => {
    const { onTotalRowChanged } = this.props;
    onTotalRowChanged && onTotalRowChanged(totalRows);
  };

  handleOnDragStopped = params => {
    const { setColumnOrder, setColumnState, impersonatingUser } = this.props;
    const colIds = params.columnApi.getAllDisplayedColumns();
    setColumnOrder && setColumnOrder(colIds);
    setColumnState && setColumnState(params.columnApi.getColumnState());

    !impersonatingUser && this.emitAutoSaveEvent(AUTOSAVE_EVENTS.DRAG_STOP);
  };

  handleResetFilter = fieldId => {
    if (!this.gridApi || !this.gridColumnApi) return;
    const { columnState, filterList, removeFilter } = this.props;
    this.gridColumnApi.setColumnState(columnState && columnState.length > 0 ? columnState : null);

    if (isEmpty(filterList) || !fieldId) {
      flowBlotterService.clearMultiFilter();
      this.gridApi.setFilterModel(null);
      const agGridFilterModel = this.gridApi.getFilterModel();

      if (!agGridFilterModel || !Object.keys(agGridFilterModel).length) {
        this.props.setColumnsFilters([]);
        [...document.getElementsByClassName('ag-tab-body')].map(n => n && n.remove());
        this.clearRowCodes();
      }
      return;
    }

    const column = columnState.find(({ colId }) => colId === fieldId);

    if (!column) {
      flowBlotterService.clearMultiFilter();
      removeFilter(fieldId);
    } else {
      const filterInstance = this.gridApi.getFilterInstance(fieldId);
      if (!filterInstance) return;

      flowBlotterService.clearMultiFilter();
      filterInstance.setModel(null);

      if (!this.isCustomFilter(filterInstance)) {
        filterInstance.applyModel();
      }

      this.gridApi.onFilterChanged();
    }
  };

  handleFilterModelAndSortingRecovery = (
    options = {
      skipSetColumnState: false,
      skipSetFilterModel: false,
      skipSetSortModel: false
    }
  ) => {
    if (this.gridColumnApi) {
      if (!options.skipSetColumnState) {
        const { columnState } = this.props;
        this.gridColumnApi.setColumnState(columnState && columnState.length > 0 ? columnState : null);
      }
    }

    if (this.gridApi) {
      if (!options.skipSetFilterModel) {
        const { filterList } = this.props;
        const agGridFilterModel = getAgGridFilter(filterList);
        this.gridApi.setFilterModel(agGridFilterModel);
      }
      if (!options.skipSetSortModel) {
        const { sortList } = this.props;
        if (sortList && sortList.length === 0) {
          this.setState({ activeSortColumn: '' });
        }
        this.gridApi.setSortModel(sortList && sortList.length > 0 ? sortList : null);
      }
    }
  };

  setFilterModel = () => {
    if (this.gridApi) {
      const { filterList } = this.props;
      const agGridFilterModel = getAgGridFilter(filterList);
      this.gridApi.setFilterModel(agGridFilterModel);
    }
  };

  isCustomFilter = filterInstance => Object.keys(filterInstance).includes(REACT_COMPONENT_FILTER_STRING);

  isValidFilter = array => {
    return array.filter.length > 0 && array.filter[0] !== '';
  };

  handleChangeCheckboxSelectAll = () => {
    const { checkboxSubject, selectAllCheckboxStatus } = this.props;
    const newSelectAllCheckboxStatus = toggleSelectAllCheckboxStatus(selectAllCheckboxStatus);
    checkboxSubject && checkboxSubject.next({ newSelectAllCheckboxStatus });

    this.gridApi.forEachNode(node => {
      const isChecked = newSelectAllCheckboxStatus === SELECTALL_CHECKBOX_STATE.CHECK;
      node.setSelected(isChecked);
    });
  };

  handleRFQEvent = rfqEvent => {
    const { type, data } = rfqEvent;

    const rfqEventHandler = this.rfqEventHandlers[type];
    rfqEventHandler && rfqEventHandler(data);
  };

  blockGridAccess = () => {
    const { blockAccess } = this.props;
    blockAccess();
  };

  getSelectAllCheckboxLabel = status => {
    switch (status) {
      case SELECTALL_CHECKBOX_STATE.UNCHECK:
        return '';
      case SELECTALL_CHECKBOX_STATE.CHECK:
        return <CheckActiveIcon />;
      case SELECTALL_CHECKBOX_STATE.DASH:
        return <CheckDashIcon />;
      case SELECTALL_CHECKBOX_STATE.PARTIAL:
        return '';
      default:
        return '';
    }
  };

  handleContextMenuUsage = action => {
    usageService.sendUsage({
      userAction: ACTION_RIGHT_CLICK,
      notes: { Selection: action, RecordCount: 1 }
    });
  };

  getDetailsOption = (
    { showClientDetails, showBondDetails },
    { colId, currentFinUser, idmonikerclient, code, value, ticker, signedInUser }
  ) => {
    const detailsOption = [];

    const launchPopup = () => {
      requestXiosWindowFromGrid(
        {
          target: {
            paramField: colId,
            paramMonikerClient: idmonikerclient,
            paramIsin: code,
            ticker: ticker
          }
        },
        currentFinUser,
        signedInUser
      );

      usageService.sendUsage({
        userAction: ACTION_RIGHT_CLICK,
        notes: {
          Selection: BLOTTER_CLICK_ACTION_LABELS[colId],
          Name: value
        }
      });
    };

    if (showClientDetails) {
      detailsOption.push({
        name: CLIENT_DETAILS,
        action: launchPopup
      });
    }

    if (showBondDetails) {
      detailsOption.push({
        name: BOND_DETAILS,
        action: launchPopup
      });
    }

    return detailsOption;
  };

  getInquiryOptions = ({ showEditInquiry }, { colId, currentFinUser, id, value, signedInUser }) => {
    const inquiryOptions = [];

    const launchPopup = () => {
      requestXiosWindowFromGrid(
        {
          target: {
            paramField: 'statusstr',
            paramId: id
          }
        },
        currentFinUser,
        signedInUser
      );
      usageService.sendUsage({
        userAction: ACTION_RIGHT_CLICK,
        notes: {
          Selection: BLOTTER_CLICK_ACTION_LABELS[colId],
          Name: value
        }
      });
    };

    if (showEditInquiry) {
      inquiryOptions.push({
        name: EDIT_INQUIRY,
        action: launchPopup
      });
    }

    return inquiryOptions;
  };

  createExportOption = (name, trigger, sowkey) => ({
    name: name,
    action: () => {
      this.props.contextMenuSubject && this.props.contextMenuSubject.next({ sowkey, trigger });
      this.handleContextMenuUsage(name);
    }
  });

  getDefaultOptions = (value, data, colId) => {
    const { columnsDictionary } = this.props;
    const { COPY_TO_CLIPBOARD, EXPORT_TO_EXCEL_AND_OPEN, EXPORT_TO_EXCEL_AS_DOWNLOAD } = FETCH_TRIGGERS;
    const { sowkey } = data;
    const copyTemplateOption = this.createExportOption(COPY_TEMPLATE, COPY_TO_CLIPBOARD, sowkey);
    const exportToExcelAndOpenOption = this.createExportOption(EXCEL_EXPORT, EXPORT_TO_EXCEL_AND_OPEN, sowkey);
    const exportToExcelAndSaveOption = this.createExportOption(SAVE_AS, EXPORT_TO_EXCEL_AS_DOWNLOAD, sowkey);
    const colDef = columnsDictionary.sourceColumnNames.find(({ sourcecolumnname }) => sourcecolumnname === colId);
    const copyOption = {
      name: COPY,
      action: () => {
        const { columntype, formatinstruction } = colDef;
        let dynamicTextarea = document.createElement('textarea');
        dynamicTextarea.innerText =
          columntype === DATETIME ? formatDateOrTime(value, formatinstruction.dateFormat) : value;
        document.body.appendChild(dynamicTextarea);
        dynamicTextarea.select();
        document.execCommand('Copy');
        dynamicTextarea.remove();
        this.handleContextMenuUsage(COPY);
      }
    };

    return [copyOption, copyTemplateOption, SEPARATOR, exportToExcelAndOpenOption, exportToExcelAndSaveOption];
  };

  createBloombergOption = (rfqData, commandLabel, command = commandLabel) => ({
    name: commandLabel,
    action: () => this.props.handleBloombergCommand(rfqData, commandLabel, command)
  });

  getBloombergOptions = (rfqData, commands) => {
    return [...commands].map(command => this.createBloombergOption(rfqData, command));
  };

  getContextMenuItems = params => {
    if (!params.column || !params.node.data) return;

    const {
      value,
      column: { colId },
      node: { selected: recordIsSelected }
    } = params;
    const data = { ...params.node.data };
    const { id, recordtype, mymarketidformatted } = data;
    const { currentFinUser, signedInUser, entitlement, selectedRFQsSubject$ } = this.props;
    const showXiosPopup = showEntitlementOption(entitlement, uiEntitlementOptions.XIOS_POPUP_VISIBLE);
    const showClientDetails = showXiosPopup && columnsHavingClientDetailsOption.includes(colId);
    const showBondDetails = showXiosPopup && columnsHavingBondDetailsOption.includes(colId);
    const showBloombergIBChat = columnsHavingBloombergIBChat.includes(colId);
    const showBloombergDataCommands = columnsHavingBloombergDataCommands.includes(colId);
    const showEditInquiryOption = showEditInquiry({ id, recordtype, mymarketidformatted });
    const showMiniTicketPanel = showMiniTicket({ recordtype, mymarketidformatted });

    const contextMenuItems = [...this.getDefaultOptions(value, data, colId)];

    if (showEditInquiryOption) {
      const inquiryOptions = this.getInquiryOptions(
        { showEditInquiry: showEditInquiryOption },
        { colId, currentFinUser, id, value, signedInUser }
      );
      inquiryOptions.length && contextMenuItems.push(SEPARATOR, ...inquiryOptions);
    }

    if (showClientDetails || showBondDetails) {
      const { idmonikerclient, code, ticker } = data;
      const detailsOption = this.getDetailsOption(
        { showClientDetails, showBondDetails },
        { colId, currentFinUser, idmonikerclient, code, value, ticker, signedInUser }
      );
      detailsOption.length && contextMenuItems.push(SEPARATOR, ...detailsOption);
    }

    if (showMiniTicketPanel) {
      contextMenuItems.push(SEPARATOR, {
        name: MINI_TICKET,
        action: () => {
          selectedRFQsSubject$.next({
            [WS_FIELDS.KEY_ID_RFQ_GROUP]: data?.[WS_FIELDS.KEY_ID_RFQ_GROUP],
            [WS_FIELDS.RECORD_TYPE]: data?.[WS_FIELDS.RECORD_TYPE],
            [WS_FIELDS.MY_MARKET_ID_FORMATTED]: data?.[WS_FIELDS.MY_MARKET_ID_FORMATTED]
          });
        }
      });
    }

    if (showBloombergIBChat) {
      const { label, command } = bloombergService.IBCHAT_COMMAND;
      const ibChatItem = this.createBloombergOption(data, label, command);
      contextMenuItems.push(SEPARATOR, ibChatItem);
    }

    if (showBloombergDataCommands) {
      const { rfqnlegs } = data;
      const { selectedRowCodes } = this.state;

      // default options
      const commands = Object.values(bloombergService.DATA_COMMANDS)
        .filter(command => command.legs === rfqnlegs)
        .map(command => command.command);
      const bloombergOptions = this.getBloombergOptions(data, commands);
      bloombergOptions.length && contextMenuItems.push(SEPARATOR, ...bloombergOptions);

      // two single LEG options checked
      if (recordIsSelected && rfqnlegs === RFQNLEGS.MAIN) {
        if (selectedRowCodes.size === 2) {
          let selectedRows = [];
          selectedRowCodes.forEach(data => {
            selectedRows.push(data);
          });
          const allAreSingleLegs = selectedRows.every(row => row.rfqnlegs === RFQNLEGS.MAIN);
          if (allAreSingleLegs) {
            const firstNodeCode = selectedRows[0].code;
            const secondNodeCode = selectedRows[1].code;

            const commandLabel = bloombergService.DATA_COMMANDS.SS.command;
            const data = {
              code: firstNodeCode,
              rfqnlegs: RFQNLEGS.L1,
              code_main_value: firstNodeCode,
              l1_code: secondNodeCode
            };
            const SSData = {
              name: commandLabel,
              action: () => this.props.handleBloombergCommand(data, commandLabel)
            };
            contextMenuItems.push(SEPARATOR, SSData);
          }
        }
      }
    }
    return contextMenuItems;
  };

  handleOnViewportReady = () => {
    const { onFlowGridReady } = this.props;
    onFlowGridReady && onFlowGridReady();
  };

  render() {
    const { gridId, columnDefs, gridOptions, selectAllCheckboxStatus, showMiniTicketPanel } = this.props;
    const {
      getRowNodeId,
      headerComponentFramework,
      components,
      frameworkComponents,
      flowGridHeaderHeight,
      sortingOrder,
      rowClassRules
    } = this.state;
    const miniTicketHeight = 324;
    const checkboxLabel = this.getSelectAllCheckboxLabel(selectAllCheckboxStatus);
    const correctionDelta = 24;
    const heightCorrection =
      (showMiniTicketPanel ? flowGridHeaderHeight + miniTicketHeight : flowGridHeaderHeight) + correctionDelta;
    const gridHeight = `calc(100vh - ${heightCorrection}px`;
    const gridContainerClassName = showMiniTicketPanel
      ? 'grid-container ag-theme-balham ag-theme-balham--panel-active'
      : 'grid-container ag-theme-balham';
    return (
      <div>
        <ErrorModal
          isOpen={this.state.showFilterTooBigMessage}
          onDismiss={() => {
            this.toggleShowFilterTooBigMessage(false);
          }}
          content="This filter cannot be applied as it exceeds maximum connection size. Please choose fewer options or remove other filters."
          controls={<TextButton handleClick={() => this.toggleShowFilterTooBigMessage(false)}>OK</TextButton>}
        />
        {FIRSTROW_ALWAYS_CHECKBOX && (
          <div className={'absolute-selectall__container'}>
            <div
              className={`absolute-selectall__checkbox ${selectAllCheckboxStatus?.toLowerCase()}`}
              role="button"
              tabIndex={0}
              onClick={this.handleChangeCheckboxSelectAll}
              onKeyPress={this.handleChangeCheckboxSelectAll}
            >
              {checkboxLabel}
            </div>
          </div>
        )}
        <div className={gridContainerClassName} style={{ height: gridHeight }}>
          <AgGridReact
            id={gridId}
            rowSelection="multiple"
            rowModelType="viewport"
            getRowNodeId={getRowNodeId}
            headerComponentFramework={headerComponentFramework}
            components={components}
            frameworkComponents={frameworkComponents}
            onGridReady={this.handleOnGridReady}
            columnDefs={columnDefs}
            gridOptions={gridOptions}
            onRowSelected={this.onRowSelected}
            onDragStopped={this.handleOnDragStopped}
            onFilterChanged={this.onFilterChanged}
            onSortChanged={this.onSortChanged}
            suppressMenuHide={true}
            getContextMenuItems={this.getContextMenuItems}
            suppressRowClickSelection={true}
            sortingOrder={sortingOrder}
            rowClassRules={rowClassRules}
            toggleShowFilterTooBigMessage={this.toggleShowFilterTooBigMessage}
          />
        </div>
      </div>
    );
  }
}

const COPY = 'Copy';
const COPY_TEMPLATE = 'Copy with Template';
const SEPARATOR = 'separator';
const EXCEL_EXPORT = 'Export to Excel';
const SAVE_AS = 'Save as Excel';
const CLIENT_DETAILS = 'Client Details';
const BOND_DETAILS = 'Bond Details';
const EDIT_INQUIRY = 'Edit Inquiry';
const MINI_TICKET = 'View Mini Ticket';

export default FlowGrid;
