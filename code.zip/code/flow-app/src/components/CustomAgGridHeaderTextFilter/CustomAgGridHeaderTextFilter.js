import React, { Component } from 'react';
import { filter } from 'rxjs/operators';
import { hasFilterChanged, hasDenominator } from '~helpers/filters';
import { CustomFilterFactory } from '~patterns/factory-method/customFilter';
import { SORT_ASC, SORT_DESC } from '~helpers/sort';
import { TriangleIcon } from '~components/common';
import filterIcon from '~assets/icon/util/filter.svg';
import menuIcon from '~assets/icon/util/menu.svg';
import styles from './CustomAgGridHeaderTextFilter.module.scss';
import { KEYS } from '~helpers/keyCodes';
import { FILTER_MODEL_SET, FILTER_MODEL_DYNAMIC_SET, FILTER_MODEL_NUMBER } from '~helpers/filterModelTypes';
import { parseSetValue } from '~helpers/filterOptionsParser';
import { hasItems } from 'flow-navigator-shared/dist/array';
import { kvpStore, formatUID } from '~patterns/singleton/kvpStore';
import { flowBlotterService } from '~services/flowBlotterService';
import { filterToggleStore } from '~patterns/singleton/filterToggleStore';
import { formatNumber, isNotEmpty } from '~helpers/number';

class CustomAgGridHeaderTextFilter extends Component {
  constructor(props) {
    super(props);

    const filterUID = formatUID(props.agGridReact.props.id, 'CustomAgGridHeaderTextFilter', props.column.colId);
    // initialValue: start with an empty string
    let initialValue = '';

    let initialFilterToggleState = {};

    const storeValue = kvpStore.get(filterUID);
    if (storeValue) {
      initialValue = storeValue;
    } else {
      const models = props.api.getFilterModel();
      if (models[props.column.colId]) {
        const model = models[props.column.colId];
        // initialValue: or if this column has a filter applied use its value instead of an empty string
        initialValue = model.filterType === FILTER_MODEL_DYNAMIC_SET ? model.textFilter : model.filter;
      }
    }

    if (hasDenominator(props.column.colDef)) {
      // initialValue: check store to see if column has a transformer applied and set state accordingly
      const filterToggleState = filterToggleStore.get(props.column.colId);
      if (filterToggleState) {
        const { showToggle, toggle, toggleOptions } = filterToggleState;

        initialFilterToggleState = {
          showToggle,
          toggle,
          toggleOptions,
          maskValue: toggle && initialValue ? parseFloat(initialValue) / toggleOptions.denominator : initialValue
        };
      }
    }

    this.state = {
      value: initialValue,
      maskValue: initialValue,
      sort: null,
      isFilterActive: false,
      filterUID,
      ...initialFilterToggleState
    };

    this.props = props;
    const { column } = props;

    this.props.column.addEventListener('sortChanged', this.onSortChanged);
    this.props.column.addEventListener('filterChanged', this.onFilterChanged);
    this.filterToggleChangeSubscription = filterToggleStore.stateChanges$
      .pipe(filter(({ field }) => field === column.colId))
      .subscribe(this.handleOnFilterToggleChange);
  }

  componentDidMount() {
    const {
      column: { sort }
    } = this.props;
    if (sort) {
      this.onSortChanged();
    }
  }

  componentWillUnmount() {
    this.props.column.removeEventListener('sortChanged', this.onSortChanged);
    this.props.column.removeEventListener('filterChanged', this.onFilterChanged);
    this.filterToggleChangeSubscription && this.filterToggleChangeSubscription.unsubscribe();
  }

  getReactContainerClasses() {
    return ['custom-header-text-box-filter'];
  }

  handleOnFilterToggleChange = () => {
    const { column, api } = this.props;
    const filterToggleState = filterToggleStore.get(column.colId);
    if (filterToggleState) {
      const { showToggle, toggle, toggleOptions } = filterToggleState;

      if (toggleOptions.filterType === FILTER_MODEL_NUMBER) {
        const { value } = this.state;

        const newValue = formatNumber(value) ?? '';
        const updatedState = { value: newValue, maskValue: newValue };

        if (showToggle) {
          if (isNotEmpty(newValue) || !isNaN(parseFloat(newValue))) {
            const models = api.getFilterModel();
            const model = models[column.colId];
            const currentValueIsActiveFilter = model?.filter === newValue;

            if (toggle) {
              updatedState.maskValue = currentValueIsActiveFilter ? newValue / toggleOptions.denominator : newValue;
              updatedState.value = currentValueIsActiveFilter ? newValue : newValue * toggleOptions.denominator;
            } else {
              updatedState.maskValue = currentValueIsActiveFilter ? newValue : newValue / toggleOptions.denominator;
              updatedState.value = currentValueIsActiveFilter ? newValue : newValue / toggleOptions.denominator;
            }
          }

          updatedState.showToggle = showToggle;
          updatedState.toggle = toggle;
          updatedState.toggleOptions = toggleOptions;
        }

        this.setState(updatedState);
      }
    }
  };

  handleKeyDown = e => {
    if (e.keyCode === KEYS.ENTER) {
      e.preventDefault();
      const { value } = this.state;
      if (value) this.handleFiltering(value);
    } else if (e.keyCode === KEYS.BACKSPACE) {
      const { value } = this.state;
      if (value) this.handleResetFilter();
    }
  };

  handleOnChange = e => {
    const renderedValue = e.target.value;
    let newRealValue = renderedValue;
    if (!renderedValue) {
      this.handleResetFilter();
    } else {
      const updatedState = { value: renderedValue, maskValue: renderedValue };
      if (hasDenominator(this.props.column.colDef)) {
        const { showToggle, toggle, toggleOptions } = this.state;
        if (toggleOptions && toggleOptions.filterType === FILTER_MODEL_NUMBER) {
          if (showToggle && toggle) {
            newRealValue = renderedValue * toggleOptions.denominator;
            updatedState.value = newRealValue;
          }
        }
      }

      kvpStore.set(this.state.filterUID, newRealValue);
      this.setState(updatedState);
    }
  };

  handleFiltering = value => {
    const { column, api } = this.props;

    const filterInstance = api.getFilterInstance(column.colId);
    if (!filterInstance) return;

    const model = filterInstance.getModel();
    if (model) {
      if (!hasFilterChanged(model, value)) return;

      if (model.filterType === FILTER_MODEL_DYNAMIC_SET) {
        const fetchFilterOptions = hasItems(model.arrayFilter) && !model.textFilter;
        const modelCopy = { ...model, textFilter: value, arrayFilter: [], fetchFilterOptions, skipFetch: true };
        filterInstance.setModel(modelCopy);
      } else if (model.filterType === FILTER_MODEL_SET) {
        const { values } = filterInstance.componentInstance.props;
        const filter = parseSetValue(value, values);
        filterInstance.setModel(filter);
      } else {
        model.filter = value;
        filterInstance.setModel(model);
      }
    } else {
      const newFilter = new CustomFilterFactory().createCustomFilter(column.colDef, value);

      if (newFilter.filterType === FILTER_MODEL_SET) {
        filterInstance.setModel(newFilter.filter);
      } else if (newFilter.filterType === FILTER_MODEL_DYNAMIC_SET) {
        const newModelCopy = { ...newFilter, skipFetch: true };
        filterInstance.setModel(newModelCopy);
      } else {
        filterInstance.setModel(newFilter);
      }
    }
  };

  handleResetFilter = () => {
    const { column, api } = this.props;
    const filterInstance = api.getFilterInstance(column.colId);
    if (!filterInstance) return;

    const model = filterInstance.getModel();
    if (model) filterInstance.setModel(null);

    kvpStore.delete(this.state.filterUID);
    flowBlotterService.clearMultiFilter();

    this.setState({ value: '', maskValue: '', isFilterActive: false });
  };

  handleSorting = order => {
    this.props.setSort(order);
  };

  onFilterChanged = () => {
    const { column, api } = this.props;
    const filterInstance = api.getFilterInstance(column.colId);
    if (!filterInstance) return;

    const model = filterInstance.getModel();
    if (!model) {
      kvpStore.delete(this.state.filterUID);
      this.setState({ value: '', maskValue: '', isFilterActive: false });
    } else {
      const isFilterActive = column.isFilterActive();
      let showToggle, toggle, toggleOptions;
      const filterToggleState = filterToggleStore.get(column.colId);
      if (filterToggleState) {
        showToggle = filterToggleState.showToggle;
        toggle = filterToggleState.toggle;
        toggleOptions = filterToggleState.toggleOptions;
      }

      let newValue = model.filterType === FILTER_MODEL_DYNAMIC_SET ? model.textFilter : model.filter;
      const updatedState = { value: newValue, maskValue: newValue, isFilterActive };

      let newMaskValue = newValue;

      if (model.filterType === FILTER_MODEL_NUMBER) {
        if (showToggle) {
          if (toggle) {
            newMaskValue = newValue / toggleOptions.denominator;
          } else {
            newMaskValue = newValue;
          }

          updatedState.maskValue = newMaskValue;
          updatedState.showToggle = showToggle;
          updatedState.toggle = toggle;
          updatedState.toggleOptions = toggleOptions;
        }
      }

      kvpStore.set(this.state.filterUID, newValue);
      this.setState(updatedState);
    }
  };

  onSortChanged = () => {
    this.forceUpdate();
  };

  renderTextBox = () => {
    const { maskValue } = this.state;
    const { column, displayName } = this.props;

    return (
      <input
        data-testid={`header-${column.colId}`}
        className={styles['header-text-filter__textbox']}
        type="text"
        placeholder={displayName}
        value={maskValue}
        onKeyDown={this.handleKeyDown}
        onChange={this.handleOnChange}
      />
    );
  };

  renderSortingIcon = () => {
    const { sort } = this.state;
    const { column } = this.props;
    const sortDir = sort || column.sort;
    if (sortDir === SORT_DESC) {
      return <TriangleIcon small />;
    } else if (sortDir === SORT_ASC) {
      return <TriangleIcon small inverted />;
    } else {
      return null;
    }
  };

  renderFilteringIcon = () =>
    this.state.isFilterActive ? <img className="filter-icon" src={filterIcon} alt="Active Filter" /> : null;

  renderMenuButton = () => (
    <div
      className="menu-button"
      role="button"
      tabIndex={0}
      ref={ref => (this.menuButton = ref)}
      onClick={() => this.props.showColumnMenu(this.menuButton)}
      onKeyPress={() => this.props.showColumnMenu(this.menuButton)}
    >
      <img className="menu-icon" src={menuIcon} alt="Menu" />
    </div>
  );

  render() {
    return (
      <div className={styles['header-text-filter']}>
        <div className={styles['header-text-filter__wrapper-textbox']}>
          {this.renderTextBox()}
          {this.renderFilteringIcon()}
          {this.renderSortingIcon()}
        </div>
        <div className={styles['header-text-filter__wrapper-options']}>{this.renderMenuButton()}</div>
      </div>
    );
  }
}

export default CustomAgGridHeaderTextFilter;
