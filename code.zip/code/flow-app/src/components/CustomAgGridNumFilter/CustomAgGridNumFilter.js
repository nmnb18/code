import React, { Component } from 'react';
import { SortingMenu, CustomAgGridNumFilterModal, HeaderToggle } from '~components';
import { moveFilterComponentToTheLeft, focusTextBox } from '~helpers/customFilterArrangement';
import { FILTER_TYPES, getNumModelValue, NUM_FILTER } from '~helpers/filters';
import { isNull } from '~helpers/dataTypes';
import { FILTER_MODEL_NUMBER } from '~helpers/filterModelTypes';
import { filterToggleStore } from '~patterns/singleton/filterToggleStore';
import styles from './CustomAgGridNumFilter.module.scss';

class CustomAgGridNumFilter extends Component {
  constructor(props) {
    super(props);

    this.state = {
      filter: null,
      filterTo: null,
      filterType: FILTER_TYPES.EQUALS,
      direction: props.column.getSort(),
      showToggle: false,
      toggle: false,
      toggleOptions: null
    };

    this.myRef = React.createRef();
  }

  handleFilterChange = (num, numTo, numType) => {
    const {
      filterChangedCallback,
      colDef: { field }
    } = this.props;
    const { filter } = this.state;

    if (isNull(filter) && isNull(num)) {
      filterChangedCallback();
      return;
    }

    this.setState(
      {
        filter: num,
        filterTo: numTo,
        filterType: numType
      },
      () => {
        filterChangedCallback({
          columnMetadata: {
            filterType: NUM_FILTER,
            field
          }
        });
      }
    );
  };

  getModel = () => {
    const { filter, filterTo, filterType } = this.state;
    const { colDef } = this.props;

    if (filter !== null) {
      return {
        field: colDef.field,
        headerName: colDef.headerName,
        filter: filter,
        filterTo: filterTo,
        filterType: FILTER_MODEL_NUMBER,
        type: filterType
      };
    } else {
      return undefined;
    }
  };

  setModel = model => {
    const {
      filterChangedCallback,
      colDef: {
        field,
        filterParams: { columnDefinition }
      }
    } = this.props;

    this.setState(
      {
        filter: getNumModelValue(model, columnDefinition),
        filterTo: model ? (model.filterTo && model.filterTo.trim() !== '' ? Number(model.filterTo) : null) : null,
        filterType: model ? model.type : FILTER_TYPES.EQUALS
      },
      () => {
        filterChangedCallback({
          columnMetadata: {
            filterType: NUM_FILTER,
            field
          }
        });
      }
    );
  };

  isFilterActive = () => {
    return this.state.filter !== null;
  };

  afterGuiAttached = () => {
    const customFilterContainer = this.myRef.current;
    const {
      colDef: { field }
    } = this.props;

    const filterToggleState = filterToggleStore.get(field);
    if (filterToggleState) {
      const { showToggle, toggle, toggleOptions } = filterToggleState;
      this.setState({ showToggle, toggle, toggleOptions });
    }

    if (customFilterContainer) {
      focusTextBox(customFilterContainer);
      moveFilterComponentToTheLeft(customFilterContainer);
    }
  };

  handleToggleChange = toggle => {
    const {
      colDef: { field }
    } = this.props;

    this.setState({ toggle }, () => {
      filterToggleStore.handleStateChange({ field, toggle });
    });
  };

  setDirection = direction => {
    const { column, api } = this.props;
    const multisort = false;
    api.sortController.setSortForColumn(column, direction, multisort);
    this.setState({ direction });
  };

  render() {
    const { direction, showToggle, toggle, toggleOptions } = this.state;
    const { sortable } = this.props;

    return (
      <div ref={this.myRef} className={styles['number-filter']}>
        <CustomAgGridNumFilterModal
          column={this.props.column}
          api={this.props.api}
          onFilterChange={this.handleFilterChange}
          sortingMenu={sortable ? <SortingMenu direction={direction} setDirection={this.setDirection} /> : null}
          showToggle={showToggle}
          toggle={toggle}
          toggleOptions={toggleOptions}
          toggleFilter={
            showToggle ? (
              <div className={styles['toggle-wrapper']}>
                <HeaderToggle
                  toggleClass={styles['toggle-label']}
                  onToggleChange={() => this.handleToggleChange(!toggle)}
                  isToggleOn={toggle}
                  text={toggleOptions.label}
                />
              </div>
            ) : null
          }
        />
      </div>
    );
  }
}

export default CustomAgGridNumFilter;
