import React, { Component } from 'react';
import styles from './CopyModule.module.scss';
import { FLOW_APP_NAME, EXPORT_COPY_LIMIT } from '~helpers/globals';
import * as settingsService from '~services/settingsService';
import { KEYS } from '~helpers/keyCodes';
import { IconButton } from '~ui-library';
import { ReactComponent as SettingsIcon } from '~assets/icon/util/settings.svg';
import { copyActions } from '~helpers/actionCreator';
class CopyModule extends Component {
  constructor(props) {
    super(props);
    this.selfRef = React.createRef();
    this.selectRef = React.createRef();
  }

  state = {
    inputDefaultIsChecked: false,
    currentCopyTemplateName: null,
    copyTemplateList: [],
    currentCopyTemplate: null,
    flowApp: {}
  };

  componentDidMount() {
    const { userSettings, selectedInDDLCopyTemplateName, setSelectedInDDLCopyTemplateName } = this.props;
    const flowApp = userSettings.Applications.find(app => app.AppName === FLOW_APP_NAME);

    if (userSettings) {
      const defaultCopyTemplateName = settingsService.getDefaultCopyTemplateName(userSettings, FLOW_APP_NAME);
      const copyTemplateList = settingsService.getCopyTemplatesList(userSettings, FLOW_APP_NAME);
      const defaultCopyTemplate =
        defaultCopyTemplateName &&
        copyTemplateList &&
        copyTemplateList.find(copyTemplate => copyTemplate.CopyTemplateName === defaultCopyTemplateName);
      defaultCopyTemplateName && this.setCurrentCopyTemplateName(defaultCopyTemplateName);
      copyTemplateList && this.setCopyTemplateList(copyTemplateList);
      defaultCopyTemplate && this.setCopyTemplate(defaultCopyTemplate);

      this.setState({
        inputDefaultIsChecked: selectedInDDLCopyTemplateName === flowApp.DefaultCopyTemplate,
        flowApp
      });

      if (selectedInDDLCopyTemplateName === null) {
        setSelectedInDDLCopyTemplateName(defaultCopyTemplateName);
      }
    }

    this.selfRef.current.focus();
  }

  componentDidUpdate(prevProps) {
    if (prevProps.showModalCopyTemplate && !this.props.showModalCopyTemplate) {
      this.selfRef.current.focus();
    }
  }

  handleChangeDropDownList = event => {
    const { userSettings } = this.props;

    const flowApp = userSettings.Applications.find(app => app.AppName === FLOW_APP_NAME);
    this.props.setSelectedInDDLCopyTemplateName(event.target.value);

    this.setState({
      inputDefaultIsChecked: event.target.value === flowApp.DefaultCopyTemplate
    });
  };

  handleChangeCheckboxCopyModule = () => {
    const { inputDefaultIsChecked, copyTemplateList } = this.state;
    const { selectedInDDLCopyTemplateName } = this.props;

    if (copyTemplateList.length > 1) {
      if (!inputDefaultIsChecked) {
        copyActions.updateDefaultCopyTemplate({ selectedInDDLCopyTemplateName });
      }
      this.setState({ inputDefaultIsChecked: !inputDefaultIsChecked });
    }
  };

  setCurrentCopyTemplateName = currentCopyTemplateName =>
    this.setState({ currentCopyTemplateName: currentCopyTemplateName });

  setCopyTemplateList = copyTemplateList => this.setState({ copyTemplateList: copyTemplateList });

  setCopyTemplate = copyTemplate => this.setState({ currentCopyTemplate: copyTemplate });

  handleKeyPress = event => {
    const { handleExportToClipboard, handleCopyModuleClose } = this.props;
    const { keyCode } = event;
    const { ENTER, ESC, UP, DOWN } = KEYS;

    event.stopPropagation();
    if (keyCode === ENTER) {
      event.preventDefault();
      handleExportToClipboard();
      handleCopyModuleClose();
    } else if (keyCode === ESC) {
      event.preventDefault();
      handleCopyModuleClose();
    } else if (keyCode === UP || keyCode === DOWN) {
      this.selectRef.current.focus();
    }
  };

  render() {
    const { inputDefaultIsChecked, copyTemplateList } = this.state;
    const {
      handleClickOpenModalCopyTemplate,
      selectedInDDLCopyTemplateName,
      isFetchingData,
      handleExportToClipboard,
      showTooltipCopy
    } = this.props;

    return (
      <div
        id="main_copy-module"
        className={styles['copyModule']}
        onKeyDown={this.handleKeyPress}
        tabIndex="1"
        ref={this.selfRef}
      >
        <div className={styles['copyModule__rows']}>
          <div className={styles['copyModule__cols']}>
            <span>Select Copy Template</span>
          </div>
          <div className={styles['copyModule__cols']}>
            <IconButton handleClick={() => handleClickOpenModalCopyTemplate(false)} title="Template Settings">
              <SettingsIcon />
            </IconButton>
          </div>
        </div>
        <div className={styles['copyModule__rows']}>
          <select
            ref={this.selectRef}
            className={styles['dropdown']}
            onChange={this.handleChangeDropDownList}
            value={selectedInDDLCopyTemplateName}
          >
            {copyTemplateList.length > 0 &&
              copyTemplateList.map((copyTemplate, index) => {
                return (
                  <option
                    key={`key_copytemplist_${copyTemplate.CopyTemplateName}_${index}`}
                    className={styles['option']}
                    value={copyTemplate.CopyTemplateName}
                  >
                    {copyTemplate.CopyTemplateName}
                  </option>
                );
              })}
          </select>
        </div>
        <div className={styles['copyModule__rows']}></div>
        <div className={styles['copyModule__rows']}>
          <div className={styles['copyModule__cols']}>
            {inputDefaultIsChecked && <div className={styles['block-set-default']}></div>}
            <label className={styles['copy-module-checkbox-container']}>
              Set Default
              <input type="checkbox" onChange={this.handleChangeCheckboxCopyModule} checked={inputDefaultIsChecked} />
              <span className={styles['copy-module-checkbox-checkmark']}></span>
            </label>
          </div>
          <div className={styles['copyModule__cols']}>
            <div className={showTooltipCopy ? styles['copyModule__copytooltip'] : null}>
              <button
                className={styles['copy-button']}
                onClick={() => handleExportToClipboard()}
                disabled={isFetchingData || showTooltipCopy}
              >
                Copy
              </button>
              <span className={styles['copyModule__copytooltip__text']}>
                Number of rows exceeds limit ({EXPORT_COPY_LIMIT} rows).<br></br>Please refine selection
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CopyModule;
