import React from 'react';
import { render, cleanup, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import ModalSaveView from './ModalSaveView';

// Unmount everything from the dom after each test
afterEach(cleanup);

const modalSaveViewProps = {
  isEditing: false,
  editingView: false,
  fromColumnPicker: false,
  currentView: '',
  handleClickOpenModalSaveView: jest.fn(),
  handleClickOpenModalSaveViewOverModal: jest.fn(),
  handleOnCloseApplication: jest.fn(),
  handleOnSwitchBlotter: jest.fn(),
  userSettings: {
    Applications: []
  },
  currentFinUser: {},
  columnOrderFromGrid: [],
  columnOrderFromView: [],
  forceClosing: false,
  setFilterList: jest.fn(),
  filterList: [],
  columnState: [],
  showModalSaveViewOverModal: false,
  switchingBlotterApp: false
};

describe('<ModalSaveView />', () => {
  test('renders ModalSaveView', () => {
    const { getByTestId } = render(<ModalSaveView {...modalSaveViewProps} />);
    const component = getByTestId('ModalSaveView');

    expect(component).toBeInTheDocument();
  });
});
