import React, { Component } from 'react';
import { FLOW_APP_NAME } from '~helpers/globals';
import * as settingsService from '~services/settingsService';
import './ModalSaveView.scss';
import { KEYS } from '~helpers/keyCodes';
import { IconButton } from '~ui-library';
import { ReactComponent as CloseIcon } from '~assets/icon/nav/close.svg';
import { viewsActions } from '~helpers/actionCreator';

class ModalSaveView extends Component {
  state = {
    currentViewName: '',
    typedViewName: '',
    defaultView: '',
    disableInput: false,
    editingView: '',
    errorViewReadOnly: false,
    inputDefaultIsChecked: false,
    readOnlyView: '',
    viewAlreadyExists: false,
    viewList: [],
    isTheSameView: false,
    isSavingNewView: false,
    isSavingView: false,
    isDeletingView: false,
    flowApp: {}
  };

  componentDidMount() {
    const { userSettings, currentView, editingView, isEditing } = this.props;
    const defaultView = settingsService.getDefaultViewName(userSettings, FLOW_APP_NAME);
    const readOnlyView = settingsService.getReadOnlyViewName(userSettings, FLOW_APP_NAME);
    const viewList = settingsService.getViewsList(userSettings, FLOW_APP_NAME);
    const flowApp = userSettings.Applications.find(app => app.AppName === FLOW_APP_NAME);

    this.setState(
      {
        currentViewName: isEditing ? editingView : currentView,
        typedViewName: isEditing ? editingView : currentView,
        viewAlreadyExists: true,
        readOnlyView,
        defaultView,
        viewList,
        flowApp
      },
      () => {
        this.setState({
          inputDefaultIsChecked: defaultView === this.state.currentViewName,
          errorViewReadOnly: readOnlyView === this.state.currentViewName,
          isTheSameView: this.state.typedViewName === this.state.currentViewName
        });
      }
    );
  }

  handleChangeTxtSaveView(event) {
    this.setState({ typedViewName: event.target.value }, () => {
      this.checkViewNameAvailability(this.state.typedViewName);
    });
  }

  checkViewNameAvailability = typedViewName => {
    const { handleClickOpenModalSaveView } = this.props;
    const { readOnlyView, viewList, currentViewName } = this.state;

    this.setState({
      isTheSameView: typedViewName === currentViewName
    });

    if (viewList) {
      const findViewFromList = viewList.filter(view => view.ViewName === typedViewName);

      this.setState({
        viewAlreadyExists: findViewFromList.length > 0,
        errorViewReadOnly: typedViewName === readOnlyView
      });
    } else {
      handleClickOpenModalSaveView(false);
    }
  };

  getResultView = () => {
    const { columnOrderFromGrid, columnOrderFromView, columnState, filterList, sortList } = this.props;
    const { typedViewName } = this.state;

    const columnsOrder = columnOrderFromGrid.length > 0 ? columnOrderFromGrid : columnOrderFromView;
    const resultView = settingsService.getNewView(typedViewName, columnsOrder, filterList, columnState, sortList);

    return resultView;
  };

  handleDelete = () => {
    const { editingView } = this.props;
    const { defaultView, readOnlyView } = this.state;

    this.setState({ isDeletingView: true }, () => {
      viewsActions.delete({
        editingView,
        defaultView,
        readOnlyView
      });
    });
  };

  handleSave = ({ saveAsNew }) => {
    const { inputDefaultIsChecked, typedViewName, currentViewName, defaultView } = this.state;
    const { isEditing, fromColumnPicker, switchingBlotterApp, forceClosing } = this.props;

    this.setState({ isSavingNewView: true }, () => {
      const resultView = this.getResultView();
      const payload = {
        resultView,
        inputDefaultIsChecked,
        typedViewName,
        fromColumnPicker,
        switchingBlotterApp,
        forceClosing,
        reload: !forceClosing && !switchingBlotterApp
      };

      if (saveAsNew) {
        viewsActions.create(payload);
      } else {
        viewsActions.update({
          ...payload,
          currentViewName,
          defaultView,
          isEditing
        });
      }
    });
  };

  handleKeyPress = event => {
    event.stopPropagation();
    if (event.keyCode === KEYS.ENTER) {
      event.preventDefault();
      if (!this.saveButtonDisabled()) {
        this.handleSave({ saveAsNew: false });
      } else if (!this.saveAsNewButtonDisabled()) {
        this.handleSave({ saveAsNew: true });
      }
    } else if (event.keyCode === KEYS.ESC) {
      event.preventDefault();
      this.handleCloseIconClick();
    }
  };

  saveAsNewButtonDisabled = () => {
    const { viewAlreadyExists, errorViewReadOnly, typedViewName, isSavingNewView } = this.state;

    return !typedViewName.length || errorViewReadOnly || viewAlreadyExists || isSavingNewView;
  };

  saveButtonDisabled = () => {
    const { isEditing } = this.props;
    const { typedViewName, errorViewReadOnly, viewAlreadyExists, isTheSameView, isSavingView } = this.state;

    return (
      !typedViewName.length ||
      errorViewReadOnly ||
      (isEditing && !isTheSameView && viewAlreadyExists) ||
      (!isEditing && !isTheSameView && viewAlreadyExists) ||
      (!isEditing && !viewAlreadyExists) ||
      isSavingView
    );
  };

  disableDelete = () => {
    const { isEditing } = this.props;
    const { errorViewReadOnly, currentViewName, disableInput } = this.state;

    return errorViewReadOnly && currentViewName && isEditing && !disableInput;
  };

  handleCloseIconClick = () => {
    const {
      closeIconClick,
      showModalSaveViewOverModal,
      handleClickOpenModalSaveView,
      handleClickOpenModalSaveViewOverModal
    } = this.props;
    closeIconClick && closeIconClick();

    showModalSaveViewOverModal ? handleClickOpenModalSaveViewOverModal(false) : handleClickOpenModalSaveView(false);
  };

  render() {
    const {
      forceClosing,
      isEditing,
      handleOnCloseApplication,
      switchingBlotterApp,
      handleOnSwitchBlotter
    } = this.props;
    const {
      inputDefaultIsChecked,
      errorViewReadOnly,
      disableInput,
      viewAlreadyExists,
      currentViewName,
      typedViewName,
      isTheSameView,
      isSavingView,
      isSavingNewView,
      isDeletingView
    } = this.state;

    return (
      <div
        data-testid="ModalSaveView"
        className="save-modal-display-on"
        tabIndex="0"
        onKeyDown={this.handleKeyPress}
        role="textbox"
      >
        <div className={!forceClosing && !switchingBlotterApp ? 'save-modal' : 'save-modal-closing'}>
          {!forceClosing && !switchingBlotterApp && (
            <header className="save-modal__header">
              <span>{isEditing ? 'Edit' : 'Save'} View</span>
              <div className="save-modal__actions">
                <IconButton colorScheme="transparent" handleClick={this.handleCloseIconClick} title="Close">
                  <CloseIcon />
                </IconButton>
              </div>
            </header>
          )}
          <div className={!forceClosing || !switchingBlotterApp ? 'save-modal-body' : 'save-modal-body__closing'}>
            {!isEditing && viewAlreadyExists && !errorViewReadOnly && !isTheSameView && (
              <div className="save-modal-error-message">
                <span>This name already exists as a saved view. Please enter a new name or edit the exising one</span>
              </div>
            )}
            {!isEditing && errorViewReadOnly && (
              <div className="save-modal-error-message">
                <span>The selected view is read only and cannot be overriden. Please save as new view.</span>
              </div>
            )}
            {isEditing && errorViewReadOnly && currentViewName && !disableInput && (
              <div className="save-modal-error-message">
                <span>The selected view is read only and cannot be overriden. Please try another name.</span>
              </div>
            )}
            {isEditing && !errorViewReadOnly && viewAlreadyExists && !isTheSameView && (
              <div className="save-modal-error-message">
                <span>This name already exists as a saved view. Please try another name.</span>
              </div>
            )}

            {(forceClosing || switchingBlotterApp) && (
              <div className="save-modal-label-closing">
                <span>Changes were made to:</span>
              </div>
            )}
            <div className="save-modal-row">
              <input
                type="text"
                autoFocus={true}
                className="save-modal-textbox"
                id="txtSaveModal_ViewName"
                autoComplete="false"
                onChange={e => this.handleChangeTxtSaveView(e)}
                value={typedViewName}
                disabled={disableInput}
              />
            </div>
            {(forceClosing || switchingBlotterApp) && (
              <div className="save-modal-label-closing__extra">
                <span>Before leaving, would you like to:</span>
              </div>
            )}
            {!forceClosing && !switchingBlotterApp && (
              <div className="save-modal-row">
                <div className="save-modal-cols">
                  <label className="save-modal-checkbox-container">
                    Set Default
                    <input
                      type="checkbox"
                      onChange={() => this.setState({ inputDefaultIsChecked: !inputDefaultIsChecked })}
                      checked={inputDefaultIsChecked}
                      disabled={this.disableDelete()}
                    />
                    <span className="save-modal-checkbox-checkmark"></span>
                  </label>
                </div>

                <div className="save-modal-cols">
                  {!disableInput && isEditing && (
                    <button
                      disabled={this.disableDelete() || isDeletingView}
                      className="save-modal-save-buttons save-modal-save-buttons--delete"
                      onClick={this.handleDelete}
                    >
                      {isDeletingView ? 'Deleting..' : 'Delete'}
                    </button>
                  )}
                  {!isEditing && (
                    <button
                      className="save-modal-save-buttons"
                      onClick={this.handleSave.bind(this, { saveAsNew: true })}
                      disabled={this.saveAsNewButtonDisabled()}
                    >
                      {isSavingNewView ? 'Saving...' : 'Save as New'}
                    </button>
                  )}
                  <button
                    className="save-modal-save-buttons"
                    onClick={this.handleSave.bind(this, { saveAsNew: false })}
                    disabled={this.saveButtonDisabled()}
                  >
                    {isSavingView ? 'Saving...' : 'Save'}
                  </button>
                </div>
              </div>
            )}
            {(forceClosing || switchingBlotterApp) && (
              <header className="save-modal__footer">
                <div className="save-modal-cols">
                  <button
                    className="save-modal-save-buttons-discard"
                    onClick={switchingBlotterApp ? handleOnSwitchBlotter : handleOnCloseApplication}
                  >
                    Discard Changes
                  </button>
                </div>

                <div className="save-modal-cols">
                  <button
                    className="save-modal-save-buttons-closing"
                    onClick={this.handleSave.bind(this, { saveAsNew: true })}
                    disabled={this.saveAsNewButtonDisabled()}
                  >
                    {isSavingNewView ? 'Saving...' : 'Save As'}
                  </button>
                  <button
                    className="save-modal-save-buttons-closing"
                    onClick={this.handleSave.bind(this, { saveAsNew: false })}
                    disabled={viewAlreadyExists && !errorViewReadOnly ? false : true}
                  >
                    {isSavingView ? 'Saving...' : 'Save'}
                  </button>
                </div>
              </header>
            )}
          </div>
        </div>
      </div>
    );
  }
}

export default ModalSaveView;
