import React, { Component, Fragment } from 'react';
import styles from './FlowGridHeader.module.scss';
import { CopyModule, ClickOutsideWrapper, ExcelExportDropdown } from '~components';
import { EXPORT_COPY_LIMIT, EXPORT_EXCEL_LIMIT, FLOW_APP_NAME, recordTypes } from '~helpers/globals';
import { usageService, ACTION_COPY, ACTION_SAVE, ACTION_QUICK_FILTER } from '~services/usageService';
import { EXPORT_BATCH_SIZE } from '~helpers/exportHelper';
import { COLUMNS } from '~helpers/columnStyles';
import { exportDataSourceService } from '~services/exportDataSourceService';
import { logger } from '~helpers/logger';
import IconButton from '../../ui-library/Buttons/IconButton';
import { ReactComponent as CopyIcon } from '~assets/icon/util/clipboard.svg';
import { ReactComponent as ChevrondownIcon } from '~assets/icon/nav/chevrondown.svg';
import TextButton from '../../ui-library/Buttons/TextButton';

class FlowGridHeader extends Component {
  state = {
    isCopyModuleVisible: false,
    isFetchingData: false,
    showTooltipCopy: false,
    showTooltipExcel: false,
    processedRecord: 0,
    totalRecords: 0
  };

  componentDidUpdate(prevProps) {
    if (prevProps.selectedRows !== this.props.selectedRows) {
      this.showExceedLimitCopy();
      this.showExceedLimitExcel();
      const processedRecord =
        this.props.selectedRows > EXPORT_BATCH_SIZE ? EXPORT_BATCH_SIZE : parseInt(this.props.selectedRows);
      this.setState({ processedRecord });
    }
  }

  componentDidMount() {
    const { processedRecordSubject$ } = this.props;
    this.fechingStatusSubscriber = exportDataSourceService.exportFetching$.subscribe(isFetching => {
      this.setState({ isFetchingData: isFetching, processedRecord: 0 });
    });

    this.processedRecordSubscriber = processedRecordSubject$.subscribe(({ processedRecord, totalRecords }) => {
      this.setState({ processedRecord, totalRecords });
    });
  }

  componentWillUnmount() {
    this.fechingStatusSubscriber.unsubscribe();
    this.processedRecordSubscriber.unsubscribe();
  }

  handleClickCopyDropdown = () => {
    const { isCopyModuleVisible } = this.state;
    if (!isCopyModuleVisible) {
      this.setState({ isCopyModuleVisible: true });
    }
  };

  closeCallback = () => {
    const { isCopyModuleVisible } = this.state;
    if (isCopyModuleVisible) {
      this.setState({ isCopyModuleVisible: false });
    }
  };

  onClickHandler = value => {
    const { onClickHandler, currentFinUser } = this.props;

    const payload = usageService.getPayload(currentFinUser, ACTION_QUICK_FILTER, FLOW_APP_NAME, {
      Tab: value
    });
    usageService.sendUsage(payload);

    onClickHandler && onClickHandler(value);
  };

  handleExportToExcel = fetchTrrigger => {
    logger.log(`Excel Export > User pressed the 'export to excel' button`);
    const { isFetchingData, showTooltipExcel } = this.state;
    if (isFetchingData || showTooltipExcel) return;

    const { exportToExcel, selectedRows, currentFinUser } = this.props;

    const payload = usageService.getPayload(currentFinUser, ACTION_SAVE, FLOW_APP_NAME, {
      AppName: FLOW_APP_NAME,
      Application: 'Excel',
      RecordCount: selectedRows
    });
    usageService.sendUsage(payload);
    this.setState({ isFetchingData: true });
    exportToExcel && exportToExcel(fetchTrrigger);
  };

  handleExportToClipboard = () => {
    const { isFetchingData, showTooltipCopy } = this.state;
    if (isFetchingData || showTooltipCopy) return;

    const { exportToClipboard, selectedRows, currentFinUser } = this.props;

    const payload = usageService.getPayload(currentFinUser, ACTION_COPY, FLOW_APP_NAME, {
      AppName: FLOW_APP_NAME,
      RecordCount: selectedRows
    });
    usageService.sendUsage(payload);
    this.setState({ isFetchingData: true });
    exportToClipboard && exportToClipboard();
  };

  showExceedLimitCopy = () => {
    const { selectedRows } = this.props;
    const { showTooltipCopy } = this.state;
    if (parseInt(selectedRows) > parseInt(EXPORT_COPY_LIMIT) && showTooltipCopy === false) {
      this.setState({
        showTooltipCopy: true
      });
    }

    if (parseInt(selectedRows) <= parseInt(EXPORT_COPY_LIMIT) && showTooltipCopy === true) {
      this.setState({
        showTooltipCopy: false
      });
    }
  };

  showExceedLimitExcel = () => {
    const { selectedRows } = this.props;
    const { showTooltipExcel } = this.state;
    if (parseInt(selectedRows) > parseInt(EXPORT_EXCEL_LIMIT) && showTooltipExcel === false) {
      this.setState({
        showTooltipExcel: true
      });
    }

    if (parseInt(selectedRows) <= parseInt(EXPORT_EXCEL_LIMIT) && showTooltipExcel === true) {
      this.setState({
        showTooltipExcel: false
      });
    }
  };

  handleOnClickCoverage = () => {
    const { onClickCoverage } = this.props;
    onClickCoverage && onClickCoverage();
  };

  handleOnClickMyDesk = () => {
    const { onClickDesk } = this.props;
    onClickDesk && onClickDesk();
  };

  isButtonActive = recordTypeFilter => {
    let active = false;
    const recordTypeFilterList = this.props.filterList.find(element => element.field === COLUMNS.SOURCE);

    if (recordTypeFilter === recordTypes.ALL && !recordTypeFilterList) {
      active = true;
    } else {
      active = recordTypeFilterList?.filter.includes(recordTypeFilter);
    }

    return active;
  };

  handleCopyModuleClose = () => {
    this.setState({ isCopyModuleVisible: false });
  };

  render() {
    const { isCopyModuleVisible, isFetchingData, showTooltipCopy, showTooltipExcel } = this.state;
    const {
      displayCopyExcel,
      handleClickOpenModalCopyTemplate,
      showModalCopyTemplate,
      userSettings,
      setSelectedInDDLCopyTemplateName,
      selectedInDDLCopyTemplateName,
      TogglesSection,
      FilterBarSection,
      ViewsSection,
      TradingDeskCoverageChoicesSection,
      SaveButtonSection
    } = this.props;

    return (
      <div className="FlowGridHeader">
        <nav>
          <div className={styles['header-buttons']}>
            <div className={styles['header-action-buttons']}>
              {displayCopyExcel && (
                <Fragment>
                  <div className={styles['header-action-button']}>
                    <div className={showTooltipCopy ? styles['header-action-buttons__copytooltip'] : null}>
                      <IconButton
                        disabled={isFetchingData || showTooltipCopy}
                        handleClick={this.handleExportToClipboard}
                        title="Copy to clipboard"
                        size="large"
                        disabledExtremeStyle
                      >
                        <CopyIcon />
                      </IconButton>
                      <span className={styles['header-action-buttons__copytooltip__text']}>
                        Number of rows exceeds limit ({EXPORT_COPY_LIMIT} rows).<br></br>Please refine selection
                      </span>
                    </div>
                    <IconButton handleClick={this.handleClickCopyDropdown} size="tiny" disabled={isCopyModuleVisible}>
                      <ChevrondownIcon />
                    </IconButton>
                  </div>
                  <div className={styles['header-action-button']}>
                    <ExcelExportDropdown
                      isFetchingData={isFetchingData}
                      handleExportToExcel={this.handleExportToExcel}
                      showTooltipExcel={showTooltipExcel}
                    />
                  </div>
                </Fragment>
              )}
            </div>

            <ClickOutsideWrapper open={isCopyModuleVisible} closeCallback={this.closeCallback}>
              <CopyModule
                userSettings={userSettings}
                handleClickOpenModalCopyTemplate={handleClickOpenModalCopyTemplate}
                setSelectedInDDLCopyTemplateName={setSelectedInDDLCopyTemplateName}
                selectedInDDLCopyTemplateName={selectedInDDLCopyTemplateName}
                showModalCopyTemplate={showModalCopyTemplate}
                handleExportToClipboard={this.handleExportToClipboard}
                handleCopyModuleClose={this.handleCopyModuleClose}
                isFetchingData={isFetchingData}
                showTooltipCopy={showTooltipCopy}
              />
            </ClickOutsideWrapper>

            <div className={styles['header-link-buttons']}>
              <TextButton
                active={this.isButtonActive(recordTypes.ALL)}
                handleClick={() => {
                  this.onClickHandler(recordTypes.ALL);
                }}
                colorScheme="secondary"
                fit="narrowWidth"
              >
                ALL
              </TextButton>
              <TextButton
                active={this.isButtonActive(recordTypes.RFQ)}
                handleClick={() => {
                  this.onClickHandler(recordTypes.RFQ);
                }}
                colorScheme="secondary"
                fit="narrowWidth"
              >
                RFQ
              </TextButton>
              <TextButton
                active={this.isButtonActive(recordTypes.TRADE)}
                handleClick={() => {
                  this.onClickHandler(recordTypes.TRADE);
                }}
                colorScheme="secondary"
                fit="narrowWidth"
              >
                Trades
              </TextButton>
              <TextButton
                active={this.isButtonActive(recordTypes.INQUIRY)}
                handleClick={() => {
                  this.onClickHandler(recordTypes.INQUIRY);
                }}
                colorScheme="secondary"
                fit="narrowWidth"
              >
                Inquiries
              </TextButton>
            </div>
          </div>

          <div className={styles['header-save-toggle-buttons']}>
            {SaveButtonSection}
            {ViewsSection}
            <div>{TradingDeskCoverageChoicesSection}</div>
            <div className={styles['header-toggle-box']}>{TogglesSection}</div>
          </div>
        </nav>
        {FilterBarSection}
      </div>
    );
  }
}

export default FlowGridHeader;
