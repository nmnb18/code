import React, { Component } from 'react';
import { getSort, SORT_ASC, SORT_DESC } from '~helpers/sort';
import { TriangleIcon } from '~components/common';
import filterIcon from '~assets/icon/util/filter.svg';
import menuIcon from '~assets/icon/util/menu.svg';
import styles from './CustomAgGridHeaderLabelFilter.module.scss';

class CustomAgGridHeaderFilter extends Component {
  constructor(props) {
    super(props);

    this.state = {
      sort: null,
      isFilterActive: false
    };

    props.column.addEventListener('sortChanged', this.onSortChanged);
    props.column.addEventListener('filterChanged', this.onFilterChanged);
  }

  componentDidMount() {
    const {
      column: { sort }
    } = this.props;
    if (sort) {
      this.onSortChanged();
    }
  }

  componentWillUnmount() {
    this.props.column.removeEventListener('sortChanged', this.onSortChanged);
    this.props.column.removeEventListener('filterChanged', this.onFilterChanged);
  }

  getReactContainerClasses() {
    return ['custom-header-text-box-filter'];
  }

  onFilterChanged = () => {
    const { column } = this.props;
    const isFilterActive = column.isFilterActive();
    const sort = getSort(column);

    this.setState({ isFilterActive, sort });
  };

  onSortChanged = () => {
    this.forceUpdate();
  };

  renderSortingIcon = () => {
    const { sort } = this.state;
    const { column } = this.props;
    const sortDir = sort || column.sort;
    if (sortDir === SORT_DESC) {
      return <TriangleIcon small />;
    } else if (sortDir === SORT_ASC) {
      return <TriangleIcon small inverted />;
    } else {
      return null;
    }
  };

  renderFilteringIcon = () => {
    const { isFilterActive } = this.state;
    return isFilterActive ? <img className="filter-icon" src={filterIcon} alt="Active Filter" /> : null;
  };

  renderMenuButton = () => (
    <div
      className="menu-button"
      role="button"
      tabIndex="0"
      ref={ref => (this.menuButton = ref)}
      onKeyPress={() => this.props.showColumnMenu(this.menuButton)}
      onClick={() => this.props.showColumnMenu(this.menuButton)}
    >
      <img className="menu-icon" src={menuIcon} alt="Menu" />
    </div>
  );

  render() {
    const { displayName } = this.props;

    return (
      <div className={styles['header-label-filter']}>
        <div className={styles['header-label-filter__wrapper-textbox']}>
          {displayName}
          {this.renderFilteringIcon()}
          {this.renderSortingIcon()}
        </div>
        <div className={styles['header-label-filter__wrapper-options']}>{this.renderMenuButton()}</div>
      </div>
    );
  }
}

export default CustomAgGridHeaderFilter;
