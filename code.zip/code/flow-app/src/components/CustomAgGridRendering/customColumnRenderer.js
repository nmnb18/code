import { isClientNameColum, isAxeSideColum, isPriorityAxeColum, isHistAxeSideColum } from '~helpers/columnStyles';
import { getLiveAxeContent, getPriorityAxeContent, getHistAxeContent } from '~helpers/columnRenderer';

export default function customColumnRenderer() {}

customColumnRenderer.prototype.init = function(params) {
  this.eGui = document.createElement('div');
  const { colDef, value, data } = params;
  const { field } = colDef;

  if (value || (isClientNameColum(field) && !value)) {
    if (isAxeSideColum(field)) {
      const { axeside, axematch } = data;
      this.eGui.innerHTML = getLiveAxeContent(axeside, axematch);
      return;
    } else if (isHistAxeSideColum(field)) {
      const { histaxeside, axematch } = data;
      this.eGui.innerHTML = getHistAxeContent(histaxeside, axematch);
      return;
    } else if (isPriorityAxeColum(field)) {
      const { priorityaxe } = data;
      this.eGui.innerHTML = getPriorityAxeContent(priorityaxe);
      return;
    } else {
      this.eGui.innerHTML = `<div class='btn-with-hyperlink'><span>${value || ''}</span></div>`;
      return;
    }
  } else {
    this.eGui.innerHTML = `<span></span>`;
    return;
  }
};

customColumnRenderer.prototype.getGui = function() {
  return this.eGui;
};

customColumnRenderer.prototype.refresh = function(params) {
  if (this.eValue) {
    this.eValue.innerHTML = params.valueFormatted ? params.valueFormatted : params.value;
  }
  return true;
};

customColumnRenderer.prototype.destroy = function() {
  this.eventListener && this.eValue.removeEventListener('click', this.eventListener);
};
