import React from 'react';
import styles from './SortingMenu.module.scss';

import { ReactComponent as RemoveSortIcon } from '~assets/icon/util/dismissSort.svg';
import { ReactComponent as SortAscIcon } from '~assets/icon/util/sort-asc.svg';
import { ReactComponent as SortDescIcon } from '~assets/icon/util/sort-desc.svg';

const SortingItem = ({ selected, itemType, setDirection }) => {
  const itemConfig = {
    SORT_ASC: {
      icon: <SortAscIcon />,
      description: 'Sort Ascending'
    },
    SORT_DESC: {
      icon: <SortDescIcon />,
      description: 'Sort Descending'
    },
    SORT_NONE: {
      icon: <RemoveSortIcon />,
      description: 'Remove Sort'
    }
  }[itemType];
  const className = `${styles['sorting-menu__item']} ${selected ? styles['sorting-menu__item--selected'] : ''}`;

  return (
    <button type="button" className={className} onClick={setDirection}>
      {itemConfig.icon}
      <p>{itemConfig.description}</p>
    </button>
  );
};

export default SortingItem;
