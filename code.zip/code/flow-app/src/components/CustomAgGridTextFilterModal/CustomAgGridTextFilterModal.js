import React, { useEffect, useState } from 'react';
import { getColumnFilterValue } from '~helpers/filters';
import styles from './CustomAgGridTextFilterModal.module.scss';
import { KEYS } from '~helpers/keyCodes';

const CustomAgGridTextFilterModal = ({ onFilterChange, sortingMenu, column, api }) => {
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    const onFilterChanged = () => {
      const filters = api.getFilterModel();
      const filter = getColumnFilterValue(column, filters);

      setSearchText(filter);
    };

    column.addEventListener('filterChanged', onFilterChanged);
    return () => column.removeEventListener('filterChanged', onFilterChanged);
  }, [column, api]);

  // Function called when you click "Clear" button
  const handleClear = () => {
    setSearchText('');
    onFilterChange('');
  };

  // Function called when you click "Apply" button
  const handleApply = () => {
    onFilterChange(searchText);
  };

  const handleKeyDown = event => {
    if (event.keyCode === KEYS.ENTER) {
      event.preventDefault();
      handleApply();
    }
  };

  return (
    <div className={styles['text-filter-modal']}>
      {sortingMenu}
      <div className={styles['text-filter-modal__wrapper-textbox']}>
        <input
          className={styles['text-filter-modal__textbox']}
          type="text"
          placeholder="Search..."
          value={searchText}
          onChange={e => setSearchText(e.target.value)}
          onKeyDown={handleKeyDown}
        />
      </div>
      <footer className={styles['text-filter-modal__footer']}>
        <button onClick={handleClear}>Clear Filter</button>
        <button onClick={handleApply}>Apply Filter</button>
      </footer>
      <div className={styles['text-filter-modal__footer__fix']}></div>
    </div>
  );
};

export default CustomAgGridTextFilterModal;
