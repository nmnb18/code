import React, { useState, useEffect } from 'react';
import DateRangePicker from '@wojtekmaj/react-daterange-picker';
import { format, subDays, compareAsc, isValid } from 'date-fns';
import { TriangleIcon } from '~components/common';
import {
  DATE_FORMAT,
  today,
  yesterday,
  ranges,
  START_STRING,
  END_STRING,
  TODAY_STRING,
  YESTERDAY_STRING,
  FYTD_STRING,
  getFiscalDate,
  getDifferenceInDatesByDays
} from '~helpers/dateHelper';
import { IconButton } from '~ui-library';
import { ReactComponent as CalendarIcon } from '~assets/icon/util/calendar.svg';
import styles from './Calendar.module.scss';
import '~assets/css/react-calendar.scss';

const Calendar = ({ onFilterChange, sortingMenu }) => {
  const [dates, setDates] = useState([today, today]);
  const [startDate, setStartDate] = useState(format(today, DATE_FORMAT));
  const [endDate, setEndDate] = useState(format(today, DATE_FORMAT));
  const [customRange, setCustomRange] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [isStartDateFocus, setIsStartDateFocus] = useState(false);
  const [isEndDateFocus, setIsEndDateFocus] = useState(false);

  // Function called when you change the calendar
  const handleUpdate = newDate => setDates(newDate);

  // Here are assign the final values for Start and End dates
  useEffect(() => {
    const [newStartDate, newEndDate] = dates;
    setStartDate(format(newStartDate, DATE_FORMAT));
    setEndDate(format(newEndDate, DATE_FORMAT));
  }, [dates]);

  const handleCustomDates = ({ date, type }) => {
    const alphabetRegex = /[a-z]/gi;

    if (alphabetRegex.test(date)) return;

    if (!date) {
      type === START_STRING ? setStartDate('') : setEndDate('');
    }

    type === START_STRING ? setStartDate(date) : setEndDate(date);

    if (date.length === 10 && isValid(new Date(date))) {
      const comparedDates = compareAsc(new Date(date), today);

      if (comparedDates === 1) {
        setTimeout(() => {
          type === START_STRING ? setStartDate(format(today, DATE_FORMAT)) : setEndDate(format(today, DATE_FORMAT));
        }, 50);
      }

      const dateDigits = date.replace(/[^0-9]/g, '');
      const [, month, day, year] = dateDigits.match(/(\d{2})-?(\d{2})-?(\d{4})/);
      const formattedDate = new Date(year, month - 1, day);

      if (type === START_STRING) {
        setDates([formattedDate, new Date(endDate)]);
      } else {
        setDates([new Date(startDate), formattedDate]);
      }
    }
  };

  // Function called when you click on ranges buttons
  const handleChangeDaysAgo = days => {
    let daysAgo = days;

    if (days === TODAY_STRING) {
      daysAgo = 0;
    } else if (days === YESTERDAY_STRING) {
      daysAgo = 1;
    } else if (days === FYTD_STRING) {
      daysAgo = getDifferenceInDatesByDays(getFiscalDate(today.getFullYear()), today);
    }

    const resultSubDays = subDays(today, daysAgo);

    if (days === YESTERDAY_STRING) {
      setDates([yesterday, yesterday]);
    } else {
      setDates([resultSubDays, today]);
    }
    setCustomRange(days);
  };

  const handleCustomRange = value => {
    if (isNaN(value) || value < 0) return;

    const number = value > 0 ? Number(value) : Math.abs(value);

    if (value) {
      setCustomRange(number);
    } else {
      handleClear();
    }
    value && handleChangeDaysAgo(number);
  };

  // Function called when you click "Clear" button
  const handleClear = () => {
    setDates([today, today]);
    setCustomRange('');
    onFilterChange();
  };

  // Function called when you click "Apply" button
  const handleApply = () => {
    onFilterChange(startDate, endDate, customRange);
  };

  // Function called when you click on any of the day from calendar
  const handleDayClick = value => {
    setCustomRange('');
    // set start/end date as sson as user clicks on any of the date from picker
    if (isStartDateFocus) {
      setStartDate(format(value, DATE_FORMAT));
      setIsStartDateFocus(false);
      setIsEndDateFocus(true);
    } else if (isEndDateFocus) {
      setEndDate(format(value, DATE_FORMAT));
    }
  };

  // Function called when you click on calendar icon to open date range
  const openCalendar = () => {
    setIsOpen(!isOpen);
    setIsStartDateFocus(true);
  };

  // Function called when date range pop closed
  const onCalendarClose = () => {
    setDates([new Date(startDate), new Date(endDate)]);
    setTimeout(() => {
      setIsOpen(false);
      setIsEndDateFocus(false);
      setIsStartDateFocus(false);
    }, 200);
  };

  const renderCalendarIcon = () => {
    return (
      <IconButton handleClick={openCalendar} title="Calendar" size="small">
        <CalendarIcon />
      </IconButton>
    );
  };

  return (
    <div className={styles.calendar}>
      {sortingMenu}
      <section>
        <header className={styles['calendar__header']}>
          {renderCalendarIcon()}
          <div className={`${styles['calendar__start']} ${isStartDateFocus ? styles['calendar__start--focus'] : ''}`}>
            <div>Start:</div>
            <div>
              <input
                placeholder="Start"
                onChange={e => handleCustomDates({ date: e.target.value, type: START_STRING })}
                value={startDate}
                maxLength="10"
              />
            </div>
          </div>
          <div className={`${styles['calendar__end']} ${isEndDateFocus ? styles['calendar__end--focus'] : ''}`}>
            <div>End:</div>
            <div>
              <input
                placeholder="End"
                onChange={e => handleCustomDates({ date: e.target.value, type: END_STRING })}
                value={endDate}
                maxLength="10"
              />
            </div>
          </div>
        </header>
        <div className={`${styles['calendar-wrapper']} ${isOpen ? styles['calendar-wrapper--open'] : ''}`}>
          {isOpen && (
            <DateRangePicker
              value={dates}
              maxDate={today}
              onChange={handleUpdate}
              clearIcon={null}
              calendarIcon={null}
              prevLabel={<TriangleIcon />}
              nextLabel={<TriangleIcon />}
              onClickDay={handleDayClick}
              isOpen={isOpen}
              locale="en"
              onCalendarClose={onCalendarClose}
            />
          )}
        </div>
        <div className={styles['calendar__daysAgo']}>
          <div className={styles['calendar__daysAgo__input']}>
            <input
              id="daysAgo"
              onChange={e => handleCustomRange(e.target.value)}
              value={!isNaN(customRange) ? customRange : ''}
            />
            <label htmlFor="daysAgo">days</label>
          </div>
          <div className={styles['calendar__daysAgo__buttons']}>
            {ranges.map(day => (
              <button
                key={day}
                onClick={() => handleChangeDaysAgo(day)}
                className={`${styles['calendar__daysAgo__buttons__button']} ${
                  customRange === day ? styles['calendar__daysAgo__buttons__button--active'] : ''
                }`}
              >
                {day}
              </button>
            ))}
          </div>
        </div>
      </section>
      <footer className={styles['calendar__footer']}>
        <button onClick={handleClear}>Clear</button>
        <button onClick={handleApply}>Apply</button>
      </footer>
    </div>
  );
};

export default Calendar;
